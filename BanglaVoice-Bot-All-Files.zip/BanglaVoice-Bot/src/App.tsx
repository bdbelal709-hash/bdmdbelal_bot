import {
  Bot,
  History,
  Image as ImageIcon,
  Menu,
  Mic,
  Shield,
  Video,
  Wallet,
  X,
} from 'lucide-react';
import { useCallback, useEffect, useState } from 'react';
import { AdminPanel } from './components/AdminPanel.tsx';
import { ArtworkStudio } from './components/ArtworkStudio.tsx';
import { HistoryView } from './components/HistoryView.tsx';
import { LiveProcessMonitor } from './components/LiveProcessMonitor.tsx';
import { TelegramSimulator } from './components/TelegramSimulator.tsx';
import { VideoStudio } from './components/VideoStudio.tsx';
import { VoiceStudio } from './components/VoiceStudio.tsx';
import { WalletModal } from './components/WalletModal.tsx';
import type {
  BotUser,
  DashboardStats,
  ErrorLogEntry,
  IncomingPaymentSms,
  PaymentRequest,
  PublicBotConfig,
  TransactionRecord,
  VideoProjectJob,
  VoiceGeneration,
  VoiceJob,
  VoicePersona,
} from './types.ts';

type WorkspaceTab =
  | 'telegram'
  | 'studio'
  | 'video'
  | 'history'
  | 'admin'
  | 'artwork';

const NAV_ITEMS: Array<{
  id: WorkspaceTab;
  label: string;
  labelBn: string;
  icon: typeof Bot;
}> = [
  {
    id: 'telegram',
    label: 'Telegram Bot',
    labelBn: 'টেলিগ্রাম বট',
    icon: Bot,
  },
  {
    id: 'studio',
    label: 'Voice Studio',
    labelBn: 'ভয়েস স্টুডিও',
    icon: Mic,
  },
  {
    id: 'video',
    label: 'Video Studio',
    labelBn: 'ভিডিও স্টুডিও',
    icon: Video,
  },
  {
    id: 'history',
    label: 'History',
    labelBn: 'হিস্টোরি',
    icon: History,
  },
  {
    id: 'admin',
    label: 'Admin Panel',
    labelBn: 'অ্যাডমিন প্যানেল',
    icon: Shield,
  },
  {
    id: 'artwork',
    label: 'Cover Artwork',
    labelBn: 'কভার আর্ট',
    icon: ImageIcon,
  },
];

export default function App() {
  const [activeTab, setActiveTab] = useState<WorkspaceTab>('telegram');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [walletOpen, setWalletOpen] = useState(false);

  const [voices, setVoices] = useState<VoicePersona[]>([]);
  const [users, setUsers] = useState<BotUser[]>([]);
  const [activeUserId, setActiveUserId] = useState<string>('');
  const [generations, setGenerations] = useState<VoiceGeneration[]>([]);
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [config, setConfig] = useState<PublicBotConfig | null>(null);
  const [paymentRequests, setPaymentRequests] = useState<PaymentRequest[]>([]);
  const [incomingPaymentSms, setIncomingPaymentSms] = useState<
    IncomingPaymentSms[]
  >([]);
  const [transactions, setTransactions] = useState<TransactionRecord[]>([]);
  const [jobs, setJobs] = useState<VoiceJob[]>([]);
  const [videoJobs, setVideoJobs] = useState<VideoProjectJob[]>([]);
  const [errorLogs, setErrorLogs] = useState<ErrorLogEntry[]>([]);

  const loadWorkspaceData = useCallback(async () => {
    try {
      const [voicesRes, overviewRes, historyRes] = await Promise.all([
        fetch('/api/voices'),
        fetch('/api/admin/overview'),
        fetch('/api/history?limit=100'),
      ]);

      if (voicesRes.ok) {
        const vData = (await voicesRes.json()) as { voices: VoicePersona[] };
        setVoices(vData.voices);
      }

      if (overviewRes.ok) {
        const oData = (await overviewRes.json()) as {
          stats: DashboardStats;
          users: BotUser[];
          config: PublicBotConfig;
          paymentRequests: PaymentRequest[];
          incomingPaymentSms?: IncomingPaymentSms[];
          transactions: TransactionRecord[];
          jobs: VoiceJob[];
          videoJobs?: VideoProjectJob[];
          errorLogs?: ErrorLogEntry[];
        };
        setStats(oData.stats);
        setUsers(oData.users);
        setConfig(oData.config);
        setPaymentRequests(oData.paymentRequests ?? []);
        setIncomingPaymentSms(oData.incomingPaymentSms ?? []);
        setTransactions(oData.transactions ?? []);
        setJobs(oData.jobs ?? []);
        setVideoJobs(oData.videoJobs ?? []);
        setErrorLogs(oData.errorLogs ?? []);
        setActiveUserId((prev) =>
          prev && oData.users.some((u) => u.id === prev)
            ? prev
            : (oData.users[0]?.id ?? ''),
        );
      }

      if (historyRes.ok) {
        const hData = (await historyRes.json()) as {
          generations: VoiceGeneration[];
        };
        setGenerations(hData.generations);
      }
    } catch (err) {
      console.error('Failed to hydrate workspace:', err);
    }
  }, []);

  useEffect(() => {
    void loadWorkspaceData();
  }, [loadWorkspaceData]);

  const hasActiveBackgroundWork =
    jobs.some((j) => j.status !== 'completed' && j.status !== 'failed') ||
    videoJobs.some((v) => v.status !== 'completed' && v.status !== 'failed');

  useEffect(() => {
    const intervalMs = hasActiveBackgroundWork ? 1100 : 4500;
    const id = setInterval(() => {
      void Promise.all([
        fetch('/api/jobs'),
        fetch('/api/video/jobs?limit=12'),
      ])
        .then(async ([jr, vr]) => {
          if (jr.ok) {
            const jData = (await jr.json()) as { jobs?: VoiceJob[] };
            if (jData.jobs) setJobs(jData.jobs);
          }
          if (vr.ok) {
            const vData = (await vr.json()) as { jobs?: VideoProjectJob[] };
            if (vData.jobs) setVideoJobs(vData.jobs);
          }
        })
        .catch(() => {});
    }, intervalMs);

    return () => clearInterval(id);
  }, [hasActiveBackgroundWork]);

  const activeUser = users.find((u) => u.id === activeUserId) ?? users[0];
  const currentNav = NAV_ITEMS.find((n) => n.id === activeTab) ?? NAV_ITEMS[0];

  const handleSelectTab = (tab: WorkspaceTab) => {
    setActiveTab(tab);
    setMobileMenuOpen(false);
  };

  return (
    <div className="flex min-h-screen bg-slate-50 text-slate-900">
      {/* Desktop Sidebar (240px) */}
      <aside className="hidden w-60 shrink-0 flex-col border-r border-slate-200 bg-white lg:flex">
        <div className="flex h-16 items-center border-b border-slate-200 px-6">
          <span className="font-display text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0">
            BanglaVoice
          </span>
        </div>

        <nav className="flex-1 space-y-1 p-4" aria-label="Primary Sidebar">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleSelectTab(item.id)}
                className={`flex w-full items-center gap-3 rounded-lg px-3.5 py-2.5 text-left text-sm font-medium transition-colors whitespace-nowrap shrink-0 ${
                  isActive
                    ? 'bg-teal-50 text-teal-900'
                    : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                }`}
              >
                <Icon
                  className={`h-4 w-4 shrink-0 ${
                    isActive ? 'text-teal-700' : 'text-slate-400'
                  }`}
                />
                <span>{item.labelBn}</span>
              </button>
            );
          })}
        </nav>

        <div className="border-t border-slate-200 p-4 text-xs text-slate-500">
          <div className="font-medium text-slate-700">
            {config?.telegramMode === 'polling' && config.telegramBotUsername
              ? `@${config.telegramBotUsername}`
              : 'Telegram Simulator Ready'}
          </div>
          <div className="mt-1 font-mono text-[11px] tabular-nums">
            মোট ভয়েস: {stats?.totalVoicesGenerated ?? 0} · ইউজার: {stats?.totalUsers ?? 0}
          </div>
        </div>
      </aside>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 flex lg:hidden">
          <div
            className="fixed inset-0 bg-slate-900/40"
            onClick={() => setMobileMenuOpen(false)}
          />
          <aside className="relative z-10 flex w-64 flex-col bg-white p-4 shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-200 pb-3">
              <span className="font-display text-lg font-bold text-slate-900">
                BanglaVoice
              </span>
              <button
                type="button"
                onClick={() => setMobileMenuOpen(false)}
                aria-label="Close navigation menu"
                className="flex h-9 w-9 items-center justify-center rounded-lg text-slate-600 hover:bg-slate-100"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <nav className="mt-4 space-y-1">
              {NAV_ITEMS.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => handleSelectTab(item.id)}
                    className={`flex w-full items-center gap-3 rounded-lg px-3.5 py-2.5 text-left text-sm font-medium ${
                      isActive
                        ? 'bg-teal-50 text-teal-900'
                        : 'text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <Icon className="h-4 w-4 shrink-0" />
                    <span>{item.labelBn}</span>
                  </button>
                );
              })}
            </nav>
          </aside>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="flex h-16 items-center justify-between gap-8 border-b border-slate-200 bg-white px-6">
          <div className="flex items-center gap-3 min-w-0">
            <button
              type="button"
              onClick={() => setMobileMenuOpen(true)}
              aria-label="Open navigation menu"
              className="flex h-9 w-9 items-center justify-center rounded-lg border border-slate-200 text-slate-700 lg:hidden"
            >
              <Menu className="h-4 w-4" />
            </button>
            <h1 className="truncate text-sm font-semibold text-slate-900">
              BanglaVoice / {currentNav.label}
            </h1>
          </div>

          <nav className="hidden items-center gap-6 text-xs font-medium text-slate-600 md:flex">
            {NAV_ITEMS.slice(0, 4).map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => handleSelectTab(item.id)}
                className={`transition-colors whitespace-nowrap shrink-0 ${
                  activeTab === item.id
                    ? 'text-teal-700 underline underline-offset-4'
                    : 'hover:text-slate-900'
                }`}
              >
                {item.label}
              </button>
            ))}
          </nav>

          <div className="flex shrink-0 items-center gap-2.5">
            {activeUser && (
              <button
                type="button"
                onClick={() => setWalletOpen(true)}
                className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs font-medium text-slate-800 transition-colors hover:bg-slate-100 whitespace-nowrap shrink-0"
              >
                <Wallet className="h-3.5 w-3.5 text-teal-700" />
                <span className="font-mono tabular-nums">
                  ৳{activeUser.balance.toFixed(0)}
                </span>
                <span className="text-teal-700">· রিচার্জ</span>
              </button>
            )}
            <button
              type="button"
              onClick={() =>
                handleSelectTab(activeTab === 'studio' ? 'telegram' : 'studio')
              }
              className="h-9 rounded-lg bg-teal-700 px-4 text-xs font-medium text-white transition-colors hover:bg-teal-800 whitespace-nowrap shrink-0"
            >
              {activeTab === 'studio' ? 'টেলিগ্রাম বট খুলুন' : 'নতুন ভয়েস তৈরি'}
            </button>
          </div>
        </header>

        <main className="mx-auto w-full max-w-[1200px] flex-1 p-6">
          <LiveProcessMonitor
            voiceJobs={jobs}
            videoJobs={videoJobs}
            onNavigate={(tab) => handleSelectTab(tab)}
          />

          {activeTab === 'telegram' && (
            <TelegramSimulator
              users={users}
              activeUserId={activeUserId}
              onSelectUser={setActiveUserId}
              onDataChanged={() => void loadWorkspaceData()}
            />
          )}

          {activeTab === 'studio' && (
            <VoiceStudio
              voices={voices}
              activeUser={activeUser}
              config={config}
              onOpenWallet={() => setWalletOpen(true)}
              onDataChanged={() => void loadWorkspaceData()}
            />
          )}

          {activeTab === 'video' && (
            <VideoStudio
              voices={voices}
              activeUser={activeUser}
              config={config}
              onOpenWallet={() => setWalletOpen(true)}
              onDataChanged={() => void loadWorkspaceData()}
            />
          )}

          {activeTab === 'history' && (
            <HistoryView
              generations={generations}
              onDataChanged={() => void loadWorkspaceData()}
            />
          )}

          {activeTab === 'admin' && (
            <AdminPanel
              stats={stats}
              users={users}
              voices={voices}
              config={config}
              paymentRequests={paymentRequests}
              incomingPaymentSms={incomingPaymentSms}
              transactions={transactions}
              jobs={jobs}
              errorLogs={errorLogs}
              onRefresh={() => void loadWorkspaceData()}
            />
          )}

          {activeTab === 'artwork' && <ArtworkStudio />}
        </main>
      </div>

      <WalletModal
        open={walletOpen}
        onClose={() => setWalletOpen(false)}
        activeUser={activeUser}
        config={config}
        transactions={transactions}
        paymentRequests={paymentRequests}
        onDataChanged={() => void loadWorkspaceData()}
      />
    </div>
  );
}
