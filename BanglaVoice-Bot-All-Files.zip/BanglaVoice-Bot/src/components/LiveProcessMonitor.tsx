import { CheckCircle2, Clock, Film, Mic, RefreshCw } from 'lucide-react';
import { useEffect, useState } from 'react';
import type { VideoProjectJob, VoiceJob } from '../types.ts';

export function formatClockMMSS(sec: number): string {
  const s = Math.max(0, Math.floor(sec));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const rem = s % 60;
  const mm = String(m).padStart(2, '0');
  const ss = String(rem).padStart(2, '0');
  if (h > 0) {
    return `${String(h).padStart(2, '0')}:${mm}:${ss}`;
  }
  return `${mm}:${ss}`;
}

export function useLiveNowMs(active: boolean): number {
  const [nowMs, setNowMs] = useState<number>(() => Date.now());

  useEffect(() => {
    if (!active) return;
    setNowMs(Date.now());
    const id = setInterval(() => {
      setNowMs(Date.now());
    }, 1000);
    return () => clearInterval(id);
  }, [active]);

  return nowMs;
}

export function computeLiveTiming(
  params: {
    startedAt?: string;
    createdAt?: string;
    updatedAt?: string;
    elapsedSec?: number;
    estimatedRemainingSec?: number;
    status?: string;
  },
  nowMs: number,
): { liveElapsedSec: number; liveRemainingSec: number } {
  const isTerminal =
    params.status === 'completed' || params.status === 'failed';
  if (isTerminal) {
    return {
      liveElapsedSec: Math.max(0, Math.round(params.elapsedSec ?? 0)),
      liveRemainingSec: 0,
    };
  }

  const anchorStr = params.startedAt || params.createdAt;
  const anchorMs = anchorStr ? Date.parse(anchorStr) : NaN;
  const computedElapsed = Number.isFinite(anchorMs)
    ? Math.max(0, Math.floor((nowMs - anchorMs) / 1000))
    : 0;
  const liveElapsedSec = Math.max(params.elapsedSec ?? 0, computedElapsed);

  let liveRemainingSec = 0;
  if (
    typeof params.estimatedRemainingSec === 'number' &&
    params.estimatedRemainingSec > 0
  ) {
    const updatedMs = params.updatedAt ? Date.parse(params.updatedAt) : NaN;
    const sinceUpdateSec = Number.isFinite(updatedMs)
      ? Math.max(0, Math.floor((nowMs - updatedMs) / 1000))
      : 0;
    liveRemainingSec = Math.max(1, params.estimatedRemainingSec - sinceUpdateSec);
  }

  return { liveElapsedSec, liveRemainingSec };
}

const VIDEO_STAGES = [
  { key: 'planning', label: '১. পরিকল্পনা' },
  { key: 'voicing', label: '২. ভয়েস' },
  { key: 'visuals', label: '৩. ভিজ্যুয়াল' },
  { key: 'rendering', label: '৪. রেন্ডার' },
] as const;

const VOICE_STAGES = [
  { key: 'queued', label: '১. প্রস্তুতি' },
  { key: 'processing', label: '২. ভয়েস' },
  { key: 'joining', label: '৩. সংযুক্তি' },
  { key: 'rendering', label: '৪. MP3' },
] as const;

export function StageStepper({
  kind,
  status,
}: {
  kind: 'video' | 'voice';
  status: string;
}) {
  const stages = kind === 'video' ? VIDEO_STAGES : VOICE_STAGES;
  const activeIdx =
    status === 'completed'
      ? stages.length
      : Math.max(
          0,
          stages.findIndex((s) => s.key === status),
        );

  return (
    <div className="flex flex-wrap items-center gap-1.5">
      {stages.map((st, idx) => {
        const done = idx < activeIdx;
        const current = idx === activeIdx && status !== 'completed' && status !== 'failed';
        return (
          <span
            key={st.key}
            className={`inline-flex items-center gap-1 rounded px-2 py-0.5 text-[10px] font-medium ${
              done
                ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                : current
                  ? 'bg-teal-700 text-white'
                  : 'bg-slate-100 text-slate-500 border border-slate-200'
            }`}
          >
            {done ? '✓ ' : current ? '● ' : ''}
            {st.label}
          </span>
        );
      })}
    </div>
  );
}

interface LiveProcessMonitorProps {
  voiceJobs: VoiceJob[];
  videoJobs: VideoProjectJob[];
  onNavigate: (tab: 'telegram' | 'studio' | 'video') => void;
}

export function LiveProcessMonitor({
  voiceJobs,
  videoJobs,
  onNavigate,
}: LiveProcessMonitorProps) {
  const activeVideos = videoJobs.filter(
    (j) => j.status !== 'completed' && j.status !== 'failed',
  );
  const activeVoices = voiceJobs.filter(
    (j) => j.status !== 'completed' && j.status !== 'failed',
  );

  const hasActive = activeVideos.length > 0 || activeVoices.length > 0;
  const nowMs = useLiveNowMs(hasActive);

  // Also show freshly completed jobs (within last 15s) so user sees 100% completion
  const recentCompletedVideos = videoJobs.filter((j) => {
    if (j.status !== 'completed') return false;
    const t = Date.parse(j.updatedAt);
    return Number.isFinite(t) && nowMs - t <= 15000;
  });
  const recentCompletedVoices = voiceJobs.filter((j) => {
    if (j.status !== 'completed') return false;
    const t = Date.parse(j.updatedAt);
    return Number.isFinite(t) && nowMs - t <= 15000;
  });

  const shownVideos = [...activeVideos, ...recentCompletedVideos].slice(0, 3);
  const shownVoices = [...activeVoices, ...recentCompletedVoices].slice(0, 3);

  if (shownVideos.length === 0 && shownVoices.length === 0) {
    return null;
  }

  return (
    <div className="mb-6 rounded-xl border border-teal-200 bg-white p-4 shadow-sm">
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 pb-2.5">
        <div className="flex items-center gap-2">
          {hasActive ? (
            <span className="relative flex h-2.5 w-2.5">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-teal-500 opacity-75" />
              <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-teal-600" />
            </span>
          ) : (
            <CheckCircle2 className="h-4 w-4 text-emerald-600" />
          )}
          <span className="text-xs font-bold tracking-wide text-slate-900">
            {hasActive
              ? `LIVE অটো-প্রসেসিং মনিটর (${activeVideos.length + activeVoices.length}টি কাজ চলমান)`
              : 'সাম্প্রতিক প্রসেসিং সম্পন্ন হয়েছে'}
          </span>
        </div>
        <span className="text-[11px] text-slate-500">
          রিয়েল-টাইম টাইমার ও শতাংশ আপডেট
        </span>
      </div>

      <div className="mt-3 grid grid-cols-1 gap-3 lg:grid-cols-2">
        {shownVideos.map((vj) => {
          const isDone = vj.status === 'completed';
          const timing = computeLiveTiming(vj, nowMs);
          const targetTab = vj.source === 'studio' ? 'video' : 'telegram';
          return (
            <div
              key={vj.id}
              className="rounded-lg border border-slate-200 bg-slate-50/80 p-3"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex min-w-0 items-center gap-2">
                  <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-teal-700 text-white">
                    <Film className="h-3.5 w-3.5" />
                  </div>
                  <div className="min-w-0">
                    <div className="truncate text-xs font-semibold text-slate-900">
                      {vj.title}
                    </div>
                    <div className="text-[11px] text-slate-500 truncate">
                      {vj.statusText}
                    </div>
                  </div>
                </div>
                <div className="flex shrink-0 items-center gap-2">
                  <span className="font-mono text-xs font-bold text-teal-800 tabular-nums">
                    {vj.progressPct}%
                  </span>
                  <button
                    type="button"
                    onClick={() => onNavigate(targetTab)}
                    className="rounded border border-slate-200 bg-white px-2 py-1 text-[11px] font-medium text-slate-700 hover:border-teal-600 hover:text-teal-800 whitespace-nowrap"
                  >
                    দেখুন →
                  </button>
                </div>
              </div>

              <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-slate-200">
                <div
                  className={`h-full transition-all duration-300 ${
                    isDone ? 'bg-emerald-600' : 'bg-teal-700 animate-pulse'
                  }`}
                  style={{ width: `${Math.max(6, vj.progressPct)}%` }}
                />
              </div>

              <div className="mt-2 flex flex-wrap items-center justify-between gap-2">
                <StageStepper kind="video" status={vj.status} />
                <div className="flex items-center gap-2 font-mono text-[11px] tabular-nums">
                  <span className="inline-flex items-center gap-1 rounded bg-slate-900 px-2 py-0.5 font-semibold text-white">
                    {!isDone && <RefreshCw className="h-3 w-3 animate-spin" />}
                    <Clock className="h-3 w-3" />
                    {formatClockMMSS(timing.liveElapsedSec)}
                  </span>
                  {timing.liveRemainingSec > 0 && !isDone && (
                    <span className="font-medium text-teal-700">
                      বাকি ~{formatClockMMSS(timing.liveRemainingSec)}
                    </span>
                  )}
                </div>
              </div>
            </div>
          );
        })}

        {shownVoices.map((job) => {
          const isDone = job.status === 'completed';
          const pct =
            job.progressPct ??
            Math.min(
              98,
              Math.round(
                (job.currentPart / Math.max(1, job.totalParts)) * 100,
              ),
            );
          const timing = computeLiveTiming(job, nowMs);
          const targetTab = job.source === 'studio' ? 'studio' : 'telegram';
          return (
            <div
              key={job.id}
              className="rounded-lg border border-slate-200 bg-slate-50/80 p-3"
            >
              <div className="flex items-start justify-between gap-2">
                <div className="flex min-w-0 items-center gap-2">
                  <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-slate-900 text-white">
                    <Mic className="h-3.5 w-3.5" />
                  </div>
                  <div className="min-w-0">
                    <div className="truncate text-xs font-semibold text-slate-900">
                      {job.voiceNameBn} ({job.currentPart}/{job.totalParts} পার্ট)
                    </div>
                    <div className="text-[11px] text-slate-500 truncate">
                      {job.statusText}
                    </div>
                  </div>
                </div>
                <div className="flex shrink-0 items-center gap-2">
                  <span className="font-mono text-xs font-bold text-teal-800 tabular-nums">
                    {pct}%
                  </span>
                  <button
                    type="button"
                    onClick={() => onNavigate(targetTab)}
                    className="rounded border border-slate-200 bg-white px-2 py-1 text-[11px] font-medium text-slate-700 hover:border-teal-600 hover:text-teal-800 whitespace-nowrap"
                  >
                    দেখুন →
                  </button>
                </div>
              </div>

              <div className="mt-2 h-2 w-full overflow-hidden rounded-full bg-slate-200">
                <div
                  className={`h-full transition-all duration-300 ${
                    isDone ? 'bg-emerald-600' : 'bg-teal-700 animate-pulse'
                  }`}
                  style={{ width: `${Math.max(6, pct)}%` }}
                />
              </div>

              <div className="mt-2 flex flex-wrap items-center justify-between gap-2">
                <StageStepper kind="voice" status={job.status} />
                <div className="flex items-center gap-2 font-mono text-[11px] tabular-nums">
                  <span className="inline-flex items-center gap-1 rounded bg-slate-900 px-2 py-0.5 font-semibold text-white">
                    {!isDone && <RefreshCw className="h-3 w-3 animate-spin" />}
                    <Clock className="h-3 w-3" />
                    {formatClockMMSS(timing.liveElapsedSec)}
                  </span>
                  {timing.liveRemainingSec > 0 && !isDone && (
                    <span className="font-medium text-teal-700">
                      বাকি ~{formatClockMMSS(timing.liveRemainingSec)}
                    </span>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
