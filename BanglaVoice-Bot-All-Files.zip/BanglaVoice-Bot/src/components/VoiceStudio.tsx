import {
  AlertCircle,
  CheckCircle2,
  Clock,
  Eye,
  FileText,
  Mic,
  RefreshCw,
  Sliders,
  Volume2,
  Wallet,
} from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import type {
  BotUser,
  PublicBotConfig,
  VoiceCategory,
  VoiceGeneration,
  VoiceJob,
  VoicePersona,
} from '../types.ts';
import { AudioPlayer } from './AudioPlayer.tsx';
import {
  computeLiveTiming,
  formatClockMMSS,
  StageStepper,
  useLiveNowMs,
} from './LiveProcessMonitor.tsx';

interface VoiceStudioProps {
  voices: VoicePersona[];
  activeUser: BotUser | undefined;
  config: PublicBotConfig | null;
  onOpenWallet?: () => void;
  onDataChanged: () => void;
}

const MALE_PORTRAIT = '/src/assets/images/male_voice_studio_1794668927923.jpg';
const FEMALE_PORTRAIT = '/src/assets/images/female_voice_studio_1794668928323.jpg';
const HERO_STUDIO_IMG = '/src/assets/images/bot_studio_hero_1794668929143.jpg';

type DetectedLang = 'bangla' | 'english' | 'mixed';

interface PreviewResponse {
  detectedLanguage: DetectedLang;
  originalScript: string;
  banglaScript: string;
  estimatedChunks: number;
  estimatedMinutes: number;
  voiceCost?: number;
}

function checkClientMultilingualScript(
  text: string,
  smartEnglishToBangla: boolean,
  strictBanglaOnly: boolean,
): {
  valid: boolean;
  detectedLanguage: DetectedLang;
  message?: string;
} {
  const trimmed = text.trim();
  if (!trimmed) {
    return {
      valid: false,
      detectedLanguage: 'bangla',
      message: 'বাংলা, ইংরেজি অথবা মিশ্রিত স্ক্রিপ্ট লিখুন।',
    };
  }
  const hasUnsupported =
    /[\u0600-\u06FF\u0900-\u0963\u0966-\u097F\u0400-\u04FF\u4E00-\u9FFF\u3040-\u30FF\uAC00-\uD7AF]/.test(
      trimmed,
    );
  if (hasUnsupported) {
    return {
      valid: false,
      detectedLanguage: 'bangla',
      message:
        'অন্য ভাষার অক্ষর পাওয়া গেছে। শুধুমাত্র বাংলা, ইংরেজি বা মিশ্রিত স্ক্রিপ্ট লিখুন।',
    };
  }

  const hasBangla = /[\u0980-\u09FF]/.test(trimmed);
  const hasEnglish = /[A-Za-z]/.test(trimmed);
  const detectedLanguage: DetectedLang =
    hasBangla && hasEnglish ? 'mixed' : hasEnglish ? 'english' : 'bangla';

  if (hasEnglish && strictBanglaOnly && !smartEnglishToBangla) {
    return {
      valid: false,
      detectedLanguage,
      message:
        'Strict Bangla-Only মোড চালু আছে এবং Smart English → Bangla বন্ধ আছে। শুধুমাত্র বাংলা স্ক্রিপ্ট লিখুন।',
    };
  }

  if (!hasBangla && !hasEnglish) {
    return {
      valid: false,
      detectedLanguage: 'bangla',
      message: 'অনুগ্রহ করে পাঠযোগ্য বাংলা বা ইংরেজি বাক্য লিখুন।',
    };
  }

  return { valid: true, detectedLanguage };
}

export function VoiceStudio({
  voices,
  activeUser,
  config,
  onOpenWallet,
  onDataChanged,
}: VoiceStudioProps) {
  const [category, setCategory] = useState<VoiceCategory>('female');
  const [selectedVoiceId, setSelectedVoiceId] = useState<string>('female-nusrat');
  const [speed, setSpeed] = useState<number>(1.0);
  const [pitch, setPitch] = useState<number>(0);
  const [script, setScript] = useState<string>(
    'আসসালামু আলাইকুম। আজকের বিশেষ প্রতিবেদনে আপনাকে স্বাগতম। শুধুমাত্র বাংলা ভাষায় লেখা আপনার যেকোনো স্ক্রিপ্ট এখন হয়ে উঠবে স্পষ্ট, সাবলীল এবং একদম বাস্তব মানুষের মতো কণ্ঠস্বর।',
  );
  const [previewLoading, setPreviewLoading] = useState(false);
  const [previewData, setPreviewData] = useState<PreviewResponse | null>(null);
  const [editedBanglaScript, setEditedBanglaScript] = useState<string>('');
  const [submitting, setSubmitting] = useState(false);
  const [activeJob, setActiveJob] = useState<VoiceJob | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [latestGen, setLatestGen] = useState<VoiceGeneration | null>(null);
  const [heroImgFailed, setHeroImgFailed] = useState(false);
  const [avatarFailed, setAvatarFailed] = useState<Record<string, boolean>>({});
  const [demoVoiceId, setDemoVoiceId] = useState<string | null>(null);
  const [demoAudioUrl, setDemoAudioUrl] = useState<string | null>(null);
  const [demoLoading, setDemoLoading] = useState(false);
  const [demoError, setDemoError] = useState<string | null>(null);

  const filteredVoices = useMemo(
    () => voices.filter((v) => v.category === category),
    [voices, category],
  );

  const activeVoice =
    voices.find((v) => v.id === selectedVoiceId) ?? filteredVoices[0];

  const getVoiceCost = (voiceId?: string): number => {
    if (voiceId && config?.voiceCosts && typeof config.voiceCosts[voiceId] === 'number') {
      return config.voiceCosts[voiceId];
    }
    return config?.voiceGenerationCost ?? 0;
  };

  const activeVoiceCost = getVoiceCost(activeVoice?.id);

  const strictBangla = config?.strictBanglaOnly ?? false;
  const smartEnToBn = config?.smartEnglishToBangla ?? true;
  const validation = useMemo(
    () => checkClientMultilingualScript(script, smartEnToBn, strictBangla),
    [script, smartEnToBn, strictBangla],
  );

  const estChunks = Math.max(1, Math.ceil(script.trim().length / 650));
  const estMinutes = Math.max(0.2, Math.round((script.trim().length / 800) * 10) / 10);

  // Auto-hydrate any currently running background VoiceJob on entry
  useEffect(() => {
    void fetch('/api/jobs')
      .then((r) => (r.ok ? r.json() : null))
      .then((data: { jobs?: VoiceJob[] } | null) => {
        if (!data?.jobs?.length) return;
        const active = data.jobs.filter(
          (j) => j.status !== 'completed' && j.status !== 'failed',
        );
        if (active.length === 0) return;
        const preferred =
          active.find((j) => j.userId === activeUser?.id) ?? active[0];
        setActiveJob((prev) =>
          prev && prev.status !== 'completed' && prev.status !== 'failed'
            ? prev
            : preferred,
        );
      })
      .catch(() => {});
  }, [activeUser?.id]);

  // Live background job polling
  useEffect(() => {
    if (
      !activeJob ||
      activeJob.status === 'completed' ||
      activeJob.status === 'failed'
    ) {
      return;
    }

    const timer = setInterval(() => {
      void fetch(`/api/jobs/${activeJob.id}`)
        .then((r) => r.json())
        .then((data: { job?: VoiceJob; generation?: VoiceGeneration }) => {
          if (data.job) {
            setActiveJob(data.job);
            if (data.job.status === 'completed' && data.generation) {
              setLatestGen(data.generation);
              onDataChanged();
            } else if (data.job.status === 'failed') {
              setError(data.job.error || 'ভয়েস তৈরি ব্যর্থ হয়েছে।');
            }
          }
        })
        .catch(() => {});
    }, 800);

    return () => clearInterval(timer);
  }, [activeJob, onDataChanged]);

  const isActiveJobRunning = Boolean(
    activeJob &&
      activeJob.status !== 'completed' &&
      activeJob.status !== 'failed',
  );
  const nowMs = useLiveNowMs(isActiveJobRunning);

  const handleCategoryChange = (nextCat: VoiceCategory) => {
    setCategory(nextCat);
    const first = voices.find((v) => v.category === nextCat);
    if (first) {
      setSelectedVoiceId(first.id);
      setSpeed(first.defaultSpeed);
      setPitch(first.defaultPitch);
    }
  };

  const handleVoicePick = (voice: VoicePersona) => {
    setSelectedVoiceId(voice.id);
    setSpeed(voice.defaultSpeed);
    setPitch(voice.defaultPitch);
  };

  const handlePlayVoiceDemo = async (voice: VoicePersona) => {
    setDemoVoiceId(voice.id);
    setDemoError(null);
    setDemoLoading(true);
    try {
      const targetUrl = `/api/voices/${voice.id}/demo.mp3`;
      const res = await fetch(targetUrl);
      if (!res.ok) {
        throw new Error('ভয়েস ডেমো লোড করা যায়নি।');
      }
      const blob = await res.blob();
      const objUrl = URL.createObjectURL(blob);
      setDemoAudioUrl((prev) => {
        if (prev?.startsWith('blob:')) URL.revokeObjectURL(prev);
        return objUrl;
      });
    } catch (err) {
      setDemoError(
        err instanceof Error ? err.message : 'ভয়েস ডেমো চালু করা যায়নি।',
      );
    } finally {
      setDemoLoading(false);
    }
  };

  const handleTxtUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const content = await file.text();
    setScript(content);
    setPreviewData(null);
    setEditedBanglaScript('');
    setError(null);
    e.target.value = '';
  };

  const isWorking =
    previewLoading ||
    submitting ||
    Boolean(
      activeJob &&
        activeJob.status !== 'completed' &&
        activeJob.status !== 'failed',
    );

  const handlePreview = async () => {
    if (isWorking) return;
    setError(null);
    if (!validation.valid) {
      setError(validation.message || 'সঠিক বাংলা বা ইংরেজি স্ক্রিপ্ট লিখুন।');
      return;
    }

    setPreviewLoading(true);
    try {
      const res = await fetch('/api/studio/preview', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: activeUser?.id,
          voiceId: activeVoice?.id,
          script,
        }),
      });
      const data = (await res.json()) as PreviewResponse & { error?: string };
      if (!res.ok || !data.banglaScript) {
        setError(data.error || 'বাংলা প্রিভিউ তৈরি করতে সমস্যা হয়েছে।');
      } else {
        setPreviewData(data);
        setEditedBanglaScript(data.banglaScript);
      }
    } catch {
      setError('সার্ভারের সাথে সংযোগ ব্যর্থ হয়েছে।');
    } finally {
      setPreviewLoading(false);
    }
  };

  const handleGenerateFromPreview = async () => {
    if (isWorking) return;
    const finalScript = editedBanglaScript.trim();
    if (!finalScript) {
      setError('প্রিভিউ বাংলা স্ক্রিপ্ট খালি রাখা যাবে না।');
      return;
    }
    setError(null);
    setSubmitting(true);
    try {
      const res = await fetch('/api/studio/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: activeUser?.id,
          script: finalScript,
          originalScript: previewData?.originalScript ?? script.trim(),
          preConvertedBangla: !/[A-Za-z]/.test(finalScript),
          voiceId: activeVoice?.id,
          speed,
          pitch,
        }),
      });
      const data = (await res.json()) as {
        job?: VoiceJob;
        error?: string;
      };
      if (!res.ok || !data.job) {
        setError(data.error || 'ভয়েস তৈরি করতে সমস্যা হয়েছে।');
      } else {
        setActiveJob(data.job);
      }
    } catch {
      setError('সার্ভারের সাথে সংযোগ ব্যর্থ হয়েছে।');
    } finally {
      setSubmitting(false);
    }
  };

  const handleRegenerate = async () => {
    if (!latestGen || isWorking) return;
    setSubmitting(true);
    setError(null);
    try {
      const res = await fetch(`/api/studio/regenerate/${latestGen.id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          voiceId: activeVoice?.id,
          speed,
          pitch,
        }),
      });
      const data = (await res.json()) as {
        job?: VoiceJob;
        error?: string;
      };
      if (!res.ok || !data.job) {
        setError(data.error || 'পুনরায় জেনারেট ব্যর্থ হয়েছে।');
      } else {
        setActiveJob(data.job);
      }
    } finally {
      setSubmitting(false);
    }
  };

  const maxChars =
    activeUser?.customCharLimit !== null && activeUser?.customCharLimit !== undefined
      ? activeUser.customCharLimit
      : activeUser?.tier === 'premium'
        ? (config?.maxScriptCharsPremium ?? 0)
        : (config?.maxScriptCharsFree ?? 0);

  const jobProgressPct = activeJob
    ? activeJob.status === 'completed'
      ? 100
      : Math.min(
          98,
          Math.round(
            (activeJob.currentPart / Math.max(1, activeJob.totalParts)) * 100,
          ),
        )
    : 0;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 overflow-hidden rounded-xl border border-slate-200 bg-white lg:grid-cols-12 lg:items-stretch">
        <div className="flex flex-col justify-center p-6 lg:col-span-7 lg:p-8">
          <p className="text-xs font-medium text-teal-700">
            Smart English → Bangla · আনলিমিটেড ডিউরেশন চাঙ্কড FFmpeg ইঞ্জিন
          </p>
          <h2 className="mt-2 text-2xl font-bold tracking-tight text-slate-900 [text-wrap:balance]">
            বাংলা, ইংরেজি অথবা মিশ্রিত স্ক্রিপ্ট থেকে প্রাকৃতিক বাংলা কণ্ঠস্বর তৈরি করুন
          </h2>
          <p className="mt-2.5 max-w-2xl text-sm leading-relaxed text-slate-600">
            ইংরেজি বা মিশ্রিত স্ক্রিপ্ট দিলে বট নিজেই অর্থ বুঝে ব্র্যান্ড ও সফটওয়্যারের সঠিক বাংলা উচ্চারণসহ প্রিভিউ তৈরি করবে। ভয়েস তৈরির আগে আপনি বাংলা স্ক্রিপ্ট দেখে ও এডিট করে চূড়ান্ত MP3 জেনারেট করতে পারবেন।
          </p>
        </div>
        <div className="relative min-h-[190px] bg-slate-900 lg:col-span-5">
          {!heroImgFailed ? (
            <img
              src={HERO_STUDIO_IMG}
              alt="BanglaVoice acoustic recording studio console"
              referrerPolicy="no-referrer"
              onError={() => setHeroImgFailed(true)}
              className="h-full w-full object-cover"
            />
          ) : (
            <div className="flex h-full w-full items-center justify-center bg-slate-800 text-slate-300">
              <Mic className="h-10 w-10" />
            </div>
          )}
          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/75 via-slate-950/20 to-transparent" />
          <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between text-xs text-white">
            <span>FFmpeg + Background Queue</span>
            <span className="font-mono tabular-nums">128 kbps MP3</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Left Column */}
        <div className="space-y-4 lg:col-span-5">
          <div className="rounded-xl border border-slate-200 bg-white p-5">
            <div className="flex items-center justify-between gap-3">
              <h3 className="text-sm font-semibold text-slate-900">
                ১. Voice Category নির্বাচন করুন
              </h3>
              <div className="flex items-center gap-1 rounded-lg bg-slate-100 p-1">
                <button
                  type="button"
                  onClick={() => handleCategoryChange('male')}
                  className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                    category === 'male'
                      ? 'bg-white text-slate-900 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Male Voice
                </button>
                <button
                  type="button"
                  onClick={() => handleCategoryChange('female')}
                  className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                    category === 'female'
                      ? 'bg-white text-slate-900 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Female Voice
                </button>
                <button
                  type="button"
                  onClick={() => handleCategoryChange('cartoon')}
                  className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                    category === 'cartoon'
                      ? 'bg-white text-slate-900 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  Cartoon Voice
                </button>
              </div>
            </div>

            <div className="mt-4 space-y-2.5">
              {filteredVoices.map((voice) => {
                const isSelected = activeVoice?.id === voice.id;
                const portraitSrc =
                  voice.category === 'male' ? MALE_PORTRAIT : FEMALE_PORTRAIT;
                return (
                  <button
                    key={voice.id}
                    type="button"
                    onClick={() => handleVoicePick(voice)}
                    className={`flex w-full items-start gap-3.5 rounded-lg border p-3.5 text-left transition-colors ${
                      isSelected
                        ? 'border-teal-700 bg-teal-50/60'
                        : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50'
                    }`}
                  >
                    <div className="h-11 w-11 shrink-0 overflow-hidden rounded-lg bg-slate-200">
                      {voice.category === 'cartoon' ? (
                        <div className="flex h-full w-full items-center justify-center bg-amber-100 text-xl font-bold text-amber-800">
                          {voice.emoji || '🎭'}
                        </div>
                      ) : !avatarFailed[voice.id] ? (
                        <img
                          src={portraitSrc}
                          alt={`${voice.nameEn} studio voice talent`}
                          referrerPolicy="no-referrer"
                          onError={() =>
                            setAvatarFailed((prev) => ({
                              ...prev,
                              [voice.id]: true,
                            }))
                          }
                          className="h-full w-full object-cover"
                        />
                      ) : (
                        <div className="flex h-full w-full items-center justify-center text-slate-500">
                          <Volume2 className="h-5 w-5" />
                        </div>
                      )}
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-sm font-semibold text-slate-900">
                          {voice.emoji ? `${voice.emoji} ` : ''}
                          {voice.nameBn} ({voice.nameEn})
                        </span>
                        <span className="font-mono text-xs font-semibold text-teal-700 tabular-nums whitespace-nowrap shrink-0">
                          {getVoiceCost(voice.id) > 0
                            ? `৳${getVoiceCost(voice.id)}`
                            : 'ফ্রি'}
                        </span>
                      </div>
                      <div className="mt-0.5 text-[11px] font-medium text-slate-500">
                        {voice.roleBn}
                      </div>
                      <p className="mt-1 text-xs leading-relaxed text-slate-600">
                        {voice.descriptionBn}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Dedicated Voice Demo Player ("ডেভলপার বেলাল হোসেন") */}
          <div className="rounded-xl border border-teal-200 bg-teal-50/40 p-5">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-sm font-semibold text-slate-900">
                <Volume2 className="h-4 w-4 text-teal-700" />
                <span>ভয়েস ডেমো শুনুন (ডেভলপার বেলাল হোসেন)</span>
              </div>
              {activeVoice && (
                <button
                  type="button"
                  disabled={demoLoading}
                  onClick={() => void handlePlayVoiceDemo(activeVoice)}
                  className="inline-flex h-8 items-center gap-1.5 rounded-lg bg-teal-700 px-3 text-xs font-medium text-white transition-colors hover:bg-teal-800 disabled:opacity-50 whitespace-nowrap shrink-0"
                >
                  <Volume2 className="h-3.5 w-3.5" />
                  <span>
                    {demoLoading && demoVoiceId === activeVoice.id
                      ? 'লোড হচ্ছে...'
                      : `${activeVoice.emoji ?? '🔊'} ${activeVoice.nameBn} ডেমো শুনুন`}
                  </span>
                </button>
              )}
            </div>
            <p className="mt-1.5 text-xs leading-relaxed text-slate-600">
              যেকোনো ভয়েসের কণ্ঠস্বর ও আবেগ পরীক্ষা করতে উপরের বাটনে ক্লিক করুন—ডেমোতে কণ্ঠশিল্পী{' '}
              <strong className="text-slate-900">ডেভলপার বেলাল হোসেন</strong> ও এই বটের পরিচিতি পড়ে শোনাবেন।
            </p>
            <div className="mt-3 flex flex-wrap gap-1.5">
              {filteredVoices.map((v) => (
                <button
                  key={`demo-btn-${v.id}`}
                  type="button"
                  disabled={demoLoading}
                  onClick={() => {
                    handleVoicePick(v);
                    void handlePlayVoiceDemo(v);
                  }}
                  className={`rounded-md border px-2.5 py-1 text-[11px] font-medium transition-colors whitespace-nowrap shrink-0 ${
                    demoVoiceId === v.id
                      ? 'border-teal-700 bg-teal-700 text-white'
                      : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  {v.emoji ?? '🎙️'} {v.nameBn}
                </button>
              ))}
            </div>
            {demoError && (
              <div className="mt-3 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-700">
                {demoError}
              </div>
            )}
            {demoAudioUrl && demoVoiceId && (
              <div className="mt-3 rounded-lg border border-slate-200 bg-white p-3">
                {(() => {
                  const playedVoice =
                    voices.find((v) => v.id === demoVoiceId) ?? activeVoice;
                  return (
                    <>
                      <div className="text-xs font-semibold text-slate-900">
                        {playedVoice?.emoji ?? '🔊'} {playedVoice?.nameBn} ({playedVoice?.roleBn})
                      </div>
                      <p className="mt-1 text-[11px] leading-relaxed text-slate-600">
                        “{playedVoice?.sampleBangla}”
                      </p>
                      <audio
                        key={demoAudioUrl}
                        controls
                        autoPlay
                        src={demoAudioUrl}
                        className="mt-2 h-9 w-full"
                      />
                    </>
                  );
                })()}
              </div>
            )}
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-5">
            <div className="flex items-center gap-2 text-sm font-semibold text-slate-900">
              <Sliders className="h-4 w-4 text-teal-700" />
              <span>২. Voice Speed ও Pitch কন্ট্রোল</span>
            </div>

            <div className="mt-4 space-y-4">
              <div>
                <div className="flex items-center justify-between text-xs">
                  <span className="font-medium text-slate-700">
                    ভয়েস স্পিড (Speed)
                  </span>
                  <span className="font-mono font-semibold text-slate-900 tabular-nums">
                    {speed.toFixed(2)}x
                  </span>
                </div>
                <input
                  type="range"
                  min={0.75}
                  max={1.35}
                  step={0.05}
                  value={speed}
                  onChange={(e) => setSpeed(Number(e.target.value))}
                  aria-label="Voice speed control"
                  className="mt-2 w-full accent-teal-700"
                />
                <div className="mt-1 flex justify-between font-mono text-[11px] text-slate-400 tabular-nums">
                  <span>0.75x (ধীর)</span>
                  <span>1.00x (স্বাভাবিক)</span>
                  <span>1.35x (দ্রুত)</span>
                </div>
              </div>

              <div className="border-t border-slate-100 pt-4">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-medium text-slate-700">
                    ভয়েস পিচ (Pitch)
                  </span>
                  <span className="font-mono font-semibold text-slate-900 tabular-nums">
                    {pitch > 0 ? `+${pitch}` : pitch} st
                  </span>
                </div>
                <input
                  type="range"
                  min={-3}
                  max={3}
                  step={1}
                  value={pitch}
                  onChange={(e) => setPitch(Number(e.target.value))}
                  aria-label="Voice pitch control"
                  className="mt-2 w-full accent-teal-700"
                />
                <div className="mt-1 flex justify-between font-mono text-[11px] text-slate-400 tabular-nums">
                  <span>-3 (গম্ভীর)</span>
                  <span>0 (স্বাভাবিক)</span>
                  <span>+3 (তীক্ষ্ণ)</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column */}
        <div className="space-y-5 lg:col-span-7">
          <div className="rounded-xl border border-slate-200 bg-white p-5">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-semibold text-slate-900">
                  ৩. বাংলা, ইংরেজি বা মিশ্রিত Script লিখুন (.txt সমর্থিত)
                </h3>
                <p className="mt-0.5 text-xs text-slate-500">
                  কণ্ঠস্বর: {activeVoice?.emoji ? `${activeVoice.emoji} ` : ''}
                  {activeVoice?.nameBn} (
                  <span className="font-mono font-medium text-teal-700 tabular-nums">
                    {activeVoiceCost > 0 ? `৳${activeVoiceCost}` : 'ফ্রি'}
                  </span>
                  ) · স্পিড:{' '}
                  <span className="font-mono tabular-nums">{speed.toFixed(2)}x</span>{' '}
                  · পিচ:{' '}
                  <span className="font-mono tabular-nums">
                    {pitch > 0 ? `+${pitch}` : pitch}
                  </span>
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <label className="flex cursor-pointer items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-medium text-slate-700 hover:bg-slate-100 whitespace-nowrap shrink-0">
                  <FileText className="h-3.5 w-3.5" />
                  <span>.txt ফাইল</span>
                  <input
                    type="file"
                    accept=".txt,text/plain"
                    onChange={handleTxtUpload}
                    className="hidden"
                  />
                </label>
                <button
                  type="button"
                  onClick={() => {
                    setScript(
                      'Welcome to Google and YouTube AI Studio! Today we will learn how Microsoft Excel and ChatGPT API work together on example.com.',
                    );
                    setPreviewData(null);
                    setEditedBanglaScript('');
                    setError(null);
                  }}
                  className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-medium text-slate-700 transition-colors hover:bg-slate-100 whitespace-nowrap shrink-0"
                >
                  ইংরেজি নমুনা
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setScript(
                      'আজকে আমরা WhatsApp এবং Facebook Ads ব্যবহার করে কীভাবে আপনার E-commerce Website-এর বিক্রি বাড়াবেন তা বিস্তারিত জানব।',
                    );
                    setPreviewData(null);
                    setEditedBanglaScript('');
                    setError(null);
                  }}
                  className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-medium text-slate-700 transition-colors hover:bg-slate-100 whitespace-nowrap shrink-0"
                >
                  মিশ্রিত নমুনা
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (activeVoice) {
                      setScript(activeVoice.sampleBangla);
                      setPreviewData(null);
                      setEditedBanglaScript('');
                      setError(null);
                    }
                  }}
                  className="rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-medium text-slate-700 transition-colors hover:bg-slate-100 whitespace-nowrap shrink-0"
                >
                  বাংলা নমুনা
                </button>
              </div>
            </div>

            <textarea
              rows={7}
              value={script}
              onChange={(e) => {
                setScript(e.target.value);
                setPreviewData(null);
                setError(null);
              }}
              placeholder="বাংলা, ইংরেজি অথবা বাংলা-ইংরেজি মিশ্রিত যেকোনো দৈর্ঘ্যের স্ক্রিপ্ট এখানে লিখুন..."
              className="mt-4 w-full rounded-lg border border-slate-200 bg-slate-50 p-4 text-base leading-relaxed text-slate-900 placeholder:text-slate-400 focus:border-teal-700 focus:bg-white focus:outline-none"
            />

            <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-xs">
                {validation.valid ? (
                  <span className="flex items-center gap-1.5 text-emerald-700">
                    <CheckCircle2 className="h-4 w-4 shrink-0" />
                    <span>
                      {validation.detectedLanguage === 'english'
                        ? 'ইংরেজি শনাক্ত · প্রিভিউতে স্বাভাবিক বাংলায় রূপান্তরিত হবে'
                        : validation.detectedLanguage === 'mixed'
                          ? 'বাংলা + ইংরেজি মিশ্রিত · প্রিভিউতে বাংলায় রূপান্তরিত হবে'
                          : 'বাংলা স্ক্রিপ্ট যাচাইকৃত'}{' '}
                      · অংশ: {estChunks}টি (~{estMinutes} মিনিট)
                    </span>
                  </span>
                ) : (
                  <span className="flex items-center gap-1.5 text-amber-700">
                    <AlertCircle className="h-4 w-4 shrink-0" />
                    <span>{validation.message}</span>
                  </span>
                )}
              </div>

              <span className="font-mono text-xs text-slate-500 tabular-nums">
                {script.trim().length.toLocaleString()} /{' '}
                {maxChars === 0 ? 'Unlimited' : maxChars.toLocaleString()} অক্ষর
              </span>
            </div>

            {error && (
              <div className="mt-3 flex flex-wrap items-center justify-between gap-2 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-xs font-medium text-red-800">
                <span>{error}</span>
                {onOpenWallet && /ব্যালেন্স|৳/.test(error) && (
                  <button
                    type="button"
                    onClick={onOpenWallet}
                    className="inline-flex h-8 items-center gap-1.5 rounded-md bg-teal-700 px-3 text-xs font-medium text-white hover:bg-teal-800 whitespace-nowrap shrink-0"
                  >
                    <Wallet className="h-3.5 w-3.5" />
                    <span>ব্যালেন্স রিচার্জ করুন</span>
                  </button>
                )}
              </div>
            )}

            <div className="mt-5 flex flex-wrap items-center justify-end gap-3 border-t border-slate-100 pt-4">
              <button
                type="button"
                onClick={() => {
                  setScript('');
                  setPreviewData(null);
                  setEditedBanglaScript('');
                }}
                className="h-10 rounded-lg border border-slate-200 bg-white px-4 text-xs font-medium text-slate-700 transition-colors hover:bg-slate-50 whitespace-nowrap shrink-0"
              >
                মুছে ফেলুন
              </button>
              <button
                type="button"
                onClick={handlePreview}
                disabled={isWorking || !validation.valid}
                className="flex h-10 items-center gap-2 rounded-lg bg-teal-700 px-6 text-sm font-medium text-white transition-colors hover:bg-teal-800 disabled:opacity-50 whitespace-nowrap shrink-0"
              >
                <Eye className="h-4 w-4" />
                <span>
                  {previewLoading
                    ? 'বাংলা প্রিভিউ তৈরি হচ্ছে...'
                    : 'বাংলা প্রিভিউ দেখুন'}
                </span>
              </button>
            </div>
          </div>

          {/* Step 4: Preview Before Generate + Editable Bangla Script */}
          {previewData && (
            <div className="rounded-xl border border-teal-200 bg-white p-5">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h3 className="text-sm font-semibold text-slate-900">
                    ৪. চূড়ান্ত বাংলা স্ক্রিপ্ট প্রিভিউ (Preview & Edit Before Generate)
                  </h3>
                  <p className="mt-0.5 text-xs text-slate-600 tabular-nums">
                    শনাক্তকৃত ভাষা:{' '}
                    {previewData.detectedLanguage === 'english'
                      ? 'ইংরেজি → বাংলা'
                      : previewData.detectedLanguage === 'mixed'
                        ? 'মিশ্রিত → বাংলা'
                        : 'বাংলা'}{' '}
                    · অক্ষর: {editedBanglaScript.trim().length.toLocaleString()}টি ·
                    আনুমানিক {Math.max(1, Math.ceil(editedBanglaScript.trim().length / 650))} অংশ
                  </p>
                </div>
                <button
                  type="button"
                  onClick={handlePreview}
                  disabled={isWorking}
                  className="flex h-8 items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs font-medium text-slate-700 hover:bg-slate-100 disabled:opacity-50 whitespace-nowrap shrink-0"
                >
                  <RefreshCw className="h-3.5 w-3.5" />
                  <span>পুনরায় অনুবাদ</span>
                </button>
              </div>

              <textarea
                rows={7}
                value={editedBanglaScript}
                onChange={(e) => setEditedBanglaScript(e.target.value)}
                aria-label="Editable converted Bangla script preview"
                className="mt-3 w-full rounded-lg border border-slate-200 bg-slate-50 p-4 text-base leading-relaxed text-slate-900 focus:border-teal-700 focus:bg-white focus:outline-none"
              />

              <div className="mt-3 flex flex-wrap items-center justify-between gap-3">
                <span className="text-xs text-slate-500 tabular-nums">
                  চার্জ:{' '}
                  <strong className="font-mono text-slate-800">
                    {activeVoiceCost > 0 ? `৳${activeVoiceCost}` : 'ফ্রি'}
                  </strong>{' '}
                  · প্রয়োজনে উপরের বাংলা টেক্সট এডিট করে ভয়েস তৈরি শুরু করুন।
                </span>
                <button
                  type="button"
                  onClick={handleGenerateFromPreview}
                  disabled={isWorking || !editedBanglaScript.trim()}
                  className="flex h-10 items-center gap-2 rounded-lg bg-slate-900 px-6 text-sm font-medium text-white transition-colors hover:bg-slate-800 disabled:opacity-50 whitespace-nowrap shrink-0"
                >
                  <Mic className="h-4 w-4" />
                  <span>
                    {submitting ||
                    (activeJob &&
                      activeJob.status !== 'completed' &&
                      activeJob.status !== 'failed')
                      ? 'ভয়েস তৈরি হচ্ছে...'
                      : 'এই বাংলা স্ক্রিপ্ট দিয়ে MP3 ভয়েস তৈরি করুন'}
                  </span>
                </button>
              </div>
            </div>
          )}

          {/* Live Job Status Progress */}
          {activeJob && (() => {
            const pct = activeJob.progressPct ?? jobProgressPct;
            const timing = computeLiveTiming(activeJob, nowMs);
            const running =
              activeJob.status !== 'completed' && activeJob.status !== 'failed';
            return (
              <div className="rounded-xl border border-teal-200 bg-white p-5 space-y-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2 text-xs">
                    {running && (
                      <span className="inline-flex items-center gap-1 rounded bg-teal-700 px-1.5 py-0.5 font-mono text-[10px] font-bold text-white">
                        <span className="h-1.5 w-1.5 rounded-full bg-white animate-ping" />
                        LIVE
                      </span>
                    )}
                    <span className="font-semibold text-slate-900">
                      {activeJob.statusText}
                    </span>
                  </div>
                  <span className="font-mono text-xs font-bold text-teal-800 tabular-nums">
                    Part {activeJob.currentPart} / {activeJob.totalParts} ({pct}%)
                  </span>
                </div>

                <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-100">
                  <div
                    className={`h-full transition-all duration-300 ${
                      activeJob.status === 'failed'
                        ? 'bg-red-600'
                        : activeJob.status === 'completed'
                          ? 'bg-emerald-600'
                          : 'bg-teal-700 animate-pulse'
                    }`}
                    style={{
                      width: `${Math.max(6, pct)}%`,
                    }}
                  />
                </div>

                <div className="flex flex-wrap items-center justify-between gap-2 pt-0.5">
                  <StageStepper kind="voice" status={activeJob.status} />
                  <div className="flex items-center gap-2 font-mono text-xs tabular-nums">
                    <span className="inline-flex items-center gap-1.5 rounded-md bg-slate-900 px-2.5 py-1 font-semibold text-white">
                      {running && <RefreshCw className="h-3 w-3 animate-spin" />}
                      <Clock className="h-3 w-3" />
                      <span>টাইমার: {formatClockMMSS(timing.liveElapsedSec)}</span>
                    </span>
                    {timing.liveRemainingSec > 0 && running && (
                      <span className="font-semibold text-teal-700">
                        বাকি: ~{formatClockMMSS(timing.liveRemainingSec)}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })()}

          {/* Generated Audio Player Result */}
          <div className="rounded-xl border border-slate-200 bg-white p-5">
            <h3 className="text-sm font-semibold text-slate-900">
              তৈরি হওয়া বাংলা ভয়েস (MP3 Output)
            </h3>

            {latestGen ? (
              <div className="mt-3 space-y-3">
                {(latestGen.audioParts && latestGen.audioParts.length > 0
                  ? latestGen.audioParts
                  : [
                      {
                        url: latestGen.audioUrl,
                        filename: `${latestGen.id}.mp3`,
                        durationSec: latestGen.durationSec,
                        fileSizeBytes: latestGen.fileSizeBytes,
                      },
                    ]
                ).map((part, idx, arr) => (
                  <AudioPlayer
                    key={part.filename}
                    url={part.url}
                    title={
                      arr.length > 1
                        ? `${latestGen.voiceNameBn} · Part ${idx + 1}/${arr.length}`
                        : `${latestGen.voiceNameBn}`
                    }
                    durationSec={part.durationSec}
                    fileSizeBytes={part.fileSizeBytes}
                    onRegenerate={idx === 0 ? handleRegenerate : undefined}
                    regenerating={isWorking}
                  />
                ))}

                <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-slate-500 tabular-nums">
                  <span>
                    ক্যাটাগরি:{' '}
                    {latestGen.category === 'male'
                      ? 'Male Voice'
                      : latestGen.category === 'female'
                        ? 'Female Voice'
                        : 'Cartoon Voice'}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span>স্পিড: {latestGen.speed}x</span>
                  <span aria-hidden="true">·</span>
                  <span>পিচ: {latestGen.pitch}</span>
                  <span aria-hidden="true">·</span>
                  <span>অংশ: {latestGen.totalChunks ?? 1}টি</span>
                  <span aria-hidden="true">·</span>
                  <span>মোট দৈর্ঘ্য: {latestGen.durationSec}s</span>
                </div>
              </div>
            ) : (
              <div className="mt-3 rounded-lg border border-dashed border-slate-200 bg-slate-50 p-6 text-center text-xs text-slate-500">
                উপরে বাংলা স্ক্রিপ্ট লিখে “MP3 ভয়েস তৈরি করুন” বাটনে ক্লিক করলে এখানে সরাসরি অডিও প্লেয়ার ও ডাউনলোড অপশন দেখা যাবে।
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
