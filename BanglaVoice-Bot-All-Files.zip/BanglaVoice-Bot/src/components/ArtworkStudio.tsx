import { Download, Image as ImageIcon } from 'lucide-react';
import { useState } from 'react';

const ASPECT_RATIOS = [
  '1:1',
  '2:3',
  '3:2',
  '3:4',
  '4:3',
  '9:16',
  '16:9',
  '21:9',
] as const;

const IMAGE_SIZES = ['1K', '2K', '4K'] as const;

export function ArtworkStudio() {
  const [prompt, setPrompt] = useState(
    'Minimalist editorial podcast cover art for a Bengali voice broadcast studio, warm studio microphone silhouette on deep slate and teal backdrop, clean typographic balance',
  );
  const [aspectRatio, setAspectRatio] = useState<string>('1:1');
  const [imageSize, setImageSize] = useState<'1K' | '2K' | '4K'>('1K');
  const [model, setModel] = useState<
    'gemini-3-pro-image-preview' | 'gemini-nano-banana-2.1'
  >('gemini-3-pro-image-preview');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [imageUrl, setImageUrl] = useState<string | null>(null);

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (loading || !prompt.trim()) return;
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/artwork/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, aspectRatio, imageSize, model }),
      });
      const data = (await res.json()) as {
        imageDataUrl?: string;
        error?: string;
      };
      if (!res.ok || !data.imageDataUrl) {
        setError(
          data.error ||
            'Artwork generation requires a paid Gemini API key in Settings > Secrets.',
        );
      } else {
        setImageUrl(data.imageDataUrl);
      }
    } catch {
      setError('Failed to contact artwork generation service.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
      <form
        onSubmit={handleGenerate}
        className="space-y-5 rounded-xl border border-slate-200 bg-white p-6 lg:col-span-5"
      >
        <div>
          <h2 className="text-base font-semibold text-slate-900">
            বট ও অডিও কভার আর্ট জেনারেটর
          </h2>
          <p className="mt-1 text-xs text-slate-500">
            আপনার টেলিগ্রাম চ্যানেল, পডকাস্ট বা অডিও ক্লিপের জন্য কাস্টম রেজোলিউশন ও অ্যাসপেক্ট রেশিও অনুযায়ী স্টুডিও কভার তৈরি করুন।
          </p>
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-700">
            ইমেজ মডেল (Studio Model)
          </label>
          <select
            value={model}
            onChange={(e) =>
              setModel(
                e.target.value as
                  | 'gemini-3-pro-image-preview'
                  | 'gemini-nano-banana-2.1',
              )
            }
            className="mt-1.5 h-10 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs text-slate-900 focus:border-teal-700 focus:outline-none"
          >
            <option value="gemini-3-pro-image-preview">
              gemini-3-pro-image-preview (Studio Quality)
            </option>
            <option value="gemini-nano-banana-2.1">
              gemini-nano-banana-2.1 (General & High-Res)
            </option>
          </select>
        </div>

        <div>
          <span className="block text-xs font-medium text-slate-700">
            ইমেজ সাইজ (Resolution)
          </span>
          <div className="mt-2 grid grid-cols-3 gap-2">
            {IMAGE_SIZES.map((sz) => (
              <button
                key={sz}
                type="button"
                onClick={() => setImageSize(sz)}
                className={`h-9 rounded-lg border font-mono text-xs font-medium transition-colors ${
                  imageSize === sz
                    ? 'border-teal-700 bg-teal-50 text-teal-900'
                    : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                }`}
              >
                {sz}
              </button>
            ))}
          </div>
        </div>

        <div>
          <span className="block text-xs font-medium text-slate-700">
            অ্যাসপেক্ট রেশিও (Aspect Ratio)
          </span>
          <div className="mt-2 grid grid-cols-4 gap-2">
            {ASPECT_RATIOS.map((ar) => (
              <button
                key={ar}
                type="button"
                onClick={() => setAspectRatio(ar)}
                className={`h-9 rounded-lg border font-mono text-xs font-medium transition-colors ${
                  aspectRatio === ar
                    ? 'border-teal-700 bg-teal-50 text-teal-900'
                    : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                }`}
              >
                {ar}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-xs font-medium text-slate-700">
            আর্টওয়ার্ক প্রম্পট
          </label>
          <textarea
            rows={4}
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            className="mt-1.5 w-full rounded-lg border border-slate-200 bg-slate-50 p-3 text-xs leading-relaxed text-slate-900 focus:border-teal-700 focus:bg-white focus:outline-none"
          />
        </div>

        {error && (
          <div className="rounded-lg border border-amber-200 bg-amber-50 p-3 text-xs text-amber-900">
            {error}
          </div>
        )}

        <button
          type="submit"
          disabled={loading || !prompt.trim()}
          className="flex h-10 w-full items-center justify-center gap-2 rounded-lg bg-teal-700 px-4 text-sm font-medium text-white transition-colors hover:bg-teal-800 disabled:opacity-50"
        >
          <ImageIcon className="h-4 w-4" />
          <span>{loading ? 'কভার তৈরি হচ্ছে...' : 'কভার আর্ট জেনারেট করুন'}</span>
        </button>
      </form>

      <div className="flex flex-col justify-between rounded-xl border border-slate-200 bg-white p-6 lg:col-span-7">
        <div className="flex items-center justify-between gap-4">
          <div className="text-xs text-slate-500 font-mono tabular-nums">
            {model} · {imageSize} · {aspectRatio}
          </div>
          {imageUrl && (
            <a
              href={imageUrl}
              download={`banglavoice-cover-${imageSize}.png`}
              className="flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs font-medium text-slate-700 hover:bg-slate-100 whitespace-nowrap shrink-0"
            >
              <Download className="h-3.5 w-3.5" />
              <span>PNG ডাউনলোড</span>
            </a>
          )}
        </div>

        <div className="mt-4 flex min-h-[420px] flex-1 items-center justify-center overflow-hidden rounded-lg border border-dashed border-slate-200 bg-slate-50 p-4">
          {imageUrl ? (
            <img
              src={imageUrl}
              alt="Generated podcast cover art"
              referrerPolicy="no-referrer"
              className="max-h-[460px] rounded-lg object-contain"
            />
          ) : (
            <div className="text-center text-xs text-slate-500">
              সাইজ (1K/2K/4K) এবং Aspect Ratio নির্বাচন করে কভার আর্ট জেনারেট করুন।
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
