import {
  ArrowLeft,
  BookOpen,
  Check,
  CheckCircle2,
  Copy,
  CreditCard,
  ShieldCheck,
  Wallet,
  X,
  Zap,
} from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import type {
  BotUser,
  PaymentAccount,
  PaymentRequest,
  PublicBotConfig,
  TransactionRecord,
} from '../types.ts';

interface WalletModalProps {
  open: boolean;
  onClose: () => void;
  activeUser: BotUser | undefined;
  config: PublicBotConfig | null;
  transactions: TransactionRecord[];
  paymentRequests: PaymentRequest[];
  onDataChanged: () => void;
}

export function WalletModal({
  open,
  onClose,
  activeUser,
  config,
  transactions,
  paymentRequests,
  onDataChanged,
}: WalletModalProps) {
  const enabledAccounts = useMemo(
    () => (config?.paymentAccounts ?? []).filter((a) => a.enabled),
    [config?.paymentAccounts],
  );

  const [selectedAccountId, setSelectedAccountId] = useState<string>('');
  const [customMethod, setCustomMethod] = useState<string>('bKash');
  const [amount, setAmount] = useState<string>('100');
  const [referenceNote, setReferenceNote] = useState<string>('');
  const [step, setStep] = useState<'form' | 'confirm' | 'submitted'>('form');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submittedPayment, setSubmittedPayment] =
    useState<PaymentRequest | null>(null);
  const [autoApproved, setAutoApproved] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    if (!open) return;
    setStep('form');
    setError(null);
    setSubmittedPayment(null);
    setAutoApproved(false);
    if (enabledAccounts.length > 0) {
      setSelectedAccountId((prev) =>
        enabledAccounts.some((a) => a.id === prev) ? prev : enabledAccounts[0].id,
      );
    } else {
      setSelectedAccountId('');
    }
  }, [open, enabledAccounts]);

  if (!open) return null;

  const selectedAccount: PaymentAccount | undefined = enabledAccounts.find(
    (a) => a.id === selectedAccountId,
  );

  const effectiveMethod = selectedAccount
    ? selectedAccount.method
    : customMethod.trim() || 'bKash';
  const effectiveAccountNumber = selectedAccount?.accountNumber ?? '';
  const parsedAmount = Number(amount);

  const userTransactions = activeUser
    ? transactions.filter((t) => t.userId === activeUser.id).slice(0, 6)
    : [];
  const userRequests = activeUser
    ? paymentRequests.filter((p) => p.userId === activeUser.id).slice(0, 4)
    : [];

  const handleCopyNumber = async (acc: PaymentAccount) => {
    await navigator.clipboard.writeText(acc.accountNumber);
    setCopiedId(acc.id);
    setTimeout(() => setCopiedId(null), 1600);
  };

  const handleProceedConfirm = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!parsedAmount || Number.isNaN(parsedAmount) || parsedAmount <= 0) {
      setError('সঠিক টাকার পরিমাণ লিখুন (যেমন: 100)।');
      return;
    }
    if (!referenceNote.trim() || referenceNote.trim().length < 3) {
      setError('সেন্ডার নম্বর অথবা TrxID সঠিকভাবে লিখুন।');
      return;
    }
    setStep('confirm');
  };

  const handleFinalSubmit = async () => {
    if (submitting) return;
    setSubmitting(true);
    setError(null);
    try {
      const res = await fetch('/api/payments/request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: activeUser?.id,
          amount: parsedAmount,
          method: selectedAccount
            ? `${selectedAccount.method} (${selectedAccount.accountType})`
            : effectiveMethod,
          accountNumber: effectiveAccountNumber || undefined,
          referenceNote: referenceNote.trim(),
        }),
      });
      const data = (await res.json()) as {
        payment?: PaymentRequest;
        autoApproved?: boolean;
        error?: string;
      };
      if (!res.ok || !data.payment) {
        setError(data.error || 'পেমেন্ট রিকোয়েস্ট পাঠানো যায়নি।');
        setStep('form');
      } else {
        setSubmittedPayment(data.payment);
        setAutoApproved(Boolean(data.autoApproved));
        setReferenceNote('');
        setStep('submitted');
        onDataChanged();
      }
    } catch {
      setError('সার্ভারের সাথে সংযোগ ব্যর্থ হয়েছে।');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="wallet-modal-title"
    >
      <div className="flex max-h-[90vh] w-full max-w-2xl flex-col overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-200 px-6 py-4">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-teal-50 text-teal-700">
              <Wallet className="h-5 w-5" />
            </div>
            <div>
              <h2
                id="wallet-modal-title"
                className="text-base font-semibold text-slate-900"
              >
                ওয়ালেট ও ব্যালেন্স রিচার্জ
              </h2>
              <p className="text-xs text-slate-500">
                {activeUser
                  ? `${activeUser.firstName} (@${activeUser.username}) · বর্তমান ব্যালেন্স: ৳${activeUser.balance.toFixed(2)}`
                  : 'অ্যাকাউন্ট তথ্য লোড হচ্ছে...'}
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close wallet dialog"
            className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 hover:text-slate-900"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Body */}
        <div className="flex-1 space-y-5 overflow-y-auto p-6">
          {/* Active Payment Numbers from Admin */}
          <div className="rounded-xl border border-slate-200 bg-slate-50 p-4">
            <div className="flex items-center justify-between gap-2">
              <h3 className="text-xs font-semibold uppercase tracking-wide text-slate-700">
                পেমেন্ট পাঠানোর নম্বরসমূহ (Admin Verified)
              </h3>
              <span className="font-mono text-[11px] text-slate-500 tabular-nums">
                {enabledAccounts.length}টি সক্রিয় নম্বর
              </span>
            </div>

            {enabledAccounts.length === 0 ? (
              <div className="mt-3 rounded-lg border border-dashed border-slate-300 bg-white p-4 text-xs text-slate-600">
                অ্যাডমিন এখনো কোনো পেমেন্ট নম্বর যুক্ত করেননি। অ্যাডমিন প্যানেল থেকে bKash / Nagad / Rocket নম্বর যুক্ত করলে এখানে স্বয়ংক্রিয়ভাবে দেখাবে।
              </div>
            ) : (
              <div className="mt-3 grid grid-cols-1 gap-2.5 sm:grid-cols-2">
                {enabledAccounts.map((acc) => {
                  const isSelected = selectedAccount?.id === acc.id;
                  return (
                    <div
                      key={acc.id}
                      onClick={() => {
                        setSelectedAccountId(acc.id);
                        if (step === 'submitted') setStep('form');
                      }}
                      className={`cursor-pointer rounded-lg border p-3 transition-colors ${
                        isSelected
                          ? 'border-teal-700 bg-white ring-1 ring-teal-700/20'
                          : 'border-slate-200 bg-white hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-semibold text-slate-900">
                          {acc.method}
                        </span>
                        <span className="text-[11px] font-medium text-teal-700">
                          {acc.accountType}
                        </span>
                      </div>
                      <div className="mt-1.5 flex items-center justify-between gap-2">
                        <span className="font-mono text-sm font-bold text-slate-900 tabular-nums">
                          {acc.accountNumber}
                        </span>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            void handleCopyNumber(acc);
                          }}
                          className="inline-flex h-7 items-center gap-1 rounded border border-slate-200 bg-slate-50 px-2 text-[11px] font-medium text-slate-700 hover:bg-slate-100"
                        >
                          {copiedId === acc.id ? (
                            <>
                              <Check className="h-3 w-3 text-emerald-600" />
                              <span>কপি হয়েছে</span>
                            </>
                          ) : (
                            <>
                              <Copy className="h-3 w-3" />
                              <span>কপি</span>
                            </>
                          )}
                        </button>
                      </div>
                      {acc.note && (
                        <p className="mt-1 text-[11px] text-slate-500">
                          {acc.note}
                        </p>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Step-by-Step User Payment & TrxID Guide Section */}
          <div className="rounded-xl border border-teal-200 bg-teal-50/40 p-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-xs font-semibold text-teal-900">
                <BookOpen className="h-4 w-4 text-teal-700" />
                <span>কিভাবে টাকা পাঠাবেন ও ট্রানজেকশন আইডি (TrxID) দেবেন</span>
              </div>
              {config?.autoVerifyPayments && (
                <span className="inline-flex items-center gap-1 font-mono text-[11px] font-semibold text-emerald-700">
                  <Zap className="h-3 w-3" />
                  <span>Auto TrxID Verify সক্রিয়</span>
                </span>
              )}
            </div>
            <div className="mt-2 space-y-1.5 whitespace-pre-line text-xs leading-relaxed text-slate-700">
              {config?.paymentInstructions?.trim() ||
                '১. উপরের যেকোনো একটি সক্রিয় নম্বর কপি করে আপনার bKash / Nagad / Rocket অ্যাপ থেকে Send Money করুন (Agent নম্বর হলে Cash Out করুন)।\n' +
                  '২. টাকা পাঠানো সফল হলে মেসেজ বা অ্যাপ থেকে Transaction ID (TrxID) সংগ্রহ করুন।\n' +
                  '৩. নিচের ঘরে কত টাকা পাঠিয়েছেন এবং আপনার সেন্ডার নম্বর বা TrxID লিখুন।\n' +
                  '৪. সব তথ্য রিভিউ ও কনফার্ম করলে অ্যাডমিন যাচাই করে আপনার ব্যালেন্স যুক্ত করে দেবেন।'}
            </div>
          </div>

          {/* Step 1: Payment Details Form */}
          {step === 'form' && (
            <form onSubmit={handleProceedConfirm} className="space-y-4">
              {enabledAccounts.length === 0 && (
                <div>
                  <label className="block text-xs font-medium text-slate-700">
                    পেমেন্ট মাধ্যম
                  </label>
                  <select
                    value={customMethod}
                    onChange={(e) => setCustomMethod(e.target.value)}
                    className="mt-1.5 h-10 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs text-slate-900 focus:border-teal-700 focus:bg-white focus:outline-none"
                  >
                    <option value="bKash">bKash</option>
                    <option value="Nagad">Nagad</option>
                    <option value="Rocket">Rocket</option>
                    <option value="Upay">Upay</option>
                    <option value="Bank Transfer">Bank Transfer</option>
                  </select>
                </div>
              )}

              <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                <div>
                  <label className="block text-xs font-medium text-slate-700">
                    রিচার্জের পরিমাণ (৳ টাকা)
                  </label>
                  <input
                    type="number"
                    min={1}
                    step="1"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value)}
                    placeholder="যেমন: 100"
                    className="mt-1.5 h-10 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-sm tabular-nums text-slate-900 focus:border-teal-700 focus:bg-white focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-700">
                    সেন্ডার নম্বর / ট্রানজেকশন আইডি (TrxID)
                  </label>
                  <input
                    type="text"
                    value={referenceNote}
                    onChange={(e) => setReferenceNote(e.target.value)}
                    placeholder="যেমন: 017XXXXXXXX / Trx9A8B7C"
                    className="mt-1.5 h-10 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-xs text-slate-900 focus:border-teal-700 focus:bg-white focus:outline-none"
                  />
                </div>
              </div>

              {error && (
                <div className="rounded-lg border border-red-200 bg-red-50 px-3.5 py-2.5 text-xs font-medium text-red-800">
                  {error}
                </div>
              )}

              <div className="flex items-center justify-between gap-3 border-t border-slate-100 pt-4">
                <p className="text-xs text-slate-500">
                  সব তথ্য যাচাই করে পরবর্তী ধাপে কনফার্ম করলেই রিকোয়েস্ট অ্যাডমিনের কাছে যাবে।
                </p>
                <button
                  type="submit"
                  className="inline-flex h-10 items-center gap-2 rounded-lg bg-teal-700 px-5 text-xs font-medium text-white hover:bg-teal-800 whitespace-nowrap shrink-0"
                >
                  <CreditCard className="h-4 w-4" />
                  <span>রিভিউ ও কনফার্ম করুন</span>
                </button>
              </div>
            </form>
          )}

          {/* Step 2: Explicit Confirmation Before Sending Request */}
          {step === 'confirm' && (
            <div className="rounded-xl border border-teal-200 bg-teal-50/40 p-5">
              <div className="flex items-center gap-2 text-sm font-semibold text-slate-900">
                <ShieldCheck className="h-4 w-4 text-teal-700" />
                <span>পেমেন্ট তথ্য কনফার্মেশন</span>
              </div>
              <p className="mt-1 text-xs text-slate-600">
                অনুগ্রহ করে নিচের সব তথ্য মিলিয়ে দেখুন। “কনফার্ম ও রিকোয়েস্ট পাঠান” বাটনে ক্লিক করলে রিকোয়েস্টটি অ্যাডমিনের কাছে পাঠানো হবে।
              </p>

              <dl className="mt-4 grid grid-cols-1 gap-3 rounded-lg border border-slate-200 bg-white p-4 text-xs sm:grid-cols-2">
                <div>
                  <dt className="text-slate-500">পেমেন্ট মাধ্যম</dt>
                  <dd className="mt-0.5 font-semibold text-slate-900">
                    {selectedAccount
                      ? `${selectedAccount.method} (${selectedAccount.accountType})`
                      : effectiveMethod}
                  </dd>
                </div>
                <div>
                  <dt className="text-slate-500">প্রাপক নম্বর</dt>
                  <dd className="mt-0.5 font-mono font-semibold text-slate-900 tabular-nums">
                    {effectiveAccountNumber || 'অ্যাডমিন নির্ধারিত মাধ্যম'}
                  </dd>
                </div>
                <div>
                  <dt className="text-slate-500">পরিমাণ</dt>
                  <dd className="mt-0.5 font-mono text-sm font-bold text-teal-700 tabular-nums">
                    ৳{parsedAmount}
                  </dd>
                </div>
                <div>
                  <dt className="text-slate-500">সেন্ডার / TrxID</dt>
                  <dd className="mt-0.5 font-mono font-semibold text-slate-900">
                    {referenceNote.trim()}
                  </dd>
                </div>
              </dl>

              {error && (
                <div className="mt-3 rounded-lg border border-red-200 bg-red-50 px-3.5 py-2.5 text-xs font-medium text-red-800">
                  {error}
                </div>
              )}

              <div className="mt-4 flex flex-wrap items-center justify-end gap-3">
                <button
                  type="button"
                  disabled={submitting}
                  onClick={() => setStep('form')}
                  className="inline-flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-4 text-xs font-medium text-slate-700 hover:bg-slate-50"
                >
                  <ArrowLeft className="h-3.5 w-3.5" />
                  <span>সংশোধন করুন</span>
                </button>
                <button
                  type="button"
                  disabled={submitting}
                  onClick={() => void handleFinalSubmit()}
                  className="inline-flex h-9 items-center gap-1.5 rounded-lg bg-emerald-700 px-5 text-xs font-medium text-white hover:bg-emerald-800 disabled:opacity-50 whitespace-nowrap shrink-0"
                >
                  <CheckCircle2 className="h-4 w-4" />
                  <span>
                    {submitting
                      ? 'পাঠানো হচ্ছে...'
                      : 'কনফার্ম ও রিকোয়েস্ট পাঠান'}
                  </span>
                </button>
              </div>
            </div>
          )}

          {/* Step 3: Request Sent or Auto-Verified */}
          {step === 'submitted' && submittedPayment && (
            <div className="rounded-xl border border-emerald-200 bg-emerald-50 p-5 text-xs text-emerald-950">
              <div className="flex items-center gap-2 text-sm font-semibold text-emerald-800">
                {autoApproved ? (
                  <Zap className="h-4 w-4 text-emerald-700" />
                ) : (
                  <CheckCircle2 className="h-4 w-4" />
                )}
                <span>
                  {autoApproved
                    ? 'পেমেন্ট স্বয়ংক্রিয়ভাবে ভেরিফাই ও ব্যালেন্স যুক্ত হয়েছে!'
                    : 'পেমেন্ট রিকোয়েস্ট সফলভাবে পাঠানো হয়েছে!'}
                </span>
              </div>
              <p className="mt-1.5 leading-relaxed text-emerald-900">
                রিকোয়েস্ট আইডি{' '}
                <span className="font-mono font-semibold">{submittedPayment.id}</span> · পরিমাণ{' '}
                <span className="font-mono font-semibold">
                  {autoApproved ? '+' : ''}৳{submittedPayment.amount}
                </span>
                {autoApproved
                  ? '। আপনার TrxID স্বয়ংক্রিয়ভাবে ভেরিফাই হয়ে ব্যালেন্সে যোগ হয়েছে।'
                  : '। পেমেন্ট SMS ম্যাচ হলে স্বয়ংক্রিয়ভাবে (অথবা অ্যাডমিন Approve করলে) আপনার ব্যালেন্স যুক্ত হয়ে যাবে।'}
              </p>
              <button
                type="button"
                onClick={() => setStep('form')}
                className="mt-3 rounded-lg border border-emerald-300 bg-white px-3.5 py-1.5 text-xs font-medium text-emerald-800 hover:bg-emerald-100"
              >
                আরেকটি পেমেন্ট রিকোয়েস্ট দিন
              </button>
            </div>
          )}

          {/* Recent User Payment Requests & Transactions */}
          {(userRequests.length > 0 || userTransactions.length > 0) && (
            <div className="grid grid-cols-1 gap-4 border-t border-slate-100 pt-4 sm:grid-cols-2">
              <div>
                <h4 className="text-xs font-semibold text-slate-700">
                  সাম্প্রতিক পেমেন্ট রিকোয়েস্ট
                </h4>
                <div className="mt-2 space-y-1.5">
                  {userRequests.length === 0 ? (
                    <p className="text-[11px] text-slate-400">কোনো রিকোয়েস্ট নেই</p>
                  ) : (
                    userRequests.map((req) => (
                      <div
                        key={req.id}
                        className="flex items-center justify-between rounded-lg border border-slate-200 px-3 py-2 text-xs"
                      >
                        <div className="min-w-0">
                          <div className="truncate font-medium text-slate-900">
                            {req.method} · ৳{req.amount}
                          </div>
                          <div className="truncate font-mono text-[11px] text-slate-500">
                            {req.referenceNote}
                          </div>
                        </div>
                        <span
                          className={`font-mono text-[11px] font-semibold uppercase ${
                            req.status === 'approved'
                              ? 'text-emerald-700'
                              : req.status === 'rejected'
                                ? 'text-red-700'
                                : 'text-amber-700'
                          }`}
                        >
                          {req.status}
                        </span>
                      </div>
                    ))
                  )}
                </div>
              </div>

              <div>
                <h4 className="text-xs font-semibold text-slate-700">
                  সাম্প্রতিক ব্যালেন্স লেনদেন
                </h4>
                <div className="mt-2 space-y-1.5">
                  {userTransactions.length === 0 ? (
                    <p className="text-[11px] text-slate-400">কোনো লেনদেন নেই</p>
                  ) : (
                    userTransactions.map((tx) => (
                      <div
                        key={tx.id}
                        className="flex items-center justify-between rounded-lg border border-slate-200 px-3 py-2 text-xs"
                      >
                        <span className="truncate pr-2 text-slate-700">
                          {tx.description}
                        </span>
                        <span
                          className={`font-mono font-semibold tabular-nums shrink-0 ${
                            tx.amount >= 0 ? 'text-emerald-700' : 'text-red-700'
                          }`}
                        >
                          {tx.amount >= 0 ? '+' : ''}৳{tx.amount}
                        </span>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
