import { Bot, Clock, RefreshCw, Send, Shield, Sparkles, UserCheck } from 'lucide-react';
import { useEffect, useRef, useState } from 'react';
import type {
  BotMessagePayload,
  BotUser,
  VideoProjectJob,
  VoiceGeneration,
  VoiceJob,
} from '../types.ts';
import { AudioPlayer } from './AudioPlayer.tsx';
import {
  computeLiveTiming,
  formatClockMMSS,
  StageStepper,
  useLiveNowMs,
} from './LiveProcessMonitor.tsx';

interface TelegramSimulatorProps {
  users: BotUser[];
  activeUserId: string;
  onSelectUser: (id: string) => void;
  onDataChanged: () => void;
}

const SAMPLE_BANGLA_SCRIPTS = [
  'আসসালামু আলাইকুম! বাংলা এআই ভয়েস জেনারেটর বটে আপনাকে স্বাগতম। এখন আপনার যেকোনো বাংলা লেখা মুহূর্তেই প্রাকৃতিক কণ্ঠস্বরে রূপান্তরিত হবে।',
  'আজকের বিশেষ অফার! আমাদের নতুন অনলাইন কোর্সে ভর্তি হলেই পাচ্ছেন ৫০ শতাংশ ছাড়। বিস্তারিত জানতে এখনই ভিজিট করুন।',
  'বর্ষার এই শান্ত বিকেলে জানালার পাশে বসে এক কাপ গরম চা হাতে পুরোনো দিনের গল্প শুনতে কার না ভালো লাগে! সময় যেন থমকে দাঁড়ায় এই মধুর মুহূর্তে।',
];

function renderFormattedBotText(text: string) {
  const parts = text.split(/(\*\*[^*]+\*\*)/g);
  return parts.map((part, i) => {
    if (part.startsWith('**') && part.endsWith('**')) {
      return (
        <strong key={i} className="font-semibold text-slate-900">
          {part.slice(2, -2)}
        </strong>
      );
    }
    return <span key={i}>{part}</span>;
  });
}

export function TelegramSimulator({
  users,
  activeUserId,
  onSelectUser,
  onDataChanged,
}: TelegramSimulatorProps) {
  const [messages, setMessages] = useState<BotMessagePayload[]>([]);
  const [inputText, setInputText] = useState('');
  const [loading, setLoading] = useState(false);
  const [initializedFor, setInitializedFor] = useState<string>('');
  const [activeJobs, setActiveJobs] = useState<Record<string, VoiceJob>>({});
  const [activeVideoJobs, setActiveVideoJobs] = useState<
    Record<string, VideoProjectJob>
  >({});
  const chatEndRef = useRef<HTMLDivElement | null>(null);

  const activeUser = users.find((u) => u.id === activeUserId) ?? users[0];

  const hasAnyActiveSimJob =
    Object.values(activeJobs).some(
      (j) => j.status !== 'completed' && j.status !== 'failed',
    ) ||
    Object.values(activeVideoJobs).some(
      (v) => v.status !== 'completed' && v.status !== 'failed',
    );
  const nowMs = useLiveNowMs(hasAnyActiveSimJob);

  // Hydrate any already running voice/video jobs when entering Telegram tab
  useEffect(() => {
    void Promise.all([
      fetch('/api/jobs'),
      fetch('/api/video/jobs?limit=10'),
    ])
      .then(async ([jr, vr]) => {
        if (jr.ok) {
          const jData = (await jr.json()) as { jobs?: VoiceJob[] };
          const runningVoices = (jData.jobs ?? []).filter(
            (j) => j.status !== 'completed' && j.status !== 'failed',
          );
          if (runningVoices.length > 0) {
            setActiveJobs((prev) => {
              const next = { ...prev };
              for (const j of runningVoices) next[j.id] = j;
              return next;
            });
          }
        }
        if (vr.ok) {
          const vData = (await vr.json()) as { jobs?: VideoProjectJob[] };
          const runningVideos = (vData.jobs ?? []).filter(
            (v) => v.status !== 'completed' && v.status !== 'failed',
          );
          if (runningVideos.length > 0) {
            setActiveVideoJobs((prev) => {
              const next = { ...prev };
              for (const v of runningVideos) next[v.id] = v;
              return next;
            });
          }
        }
      })
      .catch(() => {});
  }, [activeUser?.id]);

  // Poll any active background jobs referenced in chat bubbles
  useEffect(() => {
    const pendingIds = Object.values(activeJobs)
      .filter(
        (j) =>
          j.status !== 'completed' &&
          j.status !== 'failed',
      )
      .map((j) => j.id);

    if (pendingIds.length === 0) return;

    const timer = setInterval(() => {
      for (const jobId of pendingIds) {
        void fetch(`/api/jobs/${jobId}`)
          .then((r) => r.json())
          .then(
            (data: {
              job?: VoiceJob;
              generation?: VoiceGeneration;
            }) => {
              const job = data.job;
              if (!job) return;
              setActiveJobs((prev) => ({ ...prev, [job.id]: job }));

              if (job.status === 'completed' && data.generation) {
                const gen = data.generation;
                setMessages((prev) =>
                  prev.map((m) => {
                    if (m.jobId !== job.id) return m;
                    return {
                      ...m,
                      jobId: undefined,
                      text:
                        `✅ **ভয়েস তৈরি সম্পূর্ণ হয়েছে!**\n` +
                        `কণ্ঠস্বর: ${gen.voiceNameBn} · অংশ: ${job.totalParts}টি · দৈর্ঘ্য: ${gen.durationSec}s` +
                        (typeof job.elapsedSec === 'number'
                          ? ` · ⏱️ সময়: ${job.elapsedSec}s`
                          : ''),
                      audio: {
                        generationId: gen.id,
                        url: gen.audioUrl,
                        title: `Bangla Voice - ${gen.voiceNameBn}`,
                        performer: 'BanglaVoice AI Bot',
                        durationSec: gen.durationSec,
                        fileSizeBytes: gen.fileSizeBytes,
                      },
                      buttons: [
                        [
                          {
                            text: '🔄 পুনরায় জেনারেট',
                            callback_data: `regen:${gen.id}`,
                          },
                          {
                            text: '🎚️ স্পিড ও পিচ',
                            callback_data: 'menu:settings',
                          },
                        ],
                        [
                          {
                            text: '🎤 ভয়েস পরিবর্তন',
                            callback_data: 'menu:create',
                          },
                          { text: '🏠 মেইন মেনু', callback_data: 'menu:main' },
                        ],
                      ],
                    };
                  }),
                );
                onDataChanged();
              } else if (job.status === 'failed') {
                setMessages((prev) =>
                  prev.map((m) =>
                    m.jobId === job.id
                      ? {
                          ...m,
                          jobId: undefined,
                          text: `❌ ভয়েস তৈরি ব্যর্থ হয়েছে: ${job.error || 'Error'}`,
                        }
                      : m,
                  ),
                );
              }
            },
          )
          .catch(() => {});
      }
    }, 800);

    return () => clearInterval(timer);
  }, [activeJobs, onDataChanged]);

  // Poll any active background Video jobs referenced in chat bubbles
  useEffect(() => {
    const pendingVideoIds = Object.values(activeVideoJobs)
      .filter((v) => v.status !== 'completed' && v.status !== 'failed')
      .map((v) => v.id);

    if (pendingVideoIds.length === 0) return;

    const timer = setInterval(() => {
      for (const vidId of pendingVideoIds) {
        void fetch(`/api/video/jobs/${vidId}`)
          .then((r) => r.json())
          .then((data: { job?: VideoProjectJob }) => {
            const vJob = data.job;
            if (!vJob) return;
            setActiveVideoJobs((prev) => ({ ...prev, [vJob.id]: vJob }));
            if (vJob.status === 'completed' && vJob.outputVideoUrl) {
              setMessages((prev) =>
                prev.map((m) =>
                  m.videoJobId !== vJob.id
                    ? m
                    : {
                        ...m,
                        videoJobId: undefined,
                        text:
                          `🎬 **AI ভিডিও সম্পন্ন হয়েছে!**\n• প্রজেক্ট: **${vJob.title}**\n• ফরম্যাট: ${vJob.aspectRatio} · ${vJob.resolution.toUpperCase()} · ${vJob.durationSec ?? '?'}s` +
                          (typeof vJob.elapsedSec === 'number'
                            ? `\n• ⏱️ মোট সময় লেগেছে: ${vJob.elapsedSec}s`
                            : ''),
                        video: {
                          jobId: vJob.id,
                          url: vJob.outputVideoUrl!,
                          title: vJob.title,
                          durationSec: vJob.durationSec ?? 0,
                          fileSizeBytes: vJob.fileSizeBytes ?? 0,
                        },
                        buttons: [
                          [{ text: '🎬 নতুন ভিডিও তৈরি', callback_data: 'menu:video' }],
                          [{ text: '🏠 মেইন মেনু', callback_data: 'menu:main' }],
                        ],
                      },
                ),
              );
              onDataChanged();
            } else if (vJob.status === 'failed') {
              setMessages((prev) =>
                prev.map((m) =>
                  m.videoJobId === vJob.id
                    ? {
                        ...m,
                        videoJobId: undefined,
                        text: `❌ ভিডিও তৈরি ব্যর্থ হয়েছে: ${vJob.error || 'Error'}`,
                      }
                    : m,
                ),
              );
            }
          })
          .catch(() => {});
      }
    }, 900);

    return () => clearInterval(timer);
  }, [activeVideoJobs, onDataChanged]);

  const sendCommandOrText = async (payload: {
    text?: string;
    callbackData?: string;
    echoUserText?: string;
  }) => {
    if (loading) return;
    if (payload.echoUserText) {
      setMessages((prev) => [
        ...prev,
        {
          id: `usr-${Date.now()}`,
          sender: 'user',
          text: payload.echoUserText!,
          timestamp: new Date().toLocaleTimeString('en-US', {
            hour: '2-digit',
            minute: '2-digit',
          }),
        },
      ]);
    }

    setLoading(true);
    try {
      const res = await fetch('/api/bot/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: activeUser?.id,
          text: payload.text,
          callbackData: payload.callbackData,
        }),
      });
      const data = (await res.json()) as {
        messages?: BotMessagePayload[];
        queuedJob?: VoiceJob;
        queuedVideoJob?: VideoProjectJob;
        error?: string;
      };
      if (data.queuedJob) {
        setActiveJobs((prev) => ({
          ...prev,
          [data.queuedJob!.id]: data.queuedJob!,
        }));
      }
      if (data.queuedVideoJob) {
        setActiveVideoJobs((prev) => ({
          ...prev,
          [data.queuedVideoJob!.id]: data.queuedVideoJob!,
        }));
      }
      if (data.messages) {
        setMessages((prev) => [...prev, ...data.messages!]);
      } else if (data.error) {
        setMessages((prev) => [
          ...prev,
          {
            id: `err-${Date.now()}`,
            sender: 'bot',
            text: `❌ ${data.error}`,
            timestamp: new Date().toLocaleTimeString('en-US', {
              hour: '2-digit',
              minute: '2-digit',
            }),
          },
        ]);
      }
      onDataChanged();
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (activeUser && initializedFor !== activeUser.id) {
      setInitializedFor(activeUser.id);
      setMessages([]);
      void sendCommandOrText({ text: '/start' });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeUser?.id]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = inputText.trim();
    if (!trimmed || loading) return;
    setInputText('');
    void sendCommandOrText({ text: trimmed, echoUserText: trimmed });
  };

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
      {/* Left: Telegram Chat Simulator */}
      <div className="lg:col-span-8">
        <div className="flex h-[680px] flex-col overflow-hidden rounded-xl border border-slate-200 bg-white">
          <div className="flex items-center justify-between gap-4 border-b border-slate-200 bg-slate-900 px-5 py-3.5 text-white">
            <div className="flex items-center gap-3 min-w-0">
              <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-teal-600 text-white">
                <Bot className="h-5 w-5" />
              </div>
              <div className="min-w-0">
                <h2 className="truncate text-sm font-semibold text-white">
                  BanglaVoice All-in-One AI Bot
                </h2>
                <p className="truncate text-xs text-slate-300">
                  @controller67755382bot · ChatGPT AI, Image, Video, Voice, Docs, Code & Research
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                type="button"
                onClick={() =>
                  void sendCommandOrText({
                    text: '/start',
                    echoUserText: '/start',
                  })
                }
                disabled={loading}
                className="rounded-lg border border-slate-700 bg-slate-800 px-3 py-1.5 font-mono text-xs text-slate-100 transition-colors hover:bg-slate-700 whitespace-nowrap shrink-0"
              >
                /start
              </button>
              <button
                type="button"
                onClick={() =>
                  void sendCommandOrText({
                    text: '/admin',
                    echoUserText: '/admin',
                  })
                }
                disabled={loading}
                className="flex items-center gap-1.5 rounded-lg border border-teal-600 bg-teal-700 px-3 py-1.5 font-mono text-xs text-white transition-colors hover:bg-teal-600 whitespace-nowrap shrink-0"
              >
                <Shield className="h-3.5 w-3.5" />
                <span>/admin</span>
              </button>
              <button
                type="button"
                onClick={() =>
                  void sendCommandOrText({
                    text: '/profile',
                    echoUserText: '/profile',
                  })
                }
                disabled={loading}
                className="rounded-lg border border-slate-700 bg-slate-800 px-3 py-1.5 font-mono text-xs text-slate-100 transition-colors hover:bg-slate-700 whitespace-nowrap shrink-0"
              >
                /profile
              </button>
            </div>
          </div>

          <div className="flex-1 space-y-4 overflow-y-auto bg-slate-100/80 p-5">
            {messages.map((msg) => {
              const isUser = msg.sender === 'user';
              const liveJob = msg.jobId ? activeJobs[msg.jobId] : undefined;
              const pct = liveJob
                ? (liveJob.progressPct ??
                  Math.min(
                    100,
                    Math.round(
                      (liveJob.currentPart / Math.max(1, liveJob.totalParts)) *
                        100,
                    ),
                  ))
                : 0;

              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${
                    isUser ? 'items-end' : 'items-start'
                  }`}
                >
                  <div
                    className={`max-w-[85%] rounded-xl px-4 py-3 text-sm leading-relaxed ${
                      isUser
                        ? 'bg-teal-700 text-white'
                        : 'border border-slate-200 bg-white text-slate-800'
                    }`}
                  >
                    <div className="whitespace-pre-wrap break-words">
                      {isUser ? msg.text : renderFormattedBotText(msg.text)}
                    </div>

                    {liveJob && (() => {
                      const timing = computeLiveTiming(liveJob, nowMs);
                      const running =
                        liveJob.status !== 'completed' &&
                        liveJob.status !== 'failed';
                      return (
                        <div className="mt-3 rounded-lg border border-teal-200 bg-slate-50 p-3 space-y-2">
                          <div className="flex items-center justify-between gap-2 text-xs">
                            <span className="flex items-center gap-1.5 font-semibold text-teal-800">
                              {running && (
                                <span className="h-2 w-2 rounded-full bg-teal-600 animate-ping" />
                              )}
                              <span>{liveJob.statusText}</span>
                            </span>
                            <span className="font-mono font-semibold text-slate-700 tabular-nums shrink-0">
                              {liveJob.currentPart}/{liveJob.totalParts} ({pct}%)
                            </span>
                          </div>
                          <div className="h-2 w-full overflow-hidden rounded-full bg-slate-200">
                            <div
                              className={`h-full transition-all duration-300 ${
                                running ? 'bg-teal-700 animate-pulse' : 'bg-teal-700'
                              }`}
                              style={{ width: `${Math.max(8, pct)}%` }}
                            />
                          </div>
                          <StageStepper kind="voice" status={liveJob.status} />
                          <div className="flex flex-wrap items-center justify-between gap-2 font-mono text-[11px] tabular-nums">
                            <span className="inline-flex items-center gap-1 rounded bg-slate-900 px-2 py-0.5 font-semibold text-white">
                              {running && (
                                <RefreshCw className="h-3 w-3 animate-spin" />
                              )}
                              <Clock className="h-3 w-3" />
                              <span>
                                টাইমার: {formatClockMMSS(timing.liveElapsedSec)}
                              </span>
                            </span>
                            {timing.liveRemainingSec > 0 && running && (
                              <span className="font-semibold text-teal-700">
                                আনুমানিক বাকি: ~
                                {formatClockMMSS(timing.liveRemainingSec)}
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })()}

                    {msg.videoJobId &&
                      activeVideoJobs[msg.videoJobId] &&
                      (() => {
                        const vJob = activeVideoJobs[msg.videoJobId];
                        const timing = computeLiveTiming(vJob, nowMs);
                        const running =
                          vJob.status !== 'completed' &&
                          vJob.status !== 'failed';
                        return (
                          <div className="mt-3 rounded-lg border border-teal-200 bg-slate-50 p-3 space-y-2">
                            <div className="flex items-center justify-between gap-2 text-xs">
                              <span className="flex items-center gap-1.5 font-semibold text-teal-800">
                                {running && (
                                  <span className="h-2 w-2 rounded-full bg-teal-600 animate-ping" />
                                )}
                                <span>{vJob.statusText}</span>
                              </span>
                              <span className="font-mono font-semibold text-slate-700 tabular-nums shrink-0">
                                {vJob.progressPct}%
                              </span>
                            </div>
                            <div className="h-2 w-full overflow-hidden rounded-full bg-slate-200">
                              <div
                                className={`h-full transition-all duration-300 ${
                                  running
                                    ? 'bg-teal-700 animate-pulse'
                                    : 'bg-teal-700'
                                }`}
                                style={{
                                  width: `${Math.max(8, vJob.progressPct)}%`,
                                }}
                              />
                            </div>
                            <StageStepper kind="video" status={vJob.status} />
                            <div className="flex flex-wrap items-center justify-between gap-2 font-mono text-[11px] tabular-nums">
                              <span className="inline-flex items-center gap-1 rounded bg-slate-900 px-2 py-0.5 font-semibold text-white">
                                {running && (
                                  <RefreshCw className="h-3 w-3 animate-spin" />
                                )}
                                <Clock className="h-3 w-3" />
                                <span>
                                  টাইমার: {formatClockMMSS(timing.liveElapsedSec)}
                                </span>
                              </span>
                              {timing.liveRemainingSec > 0 && running && (
                                <span className="font-semibold text-teal-700">
                                  আনুমানিক বাকি: ~
                                  {formatClockMMSS(timing.liveRemainingSec)}
                                </span>
                              )}
                            </div>
                          </div>
                        );
                      })()}

                    {msg.audio && (
                      <div className="mt-3">
                        <AudioPlayer
                          url={msg.audio.url}
                          title={msg.audio.title}
                          durationSec={msg.audio.durationSec}
                          fileSizeBytes={msg.audio.fileSizeBytes}
                          compact
                        />
                      </div>
                    )}

                    {msg.video && (
                      <div className="mt-3 space-y-2">
                        <video
                          controls
                          playsInline
                          src={msg.video.url}
                          className="max-h-64 w-full rounded-lg border border-slate-200 bg-black"
                        />
                        <a
                          href={`${msg.video.url}?download=1`}
                          className="inline-block font-mono text-xs font-medium text-teal-700 hover:underline"
                        >
                          ⬇️ MP4 ডাউনলোড করুন ({msg.video.durationSec}s)
                        </a>
                      </div>
                    )}

                    {msg.photo && (
                      <div className="mt-3 space-y-2">
                        <img
                          src={msg.photo.url}
                          alt={msg.photo.caption || 'AI Generated Image'}
                          className="max-h-72 w-full rounded-lg border border-slate-200 object-contain bg-slate-50"
                        />
                        <div className="flex items-center justify-between gap-2 text-xs">
                          {msg.photo.caption && (
                            <span className="text-slate-600 truncate">
                              {msg.photo.caption}
                            </span>
                          )}
                          <a
                            href={`${msg.photo.url}?download=1`}
                            download
                            className="inline-block shrink-0 font-mono text-xs font-medium text-teal-700 hover:underline"
                          >
                            ⬇️ ইমেজ ডাউনলোড
                          </a>
                        </div>
                      </div>
                    )}

                    {msg.document && (
                      <div className="mt-3">
                        <a
                          href={`${msg.document.url}${msg.document.url.includes('?') ? '&' : '?'}download=1`}
                          download={msg.document.filename}
                          className="inline-flex items-center gap-2 rounded-lg border border-teal-200 bg-teal-50 px-3 py-2 text-xs font-semibold text-teal-800 hover:bg-teal-100"
                        >
                          <span>📄 {msg.document.filename}</span>
                          <span className="font-mono text-[11px] text-teal-600">
                            ({Math.max(1, Math.round(msg.document.fileSizeBytes / 1024))} KB)
                          </span>
                        </a>
                      </div>
                    )}

                    <div
                      className={`mt-1.5 text-right font-mono text-[11px] tabular-nums ${
                        isUser ? 'text-teal-100' : 'text-slate-400'
                      }`}
                    >
                      {msg.timestamp}
                    </div>
                  </div>

                  {!isUser && msg.buttons && msg.buttons.length > 0 && (
                    <div className="mt-1.5 flex w-full max-w-[85%] flex-col gap-1.5">
                      {msg.buttons.map((row, rowIdx) => (
                        <div key={rowIdx} className="grid grid-flow-col gap-1.5">
                          {row.map((btn) => (
                            <button
                              key={btn.callback_data + btn.text}
                              type="button"
                              disabled={loading}
                              onClick={() =>
                                void sendCommandOrText({
                                  callbackData: btn.callback_data,
                                })
                              }
                              className="min-h-[40px] rounded-lg border border-slate-300 bg-white px-3 py-2 text-center text-xs font-medium text-slate-800 transition-colors hover:border-teal-600 hover:bg-teal-50 hover:text-teal-900 disabled:opacity-50"
                            >
                              {btn.text}
                            </button>
                          ))}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}

            {loading && (
              <div className="flex items-start">
                <div className="rounded-xl border border-slate-200 bg-white px-4 py-3 text-sm text-slate-600">
                  বট প্রসেস করছে...
                </div>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>

          <form
            onSubmit={handleSubmit}
            className="flex items-center gap-2.5 border-t border-slate-200 bg-white p-3.5"
          >
            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="যেকোনো প্রশ্ন করুন (ChatGPT AI), অথবা /image, /code, /docs, /research, /voice, /admin লিখুন..."
              className="h-11 flex-1 rounded-lg border border-slate-200 bg-slate-50 px-3.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-teal-700 focus:bg-white focus:outline-none"
            />
            <button
              type="submit"
              disabled={loading || !inputText.trim()}
              className="flex h-11 items-center gap-2 rounded-lg bg-teal-700 px-5 text-sm font-medium text-white transition-colors hover:bg-teal-800 disabled:opacity-50 whitespace-nowrap shrink-0"
            >
              <Send className="h-4 w-4" />
              <span>পাঠান</span>
            </button>
          </form>
        </div>
      </div>

      {/* Right: User Switcher & Quick Tests */}
      <div className="space-y-5 lg:col-span-4">
        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="flex items-center gap-2 text-sm font-semibold text-slate-900">
            <UserCheck className="h-4 w-4 text-teal-700" />
            <span>অ্যাক্টিভ সিমুলেটর ইউজার</span>
          </div>
          <p className="mt-1 text-xs text-slate-500">
            Admin (/admin), Free/Premium, Balance বা Ban অবস্থা পরীক্ষা করতে ইউজার বদলান।
          </p>

          <select
            value={activeUser?.id ?? ''}
            onChange={(e) => onSelectUser(e.target.value)}
            aria-label="Select active simulator user"
            className="mt-3 h-10 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 text-sm text-slate-900 focus:border-teal-700 focus:outline-none"
          >
            {users.map((u) => (
              <option key={u.id} value={u.id}>
                {u.firstName} · {u.role.toUpperCase()} · {u.tier.toUpperCase()} · ৳
                {u.balance.toFixed(0)}
              </option>
            ))}
          </select>

          {activeUser && (
            <div className="mt-3 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs text-slate-600 tabular-nums">
              <span>রোল: {activeUser.role === 'admin' ? 'Admin' : 'User'}</span>
              <span aria-hidden="true">·</span>
              <span>প্ল্যান: {activeUser.tier === 'premium' ? 'Premium' : 'Free'}</span>
              <span aria-hidden="true">·</span>
              <span>ব্যালেন্স: ৳{activeUser.balance.toFixed(2)}</span>
              <span aria-hidden="true">·</span>
              <span>আজ: {activeUser.dailyCount}টি</span>
            </div>
          )}
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <div className="flex items-center gap-2 text-sm font-semibold text-slate-900">
            <Sparkles className="h-4 w-4 text-teal-700" />
            <span>দ্রুত বাংলা স্ক্রিপ্ট ও কমান্ড টেস্ট</span>
          </div>

          <div className="mt-3 space-y-2">
            {SAMPLE_BANGLA_SCRIPTS.map((sample, idx) => (
              <button
                key={idx}
                type="button"
                disabled={loading}
                onClick={() =>
                  void sendCommandOrText({
                    text: sample,
                    echoUserText: sample,
                  })
                }
                className="w-full rounded-lg border border-slate-200 bg-slate-50 p-3 text-left text-xs leading-relaxed text-slate-700 transition-colors hover:border-teal-600 hover:bg-teal-50/50 disabled:opacity-50"
              >
                {sample}
              </button>
            ))}
            <button
              type="button"
              disabled={loading}
              onClick={() =>
                void sendCommandOrText({
                  text: 'Welcome to Google and YouTube AI Studio! Today we will learn how ChatGPT API works on example.com.',
                  echoUserText:
                    'Welcome to Google and YouTube AI Studio! Today we will learn how ChatGPT API works on example.com.',
                })
              }
              className="w-full rounded-lg border border-teal-200 bg-teal-50/70 p-3 text-left text-xs leading-relaxed text-teal-900 transition-colors hover:bg-teal-100/70 disabled:opacity-50"
            >
              Smart English → Bangla টেস্ট: “Welcome to Google and YouTube AI Studio! Today we will learn how ChatGPT API works on example.com.”
            </button>
            <button
              type="button"
              disabled={loading}
              onClick={() =>
                void sendCommandOrText({
                  text: 'আজকে আমরা Microsoft Excel এবং Facebook Ads ব্যবহার করে অনলাইন বিজনেস গ্রোথ শিখব।',
                  echoUserText:
                    'আজকে আমরা Microsoft Excel এবং Facebook Ads ব্যবহার করে অনলাইন বিজনেস গ্রোথ শিখব।',
                })
              }
              className="w-full rounded-lg border border-slate-200 bg-slate-50 p-3 text-left text-xs leading-relaxed text-slate-800 transition-colors hover:border-teal-600 hover:bg-teal-50/50 disabled:opacity-50"
            >
              মিশ্রিত ভাষা টেস্ট: “আজকে আমরা Microsoft Excel এবং Facebook Ads ব্যবহার করে অনলাইন বিজনেস গ্রোথ শিখব।”
            </button>
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <h3 className="text-sm font-semibold text-slate-900">
            All-in-One AI Assistant কমান্ড গাইড
          </h3>
          <ul className="mt-3 space-y-2 text-xs leading-relaxed text-slate-600">
            <li>
              • সাধারণ মেসেজ করলেই <strong className="font-semibold text-slate-800">ChatGPT AI মোড</strong> বাংলা/ইংরেজিতে context মনে রেখে উত্তর দেবে।
            </li>
            <li>
              • কমান্ড: <span className="font-mono">/image</span> (ডিজাইন/ছবি),{' '}
              <span className="font-mono">/code</span> (প্রোগ্রাম/ZIP),{' '}
              <span className="font-mono">/docs</span> (PDF/DOCX/XLSX/PPTX),{' '}
              <span className="font-mono">/research</span> (লাইভ ওয়েব সার্চ),{' '}
              <span className="font-mono">/memory</span>।
            </li>
            <li>
              • ভয়েস তৈরির জন্য <span className="font-mono">/voice</span> বা মেনু থেকে ভয়েস স্টুডিও বেছে নিন এবং <span className="font-mono">/admin</span> দিয়ে পূর্ণ নিয়ন্ত্রণ নিন।
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}
