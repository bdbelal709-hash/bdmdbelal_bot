import {
  AlertCircle,
  CheckCircle2,
  Clock,
  Download,
  FileText,
  Film,
  Mic,
  Music,
  RefreshCw,
  Scissors,
  Sparkles,
  Upload,
  Video,
  Wallet,
} from 'lucide-react';
import { useCallback, useEffect, useMemo, useState } from 'react';
import type {
  BotUser,
  PublicBotConfig,
  VideoAspectRatio,
  VideoMode,
  VideoMusicMood,
  VideoProjectJob,
  VideoResolution,
  VideoTemplateId,
  VideoTemplateInfo,
  VoicePersona,
} from '../types.ts';
import {
  computeLiveTiming,
  formatClockMMSS,
  StageStepper,
  useLiveNowMs,
} from './LiveProcessMonitor.tsx';

interface VideoStudioProps {
  voices: VoicePersona[];
  activeUser: BotUser | undefined;
  config: PublicBotConfig | null;
  onOpenWallet?: () => void;
  onDataChanged: () => void;
}

const MODE_OPTIONS: Array<{
  id: VideoMode;
  titleBn: string;
  descBn: string;
  icon: typeof Sparkles;
}> = [
  {
    id: 'prompt',
    titleBn: 'প্রম্পট → AI ভিডিও',
    descBn: 'একটি আইডিয়া লিখুন, AI স্ক্রিপ্ট, ভয়েস ও দৃশ্য তৈরি করবে',
    icon: Sparkles,
  },
  {
    id: 'script',
    titleBn: 'স্ক্রিপ্ট → ভিডিও',
    descBn: 'যেকোনো দৈর্ঘ্যের স্ক্রিপ্ট (Unlimited) থেকে সম্পূর্ণ ভিডিও',
    icon: FileText,
  },
  {
    id: 'voice',
    titleBn: 'ভয়েস → AI ভিডিও',
    descBn: 'নিজস্ব ভয়েস আপলোড করলে AI শুনে মিল রেখে দৃশ্য বানাবে',
    icon: Mic,
  },
  {
    id: 'edit_video',
    titleBn: 'নিজস্ব ভিডিও এডিট',
    descBn: 'ভিডিও আপলোড করে স্পিড, ভয়েস স্পিড, মিউজিক ও টেমপ্লেট এডিট',
    icon: Scissors,
  },
];

const MUSIC_OPTIONS: Array<{ id: VideoMusicMood; labelBn: string }> = [
  { id: 'cinematic', labelBn: 'সিনেম্যাটিক অরকেস্ট্রা' },
  { id: 'emotional', labelBn: 'ইমোশনাল ও নরম' },
  { id: 'upbeat', labelBn: 'আপবিট ও এনার্জেটিক' },
  { id: 'tech', labelBn: 'টেক ও মডার্ন' },
  { id: 'suspense', labelBn: 'সাসপেন্স ও ড্রামা' },
  { id: 'none', labelBn: 'মিউজিক ছাড়া' },
];

function formatBytes(bytes?: number): string {
  if (!bytes) return '—';
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function VideoStudio({
  voices,
  activeUser,
  config,
  onOpenWallet,
  onDataChanged,
}: VideoStudioProps) {
  const [templates, setTemplates] = useState<VideoTemplateInfo[]>([]);
  const [videoJobs, setVideoJobs] = useState<VideoProjectJob[]>([]);

  const [mode, setMode] = useState<VideoMode>('prompt');
  const [title, setTitle] = useState('');
  const [prompt, setPrompt] = useState(
    'কৃত্রিম বুদ্ধিমত্তা বা এআই কিভাবে ভবিষ্যতের শিক্ষা, ব্যবসা ও দৈনন্দিন জীবন বদলে দিচ্ছে সে বিষয়ে একটি আকর্ষণীয় প্রফেশনাল ভিডিও তৈরি করো।',
  );
  const [script, setScript] = useState('');
  const [templateId, setTemplateId] =
    useState<VideoTemplateId>('cinematic_doc');
  const [aspectRatio, setAspectRatio] = useState<VideoAspectRatio>('16:9');
  const [resolution, setResolution] = useState<VideoResolution>('1080p');
  const [videoSpeed, setVideoSpeed] = useState<number>(0); // 0 = Auto-Sync
  const [voiceId, setVoiceId] = useState<string>('female-nusrat');
  const [voiceSpeed, setVoiceSpeed] = useState<number>(1.0);
  const [voicePitch, setVoicePitch] = useState<number>(0);
  const [musicMood, setMusicMood] = useState<VideoMusicMood>('cinematic');
  const [originalAudioMode, setOriginalAudioMode] = useState<
    'mute' | 'duck' | 'keep'
  >('mute');
  const [includeSubtitles, setIncludeSubtitles] = useState(true);
  const [includeIntroOutro, setIncludeIntroOutro] = useState(true);
  const [watermarkText, setWatermarkText] = useState('');

  // Uploaded media metadata
  const [uploadedVideo, setUploadedVideo] = useState<{
    filename: string;
    originalName: string;
    durationSec: number;
    width: number;
    height: number;
  } | null>(null);
  const [uploadedAudio, setUploadedAudio] = useState<{
    filename: string;
    originalName: string;
    durationSec: number;
  } | null>(null);
  const [uploadingMedia, setUploadingMedia] = useState(false);

  const [generatingScript, setGeneratingScript] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [activeJob, setActiveJob] = useState<VideoProjectJob | null>(null);
  const [error, setError] = useState<string | null>(null);

  const loadTemplatesAndJobs = useCallback(async () => {
    try {
      const [tplRes, jobsRes] = await Promise.all([
        fetch('/api/video/templates'),
        fetch('/api/video/jobs?limit=15'),
      ]);
      if (tplRes.ok) {
        const tData = (await tplRes.json()) as {
          templates: VideoTemplateInfo[];
        };
        setTemplates(tData.templates ?? []);
      }
      if (jobsRes.ok) {
        const jData = (await jobsRes.json()) as { jobs: VideoProjectJob[] };
        const list = jData.jobs ?? [];
        setVideoJobs(list);
        const running = list.find(
          (j) => j.status !== 'completed' && j.status !== 'failed',
        );
        if (running) {
          setActiveJob((prev) =>
            prev && prev.status !== 'completed' && prev.status !== 'failed'
              ? prev
              : running,
          );
        }
      }
    } catch {
      // Ignore network hiccup
    }
  }, []);

  useEffect(() => {
    void loadTemplatesAndJobs();
  }, [loadTemplatesAndJobs]);

  useEffect(() => {
    if (voices.length > 0 && !voices.some((v) => v.id === voiceId)) {
      setVoiceId(voices[0].id);
    }
  }, [voices, voiceId]);

  // Live background video job polling
  useEffect(() => {
    if (
      !activeJob ||
      activeJob.status === 'completed' ||
      activeJob.status === 'failed'
    ) {
      return;
    }

    const timer = setInterval(() => {
      void fetch(`/api/video/jobs/${activeJob.id}`)
        .then((r) => r.json())
        .then((data: { job?: VideoProjectJob }) => {
          if (data.job) {
            setActiveJob(data.job);
            if (data.job.status === 'completed') {
              void loadTemplatesAndJobs();
              onDataChanged();
            } else if (data.job.status === 'failed') {
              setError(data.job.error || 'ভিডিও তৈরি ব্যর্থ হয়েছে।');
            }
          }
        })
        .catch(() => {});
    }, 900);

    return () => clearInterval(timer);
  }, [activeJob, loadTemplatesAndJobs, onDataChanged]);

  const isActiveVideoRunning = Boolean(
    activeJob &&
      activeJob.status !== 'completed' &&
      activeJob.status !== 'failed',
  );
  const nowMs = useLiveNowMs(isActiveVideoRunning);

  const videoCost = useMemo(
    () => Math.max(0, config?.videoGenerationCost ?? 0),
    [config],
  );

  const isWorking =
    generatingScript ||
    uploadingMedia ||
    submitting ||
    Boolean(
      activeJob &&
        activeJob.status !== 'completed' &&
        activeJob.status !== 'failed',
    );

  const handleUploadMedia = async (
    file: File,
    kind: 'video' | 'audio',
  ) => {
    setError(null);
    setUploadingMedia(true);
    try {
      const res = await fetch('/api/video/upload-binary', {
        method: 'POST',
        headers: {
          'Content-Type': file.type || 'application/octet-stream',
          'x-filename': encodeURIComponent(file.name),
        },
        body: file,
      });
      const data = (await res.json()) as {
        filename?: string;
        originalName?: string;
        mediaInfo?: { durationSec: number; width: number; height: number };
        error?: string;
      };
      if (!res.ok || !data.filename) {
        setError(data.error || 'ফাইল আপলোড করা যায়নি।');
        return;
      }
      if (kind === 'video') {
        setUploadedVideo({
          filename: data.filename,
          originalName: data.originalName || file.name,
          durationSec: data.mediaInfo?.durationSec ?? 5,
          width: data.mediaInfo?.width ?? 1280,
          height: data.mediaInfo?.height ?? 720,
        });
        if (!title.trim()) {
          setTitle(file.name.replace(/\.[^.]+$/, ''));
        }
      } else {
        setUploadedAudio({
          filename: data.filename,
          originalName: data.originalName || file.name,
          durationSec: data.mediaInfo?.durationSec ?? 5,
        });
      }
    } catch {
      setError('ফাইল আপলোডের সময় নেটওয়ার্ক সমস্যা হয়েছে।');
    } finally {
      setUploadingMedia(false);
    }
  };

  const handlePromptToScript = async () => {
    if (!prompt.trim() || generatingScript) return;
    setError(null);
    setGeneratingScript(true);
    try {
      const res = await fetch('/api/video/prompt-to-script', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: prompt.trim(),
          templateId,
          durationHintSec: uploadedVideo?.durationSec,
        }),
      });
      const data = (await res.json()) as {
        title?: string;
        banglaScript?: string;
        musicMood?: VideoMusicMood;
        error?: string;
      };
      if (!res.ok || !data.banglaScript) {
        setError(data.error || 'স্ক্রিপ্ট তৈরি করা যায়নি।');
      } else {
        setTitle(data.title || title);
        setScript(data.banglaScript);
        if (data.musicMood) setMusicMood(data.musicMood);
      }
    } catch {
      setError('সার্ভারের সাথে সংযোগ ব্যর্থ হয়েছে।');
    } finally {
      setGeneratingScript(false);
    }
  };

  const handleTxtScriptUpload = async (
    e: React.ChangeEvent<HTMLInputElement>,
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const text = await file.text();
    setScript(text);
    e.target.value = '';
  };

  const handleStartRender = async () => {
    if (isWorking) return;
    setError(null);

    if (mode === 'prompt' && !prompt.trim() && !script.trim()) {
      setError('অনুগ্রহ করে ভিডিও তৈরির জন্য প্রম্পট লিখুন।');
      return;
    }
    if (mode === 'script' && !script.trim()) {
      setError('অনুগ্রহ করে ভিডিও স্ক্রিপ্ট লিখুন অথবা .txt ফাইল আপলোড করুন।');
      return;
    }
    if (mode === 'voice' && !uploadedAudio) {
      setError('অনুগ্রহ করে ভয়েস বা অডিও ফাইল আপলোড করুন।');
      return;
    }
    if (mode === 'edit_video' && !uploadedVideo) {
      setError('এডিট করার জন্য অনুগ্রহ করে প্রথমে একটি ভিডিও ফাইল আপলোড করুন।');
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch('/api/video/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: activeUser?.id,
          mode,
          title: title.trim() || undefined,
          prompt: prompt.trim() || undefined,
          script: script.trim() || undefined,
          templateId,
          aspectRatio,
          resolution,
          videoSpeed,
          voiceId,
          voiceSpeed,
          voicePitch,
          musicMood,
          originalAudioMode,
          includeSubtitles,
          includeIntroOutro: mode === 'edit_video' ? false : includeIntroOutro,
          watermarkText: watermarkText.trim() || undefined,
          uploadedVideoFilename: uploadedVideo?.filename,
          uploadedAudioFilename: uploadedAudio?.filename,
        }),
      });
      const data = (await res.json()) as {
        job?: VideoProjectJob;
        error?: string;
      };
      if (!res.ok || !data.job) {
        setError(data.error || 'ভিডিও রেন্ডার শুরু করা যায়নি।');
      } else {
        setActiveJob(data.job);
      }
    } catch {
      setError('সার্ভারের সাথে সংযোগ ব্যর্থ হয়েছে।');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Mode Selector Bar */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {MODE_OPTIONS.map((m) => {
          const Icon = m.icon;
          const active = mode === m.id;
          return (
            <button
              key={m.id}
              type="button"
              onClick={() => {
                setMode(m.id);
                setError(null);
              }}
              className={`flex flex-col items-start rounded-xl border p-4 text-left transition-colors ${
                active
                  ? 'border-teal-700 bg-teal-50/60'
                  : 'border-slate-200 bg-white hover:border-slate-300'
              }`}
            >
              <div className="flex w-full items-center justify-between gap-2">
                <span className="text-sm font-semibold text-slate-900">
                  {m.titleBn}
                </span>
                <Icon
                  className={`h-4 w-4 shrink-0 ${
                    active ? 'text-teal-700' : 'text-slate-400'
                  }`}
                />
              </div>
              <p className="mt-1.5 text-xs leading-relaxed text-slate-600">
                {m.descBn}
              </p>
            </button>
          );
        })}
      </div>

      {/* Main Split Builder */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Left Column: Source Input & Unique Templates (7 cols) */}
        <div className="space-y-6 lg:col-span-7">
          {/* Source Card */}
          <div className="rounded-xl border border-slate-200 bg-white p-5">
            <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 pb-3">
              <div>
                <h2 className="text-sm font-semibold text-slate-900">
                  {mode === 'prompt'
                    ? '১. প্রম্পট থেকে AI স্ক্রিপ্ট ও ভিডিও'
                    : mode === 'script'
                      ? '১. সম্পূর্ণ স্ক্রিপ্ট (Unlimited Duration)'
                      : mode === 'voice'
                        ? '১. ভয়েস বা অডিও ফাইল আপলোড'
                        : '১. নিজস্ব ভিডিও আপলোড ও এডিটিং সামগ্রী'}
                </h2>
                <p className="mt-0.5 text-xs text-slate-500">
                  {mode === 'edit_video'
                    ? 'আপনার ভিডিও স্পিড, ভয়েস স্পিড, বাংলা ভয়েসওভার ও টেমপ্লেট সেট করুন।'
                    : 'বাংলা, ইংরেজি বা মিশ্রিত ভাষায় লিখুন—AI স্বয়ংক্রিয়ভাবে ভিজ্যুয়াল ও বাংলা সাবটাইটেল তৈরি করবে।'}
                </p>
              </div>
              {activeUser && (
                <button
                  type="button"
                  onClick={onOpenWallet}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-medium text-slate-800 hover:bg-slate-100"
                >
                  <Wallet className="h-3.5 w-3.5 text-teal-700" />
                  <span className="font-mono tabular-nums">
                    ৳{activeUser.balance.toFixed(0)}
                  </span>
                </button>
              )}
            </div>

            <div className="mt-4 space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-700">
                  ভিডিওর শিরোনাম (Intro Title)
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="যেমন: ভবিষ্যতের কৃত্রিম বুদ্ধিমত্তা ও বাংলাদেশ"
                  className="mt-1.5 h-10 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 text-sm text-slate-900 focus:border-teal-700 focus:bg-white focus:outline-none"
                />
              </div>

              {(mode === 'prompt' || mode === 'edit_video') && (
                <div>
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <label className="text-xs font-medium text-slate-700">
                      {mode === 'edit_video'
                        ? 'AI দিয়ে ভয়েসওভার স্ক্রিপ্ট লেখার প্রম্পট (ঐচ্ছিক)'
                        : 'ভিডিও প্রম্পট (আপনি কী নিয়ে ভিডিও চান?)'}
                    </label>
                    <button
                      type="button"
                      disabled={generatingScript || !prompt.trim()}
                      onClick={() => void handlePromptToScript()}
                      className="inline-flex h-8 items-center gap-1.5 rounded-lg border border-teal-200 bg-teal-50 px-3 text-xs font-medium text-teal-800 hover:bg-teal-100 disabled:opacity-50"
                    >
                      <Sparkles className="h-3.5 w-3.5" />
                      <span>
                        {generatingScript
                          ? 'স্ক্রিপ্ট তৈরি হচ্ছে...'
                          : 'AI দিয়ে বাংলা স্ক্রিপ্ট লিখুন'}
                      </span>
                    </button>
                  </div>
                  <textarea
                    rows={3}
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="উদাহরণ: সমুদ্রের গভীরের রহস্য ও অদ্ভুত প্রাণীদের নিয়ে একটি সিনেম্যাটিক ভিডিও তৈরি করো..."
                    className="mt-1.5 w-full rounded-lg border border-slate-200 bg-slate-50 p-3 text-sm text-slate-900 focus:border-teal-700 focus:bg-white focus:outline-none"
                  />
                </div>
              )}

              {mode === 'edit_video' && (
                <div className="rounded-lg border border-dashed border-slate-300 bg-slate-50 p-4">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <div className="text-xs font-semibold text-slate-900">
                        আপনার ভিডিও ফাইল আপলোড করুন (MP4 / MOV / WEBM)
                      </div>
                      <div className="mt-0.5 text-[11px] text-slate-500">
                        {uploadedVideo
                          ? `নির্বাচিত: ${uploadedVideo.originalName} · ${uploadedVideo.durationSec}s (${uploadedVideo.width}×${uploadedVideo.height})`
                          : 'এডিট করার জন্য ডিভাইস থেকে একটি ভিডিও বেছে নিন'}
                      </div>
                    </div>
                    <label className="inline-flex h-9 cursor-pointer items-center gap-2 rounded-lg bg-slate-900 px-3.5 text-xs font-medium text-white hover:bg-slate-800">
                      <Upload className="h-3.5 w-3.5" />
                      <span>
                        {uploadingMedia
                          ? 'আপলোড হচ্ছে...'
                          : uploadedVideo
                            ? 'ভিডিও বদলান'
                            : 'ভিডিও বাছাই করুন'}
                      </span>
                      <input
                        type="file"
                        accept="video/*"
                        className="hidden"
                        onChange={(e) => {
                          const f = e.target.files?.[0];
                          if (f) void handleUploadMedia(f, 'video');
                          e.target.value = '';
                        }}
                      />
                    </label>
                  </div>
                </div>
              )}

              {(mode === 'voice' || mode === 'edit_video') && (
                <div className="rounded-lg border border-dashed border-slate-300 bg-slate-50 p-4">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <div className="text-xs font-semibold text-slate-900">
                        {mode === 'edit_video'
                          ? 'নিজস্ব ভয়েস / অডিও ট্র্যাক যোগ করুন (ঐচ্ছিক)'
                          : 'আপনার ভয়েস বা অডিও ফাইল আপলোড করুন (MP3 / WAV / OGG / M4A)'}
                      </div>
                      <div className="mt-0.5 text-[11px] text-slate-500">
                        {uploadedAudio
                          ? `নির্বাচিত: ${uploadedAudio.originalName} · ${uploadedAudio.durationSec}s`
                          : 'ভয়েসের সময় ও অর্থ বুঝে AI দৃশ্য ও সাবটাইটেল মিলিয়ে দেবে'}
                      </div>
                    </div>
                    <label className="inline-flex h-9 cursor-pointer items-center gap-2 rounded-lg border border-slate-300 bg-white px-3.5 text-xs font-medium text-slate-800 hover:bg-slate-100">
                      <Mic className="h-3.5 w-3.5 text-teal-700" />
                      <span>
                        {uploadingMedia
                          ? 'আপলোড হচ্ছে...'
                          : uploadedAudio
                            ? 'অডিও বদলান'
                            : 'ভয়েস ফাইল দিন'}
                      </span>
                      <input
                        type="file"
                        accept="audio/*"
                        className="hidden"
                        onChange={(e) => {
                          const f = e.target.files?.[0];
                          if (f) void handleUploadMedia(f, 'audio');
                          e.target.value = '';
                        }}
                      />
                    </label>
                  </div>
                </div>
              )}

              {(mode === 'script' ||
                mode === 'prompt' ||
                mode === 'edit_video') && (
                <div>
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <label className="text-xs font-medium text-slate-700">
                      {mode === 'prompt'
                        ? 'তৈরিকৃত / এডিটেবল ভিডিও স্ক্রিপ্ট (খালি রাখলে প্রম্পট থেকে স্বয়ংক্রিয়ভাবে হবে)'
                        : mode === 'edit_video'
                          ? 'ভিডিওর নতুন বাংলা ভয়েসওভার স্ক্রিপ্ট (ঐচ্ছিক)'
                          : 'সম্পূর্ণ ভিডিও স্ক্রিপ্ট (Unlimited Characters)'}
                    </label>
                    <label className="inline-flex cursor-pointer items-center gap-1.5 text-xs font-medium text-teal-700 hover:underline">
                      <Upload className="h-3.5 w-3.5" />
                      <span>.txt ফাইল লোড</span>
                      <input
                        type="file"
                        accept=".txt,text/plain"
                        className="hidden"
                        onChange={(e) => void handleTxtScriptUpload(e)}
                      />
                    </label>
                  </div>
                  <textarea
                    rows={mode === 'script' ? 6 : 4}
                    value={script}
                    onChange={(e) => setScript(e.target.value)}
                    placeholder="এখানে বাংলা, ইংরেজি বা মিশ্রিত ভাষায় আপনার স্ক্রিপ্ট লিখুন। AI প্রতিটি অংশ অনুযায়ী দৃশ্য ও বাংলা ভয়েস তৈরি করবে..."
                    className="mt-1.5 w-full rounded-lg border border-slate-200 bg-slate-50 p-3 text-sm leading-relaxed text-slate-900 focus:border-teal-700 focus:bg-white focus:outline-none"
                  />
                  <div className="mt-1 flex items-center justify-between text-[11px] text-slate-500 font-mono tabular-nums">
                    <span>অক্ষর: {script.length.toLocaleString()} (Unlimited)</span>
                    <span>
                      আনুমানিক দৈর্ঘ্য: ~
                      {Math.max(
                        0.2,
                        Math.round((script.trim().length / 750) * 10) / 10,
                      )}{' '}
                      মি.
                    </span>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* 5 Unique Premium Templates */}
          <div className="rounded-xl border border-slate-200 bg-white p-5">
            <h2 className="text-sm font-semibold text-slate-900">
              ২. ইউনিক প্রিমিয়াম টেমপ্লেট নির্বাচন (৫টি ডিজাইন)
            </h2>
            <p className="mt-0.5 text-xs text-slate-500">
              প্রতিটি টেমপ্লেটে আলাদা কালার গ্রেডিং, সাবটাইটেল টাইপোগ্রাফি ও ইন্ট্রো/আউট্রো স্টাইল রয়েছে।
            </p>

            <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
              {templates.map((tpl) => {
                const selected = templateId === tpl.id;
                return (
                  <button
                    key={tpl.id}
                    type="button"
                    onClick={() => setTemplateId(tpl.id)}
                    className={`flex items-start gap-3 rounded-lg border p-3.5 text-left transition-colors ${
                      selected
                        ? 'border-teal-700 bg-teal-50/50'
                        : 'border-slate-200 bg-white hover:border-slate-300'
                    }`}
                  >
                    <div
                      className="mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-md font-mono text-[10px] font-bold text-white"
                      style={{
                        background: `linear-gradient(135deg, ${tpl.bgDarkHex}, ${tpl.accentHex})`,
                        borderBottom: `2px solid ${tpl.secondaryHex}`,
                      }}
                    >
                      {tpl.badgeText}
                    </div>
                    <div className="min-w-0">
                      <div className="text-xs font-semibold text-slate-900">
                        {tpl.nameBn}
                      </div>
                      <div className="mt-0.5 text-[11px] leading-snug text-slate-500">
                        {tpl.taglineBn}
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: Speed, Voice, Format & Render Controls (5 cols) */}
        <div className="space-y-6 lg:col-span-5">
          <div className="rounded-xl border border-slate-200 bg-white p-5 space-y-4">
            <h2 className="flex items-center gap-2 text-sm font-semibold text-slate-900">
              <Film className="h-4 w-4 text-teal-700" />
              <span>৩. ভিডিও স্পিড, ভয়েস ও এক্সপোর্ট সেটিংস</span>
            </h2>

            {/* Aspect Ratio & Resolution */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-slate-700">
                  ভিডিও রেশিও (Aspect Ratio)
                </label>
                <select
                  value={aspectRatio}
                  onChange={(e) =>
                    setAspectRatio(e.target.value as VideoAspectRatio)
                  }
                  className="mt-1.5 h-10 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs text-slate-900 focus:border-teal-700 focus:outline-none"
                >
                  <option value="16:9">16:9 (YouTube Landscape)</option>
                  <option value="9:16">9:16 (Reels / TikTok / Shorts)</option>
                  <option value="1:1">1:1 (Facebook Square)</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700">
                  এক্সপোর্ট কোয়ালিটি
                </label>
                <select
                  value={resolution}
                  onChange={(e) =>
                    setResolution(e.target.value as VideoResolution)
                  }
                  className="mt-1.5 h-10 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs text-slate-900 focus:border-teal-700 focus:outline-none"
                >
                  <option value="720p">720p HD (Fast)</option>
                  <option value="1080p">1080p Full HD (Pro)</option>
                  <option value="4k">4K Ultra HD</option>
                </select>
              </div>
            </div>

            {/* Video Speed & Original Audio (highlighted in edit_video mode) */}
            {mode === 'edit_video' && (
              <div className="grid grid-cols-2 gap-3 border-t border-slate-100 pt-3">
                <div>
                  <label className="block text-xs font-medium text-slate-700">
                    ভিডিও স্পিড (Video Speed)
                  </label>
                  <select
                    value={videoSpeed}
                    onChange={(e) => setVideoSpeed(Number(e.target.value))}
                    className="mt-1.5 h-10 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-xs text-slate-900 focus:border-teal-700 focus:outline-none"
                  >
                    <option value={0}>Auto-Sync (ভয়েস অনুযায়ী মিল)</option>
                    <option value={0.5}>0.5x (Slow Motion)</option>
                    <option value={0.75}>0.75x (Cinematic Slow)</option>
                    <option value={1}>1.0x (Original Speed)</option>
                    <option value={1.25}>1.25x (Fast Pace)</option>
                    <option value={1.5}>1.5x (Dynamic)</option>
                    <option value={2}>2.0x (Timelapse)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700">
                    ভিডিওর মূল অডিও
                  </label>
                  <select
                    value={originalAudioMode}
                    onChange={(e) =>
                      setOriginalAudioMode(
                        e.target.value as 'mute' | 'duck' | 'keep',
                      )
                    }
                    className="mt-1.5 h-10 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs text-slate-900 focus:border-teal-700 focus:outline-none"
                  >
                    <option value="mute">Mute (শুধু নতুন AI ভয়েস)</option>
                    <option value="duck">Duck 20% (ভয়েসওভার + হালকা সাউন্ড)</option>
                    <option value="keep">Keep Original Sound</option>
                  </select>
                </div>
              </div>
            )}

            {/* AI Voice & Voice Speed */}
            {mode !== 'voice' && (
              <div className="grid grid-cols-1 gap-3 border-t border-slate-100 pt-3 sm:grid-cols-2">
                <div>
                  <label className="block text-xs font-medium text-slate-700">
                    AI কণ্ঠস্বর (Bangla Voice)
                  </label>
                  <select
                    value={voiceId}
                    onChange={(e) => setVoiceId(e.target.value)}
                    className="mt-1.5 h-10 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs text-slate-900 focus:border-teal-700 focus:outline-none"
                  >
                    {voices.map((v) => (
                      <option key={v.id} value={v.id}>
                        {v.nameBn} ({v.roleBn})
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700">
                    ভয়েস স্পিড:{' '}
                    <span className="font-mono tabular-nums">
                      {voiceSpeed.toFixed(2)}x
                    </span>{' '}
                    · পিচ:{' '}
                    <span className="font-mono tabular-nums">
                      {voicePitch > 0 ? `+${voicePitch}` : voicePitch}
                    </span>
                  </label>
                  <div className="mt-2 flex items-center gap-2">
                    <input
                      type="range"
                      min={0.75}
                      max={1.35}
                      step={0.05}
                      value={voiceSpeed}
                      onChange={(e) => setVoiceSpeed(Number(e.target.value))}
                      className="w-full accent-teal-700"
                    />
                    <select
                      value={voicePitch}
                      onChange={(e) => setVoicePitch(Number(e.target.value))}
                      aria-label="Voice Pitch"
                      className="h-8 rounded border border-slate-200 bg-slate-50 px-1.5 font-mono text-xs"
                    >
                      <option value={-2}>-2</option>
                      <option value={0}>0</option>
                      <option value={2}>+2</option>
                    </select>
                  </div>
                </div>
              </div>
            )}

            {mode === 'voice' && (
              <div className="border-t border-slate-100 pt-3">
                <label className="block text-xs font-medium text-slate-700">
                  আপলোডেড ভয়েসের স্পিড:{' '}
                  <span className="font-mono tabular-nums">
                    {voiceSpeed.toFixed(2)}x
                  </span>
                </label>
                <input
                  type="range"
                  min={0.75}
                  max={1.35}
                  step={0.05}
                  value={voiceSpeed}
                  onChange={(e) => setVoiceSpeed(Number(e.target.value))}
                  className="mt-2 w-full accent-teal-700"
                />
              </div>
            )}

            {/* Background Music & Watermark */}
            <div className="grid grid-cols-1 gap-3 border-t border-slate-100 pt-3 sm:grid-cols-2">
              <div>
                <label className="flex items-center gap-1.5 text-xs font-medium text-slate-700">
                  <Music className="h-3.5 w-3.5 text-teal-700" />
                  <span>ব্যাকগ্রাউন্ড মিউজিক</span>
                </label>
                <select
                  value={musicMood}
                  onChange={(e) =>
                    setMusicMood(e.target.value as VideoMusicMood)
                  }
                  className="mt-1.5 h-10 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs text-slate-900 focus:border-teal-700 focus:outline-none"
                >
                  {MUSIC_OPTIONS.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.labelBn}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-xs font-medium text-slate-700">
                  ওয়াটারমার্ক / চ্যানেল নাম
                </label>
                <input
                  type="text"
                  value={watermarkText}
                  onChange={(e) => setWatermarkText(e.target.value)}
                  placeholder="যেমন: @BanglaStudio"
                  className="mt-1.5 h-10 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs text-slate-900 focus:border-teal-700 focus:bg-white focus:outline-none"
                />
              </div>
            </div>

            {/* Toggles */}
            <div className="flex flex-wrap gap-3 border-t border-slate-100 pt-3">
              <label className="flex cursor-pointer items-center gap-2 text-xs font-medium text-slate-800">
                <input
                  type="checkbox"
                  checked={includeSubtitles}
                  onChange={(e) => setIncludeSubtitles(e.target.checked)}
                  className="h-4 w-4 accent-teal-700"
                />
                <span>অটো বাংলা সাবটাইটেল (Captions)</span>
              </label>

              {mode !== 'edit_video' && (
                <label className="flex cursor-pointer items-center gap-2 text-xs font-medium text-slate-800">
                  <input
                    type="checkbox"
                    checked={includeIntroOutro}
                    onChange={(e) => setIncludeIntroOutro(e.target.checked)}
                    className="h-4 w-4 accent-teal-700"
                  />
                  <span>প্রফেশনাল Intro & Outro</span>
                </label>
              )}
            </div>

            {error && (
              <div className="flex items-start gap-2 rounded-lg border border-red-200 bg-red-50 p-3 text-xs text-red-800">
                <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
                <span>{error}</span>
              </div>
            )}

            <button
              type="button"
              disabled={isWorking}
              onClick={() => void handleStartRender()}
              className="flex h-11 w-full items-center justify-center gap-2 rounded-lg bg-teal-700 px-4 text-sm font-semibold text-white transition-colors hover:bg-teal-800 disabled:opacity-60"
            >
              {isWorking ? (
                <RefreshCw className="h-4 w-4 animate-spin" />
              ) : (
                <Video className="h-4 w-4" />
              )}
              <span>
                {isWorking
                  ? 'ভিডিও প্রসেসিং চলছে...'
                  : mode === 'edit_video'
                    ? `ভিডিও এডিট ও এক্সপোর্ট করুন (${videoCost > 0 ? `৳${videoCost}` : 'ফ্রি'})`
                    : `প্রফেশনাল AI ভিডিও তৈরি করুন (${videoCost > 0 ? `৳${videoCost}` : 'ফ্রি'})`}
              </span>
            </button>
          </div>

          {/* Live Render Progress & Preview Output */}
          {activeJob && (() => {
            const running =
              activeJob.status !== 'completed' && activeJob.status !== 'failed';
            const timing = computeLiveTiming(activeJob, nowMs);
            return (
            <div className="rounded-xl border border-teal-200 bg-white p-5 space-y-4">
              <div className="flex items-center justify-between gap-2">
                <div className="flex min-w-0 items-center gap-2 text-sm font-semibold text-slate-900">
                  {activeJob.status === 'completed' ? (
                    <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-600" />
                  ) : activeJob.status === 'failed' ? (
                    <AlertCircle className="h-4 w-4 shrink-0 text-red-600" />
                  ) : (
                    <>
                      <span className="inline-flex shrink-0 items-center gap-1 rounded bg-teal-700 px-1.5 py-0.5 font-mono text-[10px] font-bold text-white">
                        <span className="h-1.5 w-1.5 rounded-full bg-white animate-ping" />
                        LIVE
                      </span>
                      <RefreshCw className="h-4 w-4 shrink-0 animate-spin text-teal-700" />
                    </>
                  )}
                  <span className="truncate">{activeJob.title}</span>
                </div>
                <span className="shrink-0 font-mono text-xs font-bold text-teal-700 tabular-nums">
                  {activeJob.progressPct}%
                </span>
              </div>

              <div className="h-2.5 w-full overflow-hidden rounded-full bg-slate-100">
                <div
                  className={`h-full transition-all duration-300 ${
                    activeJob.status === 'failed'
                      ? 'bg-red-600'
                      : activeJob.status === 'completed'
                        ? 'bg-emerald-600'
                        : 'bg-teal-700 animate-pulse'
                  }`}
                  style={{ width: `${Math.max(6, activeJob.progressPct)}%` }}
                />
              </div>

              <div className="text-xs font-medium text-slate-700">
                {activeJob.statusText}
              </div>

              <div className="flex flex-wrap items-center justify-between gap-2">
                <StageStepper kind="video" status={activeJob.status} />
                <div className="flex items-center gap-2 font-mono text-xs tabular-nums">
                  <span className="inline-flex items-center gap-1.5 rounded-md bg-slate-900 px-2.5 py-1 font-semibold text-white">
                    {running && <RefreshCw className="h-3 w-3 animate-spin" />}
                    <Clock className="h-3 w-3" />
                    <span>টাইমার: {formatClockMMSS(timing.liveElapsedSec)}</span>
                  </span>
                  {timing.liveRemainingSec > 0 && running && (
                    <span className="font-semibold text-teal-700">
                      বাকি: ~{formatClockMMSS(timing.liveRemainingSec)}
                    </span>
                  )}
                </div>
              </div>

              {activeJob.status === 'completed' && activeJob.outputVideoUrl && (
                <div className="space-y-3 border-t border-slate-100 pt-3">
                  <video
                    controls
                    playsInline
                    src={activeJob.outputVideoUrl}
                    className="max-h-80 w-full rounded-lg border border-slate-200 bg-black"
                  />
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <div className="font-mono text-xs text-slate-500 tabular-nums">
                      {activeJob.aspectRatio} ·{' '}
                      {activeJob.resolution.toUpperCase()} ·{' '}
                      {activeJob.durationSec ?? '?'}s ·{' '}
                      {formatBytes(activeJob.fileSizeBytes)}
                    </div>
                    <a
                      href={`${activeJob.outputVideoUrl}?download=1`}
                      className="inline-flex h-9 items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 text-xs font-medium text-white hover:bg-slate-800"
                    >
                      <Download className="h-3.5 w-3.5" />
                      <span>MP4 ডাউনলোড করুন</span>
                    </a>
                  </div>
                </div>
              )}
            </div>
            );
          })()}
        </div>
      </div>

      {/* Scene Plan Breakdown (when scenes exist on activeJob) */}
      {activeJob && activeJob.scenes.length > 0 && (
        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <h3 className="text-sm font-semibold text-slate-900">
            AI সিন ও সাবটাইটেল টাইমলাইন ({activeJob.scenes.length}টি সিন)
          </h3>
          <div className="mt-3 grid grid-cols-1 gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
            {activeJob.scenes.map((sc) => (
              <div
                key={sc.index}
                className="rounded-lg border border-slate-200 bg-slate-50 p-3 text-xs"
              >
                <div className="flex items-center justify-between gap-2 font-mono text-[11px] text-slate-500 tabular-nums">
                  <span>Scene #{sc.index + 1}</span>
                  <span>
                    {sc.startSec !== undefined && sc.endSec !== undefined
                      ? `${sc.startSec.toFixed(1)}s – ${sc.endSec.toFixed(1)}s`
                      : sc.motion}
                  </span>
                </div>
                <p className="mt-1.5 line-clamp-2 font-medium text-slate-900">
                  {sc.subtitleText || sc.narrationBangla || sc.searchKeywords}
                </p>
                <p className="mt-1 truncate font-mono text-[11px] text-teal-700">
                  Visual: {sc.searchKeywords}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Video History */}
      <div className="rounded-xl border border-slate-200 bg-white p-5">
        <div className="flex items-center justify-between gap-2">
          <h3 className="text-sm font-semibold text-slate-900">
            সাম্প্রতিক তৈরিকৃত ও এডিটেড ভিডিও ({videoJobs.length})
          </h3>
          <button
            type="button"
            onClick={() => void loadTemplatesAndJobs()}
            className="text-xs font-medium text-teal-700 hover:underline"
          >
            রিফ্রেশ
          </button>
        </div>

        {videoJobs.length === 0 ? (
          <div className="mt-3 rounded-lg border border-dashed border-slate-200 bg-slate-50 p-6 text-center text-xs text-slate-500">
            এখনো কোনো ভিডিও তৈরি হয়নি। উপরের যেকোনো মোড ব্যবহার করে প্রথম প্রফেশনাল AI ভিডিও তৈরি করুন।
          </div>
        ) : (
          <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
            {videoJobs.map((vj) => (
              <div
                key={vj.id}
                className="flex flex-col justify-between rounded-lg border border-slate-200 bg-slate-50 p-3.5 text-xs"
              >
                <div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="truncate font-semibold text-slate-900">
                      {vj.title}
                    </span>
                    <span
                      className={`font-mono text-[11px] font-semibold ${
                        vj.status === 'completed'
                          ? 'text-emerald-700'
                          : vj.status === 'failed'
                            ? 'text-red-700'
                            : 'text-teal-700'
                      }`}
                    >
                      {vj.status.toUpperCase()}
                    </span>
                  </div>
                  <div className="mt-1 font-mono text-[11px] text-slate-500 tabular-nums">
                    {vj.mode} · {vj.aspectRatio} · {vj.resolution} ·{' '}
                    {vj.durationSec ? `${vj.durationSec}s` : `${vj.progressPct}%`}
                  </div>
                </div>

                {vj.outputVideoUrl && (
                  <div className="mt-3 flex items-center justify-between gap-2 border-t border-slate-200 pt-2.5">
                    <button
                      type="button"
                      onClick={() => setActiveJob(vj)}
                      className="font-medium text-teal-700 hover:underline"
                    >
                      প্রিভিউ দেখুন
                    </button>
                    <a
                      href={`${vj.outputVideoUrl}?download=1`}
                      className="inline-flex items-center gap-1 font-medium text-slate-800 hover:text-teal-700"
                    >
                      <Download className="h-3.5 w-3.5" />
                      <span>MP4 ({formatBytes(vj.fileSizeBytes)})</span>
                    </a>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
