import {
  AlertTriangle,
  Ban,
  Check,
  CheckCircle2,
  Copy,
  Cpu,
  CreditCard,
  Crown,
  Plus,
  RefreshCw,
  Search,
  Shield,
  ShieldCheck,
  Trash2,
  UserPlus,
  Wallet,
  XCircle,
  Zap,
} from 'lucide-react';
import { useEffect, useMemo, useState } from 'react';
import type {
  AssistantModuleId,
  BotUser,
  DashboardStats,
  ErrorLogEntry,
  IncomingPaymentSms,
  PaymentAccount,
  PaymentRequest,
  PublicBotConfig,
  TransactionRecord,
  VideoVisualMode,
  VoiceJob,
  VoicePersona,
} from '../types.ts';

interface AdminPanelProps {
  stats: DashboardStats | null;
  users: BotUser[];
  voices: VoicePersona[];
  config: PublicBotConfig | null;
  paymentRequests: PaymentRequest[];
  incomingPaymentSms: IncomingPaymentSms[];
  transactions: TransactionRecord[];
  jobs: VoiceJob[];
  errorLogs?: ErrorLogEntry[];
  onRefresh: () => void;
}

const FEATURE_META: Array<{
  id: AssistantModuleId;
  label: string;
  labelBn: string;
  desc: string;
}> = [
  { id: 'chat', label: 'AI Chat', labelBn: 'ChatGPT এআই চ্যাট', desc: 'বহুভাষিক কথোপকথন ও রিজনিং' },
  { id: 'image', label: 'Image Studio', labelBn: 'ইমেজ ও ডিজাইন', desc: 'ছবি তৈরি, আপস্কেল ও ব্যাকগ্রাউন্ড রিমুভ' },
  { id: 'video', label: 'Video Studio', labelBn: 'ভিডিও স্টুডিও', desc: 'প্রম্পট/স্ক্রিপ্ট/ইমেজ থেকে MP4' },
  { id: 'voice', label: 'Voice Studio', labelBn: 'ভয়েস স্টুডিও', desc: '১৬টি বাংলা কণ্ঠ, STT ও নয়েজ রিমুভ' },
  { id: 'documents', label: 'Documents', labelBn: 'ডকুমেন্ট অ্যাসিস্ট্যান্ট', desc: 'PDF/Word/Excel/PPT তৈরি ও বিশ্লেষণ' },
  { id: 'coding', label: 'Coding AI', labelBn: 'কোডিং অ্যাসিস্ট্যান্ট', desc: 'কোড, ডিবাগিং ও ডাউনলোডেবল প্রজেক্ট' },
  { id: 'research', label: 'Web Research', labelBn: 'ওয়েব রিসার্চ', desc: 'Google সার্চ গ্রাউন্ডিং ও URL বিশ্লেষণ' },
  { id: 'memory', label: 'Memory', labelBn: 'মেমোরি ও পার্সোনালাইজেশন', desc: 'দীর্ঘমেয়াদী ইউজার তথ্য সংরক্ষণ' },
];

export function AdminPanel({
  stats,
  users,
  voices,
  config,
  paymentRequests,
  incomingPaymentSms,
  transactions,
  jobs,
  errorLogs = [],
  onRefresh,
}: AdminPanelProps) {
  const [userSearch, setUserSearch] = useState('');
  const [userFilter, setUserFilter] = useState<
    'all' | 'free' | 'premium' | 'banned'
  >('all');
  const [newUserName, setNewUserName] = useState('');
  const [newUserTier, setNewUserTier] = useState<'free' | 'premium'>('free');
  const [addingUser, setAddingUser] = useState(false);

  // Config form state
  const [freeLimit, setFreeLimit] = useState<number>(config?.freeDailyLimit ?? 10);
  const [premiumLimit, setPremiumLimit] = useState<number>(
    config?.premiumDailyLimit ?? 200,
  );
  const [maxCharsFree, setMaxCharsFree] = useState<number>(
    config?.maxScriptCharsFree ?? 0,
  );
  const [maxCharsPremium, setMaxCharsPremium] = useState<number>(
    config?.maxScriptCharsPremium ?? 0,
  );
  const [voiceCost, setVoiceCost] = useState<number>(
    config?.voiceGenerationCost ?? 0,
  );
  const [videoCost, setVideoCost] = useState<number>(
    config?.videoGenerationCost ?? 0,
  );
  const [visualProviderMode, setVisualProviderMode] =
    useState<VideoVisualMode>(config?.visualProviderMode ?? 'auto');
  const [pexelsApiKeyInput, setPexelsApiKeyInput] = useState<string>('');
  const [premiumDays, setPremiumDays] = useState<number>(
    config?.premiumMembershipDays ?? 30,
  );
  const [adminClaimCode, setAdminClaimCode] = useState<string>(
    config?.adminClaimCode ?? 'ADMIN2026',
  );
  const [adminIdsText, setAdminIdsText] = useState<string>(
    (config?.adminTelegramIds ?? []).join(', '),
  );
  const [strictBangla, setStrictBangla] = useState<boolean>(
    config?.strictBanglaOnly ?? false,
  );
  const [autoNormalize, setAutoNormalize] = useState<boolean>(
    config?.autoNormalizeBangla ?? true,
  );
  const [smartEnglishToBangla, setSmartEnglishToBangla] = useState<boolean>(
    config?.smartEnglishToBangla ?? true,
  );
  const [ttsModel, setTtsModel] = useState<
    'gemini-3.8-flash-lite-tts' | 'gemini-3.8-flash-tts'
  >(config?.ttsModel ?? 'gemini-3.8-flash-lite-tts');
  const [savingConfig, setSavingConfig] = useState(false);
  const [configMsg, setConfigMsg] = useState<string | null>(null);

  // Telegram Bot API connection state
  const [botTokenInput, setBotTokenInput] = useState('');
  const [notificationChannelInput, setNotificationChannelInput] = useState(
    config?.notificationChannelId ?? '',
  );
  const [tgLoading, setTgLoading] = useState(false);
  const [tgMessage, setTgMessage] = useState<string | null>(null);
  const [tgError, setTgError] = useState<string | null>(null);
  const [copiedWebhook, setCopiedWebhook] = useState(false);
  const [copiedHealth, setCopiedHealth] = useState(false);

  useEffect(() => {
    setNotificationChannelInput(config?.notificationChannelId ?? '');
  }, [config?.notificationChannelId]);

  // Balance quick adjustment state
  const [balanceInputs, setBalanceInputs] = useState<Record<string, string>>({});

  // Payment Numbers state
  const [paymentAccounts, setPaymentAccounts] = useState<PaymentAccount[]>(
    config?.paymentAccounts ?? [],
  );
  const [newPayMethod, setNewPayMethod] = useState<string>('bKash');
  const [newPayType, setNewPayType] = useState<string>('Personal (Send Money)');
  const [newPayNumber, setNewPayNumber] = useState<string>('');
  const [newPayNote, setNewPayNote] = useState<string>('');
  const [paymentInstructions, setPaymentInstructions] = useState<string>(
    config?.paymentInstructions ?? '',
  );
  const [autoVerifyPayments, setAutoVerifyPayments] = useState<boolean>(
    config?.autoVerifyPayments ?? true,
  );
  const [smsPasteText, setSmsPasteText] = useState<string>('');
  const [smsSyncing, setSmsSyncing] = useState(false);
  const [smsMsg, setSmsMsg] = useState<string | null>(null);
  const [smsError, setSmsError] = useState<string | null>(null);
  const [copiedSmsUrl, setCopiedSmsUrl] = useState(false);
  const [copiedSmsSecret, setCopiedSmsSecret] = useState(false);
  const [savingPayAcc, setSavingPayAcc] = useState(false);
  const [payAccMsg, setPayAccMsg] = useState<string | null>(null);

  // Per-voice separate charges (string map so empty = use global default, "0" = explicitly free)
  const [voiceCostInputs, setVoiceCostInputs] = useState<Record<string, string>>({});
  const [savingFeatures, setSavingFeatures] = useState(false);
  const [clearingErrors, setClearingErrors] = useState(false);

  const handleFeatureToggle = async (modId: AssistantModuleId) => {
    if (savingFeatures) return;
    setSavingFeatures(true);
    try {
      const currentVal = config?.enabledFeatures?.[modId] ?? true;
      await fetch('/api/admin/features', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          enabledFeatures: { [modId]: !currentVal },
        }),
      });
      onRefresh();
    } finally {
      setSavingFeatures(false);
    }
  };

  const handleChatModelChange = async (
    nextModel: 'gemini-4-hydrogen' | 'gemini-3.1-flash-lite',
  ) => {
    if (savingFeatures) return;
    setSavingFeatures(true);
    try {
      await fetch('/api/admin/features', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ defaultChatModel: nextModel }),
      });
      onRefresh();
    } finally {
      setSavingFeatures(false);
    }
  };

  const handleClearErrorLogs = async () => {
    if (clearingErrors) return;
    setClearingErrors(true);
    try {
      await fetch('/api/admin/errors/clear', { method: 'POST' });
      onRefresh();
    } finally {
      setClearingErrors(false);
    }
  };

  useEffect(() => {
    if (!config) return;
    setFreeLimit(config.freeDailyLimit);
    setPremiumLimit(config.premiumDailyLimit);
    setMaxCharsFree(config.maxScriptCharsFree);
    setMaxCharsPremium(config.maxScriptCharsPremium);
    setVoiceCost(config.voiceGenerationCost);
    setVideoCost(config.videoGenerationCost ?? 0);
    setVisualProviderMode(config.visualProviderMode ?? 'auto');
    setPremiumDays(config.premiumMembershipDays);
    setAdminClaimCode(config.adminClaimCode);
    setAdminIdsText((config.adminTelegramIds ?? []).join(', '));
    setStrictBangla(config.strictBanglaOnly);
    setAutoNormalize(config.autoNormalizeBangla);
    setSmartEnglishToBangla(config.smartEnglishToBangla ?? true);
    setTtsModel(config.ttsModel);
    setPaymentAccounts(config.paymentAccounts ?? []);
    setPaymentInstructions(config.paymentInstructions ?? '');
    setAutoVerifyPayments(config.autoVerifyPayments ?? true);

    const nextInputs: Record<string, string> = {};
    for (const [vId, costVal] of Object.entries(config.voiceCosts ?? {})) {
      if (typeof costVal === 'number' && !Number.isNaN(costVal)) {
        nextInputs[vId] = String(costVal);
      }
    }
    setVoiceCostInputs(nextInputs);
  }, [config]);

  const filteredUsers = useMemo(() => {
    const q = userSearch.trim().toLowerCase();
    return users.filter((u) => {
      if (userFilter === 'free' && u.tier !== 'free') return false;
      if (userFilter === 'premium' && u.tier !== 'premium') return false;
      if (userFilter === 'banned' && u.status !== 'banned') return false;
      if (!q) return true;
      return (
        u.firstName.toLowerCase().includes(q) ||
        u.username.toLowerCase().includes(q) ||
        u.telegramId.toLowerCase().includes(q)
      );
    });
  }, [users, userSearch, userFilter]);

  const maxDailyGen = useMemo(() => {
    const vals = stats?.dailySeries.map((d) => d.generations) ?? [1];
    return Math.max(1, ...vals);
  }, [stats]);

  const handleUserUpdate = async (
    id: string,
    patch: {
      tier?: 'free' | 'premium';
      status?: 'active' | 'banned';
      role?: 'user' | 'admin';
      customDailyLimit?: number | null;
      customCharLimit?: number | null;
    },
  ) => {
    await fetch(`/api/admin/users/${id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(patch),
    });
    onRefresh();
  };

  const handleBalanceAdjust = async (id: string, delta: number) => {
    if (!delta || Number.isNaN(delta)) return;
    await fetch(`/api/admin/users/${id}/balance`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ amountDelta: delta }),
    });
    setBalanceInputs((prev) => ({ ...prev, [id]: '' }));
    onRefresh();
  };

  const handlePaymentReview = async (
    paymentId: string,
    decision: 'approved' | 'rejected',
  ) => {
    await fetch(`/api/admin/payments/${paymentId}/review`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ decision, reviewedBy: 'Web Admin' }),
    });
    onRefresh();
  };

  const handleAddUser = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newUserName.trim() || addingUser) return;
    setAddingUser(true);
    try {
      await fetch('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          firstName: newUserName.trim(),
          tier: newUserTier,
        }),
      });
      setNewUserName('');
      onRefresh();
    } finally {
      setAddingUser(false);
    }
  };

  const persistPaymentAccounts = async (
    nextAccounts: PaymentAccount[],
    successText: string,
  ) => {
    setSavingPayAcc(true);
    setPayAccMsg(null);
    try {
      const res = await fetch('/api/admin/config', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ paymentAccounts: nextAccounts }),
      });
      if (res.ok) {
        setPaymentAccounts(nextAccounts);
        setPayAccMsg(successText);
        onRefresh();
      }
    } finally {
      setSavingPayAcc(false);
    }
  };

  const handleAddPaymentAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPayNumber.trim() || savingPayAcc) return;
    const nextAcc: PaymentAccount = {
      id: `payacc-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      method: newPayMethod.trim() || 'bKash',
      accountNumber: newPayNumber.trim(),
      accountType: newPayType.trim() || 'Personal (Send Money)',
      note: newPayNote.trim() || undefined,
      enabled: true,
    };
    const nextList = [...paymentAccounts, nextAcc];
    await persistPaymentAccounts(
      nextList,
      `${nextAcc.method} নম্বর (${nextAcc.accountNumber}) যুক্ত করা হয়েছে।`,
    );
    setNewPayNumber('');
    setNewPayNote('');
  };

  const handleTogglePaymentAccount = async (id: string) => {
    const nextList = paymentAccounts.map((acc) =>
      acc.id === id ? { ...acc, enabled: !acc.enabled } : acc,
    );
    await persistPaymentAccounts(nextList, 'পেমেন্ট নম্বরের অবস্থা আপডেট হয়েছে।');
  };

  const handleDeletePaymentAccount = async (id: string) => {
    const nextList = paymentAccounts.filter((acc) => acc.id !== id);
    await persistPaymentAccounts(nextList, 'পেমেন্ট নম্বর মুছে ফেলা হয়েছে।');
  };

  const handleSavePaymentInstructions = async () => {
    setSavingPayAcc(true);
    setPayAccMsg(null);
    try {
      const res = await fetch('/api/admin/config', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ paymentInstructions }),
      });
      if (res.ok) {
        setPayAccMsg('ইউজারদের জন্য পেমেন্ট নির্দেশনা (Description) সংরক্ষিত হয়েছে।');
        onRefresh();
      }
    } finally {
      setSavingPayAcc(false);
    }
  };

  const handleToggleAutoVerify = async (nextVal: boolean) => {
    setAutoVerifyPayments(nextVal);
    await fetch('/api/admin/config', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ autoVerifyPayments: nextVal }),
    });
    onRefresh();
  };

  const handleRegenerateSmsSecret = async () => {
    setSmsSyncing(true);
    try {
      await fetch('/api/admin/payments/regenerate-secret', { method: 'POST' });
      onRefresh();
    } finally {
      setSmsSyncing(false);
    }
  };

  const handleManualSmsSync = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!smsPasteText.trim() || smsSyncing) return;
    setSmsSyncing(true);
    setSmsMsg(null);
    setSmsError(null);
    try {
      const res = await fetch('/api/admin/payments/ingest-sms', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ rawText: smsPasteText.trim() }),
      });
      const data = (await res.json()) as {
        sms?: IncomingPaymentSms;
        duplicateSms?: boolean;
        matchedPayment?: PaymentRequest;
        error?: string;
      };
      if (!res.ok || !data.sms) {
        setSmsError(data.error || 'SMS পার্স করা যায়নি।');
      } else {
        setSmsPasteText('');
        if (data.matchedPayment) {
          setSmsMsg(
            `⚡ SMS (${data.sms.trxId} · ৳${data.sms.amount}) সিঙ্ক হয়ে পেন্ডিং রিকোয়েস্ট ${data.matchedPayment.id} অটো-ভেরিফাই ও ব্যালেন্স যুক্ত করেছে!`,
          );
        } else if (data.duplicateSms) {
          setSmsMsg(`এই TrxID (${data.sms.trxId}) ইতিমধ্যেই SMS পুলে সংরক্ষিত আছে।`);
        } else {
          setSmsMsg(
            `✅ SMS সংরক্ষিত হয়েছে (${data.sms.method} · ৳${data.sms.amount} · TrxID: ${data.sms.trxId})। ইউজার এই TrxID জমা দিলে সাথে সাথেই অটো-ভেরিফাই হবে।`,
          );
        }
        onRefresh();
      }
    } finally {
      setSmsSyncing(false);
    }
  };

  const handleSaveConfig = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingConfig(true);
    setConfigMsg(null);
    try {
      const parsedIds = adminIdsText
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean);

      const parsedVoiceCosts: Record<string, number> = {};
      for (const v of voices) {
        const raw = (voiceCostInputs[v.id] ?? '').trim();
        if (raw !== '') {
          const num = Number(raw);
          if (!Number.isNaN(num) && num >= 0) {
            parsedVoiceCosts[v.id] = num;
          }
        }
      }

      const res = await fetch('/api/admin/config', {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          freeDailyLimit: freeLimit,
          premiumDailyLimit: premiumLimit,
          maxScriptCharsFree: maxCharsFree,
          maxScriptCharsPremium: maxCharsPremium,
          voiceGenerationCost: voiceCost,
          voiceCosts: parsedVoiceCosts,
          videoGenerationCost: videoCost,
          visualProviderMode,
          ...(pexelsApiKeyInput.trim()
            ? { pexelsApiKey: pexelsApiKeyInput.trim() }
            : {}),
          premiumMembershipDays: premiumDays,
          adminClaimCode,
          adminTelegramIds: parsedIds,
          strictBanglaOnly: strictBangla,
          autoNormalizeBangla: autoNormalize,
          smartEnglishToBangla,
          ttsModel,
        }),
      });
      if (res.ok) {
        setConfigMsg(
          'সকল লিমিট, ভয়েস ও ভিডিও চার্জ, মেম্বারশিপ এবং সিস্টেম সেটিংস সংরক্ষিত হয়েছে।',
        );
        setPexelsApiKeyInput('');
        onRefresh();
      }
    } finally {
      setSavingConfig(false);
    }
  };

  const handleTelegramAction = async (
    action: 'verify' | 'start_polling' | 'stop' | 'set_webhook',
  ) => {
    setTgLoading(true);
    setTgError(null);
    setTgMessage(null);
    try {
      const res = await fetch('/api/admin/telegram/connect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          token: botTokenInput.trim() || undefined,
          action,
          ...(action === 'set_webhook' ? { webhookUrl } : {}),
        }),
      });
      const data = (await res.json()) as {
        bot?: { username: string; first_name: string };
        error?: string;
      };
      if (!res.ok) {
        setTgError(data.error || 'Telegram সংযোগ ব্যর্থ হয়েছে।');
      } else if (action === 'stop') {
        setTgMessage('Telegram Bot Polling বন্ধ করা হয়েছে।');
        onRefresh();
      } else if (data.bot) {
        setTgMessage(
          action === 'start_polling'
            ? `লাইভ বট চালু হয়েছে (Polling): @${data.bot.username}`
            : action === 'set_webhook'
              ? `24/7 Webhook সংযুক্ত হয়েছে: @${data.bot.username}`
              : `টোকেন যাচাইকৃত: @${data.bot.username}`,
        );
        setBotTokenInput('');
        onRefresh();
      }
    } finally {
      setTgLoading(false);
    }
  };

  const healthKeepAliveUrl =
    typeof window !== 'undefined'
      ? `${window.location.origin}/api/health`
      : '/api/health';

  const copyHealthUrl = async () => {
    await navigator.clipboard.writeText(healthKeepAliveUrl);
    setCopiedHealth(true);
    setTimeout(() => setCopiedHealth(false), 1800);
  };

  const handleSaveAndTestChannel = async () => {
    setTgLoading(true);
    setTgError(null);
    setTgMessage(null);
    try {
      const res = await fetch('/api/admin/telegram/test-channel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ channelId: notificationChannelInput }),
      });
      const data = (await res.json()) as {
        ok?: boolean;
        cleared?: boolean;
        channelId?: string;
        error?: string;
      };
      if (!res.ok) {
        setTgError(data.error || 'চ্যানেলে টেস্ট মেসেজ পাঠানো যায়নি।');
      } else if (data.cleared) {
        setTgMessage('চ্যানেল মুছে ফেলা হয়েছে। এখন অ্যালার্ট Admin DM-এ যাবে।');
        onRefresh();
      } else {
        setTgMessage(
          `✅ নোটিফিকেশন চ্যানেল (${data.channelId}) সেভ ও টেস্ট সফল হয়েছে!`,
        );
        onRefresh();
      }
    } finally {
      setTgLoading(false);
    }
  };

  const webhookUrl =
    typeof window !== 'undefined'
      ? `${window.location.origin}/api/telegram/webhook`
      : '/api/telegram/webhook';

  const copyWebhook = async () => {
    await navigator.clipboard.writeText(webhookUrl);
    setCopiedWebhook(true);
    setTimeout(() => setCopiedWebhook(false), 1800);
  };

  return (
    <div className="space-y-6">
      {/* KPI Metrics Strip */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <p className="text-xs font-medium text-slate-500">
            Total & Active Users
          </p>
          <p className="mt-2 font-mono text-2xl font-bold text-slate-900 tabular-nums">
            {stats?.totalUsers ?? 0}
          </p>
          <p className="mt-1 text-xs text-slate-500 tabular-nums">
            Active: {stats?.activeUsers ?? 0} · Banned: {stats?.bannedUsers ?? 0}
          </p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <p className="text-xs font-medium text-slate-500">
            Total Voices & AI Videos
          </p>
          <p className="mt-2 font-mono text-2xl font-bold text-slate-900 tabular-nums">
            {stats?.totalVoicesGenerated ?? 0} / {stats?.totalVideosGenerated ?? 0}
          </p>
          <p className="mt-1 text-xs text-slate-500 tabular-nums">
            Today: {stats?.todayGenerations ?? 0} · Active Jobs: {stats?.activeJobs ?? 0}
          </p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <p className="text-xs font-medium text-slate-500">
            Free & Premium Plans
          </p>
          <p className="mt-2 font-mono text-2xl font-bold text-slate-900 tabular-nums">
            {stats?.premiumUsers ?? 0} Premium
          </p>
          <p className="mt-1 text-xs text-slate-500 tabular-nums">
            Free Users: {stats?.freeUsers ?? 0} · Duration: {config?.premiumMembershipDays ?? 30}d
          </p>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5">
          <p className="text-xs font-medium text-slate-500">
            Balance & Pending Payments
          </p>
          <p className="mt-2 font-mono text-2xl font-bold text-slate-900 tabular-nums">
            ৳{(stats?.totalBalance ?? 0).toFixed(2)}
          </p>
          <p className="mt-1 text-xs text-slate-500 tabular-nums">
            Pending Requests: {stats?.pendingPayments ?? 0} · Cost: ৳{config?.voiceGenerationCost ?? 0}
          </p>
        </div>
      </div>

      {/* Daily Usage Statistics Chart + Telegram API Config */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="rounded-xl border border-slate-200 bg-white p-5 lg:col-span-7">
          <div className="flex items-center justify-between gap-4">
            <div>
              <h3 className="text-sm font-semibold text-slate-900">
                দৈনিক ব্যবহারের পরিসংখ্যান (Daily Usage Statistics)
              </h3>
              <p className="mt-0.5 text-xs text-slate-500">
                গত ৭ দিনের ভয়েস জেনারেশন সংখ্যা ও অক্ষর ব্যবহার
              </p>
            </div>
            <span className="font-mono text-xs text-slate-500 tabular-nums">
              সর্বোচ্চ: {maxDailyGen} / দিন
            </span>
          </div>

          <div className="mt-6 flex h-44 items-end gap-3 border-b border-slate-100 pb-2">
            {(stats?.dailySeries ?? []).map((day) => {
              const heightPct = Math.max(
                6,
                Math.round((day.generations / maxDailyGen) * 100),
              );
              return (
                <div
                  key={day.date}
                  className="flex flex-1 flex-col items-center justify-end gap-2"
                >
                  <span className="font-mono text-xs font-semibold text-slate-700 tabular-nums">
                    {day.generations}
                  </span>
                  <div className="flex h-28 w-full items-end justify-center">
                    <div
                      className="w-full max-w-[44px] rounded-t-md bg-teal-700 transition-all duration-200"
                      style={{ height: `${heightPct}%` }}
                    />
                  </div>
                  <span className="font-mono text-[11px] text-slate-500 tabular-nums">
                    {day.date.slice(5)}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5 lg:col-span-5">
          <div className="flex items-center justify-between gap-2">
            <h3 className="text-sm font-semibold text-slate-900">
              Telegram Bot API কনফিগারেশন
            </h3>
            <span className="font-mono text-xs font-medium text-slate-600">
              {config?.telegramMode === 'polling'
                ? `Polling · @${config.telegramBotUsername}`
                : config?.telegramMode === 'webhook'
                  ? `Webhook · @${config.telegramBotUsername}`
                  : 'Standby'}
            </span>
          </div>
          <p className="mt-1 text-xs text-slate-500">
            @BotFather থেকে প্রাপ্ত Token এবং /admin অনুমোদন নিয়ন্ত্রণ করুন।
          </p>

          <div className="mt-4 space-y-3">
            <div>
              <label className="block text-xs font-medium text-slate-700">
                Telegram Bot Token{' '}
                {config?.hasTelegramToken ? `(${config.telegramBotTokenMasked})` : ''}
              </label>
              <input
                type="password"
                value={botTokenInput}
                onChange={(e) => setBotTokenInput(e.target.value)}
                placeholder={
                  config?.hasTelegramToken
                    ? 'টোকেন পরিবর্তন করতে নতুন টোকেন দিন...'
                    : '123456789:ABCdefGHIjklMNOpqr...'
                }
                className="mt-1.5 h-10 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-xs text-slate-900 focus:border-teal-700 focus:bg-white focus:outline-none"
              />
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                disabled={tgLoading}
                onClick={() => void handleTelegramAction('verify')}
                className="h-9 rounded-lg border border-slate-200 bg-white px-3.5 text-xs font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-50 whitespace-nowrap shrink-0"
              >
                টোকেন যাচাই
              </button>
              <button
                type="button"
                disabled={tgLoading}
                onClick={() => void handleTelegramAction('start_polling')}
                className="h-9 rounded-lg bg-teal-700 px-3.5 text-xs font-medium text-white hover:bg-teal-800 disabled:opacity-50 whitespace-nowrap shrink-0"
              >
                Polling চালু করুন
              </button>
              <button
                type="button"
                disabled={tgLoading}
                onClick={() => void handleTelegramAction('set_webhook')}
                className="h-9 rounded-lg border border-teal-700 bg-teal-50 px-3.5 text-xs font-medium text-teal-800 hover:bg-teal-100 disabled:opacity-50 whitespace-nowrap shrink-0"
              >
                Webhook সেট (24/7)
              </button>
              {config?.telegramMode === 'polling' && (
                <button
                  type="button"
                  disabled={tgLoading}
                  onClick={() => void handleTelegramAction('stop')}
                  className="h-9 rounded-lg border border-red-200 bg-red-50 px-3.5 text-xs font-medium text-red-700 hover:bg-red-100 disabled:opacity-50 whitespace-nowrap shrink-0"
                >
                  বট বন্ধ করুন
                </button>
              )}
            </div>

            {tgMessage && (
              <div className="rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs text-emerald-800">
                {tgMessage}
              </div>
            )}
            {tgError && (
              <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-800">
                {tgError}
              </div>
            )}

            <div className="border-t border-slate-100 pt-3">
              <label className="block text-xs font-medium text-slate-700">
                Notification Channel (@username বা -100...)
              </label>
              <p className="mt-0.5 text-[11px] text-slate-500">
                কেউ অডিও বা ভিডিও জেনারেট করলে সরাসরি এই চ্যানেলে অ্যালার্ট মেসেজ যাবে (বটকে চ্যানেলের Admin করুন)।
              </p>
              <div className="mt-1.5 flex items-center gap-2">
                <input
                  type="text"
                  value={notificationChannelInput}
                  onChange={(e) => setNotificationChannelInput(e.target.value)}
                  placeholder="@your_channel অথবা -1001234567890"
                  className="h-9 flex-1 rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-xs text-slate-900 focus:border-teal-700 focus:bg-white focus:outline-none"
                />
                <button
                  type="button"
                  disabled={tgLoading}
                  onClick={() => void handleSaveAndTestChannel()}
                  className="h-9 rounded-lg bg-slate-900 px-3 text-xs font-medium text-white hover:bg-slate-800 disabled:opacity-50 whitespace-nowrap shrink-0"
                >
                  সেভ ও টেস্ট
                </button>
              </div>
            </div>

            <div className="border-t border-slate-100 pt-3">
              <label className="block text-xs font-medium text-slate-700">
                Webhook Endpoint URL
              </label>
              <div className="mt-1.5 flex items-center gap-2">
                <input
                  type="text"
                  readOnly
                  value={webhookUrl}
                  aria-label="Telegram Webhook URL"
                  className="h-9 flex-1 rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-[11px] text-slate-600"
                />
                <button
                  type="button"
                  onClick={copyWebhook}
                  className="flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap shrink-0"
                >
                  {copiedWebhook ? (
                    <Check className="h-3.5 w-3.5 text-emerald-600" />
                  ) : (
                    <Copy className="h-3.5 w-3.5" />
                  )}
                  <span>{copiedWebhook ? 'কপি হয়েছে' : 'কপি'}</span>
                </button>
              </div>
            </div>

            <div className="border-t border-slate-100 pt-3">
              <label className="block text-xs font-medium text-slate-700">
                24/7 Keep-Alive Health URL (UptimeRobot / Render)
              </label>
              <p className="mt-0.5 text-[11px] text-slate-500">
                Render Free প্ল্যানে ২৪ ঘণ্টা সক্রিয় রাখতে UptimeRobot-এ প্রতি ৫ মিনিটে এই URL-টি পিং করুন।
              </p>
              <div className="mt-1.5 flex items-center gap-2">
                <input
                  type="text"
                  readOnly
                  value={healthKeepAliveUrl}
                  aria-label="Keep Alive Health URL"
                  className="h-9 flex-1 rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-[11px] text-slate-600"
                />
                <button
                  type="button"
                  onClick={copyHealthUrl}
                  className="flex h-9 items-center gap-1.5 rounded-lg border border-slate-200 bg-white px-3 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap shrink-0"
                >
                  {copiedHealth ? (
                    <Check className="h-3.5 w-3.5 text-emerald-600" />
                  ) : (
                    <Copy className="h-3.5 w-3.5" />
                  )}
                  <span>{copiedHealth ? 'কপি হয়েছে' : 'কপি'}</span>
                </button>
              </div>
            </div>

            <div className="border-t border-slate-100 pt-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <span className="block text-xs font-medium text-slate-700">
                    পোর্টেবল বট সোর্স ও ডিপ্লয়মেন্ট ফাইল (.ZIP)
                  </span>
                  <span className="text-[11px] text-slate-500">
                    যেকোনো VPS, Render বা কম্পিউটারে চালাতে বটের সম্পূর্ণ ফাইল ডাউনলোড করুন (টেলিগ্রামে /files)।
                  </span>
                </div>
                <a
                  href="/api/admin/export-bot-zip"
                  download="BanglaVoice-Bot-All-Files.zip"
                  className="inline-flex h-9 items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 text-xs font-medium text-white hover:bg-slate-800 whitespace-nowrap shrink-0"
                >
                  📦 একত্রিত সব ফাইল (.ZIP) ডাউনলোড
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Payment Requests & Transaction History */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="rounded-xl border border-slate-200 bg-white p-5 lg:col-span-6">
          <h3 className="text-sm font-semibold text-slate-900">
            Payment Management ({paymentRequests.filter((p) => p.status === 'pending').length} Pending)
          </h3>
          <p className="mt-0.5 text-xs text-slate-500">
            ইউজার পেমেন্ট রিকোয়েস্ট Approve করলে ব্যালেন্স স্বয়ংক্রিয়ভাবে যুক্ত হবে ও টেলিগ্রামে নোটিফিকেশন যাবে।
          </p>

          <div className="mt-4 space-y-2.5 max-h-72 overflow-y-auto">
            {paymentRequests.length === 0 ? (
              <div className="rounded-lg border border-dashed border-slate-200 bg-slate-50 p-6 text-center text-xs text-slate-500">
                এখনো কোনো পেমেন্ট রিকোয়েস্ট জমা পড়েনি।
              </div>
            ) : (
              paymentRequests.map((pay) => (
                <div
                  key={pay.id}
                  className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-slate-200 p-3 text-xs"
                >
                  <div>
                    <div className="font-semibold text-slate-900">
                      {pay.userName} · <span className="font-mono">৳{pay.amount}</span>
                    </div>
                    <div className="mt-0.5 text-slate-500">
                      {pay.method}
                      {pay.accountNumber ? ` (${pay.accountNumber})` : ''} · {pay.referenceNote} ·{' '}
                      <span className="font-mono text-[11px]">{pay.id}</span>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    {pay.status === 'pending' ? (
                      <>
                        <button
                          type="button"
                          onClick={() => void handlePaymentReview(pay.id, 'approved')}
                          className="inline-flex h-8 items-center gap-1 rounded-md bg-emerald-700 px-2.5 text-xs font-medium text-white hover:bg-emerald-800 whitespace-nowrap shrink-0"
                        >
                          <CheckCircle2 className="h-3.5 w-3.5" />
                          <span>Approve</span>
                        </button>
                        <button
                          type="button"
                          onClick={() => void handlePaymentReview(pay.id, 'rejected')}
                          className="inline-flex h-8 items-center gap-1 rounded-md border border-red-200 bg-red-50 px-2.5 text-xs font-medium text-red-700 hover:bg-red-100 whitespace-nowrap shrink-0"
                        >
                          <XCircle className="h-3.5 w-3.5" />
                          <span>Reject</span>
                        </button>
                      </>
                    ) : (
                      <span
                        className={`font-mono text-xs font-semibold ${
                          pay.status === 'approved'
                            ? 'text-emerald-700'
                            : 'text-red-700'
                        }`}
                      >
                        {pay.autoVerified ? 'AUTO VERIFIED' : pay.status.toUpperCase()}
                      </span>
                    )}
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5 lg:col-span-6">
          <h3 className="text-sm font-semibold text-slate-900">
            Transaction History & Background Jobs
          </h3>
          <p className="mt-0.5 text-xs text-slate-500">
            সাম্প্রতিক ব্যালেন্স লেনদেন এবং দীর্ঘ অডিও প্রসেসিং জব স্ট্যাটাস।
          </p>

          <div className="mt-4 space-y-2 max-h-72 overflow-y-auto">
            {jobs.slice(0, 4).map((j) => (
              <div
                key={j.id}
                className="flex items-center justify-between gap-3 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs"
              >
                <div className="min-w-0">
                  <div className="truncate font-semibold text-slate-900">
                    Job: {j.voiceNameBn} ({j.userName})
                  </div>
                  <div className="text-slate-500">{j.statusText}</div>
                </div>
                <span className="font-mono text-xs text-slate-700 tabular-nums shrink-0">
                  {j.currentPart}/{j.totalParts}
                </span>
              </div>
            ))}

            {transactions.slice(0, 6).map((tx) => (
              <div
                key={tx.id}
                className="flex items-center justify-between gap-3 rounded-lg border border-slate-100 px-3 py-2 text-xs"
              >
                <div className="min-w-0">
                  <div className="truncate font-medium text-slate-900">
                    {tx.userName} — {tx.description}
                  </div>
                  <div className="font-mono text-[11px] text-slate-400 tabular-nums">
                    Bal: ৳{tx.balanceAfter.toFixed(2)}
                  </div>
                </div>
                <span
                  className={`font-mono font-semibold tabular-nums shrink-0 ${
                    tx.amount >= 0 ? 'text-emerald-700' : 'text-red-700'
                  }`}
                >
                  {tx.amount >= 0 ? '+' : ''}৳{tx.amount}
                </span>
              </div>
            ))}

            {transactions.length === 0 && jobs.length === 0 && (
              <div className="rounded-lg border border-dashed border-slate-200 bg-slate-50 p-6 text-center text-xs text-slate-500">
                এখনো কোনো লেনদেন বা জব রেকর্ড হয়নি।
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Admin Payment Numbers Management */}
      <div className="rounded-xl border border-slate-200 bg-white p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="flex items-center gap-2 text-sm font-semibold text-slate-900">
              <CreditCard className="h-4 w-4 text-teal-700" />
              <span>পেমেন্ট নম্বর ম্যানেজমেন্ট (Payment Numbers Setup)</span>
            </h3>
            <p className="mt-0.5 text-xs text-slate-500">
              এখানে bKash / Nagad / Rocket / Upay নম্বর যুক্ত করলে ব্যবহারকারীরা টেলিগ্রাম বট ও ওয়েব ওয়ালেটে নম্বর দেখে পেমেন্ট কনফার্ম করে রিকোয়েস্ট পাঠাতে পারবে।
            </p>
          </div>
          <span className="font-mono text-xs text-slate-600 tabular-nums">
            সক্রিয় নম্বর: {paymentAccounts.filter((a) => a.enabled).length} / {paymentAccounts.length}
          </span>
        </div>

        <form
          onSubmit={handleAddPaymentAccount}
          className="mt-4 grid grid-cols-1 gap-3 border-y border-slate-100 py-4 md:grid-cols-12"
        >
          <div className="md:col-span-2">
            <label className="block text-[11px] font-medium text-slate-600">
              মাধ্যম (Method)
            </label>
            <select
              value={newPayMethod}
              onChange={(e) => setNewPayMethod(e.target.value)}
              className="mt-1 h-9 w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 text-xs text-slate-900 focus:border-teal-700 focus:bg-white focus:outline-none"
            >
              <option value="bKash">bKash</option>
              <option value="Nagad">Nagad</option>
              <option value="Rocket">Rocket</option>
              <option value="Upay">Upay</option>
              <option value="Bank">Bank</option>
            </select>
          </div>

          <div className="md:col-span-3">
            <label className="block text-[11px] font-medium text-slate-600">
              অ্যাকাউন্ট ধরন
            </label>
            <select
              value={newPayType}
              onChange={(e) => setNewPayType(e.target.value)}
              className="mt-1 h-9 w-full rounded-lg border border-slate-200 bg-slate-50 px-2.5 text-xs text-slate-900 focus:border-teal-700 focus:bg-white focus:outline-none"
            >
              <option value="Personal (Send Money)">Personal (Send Money)</option>
              <option value="Agent (Cash Out)">Agent (Cash Out)</option>
              <option value="Merchant (Payment)">Merchant (Payment)</option>
              <option value="Bank Account">Bank Account</option>
            </select>
          </div>

          <div className="md:col-span-3">
            <label className="block text-[11px] font-medium text-slate-600">
              পেমেন্ট নম্বর
            </label>
            <input
              type="text"
              value={newPayNumber}
              onChange={(e) => setNewPayNumber(e.target.value)}
              placeholder="যেমন: 017XXXXXXXX"
              className="mt-1 h-9 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-xs text-slate-900 focus:border-teal-700 focus:bg-white focus:outline-none"
            />
          </div>

          <div className="md:col-span-2">
            <label className="block text-[11px] font-medium text-slate-600">
              নোট (ঐচ্ছিক)
            </label>
            <input
              type="text"
              value={newPayNote}
              onChange={(e) => setNewPayNote(e.target.value)}
              placeholder="Send Money Only"
              className="mt-1 h-9 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs text-slate-900 focus:border-teal-700 focus:bg-white focus:outline-none"
            />
          </div>

          <div className="flex items-end md:col-span-2">
            <button
              type="submit"
              disabled={savingPayAcc || !newPayNumber.trim()}
              className="flex h-9 w-full items-center justify-center gap-1.5 rounded-lg bg-teal-700 px-3 text-xs font-medium text-white hover:bg-teal-800 disabled:opacity-50 whitespace-nowrap"
            >
              <Plus className="h-3.5 w-3.5" />
              <span>নম্বর যোগ করুন</span>
            </button>
          </div>
        </form>

        {payAccMsg && (
          <div className="mt-3 rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs text-emerald-800">
            {payAccMsg}
          </div>
        )}

        <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {paymentAccounts.length === 0 ? (
            <div className="col-span-full rounded-lg border border-dashed border-slate-200 bg-slate-50 p-5 text-center text-xs text-slate-500">
              এখনো কোনো পেমেন্ট নম্বর যুক্ত করা হয়নি। উপরে আপনার bKash / Nagad / Rocket নম্বর যুক্ত করুন।
            </div>
          ) : (
            paymentAccounts.map((acc) => (
              <div
                key={acc.id}
                className={`flex flex-col justify-between rounded-lg border p-3.5 text-xs ${
                  acc.enabled
                    ? 'border-slate-200 bg-white'
                    : 'border-slate-200 bg-slate-50 opacity-75'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-semibold text-slate-900">
                      {acc.method}
                    </span>
                    <span
                      className={`font-mono text-[11px] font-medium ${
                        acc.enabled ? 'text-emerald-700' : 'text-slate-500'
                      }`}
                    >
                      {acc.enabled ? 'Active' : 'Disabled'}
                    </span>
                  </div>
                  <div className="mt-1 font-mono text-sm font-bold text-slate-900 tabular-nums">
                    {acc.accountNumber}
                  </div>
                  <div className="mt-0.5 text-[11px] text-slate-500">
                    {acc.accountType}
                    {acc.note ? ` · ${acc.note}` : ''}
                  </div>
                </div>

                <div className="mt-3 flex items-center justify-end gap-2 border-t border-slate-100 pt-2.5">
                  <button
                    type="button"
                    disabled={savingPayAcc}
                    onClick={() => void handleTogglePaymentAccount(acc.id)}
                    className="h-7 rounded border border-slate-200 bg-white px-2.5 text-[11px] font-medium text-slate-700 hover:bg-slate-50"
                  >
                    {acc.enabled ? 'বন্ধ করুন' : 'চালু করুন'}
                  </button>
                  <button
                    type="button"
                    disabled={savingPayAcc}
                    onClick={() => void handleDeletePaymentAccount(acc.id)}
                    aria-label={`Delete ${acc.method} ${acc.accountNumber}`}
                    className="inline-flex h-7 items-center gap-1 rounded border border-red-200 bg-red-50 px-2 text-[11px] font-medium text-red-700 hover:bg-red-100"
                  >
                    <Trash2 className="h-3 w-3" />
                    <span>মুছুন</span>
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* User Payment Description / Instructions Editor */}
        <div className="mt-5 border-t border-slate-100 pt-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <label
                htmlFor="payment-instructions-input"
                className="block text-xs font-semibold text-slate-900"
              >
                ইউজার পেমেন্ট নির্দেশনা / ডেসক্রিপশন (User Payment Guide)
              </label>
              <p className="mt-0.5 text-[11px] text-slate-500">
                ইউজার কিভাবে টাকা পাঠাবে ও TrxID জমা দেবে তার বিবরণ এখানে লিখুন—এটি ওয়েব ওয়ালেট ও টেলিগ্রাম বটে ইউজারকে দেখানো হবে।
              </p>
            </div>
            <button
              type="button"
              disabled={savingPayAcc}
              onClick={() => void handleSavePaymentInstructions()}
              className="h-8 rounded-lg bg-slate-900 px-3.5 text-xs font-medium text-white hover:bg-slate-800 disabled:opacity-50 whitespace-nowrap shrink-0"
            >
              নির্দেশনা সেভ করুন
            </button>
          </div>
          <textarea
            id="payment-instructions-input"
            rows={4}
            value={paymentInstructions}
            onChange={(e) => setPaymentInstructions(e.target.value)}
            placeholder="১. নম্বর কপি করে Send Money করুন..."
            className="mt-2 w-full rounded-lg border border-slate-200 bg-slate-50 p-3 text-xs leading-relaxed text-slate-900 focus:border-teal-700 focus:bg-white focus:outline-none"
          />
        </div>
      </div>

      {/* Automatic TrxID SMS Verification Setup */}
      <div className="rounded-xl border border-slate-200 bg-white p-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="flex items-center gap-2 text-sm font-semibold text-slate-900">
              <Zap className="h-4 w-4 text-teal-700" />
              <span>অটোমেটিক পেমেন্ট ভেরিফিকেশন (Auto TrxID & SMS Forwarder)</span>
            </h3>
            <p className="mt-0.5 text-xs text-slate-500">
              আপনার অ্যান্ড্রয়েড ফোনে আসা bKash / Nagad / Rocket পেমেন্ট SMS সরাসরি নিচের Webhook-এ পাঠালে, ইউজার TrxID বসানোর সাথে সাথেই সিস্টেম অটো-ভেরিফাই করে ব্যালেন্স যুক্ত করে দেবে (এবং একই TrxID দ্বিতীয়বার ব্যবহার বন্ধ রাখবে)।
            </p>
          </div>

          <label className="flex cursor-pointer items-center gap-2 rounded-lg border border-slate-200 bg-slate-50 px-3 py-2 text-xs font-medium text-slate-900">
            <input
              type="checkbox"
              checked={autoVerifyPayments}
              onChange={(e) => void handleToggleAutoVerify(e.target.checked)}
              className="h-4 w-4 accent-teal-700"
            />
            <span>Auto Verify চালু রাখুন</span>
          </label>
        </div>

        <div className="mt-4 grid grid-cols-1 gap-4 lg:grid-cols-12">
          <div className="space-y-3 lg:col-span-6">
            <div>
              <label className="block text-[11px] font-medium text-slate-600">
                SMS Forwarder Webhook URL (POST JSON)
              </label>
              <div className="mt-1 flex items-center gap-2">
                <input
                  type="text"
                  readOnly
                  value={
                    typeof window !== 'undefined'
                      ? `${window.location.origin}/api/payments/sms-webhook`
                      : '/api/payments/sms-webhook'
                  }
                  aria-label="SMS Webhook URL"
                  className="h-9 flex-1 rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-[11px] text-slate-700"
                />
                <button
                  type="button"
                  onClick={async () => {
                    const url =
                      typeof window !== 'undefined'
                        ? `${window.location.origin}/api/payments/sms-webhook`
                        : '/api/payments/sms-webhook';
                    await navigator.clipboard.writeText(url);
                    setCopiedSmsUrl(true);
                    setTimeout(() => setCopiedSmsUrl(false), 1600);
                  }}
                  className="inline-flex h-9 items-center gap-1 rounded-lg border border-slate-200 bg-white px-3 text-xs font-medium text-slate-700 hover:bg-slate-50"
                >
                  {copiedSmsUrl ? (
                    <Check className="h-3.5 w-3.5 text-emerald-600" />
                  ) : (
                    <Copy className="h-3.5 w-3.5" />
                  )}
                  <span>{copiedSmsUrl ? 'কপি' : 'কপি'}</span>
                </button>
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-medium text-slate-600">
                Webhook Secret (Header: x-webhook-secret অথবা JSON body: secret)
              </label>
              <div className="mt-1 flex items-center gap-2">
                <input
                  type="text"
                  readOnly
                  value={config?.smsWebhookSecret ?? ''}
                  aria-label="SMS Webhook Secret"
                  className="h-9 flex-1 rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-xs font-semibold text-slate-900"
                />
                <button
                  type="button"
                  onClick={async () => {
                    if (!config?.smsWebhookSecret) return;
                    await navigator.clipboard.writeText(config.smsWebhookSecret);
                    setCopiedSmsSecret(true);
                    setTimeout(() => setCopiedSmsSecret(false), 1600);
                  }}
                  className="inline-flex h-9 items-center gap-1 rounded-lg border border-slate-200 bg-white px-3 text-xs font-medium text-slate-700 hover:bg-slate-50"
                >
                  {copiedSmsSecret ? (
                    <Check className="h-3.5 w-3.5 text-emerald-600" />
                  ) : (
                    <Copy className="h-3.5 w-3.5" />
                  )}
                  <span>কপি</span>
                </button>
                <button
                  type="button"
                  disabled={smsSyncing}
                  onClick={() => void handleRegenerateSmsSecret()}
                  title="নতুন Secret তৈরি করুন"
                  className="inline-flex h-9 items-center gap-1 rounded-lg border border-slate-200 bg-white px-2.5 text-xs font-medium text-slate-700 hover:bg-slate-50"
                >
                  <RefreshCw className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>

            <div className="rounded-lg border border-slate-200 bg-slate-50 p-3 text-[11px] text-slate-600">
              <div className="font-semibold text-slate-800">
                Android SMS Forwarder / MacroDroid JSON ফরম্যাট:
              </div>
              <pre className="mt-1 overflow-x-auto font-mono text-[11px] text-slate-800">
                {`{ "secret": "${config?.smsWebhookSecret || 'SECRET'}", "message": "{sms_body}" }`}
              </pre>
            </div>
          </div>

          <div className="space-y-3 lg:col-span-6">
            <form onSubmit={handleManualSmsSync} className="space-y-2">
              <label
                htmlFor="manual-sms-sync"
                className="block text-[11px] font-medium text-slate-600"
              >
                বিকাশ / নগদ / রকেট পেমেন্ট SMS সরাসরি পেস্ট করে সিঙ্ক করুন (তাৎক্ষণিক ম্যাচিং)
              </label>
              <div className="flex gap-2">
                <textarea
                  id="manual-sms-sync"
                  rows={2}
                  value={smsPasteText}
                  onChange={(e) => setSmsPasteText(e.target.value)}
                  placeholder="যেমন: You have received Tk 100.00 from 01711223344. Ref ... TrxID 9X82AB12"
                  className="flex-1 rounded-lg border border-slate-200 bg-slate-50 p-2.5 font-mono text-xs text-slate-900 focus:border-teal-700 focus:bg-white focus:outline-none"
                />
                <button
                  type="submit"
                  disabled={smsSyncing || !smsPasteText.trim()}
                  className="h-auto rounded-lg bg-teal-700 px-4 text-xs font-medium text-white hover:bg-teal-800 disabled:opacity-50 whitespace-nowrap shrink-0"
                >
                  SMS সিঙ্ক
                </button>
              </div>
            </form>

            {smsMsg && (
              <div className="rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-xs text-emerald-800">
                {smsMsg}
              </div>
            )}
            {smsError && (
              <div className="rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-xs text-red-800">
                {smsError}
              </div>
            )}

            <div>
              <div className="text-[11px] font-semibold text-slate-700">
                আগত ভেরিফাইড SMS লগ ({incomingPaymentSms.length})
              </div>
              <div className="mt-1.5 max-h-36 space-y-1.5 overflow-y-auto">
                {incomingPaymentSms.length === 0 ? (
                  <div className="rounded-lg border border-dashed border-slate-200 bg-slate-50 p-3 text-center text-[11px] text-slate-500">
                    এখনো কোনো পেমেন্ট SMS সিঙ্ক হয়নি।
                  </div>
                ) : (
                  incomingPaymentSms.slice(0, 10).map((s) => (
                    <div
                      key={s.id}
                      className="flex items-center justify-between gap-2 rounded-lg border border-slate-200 px-3 py-1.5 text-xs"
                    >
                      <div className="min-w-0">
                        <span className="font-semibold text-slate-900">
                          {s.method} · ৳{s.amount}
                        </span>{' '}
                        <span className="font-mono text-[11px] text-slate-600">
                          TrxID: {s.trxId}
                        </span>
                      </div>
                      <span
                        className={`font-mono text-[11px] font-semibold shrink-0 ${
                          s.status === 'claimed'
                            ? 'text-emerald-700'
                            : 'text-amber-700'
                        }`}
                      >
                        {s.status === 'claimed'
                          ? `CLAIMED (${s.claimedByUserName ?? ''})`
                          : 'UNMATCHED'}
                      </span>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* User Management Section */}
      <div className="rounded-xl border border-slate-200 bg-white p-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h3 className="text-sm font-semibold text-slate-900">
              ইউজার ম্যানেজমেন্ট (Balance, Limit, Free/Premium ও Ban/Unban)
            </h3>
            <p className="mt-0.5 text-xs text-slate-500">
              ব্যবহারকারীদের ব্যালেন্স যোগ/বিয়োগ, দৈনিক লিমিট, প্রিমিয়াম মেম্বারশিপ এবং টেলিগ্রাম অ্যাডমিন অনুমোদন নিয়ন্ত্রণ করুন।
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={userSearch}
                onChange={(e) => setUserSearch(e.target.value)}
                placeholder="Telegram ID বা নাম খুঁজুন..."
                className="h-9 w-56 rounded-lg border border-slate-200 bg-slate-50 pl-9 pr-3 text-xs text-slate-900 focus:border-teal-700 focus:bg-white focus:outline-none"
              />
            </div>

            <div className="flex items-center gap-1 rounded-lg bg-slate-100 p-1">
              {(['all', 'free', 'premium', 'banned'] as const).map((tab) => (
                <button
                  key={tab}
                  type="button"
                  onClick={() => setUserFilter(tab)}
                  className={`rounded-md px-3 py-1 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                    userFilter === tab
                      ? 'bg-white text-slate-900 shadow-sm'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {tab === 'all'
                    ? 'সবাই'
                    : tab === 'free'
                      ? 'Free'
                      : tab === 'premium'
                        ? 'Premium'
                        : 'Banned'}
                </button>
              ))}
            </div>
          </div>
        </div>

        <form
          onSubmit={handleAddUser}
          className="mt-4 flex flex-wrap items-center gap-2.5 border-y border-slate-100 py-3"
        >
          <UserPlus className="h-4 w-4 text-slate-500" />
          <input
            type="text"
            value={newUserName}
            onChange={(e) => setNewUserName(e.target.value)}
            placeholder="নতুন টেস্ট ইউজারের নাম (যেমন: রাকিব হাসান)"
            className="h-9 w-64 rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs text-slate-900 focus:border-teal-700 focus:bg-white focus:outline-none"
          />
          <select
            value={newUserTier}
            onChange={(e) => setNewUserTier(e.target.value as 'free' | 'premium')}
            aria-label="New user tier"
            className="h-9 rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs text-slate-900 focus:border-teal-700 focus:outline-none"
          >
            <option value="free">Free Plan</option>
            <option value="premium">Premium Plan</option>
          </select>
          <button
            type="submit"
            disabled={addingUser || !newUserName.trim()}
            className="flex h-9 items-center gap-1.5 rounded-lg bg-slate-900 px-3.5 text-xs font-medium text-white hover:bg-slate-800 disabled:opacity-50 whitespace-nowrap shrink-0"
          >
            <Plus className="h-3.5 w-3.5" />
            <span>ইউজার যোগ করুন</span>
          </button>
        </form>

        <div className="mt-3 overflow-x-auto">
          <table className="w-full min-w-[960px] border-collapse text-left text-xs">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500">
                <th className="py-3 font-medium">ব্যবহারকারী</th>
                <th className="py-3 font-medium">প্ল্যান ও রোল</th>
                <th className="py-3 font-medium">অবস্থা</th>
                <th className="py-3 text-right font-medium">ব্যালেন্স</th>
                <th className="py-3 text-right font-medium">আজ / মোট</th>
                <th className="py-3 text-right font-medium">কাস্টম লিমিট</th>
                <th className="py-3 text-right font-medium">অ্যাকশন</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredUsers.map((u) => {
                const defaultLimit =
                  u.tier === 'premium'
                    ? (config?.premiumDailyLimit ?? 200)
                    : (config?.freeDailyLimit ?? 10);
                const effectiveLimit = u.customDailyLimit ?? defaultLimit;
                const balVal = balanceInputs[u.id] ?? '';

                return (
                  <tr key={u.id} className="hover:bg-slate-50/80">
                    <td className="py-3 pr-4">
                      <div className="font-semibold text-slate-900">
                        {u.firstName}
                      </div>
                      <div className="font-mono text-[11px] text-slate-500">
                        @{u.username} · ID {u.telegramId}
                      </div>
                    </td>
                    <td className="py-3 pr-4">
                      <div
                        className={`font-medium ${
                          u.tier === 'premium'
                            ? 'text-amber-700'
                            : 'text-slate-600'
                        }`}
                      >
                        {u.tier === 'premium' ? 'Premium' : 'Free'}
                        {u.role === 'admin' ? ' · Admin' : ''}
                      </div>
                    </td>
                    <td className="py-3 pr-4">
                      <span
                        className={`font-medium ${
                          u.status === 'banned'
                            ? 'text-red-700'
                            : 'text-emerald-700'
                        }`}
                      >
                        {u.status === 'banned' ? 'Banned' : 'Active'}
                      </span>
                    </td>
                    <td className="py-3 pr-4 text-right">
                      <div className="inline-flex items-center gap-1.5">
                        <span className="font-mono font-semibold tabular-nums text-slate-900">
                          ৳{u.balance.toFixed(0)}
                        </span>
                        <input
                          type="number"
                          placeholder="+/-"
                          value={balVal}
                          onChange={(e) =>
                            setBalanceInputs((prev) => ({
                              ...prev,
                              [u.id]: e.target.value,
                            }))
                          }
                          className="h-7 w-16 rounded border border-slate-200 bg-slate-50 px-1.5 text-right font-mono text-[11px] tabular-nums"
                        />
                        <button
                          type="button"
                          onClick={() =>
                            void handleBalanceAdjust(u.id, Number(balVal))
                          }
                          title="Add/Deduct Balance"
                          className="inline-flex h-7 items-center rounded border border-slate-200 bg-white px-2 text-[11px] font-medium text-slate-700 hover:bg-slate-50"
                        >
                          <Wallet className="h-3 w-3" />
                        </button>
                      </div>
                    </td>
                    <td className="py-3 pr-4 text-right font-mono tabular-nums text-slate-900">
                      {u.dailyCount}/{effectiveLimit} · {u.totalCount}
                    </td>
                    <td className="py-3 pr-4 text-right">
                      <input
                        type="number"
                        min={0}
                        placeholder={String(defaultLimit)}
                        defaultValue={u.customDailyLimit ?? ''}
                        onBlur={(e) => {
                          const raw = e.target.value.trim();
                          const nextVal = raw === '' ? null : Number(raw);
                          if (nextVal !== u.customDailyLimit) {
                            void handleUserUpdate(u.id, {
                              customDailyLimit: nextVal,
                            });
                          }
                        }}
                        aria-label={`Custom daily limit for ${u.firstName}`}
                        className="h-8 w-20 rounded border border-slate-200 bg-slate-50 px-2 text-right font-mono text-xs tabular-nums text-slate-900 focus:border-teal-700 focus:bg-white focus:outline-none"
                      />
                    </td>
                    <td className="py-3 text-right">
                      <div className="inline-flex items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() =>
                            void handleUserUpdate(u.id, {
                              tier: u.tier === 'premium' ? 'free' : 'premium',
                            })
                          }
                          className="inline-flex h-8 items-center gap-1 rounded-md border border-slate-200 bg-white px-2.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap shrink-0"
                        >
                          <Crown className="h-3.5 w-3.5 text-amber-600" />
                          <span>
                            {u.tier === 'premium' ? 'Free' : 'Premium'}
                          </span>
                        </button>

                        <button
                          type="button"
                          onClick={() =>
                            void handleUserUpdate(u.id, {
                              role: u.role === 'admin' ? 'user' : 'admin',
                            })
                          }
                          className="inline-flex h-8 items-center gap-1 rounded-md border border-slate-200 bg-white px-2.5 text-xs font-medium text-slate-700 hover:bg-slate-50 whitespace-nowrap shrink-0"
                        >
                          <Shield className="h-3.5 w-3.5 text-teal-700" />
                          <span>{u.role === 'admin' ? 'User' : 'Admin'}</span>
                        </button>

                        <button
                          type="button"
                          onClick={() =>
                            void handleUserUpdate(u.id, {
                              status:
                                u.status === 'banned' ? 'active' : 'banned',
                            })
                          }
                          className={`inline-flex h-8 items-center gap-1 rounded-md border px-2.5 text-xs font-medium whitespace-nowrap shrink-0 ${
                            u.status === 'banned'
                              ? 'border-emerald-200 bg-emerald-50 text-emerald-800 hover:bg-emerald-100'
                              : 'border-red-200 bg-red-50 text-red-700 hover:bg-red-100'
                          }`}
                        >
                          {u.status === 'banned' ? (
                            <>
                              <ShieldCheck className="h-3.5 w-3.5" />
                              <span>Unban</span>
                            </>
                          ) : (
                            <>
                              <Ban className="h-3.5 w-3.5" />
                              <span>Ban</span>
                            </>
                          )}
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Free & Premium Plan Settings + Voice Engine & Admin Access */}
      <form
        onSubmit={handleSaveConfig}
        className="rounded-xl border border-slate-200 bg-white p-5"
      >
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h3 className="text-sm font-semibold text-slate-900">
              Free & Premium Plans, Voice Cost ও System Settings
            </h3>
            <p className="mt-0.5 text-xs text-slate-500">
              Character Limit 0 রাখলে Unlimited Duration চালু থাকবে। প্রতিটি পরিবর্তন সাথে সাথে কার্যকর হবে।
            </p>
          </div>
          <button
            type="submit"
            disabled={savingConfig}
            className="h-9 rounded-lg bg-teal-700 px-4 text-xs font-medium text-white hover:bg-teal-800 disabled:opacity-50 whitespace-nowrap shrink-0"
          >
            {savingConfig ? 'সংরক্ষণ হচ্ছে...' : 'সেটিংস সেভ করুন'}
          </button>
        </div>

        <div className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <div>
            <label className="block text-xs font-medium text-slate-700">
              Free User Daily Limit
            </label>
            <input
              type="number"
              min={0}
              value={freeLimit}
              onChange={(e) => setFreeLimit(Number(e.target.value))}
              className="mt-1.5 h-10 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-sm tabular-nums text-slate-900 focus:border-teal-700 focus:bg-white focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700">
              Premium User Daily Limit
            </label>
            <input
              type="number"
              min={0}
              value={premiumLimit}
              onChange={(e) => setPremiumLimit(Number(e.target.value))}
              className="mt-1.5 h-10 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-sm tabular-nums text-slate-900 focus:border-teal-700 focus:bg-white focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700">
              Free Character Limit (0 = Unlimited)
            </label>
            <input
              type="number"
              min={0}
              value={maxCharsFree}
              onChange={(e) => setMaxCharsFree(Number(e.target.value))}
              className="mt-1.5 h-10 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-sm tabular-nums text-slate-900 focus:border-teal-700 focus:bg-white focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700">
              Premium Character Limit (0 = Unlimited)
            </label>
            <input
              type="number"
              min={0}
              value={maxCharsPremium}
              onChange={(e) => setMaxCharsPremium(Number(e.target.value))}
              className="mt-1.5 h-10 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-sm tabular-nums text-slate-900 focus:border-teal-700 focus:bg-white focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700">
              Voice Generation Cost (৳ / Voice)
            </label>
            <input
              type="number"
              min={0}
              step="0.5"
              value={voiceCost}
              onChange={(e) => setVoiceCost(Number(e.target.value))}
              className="mt-1.5 h-10 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-sm tabular-nums text-slate-900 focus:border-teal-700 focus:bg-white focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700">
              Premium Membership Duration (Days)
            </label>
            <input
              type="number"
              min={1}
              value={premiumDays}
              onChange={(e) => setPremiumDays(Number(e.target.value))}
              className="mt-1.5 h-10 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-sm tabular-nums text-slate-900 focus:border-teal-700 focus:bg-white focus:outline-none"
            />
          </div>
        </div>

        <div className="mt-4 grid grid-cols-1 gap-4 border-t border-slate-100 pt-4 md:grid-cols-2">
          <div>
            <label className="block text-xs font-medium text-slate-700">
              Authorized Admin Telegram IDs (comma separated)
            </label>
            <input
              type="text"
              value={adminIdsText}
              onChange={(e) => setAdminIdsText(e.target.value)}
              placeholder="123456789, 987654321"
              className="mt-1.5 h-10 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-xs text-slate-900 focus:border-teal-700 focus:bg-white focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700">
              Telegram /admin Claim Code
            </label>
            <input
              type="text"
              value={adminClaimCode}
              onChange={(e) => setAdminClaimCode(e.target.value)}
              className="mt-1.5 h-10 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-xs text-slate-900 focus:border-teal-700 focus:bg-white focus:outline-none"
            />
          </div>
        </div>

        <div className="mt-4 grid grid-cols-1 gap-4 border-t border-slate-100 pt-4 md:grid-cols-2 lg:grid-cols-4">
          <div>
            <label className="block text-xs font-medium text-slate-700">
              TTS ভয়েস ইঞ্জিন মডেল
            </label>
            <select
              value={ttsModel}
              onChange={(e) =>
                setTtsModel(
                  e.target.value as
                    | 'gemini-3.8-flash-lite-tts'
                    | 'gemini-3.8-flash-tts',
                )
              }
              className="mt-1.5 h-10 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs text-slate-900 focus:border-teal-700 focus:outline-none"
            >
              <option value="gemini-3.8-flash-lite-tts">
                gemini-3.8-flash-lite-tts (Fast & Natural)
              </option>
              <option value="gemini-3.8-flash-tts">
                gemini-3.8-flash-tts (Expressive Studio)
              </option>
            </select>
          </div>

          <label className="flex cursor-pointer items-center gap-3 rounded-lg border border-slate-200 bg-slate-50 px-4 py-2.5">
            <input
              type="checkbox"
              checked={smartEnglishToBangla}
              onChange={(e) => setSmartEnglishToBangla(e.target.checked)}
              className="h-4 w-4 accent-teal-700"
            />
            <div>
              <div className="text-xs font-semibold text-slate-900">
                Smart English → Bangla
              </div>
              <div className="text-[11px] text-slate-500">
                ইংরেজি ও মিশ্রিত স্ক্রিপ্ট ব্র্যান্ড উচ্চারণসহ বাংলায় রূপান্তর
              </div>
            </div>
          </label>

          <label className="flex cursor-pointer items-center gap-3 rounded-lg border border-slate-200 bg-slate-50 px-4 py-2.5">
            <input
              type="checkbox"
              checked={strictBangla}
              onChange={(e) => setStrictBangla(e.target.checked)}
              className="h-4 w-4 accent-teal-700"
            />
            <div>
              <div className="text-xs font-semibold text-slate-900">
                Strict Bangla-Only মোড
              </div>
              <div className="text-[11px] text-slate-500">
                Smart EN→BN বন্ধ থাকলে ইংরেজি বাতিল করবে
              </div>
            </div>
          </label>

          <label className="flex cursor-pointer items-center gap-3 rounded-lg border border-slate-200 bg-slate-50 px-4 py-2.5">
            <input
              type="checkbox"
              checked={autoNormalize}
              onChange={(e) => setAutoNormalize(e.target.checked)}
              className="h-4 w-4 accent-teal-700"
            />
            <div>
              <div className="text-xs font-semibold text-slate-900">
                স্বাভাবিক উচ্চারণ অপটিমাইজেশন
              </div>
              <div className="text-[11px] text-slate-500">
                সংখ্যা ও বিরামচিহ্ন স্পষ্ট বাংলা শব্দে রূপান্তর
              </div>
            </div>
          </label>
        </div>

        {/* AI Video Studio Engine Configuration */}
        <div className="mt-4 grid grid-cols-1 gap-4 border-t border-slate-100 pt-4 md:grid-cols-3">
          <div>
            <label className="block text-xs font-medium text-slate-700">
              AI Video Cost (৳ / Video · 0 = ফ্রি)
            </label>
            <input
              type="number"
              min={0}
              step="1"
              value={videoCost}
              onChange={(e) => setVideoCost(Number(e.target.value))}
              className="mt-1.5 h-10 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-sm tabular-nums text-slate-900 focus:border-teal-700 focus:bg-white focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700">
              ভিজ্যুয়াল প্রোভাইডার মোড (Visual Engine)
            </label>
            <select
              value={visualProviderMode}
              onChange={(e) =>
                setVisualProviderMode(e.target.value as VideoVisualMode)
              }
              className="mt-1.5 h-10 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 text-xs text-slate-900 focus:border-teal-700 focus:outline-none"
            >
              <option value="auto">
                Auto (Stock Video → AI Image → Motion Art)
              </option>
              <option value="stock_video">Stock HD Video First (Pexels)</option>
              <option value="ai_image">AI Generated Images First</option>
              <option value="cinematic_motion">
                Fast Motion Art Only (Ultra Reliable)
              </option>
            </select>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-700">
              Pexels Stock Video API Key (ঐচ্ছিক){' '}
              {config?.hasPexelsKey ? `(${config.pexelsApiKeyMasked})` : ''}
            </label>
            <input
              type="password"
              value={pexelsApiKeyInput}
              onChange={(e) => setPexelsApiKeyInput(e.target.value)}
              placeholder={
                config?.hasPexelsKey
                  ? 'পরিবর্তন করতে নতুন Key দিন...'
                  : 'Pexels Video API Key দিলে রিয়েল HD ফুটেজ আসবে'
              }
              className="mt-1.5 h-10 w-full rounded-lg border border-slate-200 bg-slate-50 px-3 font-mono text-xs text-slate-900 focus:border-teal-700 focus:bg-white focus:outline-none"
            />
          </div>
        </div>

        <div className="mt-5 border-t border-slate-100 pt-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div>
              <h4 className="text-xs font-semibold text-slate-900">
                ভয়েস অনুযায়ী আলাদা চার্জ (Per-Voice Charges · ৳ / Voice)
              </h4>
              <p className="mt-0.5 text-[11px] text-slate-500">
                কোনো ভয়েসের ঘর খালি রাখলে উপরে সেট করা Default Cost (৳{voiceCost}) প্রযোজ্য হবে। 0 দিলে ঐ নির্দিষ্ট ভয়েসটি ফ্রি থাকবে।
              </p>
            </div>
            <button
              type="button"
              onClick={() => setVoiceCostInputs({})}
              className="rounded border border-slate-200 bg-slate-50 px-2.5 py-1 text-[11px] font-medium text-slate-600 hover:bg-slate-100"
            >
              সবগুলো Default-এ রিসেট
            </button>
          </div>

          <div className="mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {voices.map((v) => {
              const rawVal = voiceCostInputs[v.id] ?? '';
              const effectivePrice =
                rawVal.trim() !== '' && !Number.isNaN(Number(rawVal))
                  ? Number(rawVal)
                  : voiceCost;
              return (
                <div
                  key={v.id}
                  className="rounded-lg border border-slate-200 bg-slate-50 p-3"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="truncate text-xs font-semibold text-slate-900">
                      {v.nameBn}
                    </span>
                    <span className="font-mono text-[11px] font-semibold text-teal-700 tabular-nums shrink-0">
                      {effectivePrice > 0 ? `৳${effectivePrice}` : 'ফ্রি'}
                    </span>
                  </div>
                  <div className="mt-0.5 text-[11px] text-slate-500">
                    {v.category === 'male'
                      ? 'Male'
                      : v.category === 'female'
                        ? 'Female'
                        : 'Cartoon'}{' '}
                    · {v.roleBn}
                  </div>
                  <input
                    type="number"
                    min={0}
                    step="0.5"
                    value={rawVal}
                    onChange={(e) =>
                      setVoiceCostInputs((prev) => ({
                        ...prev,
                        [v.id]: e.target.value,
                      }))
                    }
                    placeholder={`Default (৳${voiceCost})`}
                    aria-label={`Charge in BDT for ${v.nameEn}`}
                    className="mt-2 h-8 w-full rounded border border-slate-200 bg-white px-2.5 font-mono text-xs tabular-nums text-slate-900 focus:border-teal-700 focus:outline-none"
                  />
                </div>
              );
            })}
          </div>
        </div>

        {configMsg && (
          <div className="mt-4 rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-2.5 text-xs font-medium text-emerald-800">
            {configMsg}
          </div>
        )}
      </form>

      {/* AI Feature Controls, Usage Stats & System Error Logs */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <div className="rounded-xl border border-slate-200 bg-white p-5 lg:col-span-7">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="flex items-center gap-2 text-sm font-semibold text-slate-900">
                <Cpu className="h-4 w-4 text-teal-700" />
                <span>AI ফিচার কন্ট্রোল ও ব্যবহার পরিসংখ্যান</span>
              </h3>
              <p className="mt-0.5 text-xs text-slate-500">
                প্রতিটি মডিউল তাৎক্ষণিক চালু/বন্ধ করুন এবং রিয়েল-টাইম ব্যবহারের সংখ্যা দেখুন।
              </p>
            </div>
            <div className="flex items-center gap-2">
              <label className="text-[11px] font-medium text-slate-600">
                Chat Engine:
              </label>
              <select
                value={config?.defaultChatModel ?? 'gemini-4-hydrogen'}
                disabled={savingFeatures}
                onChange={(e) =>
                  void handleChatModelChange(
                    e.target.value as 'gemini-4-hydrogen' | 'gemini-3.1-flash-lite',
                  )
                }
                aria-label="Default AI Chat Model"
                className="h-8 rounded-lg border border-slate-200 bg-slate-50 px-2.5 font-mono text-[11px] text-slate-900 focus:border-teal-700 focus:outline-none"
              >
                <option value="gemini-4-hydrogen">gemini-4-hydrogen (Balanced)</option>
                <option value="gemini-3.1-flash-lite">gemini-3.1-flash-lite (Fast)</option>
              </select>
            </div>
          </div>

          <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
            {FEATURE_META.map((feat) => {
              const enabled = config?.enabledFeatures?.[feat.id] ?? true;
              const usageCount = stats?.featureUsage?.[feat.id] ?? 0;
              return (
                <div
                  key={feat.id}
                  className={`flex items-center justify-between gap-3 rounded-lg border p-3 transition-colors ${
                    enabled
                      ? 'border-slate-200 bg-slate-50/70'
                      : 'border-red-200 bg-red-50/40'
                  }`}
                >
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="truncate text-xs font-semibold text-slate-900">
                        {feat.labelBn}
                      </span>
                      <span className="font-mono text-[11px] text-teal-700 tabular-nums shrink-0">
                        {usageCount}x
                      </span>
                    </div>
                    <p className="mt-0.5 truncate text-[11px] text-slate-500">
                      {feat.desc}
                    </p>
                  </div>
                  <button
                    type="button"
                    disabled={savingFeatures}
                    onClick={() => void handleFeatureToggle(feat.id)}
                    className={`h-8 shrink-0 rounded-md px-3 text-xs font-medium transition-colors whitespace-nowrap ${
                      enabled
                        ? 'bg-emerald-700 text-white hover:bg-emerald-800'
                        : 'border border-red-300 bg-white text-red-700 hover:bg-red-50'
                    }`}
                  >
                    {enabled ? 'চালু' : 'বন্ধ'}
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        <div className="rounded-xl border border-slate-200 bg-white p-5 lg:col-span-5">
          <div className="flex items-center justify-between gap-3">
            <div>
              <h3 className="flex items-center gap-2 text-sm font-semibold text-slate-900">
                <AlertTriangle className="h-4 w-4 text-amber-600" />
                <span>সিস্টেম এরর লগ ({errorLogs.length})</span>
              </h3>
              <p className="mt-0.5 text-xs text-slate-500">
                বট বা AI ইঞ্জিনের সাম্প্রতিক ত্রুটি পর্যবেক্ষণ ও পরিষ্কার করুন।
              </p>
            </div>
            <button
              type="button"
              disabled={clearingErrors || errorLogs.length === 0}
              onClick={() => void handleClearErrorLogs()}
              className="inline-flex h-8 items-center gap-1 rounded-md border border-slate-200 bg-white px-2.5 text-xs font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-50 whitespace-nowrap shrink-0"
            >
              <Trash2 className="h-3.5 w-3.5" />
              <span>লগ মুছুন</span>
            </button>
          </div>

          <div className="mt-4 max-h-72 space-y-2 overflow-y-auto">
            {errorLogs.length === 0 ? (
              <div className="rounded-lg border border-dashed border-slate-200 bg-slate-50 p-6 text-center text-xs text-slate-500">
                কোনো এরর লগ নেই — সিস্টেম স্বাভাবিক রয়েছে।
              </div>
            ) : (
              errorLogs.map((log) => (
                <div
                  key={log.id}
                  className="rounded-lg border border-amber-200 bg-amber-50/50 p-2.5 text-xs"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-mono text-[11px] font-semibold text-amber-900">
                      [{log.module}]
                    </span>
                    <span className="font-mono text-[10px] text-slate-500 tabular-nums">
                      {new Date(log.createdAt).toLocaleTimeString('en-US', {
                        hour: '2-digit',
                        minute: '2-digit',
                        second: '2-digit',
                      })}
                    </span>
                  </div>
                  <p className="mt-1 break-words text-[11px] text-slate-700">
                    {log.message}
                  </p>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
