import { Search } from 'lucide-react';
import { useMemo, useState } from 'react';
import type { VoiceGeneration, VoiceJob } from '../types.ts';
import { AudioPlayer } from './AudioPlayer.tsx';

interface HistoryViewProps {
  generations: VoiceGeneration[];
  onDataChanged: () => void;
}

export function HistoryView({ generations, onDataChanged }: HistoryViewProps) {
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState<'all' | 'male' | 'female' | 'cartoon'>('all');
  const [regeneratingId, setRegeneratingId] = useState<string | null>(null);
  const [statusNote, setStatusNote] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    return generations.filter((g) => {
      if (categoryFilter !== 'all' && g.category !== categoryFilter) {
        return false;
      }
      if (!q) return true;
      return (
        g.script.toLowerCase().includes(q) ||
        g.voiceNameBn.toLowerCase().includes(q) ||
        g.userName.toLowerCase().includes(q)
      );
    });
  }, [generations, search, categoryFilter]);

  const pollUntilDone = async (jobId: string) => {
    for (let i = 0; i < 600; i++) {
      await new Promise((r) => setTimeout(r, 900));
      const res = await fetch(`/api/jobs/${jobId}`);
      if (!res.ok) break;
      const data = (await res.json()) as { job?: VoiceJob };
      if (!data.job) break;
      setStatusNote(
        `${data.job.statusText} (${data.job.currentPart}/${data.job.totalParts})`,
      );
      if (data.job.status === 'completed') {
        onDataChanged();
        return;
      }
      if (data.job.status === 'failed') {
        setError(data.job.error || 'পুনরায় জেনারেট ব্যর্থ হয়েছে।');
        return;
      }
    }
  };

  const handleRegenerate = async (genId: string) => {
    if (regeneratingId) return;
    setRegeneratingId(genId);
    setError(null);
    setStatusNote('প্রসেসিং শুরু হচ্ছে...');
    try {
      const res = await fetch(`/api/studio/regenerate/${genId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
      });
      const data = (await res.json()) as { job?: VoiceJob; error?: string };
      if (!res.ok || !data.job) {
        setError(data.error || 'পুনরায় জেনারেট করা যায়নি।');
      } else {
        await pollUntilDone(data.job.id);
      }
    } finally {
      setRegeneratingId(null);
      setStatusNote(null);
    }
  };

  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-slate-200 bg-white p-5">
        <div>
          <h2 className="text-base font-semibold text-slate-900">
            ভয়েস জেনারেশন হিস্টোরি (Voice History)
          </h2>
          <p className="mt-0.5 text-xs text-slate-500">
            টেলিগ্রাম বট, সিমুলেটর এবং ওয়েব স্টুডিও থেকে তৈরি সকল বাংলা MP3 ভয়েসের তালিকা।
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="relative">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="স্ক্রিপ্ট বা কণ্ঠস্বর খুঁজুন..."
              className="h-10 w-64 rounded-lg border border-slate-200 bg-slate-50 pl-9 pr-3 text-xs text-slate-900 placeholder:text-slate-400 focus:border-teal-700 focus:bg-white focus:outline-none"
            />
          </div>

          <div className="flex items-center gap-1 rounded-lg bg-slate-100 p-1">
            {(['all', 'male', 'female', 'cartoon'] as const).map((tab) => (
              <button
                key={tab}
                type="button"
                onClick={() => setCategoryFilter(tab)}
                className={`rounded-md px-3 py-1.5 text-xs font-medium transition-colors whitespace-nowrap shrink-0 ${
                  categoryFilter === tab
                    ? 'bg-white text-slate-900 shadow-sm'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {tab === 'all'
                  ? 'সবগুলো'
                  : tab === 'male'
                    ? 'Male'
                    : tab === 'female'
                      ? 'Female'
                      : 'Cartoon'}
              </button>
            ))}
          </div>
        </div>
      </div>

      {statusNote && (
        <div className="rounded-lg border border-teal-200 bg-teal-50 px-4 py-3 text-xs font-medium text-teal-900">
          {statusNote}
        </div>
      )}

      {error && (
        <div className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-xs font-medium text-red-800">
          {error}
        </div>
      )}

      {filtered.length === 0 ? (
        <div className="rounded-xl border border-slate-200 bg-white p-12 text-center">
          <p className="text-sm font-medium text-slate-700">
            কোনো ভয়েস জেনারেশন হিস্টোরি পাওয়া যায়নি।
          </p>
          <p className="mt-1 text-xs text-slate-500">
            Telegram Bot Simulator অথবা Voice Studio থেকে প্রথম বাংলা অডিও তৈরি করুন।
          </p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((gen) => {
            const parts =
              gen.audioParts && gen.audioParts.length > 0
                ? gen.audioParts
                : [
                    {
                      url: gen.audioUrl,
                      filename: `${gen.id}.mp3`,
                      durationSec: gen.durationSec,
                      fileSizeBytes: gen.fileSizeBytes,
                    },
                  ];
            return (
              <div
                key={gen.id}
                className="rounded-xl border border-slate-200 bg-white p-4"
              >
                <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                  <div className="flex flex-wrap items-center gap-2 text-xs text-slate-600">
                    <span className="font-semibold text-slate-900">
                      {gen.voiceNameBn}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>
                      {gen.category === 'male'
                        ? 'Male Voice'
                        : gen.category === 'female'
                          ? 'Female Voice'
                          : 'Cartoon Voice'}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>ইউজার: {gen.userName}</span>
                    <span aria-hidden="true">·</span>
                    <span>অংশ: {gen.totalChunks ?? 1}টি</span>
                    <span aria-hidden="true">·</span>
                    <span>মাধ্যম: {gen.source}</span>
                  </div>

                  <span className="font-mono text-xs text-slate-400 tabular-nums">
                    {new Date(gen.createdAt).toLocaleString()}
                  </span>
                </div>

                <p className="mb-3 text-sm leading-relaxed text-slate-800">
                  “{gen.script.slice(0, 260)}
                  {gen.script.length > 260 ? '...' : ''}”
                </p>

                <div className="space-y-2">
                  {parts.map((part, idx) => (
                    <AudioPlayer
                      key={part.filename}
                      url={part.url}
                      title={
                        parts.length > 1
                          ? `${gen.voiceNameBn} · Part ${idx + 1}/${parts.length}`
                          : `Bangla Voice · ${gen.voiceNameBn}`
                      }
                      durationSec={part.durationSec}
                      fileSizeBytes={part.fileSizeBytes}
                      compact
                      onRegenerate={
                        idx === 0 ? () => void handleRegenerate(gen.id) : undefined
                      }
                      regenerating={regeneratingId === gen.id}
                    />
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
