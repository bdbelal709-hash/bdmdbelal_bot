export type VoiceCategory = 'male' | 'female' | 'cartoon';

export interface VoicePersona {
  id: string;
  category: VoiceCategory;
  emoji?: string;
  nameBn: string;
  nameEn: string;
  roleBn: string;
  roleEn: string;
  descriptionBn: string;
  geminiVoice: string;
  defaultSpeed: number;
  defaultPitch: number;
  sampleBangla: string;
}

export interface AudioPartOutput {
  url: string;
  filename: string;
  durationSec: number;
  fileSizeBytes: number;
}

export interface BotUser {
  id: string;
  telegramId: string;
  username: string;
  firstName: string;
  role: 'user' | 'admin';
  tier: 'free' | 'premium';
  premiumExpiresAt: string | null;
  status: 'active' | 'banned';
  balance: number;
  dailyCount: number;
  totalCount: number;
  lastResetDate: string;
  selectedCategory: VoiceCategory;
  selectedVoiceId: string;
  speed: number;
  pitch: number;
  step: string;
  customDailyLimit: number | null;
  customCharLimit: number | null;
  joinedAt: string;
  lastActiveAt: string;
}

export interface VoiceGeneration {
  id: string;
  jobId?: string;
  userId: string;
  userName: string;
  voiceId: string;
  voiceNameBn: string;
  category: VoiceCategory;
  script: string;
  spokenScript: string;
  speed: number;
  pitch: number;
  durationSec: number;
  fileSizeBytes: number;
  audioUrl: string;
  audioParts?: AudioPartOutput[];
  totalChunks?: number;
  costCharged: number;
  source: 'telegram' | 'simulator' | 'studio';
  createdAt: string;
}

export interface VoiceJob {
  id: string;
  userId: string;
  userName: string;
  voiceId: string;
  voiceNameBn: string;
  category: VoiceCategory;
  speed: number;
  pitch: number;
  status:
    | 'queued'
    | 'processing'
    | 'joining'
    | 'rendering'
    | 'completed'
    | 'failed';
  statusText: string;
  progressPct?: number;
  currentPart: number;
  totalParts: number;
  startedAt?: string;
  elapsedSec?: number;
  estimatedTotalSec?: number;
  estimatedRemainingSec?: number;
  retryCount: number;
  source: 'telegram' | 'simulator' | 'studio';
  generationId?: string;
  outputParts?: AudioPartOutput[];
  error?: string;
  createdAt: string;
  updatedAt: string;
}

export interface PaymentAccount {
  id: string;
  method: string;
  accountNumber: string;
  accountType: string;
  note?: string;
  enabled: boolean;
}

export interface IncomingPaymentSms {
  id: string;
  method: string;
  amount: number;
  trxId: string;
  sender?: string;
  rawText: string;
  status: 'unmatched' | 'claimed';
  claimedByPaymentId?: string;
  claimedByUserName?: string;
  receivedAt: string;
  claimedAt?: string;
}

export interface PaymentRequest {
  id: string;
  userId: string;
  telegramId: string;
  userName: string;
  amount: number;
  method: string;
  accountNumber?: string;
  referenceNote: string;
  trxId?: string;
  autoVerified?: boolean;
  status: 'pending' | 'approved' | 'rejected';
  reviewedBy?: string;
  createdAt: string;
  reviewedAt?: string;
}

export type AssistantModuleId =
  | 'chat'
  | 'image'
  | 'video'
  | 'voice'
  | 'documents'
  | 'coding'
  | 'research'
  | 'memory';

export interface ErrorLogEntry {
  id: string;
  module: string;
  userId?: string;
  message: string;
  createdAt: string;
}

export type VideoMode =
  | 'prompt'
  | 'script'
  | 'voice'
  | 'edit_video'
  | 'image_to_video';

export type VideoTemplateId =
  | 'cinematic_doc'
  | 'viral_reels'
  | 'tech_explainer'
  | 'news_fact'
  | 'emotional_story';

export type VideoAspectRatio = '16:9' | '9:16' | '1:1';
export type VideoResolution = '720p' | '1080p' | '4k';
export type VideoMusicMood =
  | 'none'
  | 'cinematic'
  | 'emotional'
  | 'upbeat'
  | 'tech'
  | 'suspense';
export type VideoVisualMode =
  | 'auto'
  | 'ai_image'
  | 'stock_video'
  | 'cinematic_motion';

export interface VideoTemplateInfo {
  id: VideoTemplateId;
  nameBn: string;
  nameEn: string;
  taglineBn: string;
  badgeText: string;
  accentHex: string;
  secondaryHex: string;
  bgDarkHex: string;
  subtitleFont: string;
}

export interface VideoScene {
  index: number;
  narrationBangla: string;
  subtitleText: string;
  visualPrompt: string;
  searchKeywords: string;
  emotion: string;
  motion: string;
  transition: string;
  startSec?: number;
  endSec?: number;
  durationSec?: number;
  assetType?: 'video' | 'image';
}

export interface VideoProjectJob {
  id: string;
  userId: string;
  userName: string;
  mode: VideoMode;
  title: string;
  prompt?: string;
  script: string;
  templateId: VideoTemplateId;
  aspectRatio: VideoAspectRatio;
  resolution: VideoResolution;
  videoSpeed: number;
  voiceId: string;
  voiceNameBn: string;
  voiceSpeed: number;
  voicePitch: number;
  musicMood: VideoMusicMood;
  originalAudioMode: 'mute' | 'duck' | 'keep';
  includeSubtitles: boolean;
  includeIntroOutro: boolean;
  watermarkText?: string;
  scenes: VideoScene[];
  status:
    | 'queued'
    | 'planning'
    | 'voicing'
    | 'visuals'
    | 'rendering'
    | 'completed'
    | 'failed';
  statusText: string;
  progressPct: number;
  currentStep: number;
  totalSteps: number;
  startedAt?: string;
  elapsedSec?: number;
  estimatedTotalSec?: number;
  estimatedRemainingSec?: number;
  durationSec?: number;
  fileSizeBytes?: number;
  outputVideoUrl?: string;
  outputFilename?: string;
  costCharged: number;
  source: 'telegram' | 'simulator' | 'studio';
  error?: string;
  createdAt: string;
  updatedAt: string;
}

export interface TransactionRecord {
  id: string;
  userId: string;
  userName: string;
  type:
    | 'payment_approved'
    | 'admin_add'
    | 'admin_deduct'
    | 'voice_charge'
    | 'video_charge'
    | 'premium_upgrade';
  amount: number;
  balanceAfter: number;
  description: string;
  createdAt: string;
}

export interface PublicBotConfig {
  telegramBotUsername: string;
  telegramMode: 'stopped' | 'polling' | 'webhook';
  notificationChannelId: string;
  adminTelegramIds: string[];
  adminClaimCode: string;
  freeDailyLimit: number;
  premiumDailyLimit: number;
  maxScriptCharsFree: number;
  maxScriptCharsPremium: number;
  voiceGenerationCost: number;
  voiceCosts: Record<string, number>;
  videoGenerationCost: number;
  visualProviderMode: VideoVisualMode;
  hasPexelsKey: boolean;
  pexelsApiKeyMasked: string;
  paymentAccounts: PaymentAccount[];
  paymentInstructions: string;
  autoVerifyPayments: boolean;
  smsWebhookSecret: string;
  premiumMembershipDays: number;
  strictBanglaOnly: boolean;
  ttsModel: 'gemini-3.8-flash-lite-tts' | 'gemini-3.8-flash-tts';
  autoNormalizeBangla: boolean;
  smartEnglishToBangla: boolean;
  enabledFeatures?: Record<AssistantModuleId, boolean>;
  defaultChatModel?: 'gemini-4-hydrogen' | 'gemini-3.1-flash-lite';
  hasTelegramToken: boolean;
  telegramBotTokenMasked: string;
}

export interface DashboardStats {
  totalUsers: number;
  activeUsers: number;
  freeUsers: number;
  premiumUsers: number;
  bannedUsers: number;
  totalVoicesGenerated: number;
  totalVideosGenerated?: number;
  todayGenerations: number;
  todayCharacters: number;
  pendingPayments: number;
  totalBalance: number;
  activeJobs: number;
  errorCount?: number;
  featureUsage?: Record<AssistantModuleId, number>;
  dailySeries: Array<{
    date: string;
    generations: number;
    characters: number;
    activeUsers: number;
  }>;
}

export interface InlineButton {
  text: string;
  callback_data: string;
}

export interface BotMessagePayload {
  id: string;
  sender: 'bot' | 'user';
  text: string;
  timestamp: string;
  buttons?: InlineButton[][];
  jobId?: string;
  videoJobId?: string;
  audio?: {
    generationId: string;
    url: string;
    title: string;
    performer: string;
    durationSec: number;
    fileSizeBytes: number;
  };
  video?: {
    jobId: string;
    url: string;
    title: string;
    durationSec: number;
    fileSizeBytes: number;
  };
  photo?: {
    url: string;
    caption?: string;
  };
  document?: {
    url: string;
    filename: string;
    fileSizeBytes: number;
    mimeType?: string;
  };
}
