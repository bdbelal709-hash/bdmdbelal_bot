import { Mp3Encoder } from '@breezystack/lamejs';
import { execFile } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { promisify } from 'node:util';

const execFileAsync = promisify(execFile);

export interface WavData {
  sampleRate: number;
  numChannels: number;
  samples: Int16Array;
}

const TELEGRAM_MAX_SAFE_BYTES = 45 * 1024 * 1024; // 45 MB (safe margin under Telegram's 50 MB sendAudio limit)

/**
 * Parses a RIFF WAV buffer into raw Int16 PCM samples.
 */
export function parseWavBuffer(wavBuffer: Buffer): WavData {
  if (wavBuffer.length < 44) {
    throw new Error('Invalid WAV buffer: too short');
  }

  const riff = wavBuffer.toString('ascii', 0, 4);
  const wave = wavBuffer.toString('ascii', 8, 12);
  if (riff !== 'RIFF' || wave !== 'WAVE') {
    throw new Error('Invalid WAV buffer: missing RIFF/WAVE header');
  }

  let offset = 12;
  let sampleRate = 24000;
  let numChannels = 1;
  let dataOffset = 44;
  let dataSize = wavBuffer.length - 44;

  while (offset + 8 <= wavBuffer.length) {
    const chunkId = wavBuffer.toString('ascii', offset, offset + 4);
    const chunkSize = wavBuffer.readUInt32LE(offset + 4);
    if (chunkId === 'fmt ') {
      numChannels = wavBuffer.readUInt16LE(offset + 10);
      sampleRate = wavBuffer.readUInt32LE(offset + 12);
    } else if (chunkId === 'data') {
      dataOffset = offset + 8;
      dataSize = Math.min(chunkSize, wavBuffer.length - dataOffset);
      break;
    }
    offset += 8 + chunkSize + (chunkSize % 2);
  }

  const sampleCount = Math.floor(dataSize / 2);
  const samples = new Int16Array(sampleCount);
  for (let i = 0; i < sampleCount; i++) {
    samples[i] = wavBuffer.readInt16LE(dataOffset + i * 2);
  }

  return { sampleRate, numChannels, samples };
}

function buildAtempoChain(factor: number): string {
  // FFmpeg atempo accepts [0.5, 2.0]; chain filters if outside
  const filters: string[] = [];
  let remaining = factor;
  while (remaining > 2.0) {
    filters.push('atempo=2.0');
    remaining /= 2.0;
  }
  while (remaining < 0.5) {
    filters.push('atempo=0.5');
    remaining /= 0.5;
  }
  filters.push(`atempo=${remaining.toFixed(4)}`);
  return filters.join(',');
}

/**
 * Processes a single raw Gemini TTS WAV chunk via FFmpeg:
 * - Uniformly applies Speed & Pitch so voice consistency stays locked across all chunks
 * - Gently trims leading/trailing digital silence to avoid unnatural dead gaps
 * - Normalizes to 24kHz mono 16-bit PCM WAV for seamless concatenation
 */
export async function normalizeChunkWavWithFfmpeg(params: {
  rawWavBuffer: Buffer;
  outputWavPath: string;
  speed: number;
  pitchSemitones: number;
}): Promise<void> {
  const { rawWavBuffer, outputWavPath, speed, pitchSemitones } = params;
  const tmpInputPath = `${outputWavPath}.raw.wav`;
  fs.writeFileSync(tmpInputPath, rawWavBuffer);

  const clampedSpeed = Math.max(0.7, Math.min(1.5, speed || 1.0));
  const clampedPitch = Math.max(-6, Math.min(6, pitchSemitones || 0));
  const pitchFactor = Math.pow(2, clampedPitch / 12);
  const tempoFactor = clampedSpeed / pitchFactor;

  const filterParts: string[] = [
    // Remove excess silence at edges without cutting speech onset
    'silenceremove=start_periods=1:start_duration=0.02:start_threshold=-48dB:stop_periods=-1:stop_duration=0.25:stop_threshold=-48dB',
  ];

  if (Math.abs(pitchFactor - 1.0) >= 0.005) {
    const shiftedRate = Math.round(24000 * pitchFactor);
    filterParts.push(`asetrate=${shiftedRate}`, 'aresample=24000');
  }

  if (Math.abs(tempoFactor - 1.0) >= 0.005) {
    filterParts.push(buildAtempoChain(tempoFactor));
  }

  // Soft 10ms fade edges to guarantee zero click/pop on chunk join + small 140ms natural sentence breath pause
  filterParts.push(
    'afade=t=in:st=0:d=0.01',
    'apad=pad_dur=0.14',
  );

  try {
    await execFileAsync('ffmpeg', [
      '-y',
      '-i',
      tmpInputPath,
      '-af',
      filterParts.join(','),
      '-ar',
      '24000',
      '-ac',
      '1',
      '-c:a',
      'pcm_s16le',
      outputWavPath,
    ]);
  } finally {
    if (fs.existsSync(tmpInputPath)) {
      fs.unlinkSync(tmpInputPath);
    }
  }
}

/**
 * Probes exact audio duration (in seconds) using ffprobe (with WAV/MP3 size fallback).
 */
export async function probeAudioDurationSec(filePath: string): Promise<number> {
  try {
    const { stdout } = await execFileAsync('ffprobe', [
      '-v',
      'error',
      '-show_entries',
      'format=duration',
      '-of',
      'default=noprint_wrappers=1:nokey=1',
      filePath,
    ]);
    const parsed = Number.parseFloat(stdout.trim());
    if (Number.isFinite(parsed) && parsed > 0) {
      return Math.round(parsed * 10) / 10;
    }
  } catch {
    // Fallback below
  }
  const stat = fs.statSync(filePath);
  return Math.max(1, Math.round((stat.size / 16000) * 10) / 10);
}

/**
 * Merges an ordered list of normalized WAV chunk files into one seamless MP3 using FFmpeg.
 * If the resulting MP3 exceeds Telegram's safe 45 MB upload limit, splits it cleanly into
 * ordered MP3 parts so delivery never fails.
 */
export async function mergeChunksToMp3WithFfmpeg(params: {
  chunkWavPaths: string[];
  outputDir: string;
  baseFilename: string;
}): Promise<
  Array<{
    filePath: string;
    filename: string;
    durationSec: number;
    fileSizeBytes: number;
  }>
> {
  const { chunkWavPaths, outputDir, baseFilename } = params;
  if (chunkWavPaths.length === 0) {
    throw new Error('No audio chunks available to merge.');
  }

  for (const p of chunkWavPaths) {
    if (!fs.existsSync(p) || fs.statSync(p).size < 128) {
      throw new Error(`Missing or corrupted audio chunk: ${path.basename(p)}`);
    }
  }

  const concatListPath = path.join(outputDir, `${baseFilename}_concat.txt`);
  const listContent = chunkWavPaths
    .map((p) => `file '${p.replace(/'/g, "'\\''")}'`)
    .join('\n');
  fs.writeFileSync(concatListPath, listContent, 'utf-8');

  const finalFilename = `${baseFilename}.mp3`;
  const finalMp3Path = path.join(outputDir, finalFilename);

  try {
    await execFileAsync('ffmpeg', [
      '-y',
      '-f',
      'concat',
      '-safe',
      '0',
      '-i',
      concatListPath,
      '-ar',
      '24000',
      '-ac',
      '1',
      '-c:a',
      'libmp3lame',
      '-b:a',
      '128k',
      finalMp3Path,
    ]);
  } finally {
    if (fs.existsSync(concatListPath)) {
      fs.unlinkSync(concatListPath);
    }
  }

  const stat = fs.statSync(finalMp3Path);
  const totalDuration = await probeAudioDurationSec(finalMp3Path);

  if (stat.size <= TELEGRAM_MAX_SAFE_BYTES) {
    return [
      {
        filePath: finalMp3Path,
        filename: finalFilename,
        durationSec: totalDuration,
        fileSizeBytes: stat.size,
      },
    ];
  }

  // Split ultra-long (>45MB) MP3 into ~40-minute parts so every Telegram upload stays under 50MB
  const segmentPattern = path.join(outputDir, `${baseFilename}_part_%03d.mp3`);
  await execFileAsync('ffmpeg', [
    '-y',
    '-i',
    finalMp3Path,
    '-f',
    'segment',
    '-segment_time',
    '2400',
    '-c',
    'copy',
    segmentPattern,
  ]);

  const splitFiles = fs
    .readdirSync(outputDir)
    .filter((f) => f.startsWith(`${baseFilename}_part_`) && f.endsWith('.mp3'))
    .sort();

  const parts: Array<{
    filePath: string;
    filename: string;
    durationSec: number;
    fileSizeBytes: number;
  }> = [];

  for (const f of splitFiles) {
    const p = path.join(outputDir, f);
    const s = fs.statSync(p);
    const d = await probeAudioDurationSec(p);
    parts.push({
      filePath: p,
      filename: f,
      durationSec: d,
      fileSizeBytes: s.size,
    });
  }

  return parts.length > 0
    ? parts
    : [
        {
          filePath: finalMp3Path,
          filename: finalFilename,
          durationSec: totalDuration,
          fileSizeBytes: stat.size,
        },
      ];
}

/**
 * Legacy fast single-buffer fallback encoder using @breezystack/lamejs.
 */
export function encodeWavBufferToMp3Fallback(wavBuffer: Buffer): {
  mp3Buffer: Buffer;
  durationSec: number;
} {
  const parsed = parseWavBuffer(wavBuffer);
  const encoder = new Mp3Encoder(1, parsed.sampleRate, 128);
  const chunkSize = 1152;
  const mp3Parts: Buffer[] = [];

  for (let i = 0; i < parsed.samples.length; i += chunkSize) {
    const slice = parsed.samples.subarray(i, i + chunkSize);
    const mp3buf = encoder.encodeBuffer(slice);
    if (mp3buf.length > 0) {
      mp3Parts.push(Buffer.from(mp3buf));
    }
  }
  const endBuf = encoder.flush();
  if (endBuf.length > 0) {
    mp3Parts.push(Buffer.from(endBuf));
  }

  return {
    mp3Buffer: Buffer.concat(mp3Parts),
    durationSec: Math.max(
      1,
      Math.round((parsed.samples.length / parsed.sampleRate) * 10) / 10,
    ),
  };
}
