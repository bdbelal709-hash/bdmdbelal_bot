import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';
import { execFile } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { promisify } from 'node:util';
import type { VoicePersona } from './types.ts';
import { chunkBanglaScript, validateBanglaOnlyScript } from './voices.ts';

const execFileAsync = promisify(execFile);

// In-memory cooldown tracker so exhausted Free Tier models aren't hammered repeatedly
const modelCooldownUntil = new Map<string, number>();

export function isQuotaOrRateLimitError(err: unknown): boolean {
  const msg =
    err instanceof Error
      ? err.message
      : typeof err === 'string'
        ? err
        : JSON.stringify(err ?? '');
  return /429|RESOURCE_EXHAUSTED|quota|rate[-_\s]?limit|Too Many Requests/i.test(
    msg,
  );
}

export function isModelExhausted(model: string): boolean {
  const until = modelCooldownUntil.get(model);
  if (!until) return false;
  if (Date.now() >= until) {
    modelCooldownUntil.delete(model);
    return false;
  }
  return true;
}

export function markModelExhausted(model: string, err?: unknown): void {
  const msg = err instanceof Error ? err.message : String(err ?? '');
  let cooldownMs = 20 * 60 * 1000; // 20 min default cooldown
  const retryMatch = msg.match(/retryDelay["':\s]+(\d+)s/i);
  if (retryMatch) {
    const parsedSec = Number.parseInt(retryMatch[1], 10);
    if (Number.isFinite(parsedSec) && parsedSec > 0) {
      // Cap cooldown at 2 hours in case user upgrades billing/key
      cooldownMs = Math.min(2 * 60 * 60 * 1000, Math.max(60_000, parsedSec * 1000));
    }
  }
  modelCooldownUntil.set(model, Date.now() + cooldownMs);
}

/**
 * Converts verbose Google/API JSON errors into clean, polite Bangla messages.
 */
export function formatUserFriendlyError(err: unknown): string {
  const raw =
    err instanceof Error
      ? err.message
      : typeof err === 'string'
        ? err
        : 'অপ্রত্যাশিত ত্রুটি ঘটেছে।';

  if (isQuotaOrRateLimitError(err)) {
    return 'সার্ভারের ফ্রি কোটা সাময়িকভাবে পূর্ণ হওয়ায় ব্যাকআপ ভয়েস ইঞ্জিন ব্যবহার করা হচ্ছে। অনুগ্রহ করে কিছুক্ষণ পর আবার চেষ্টা করুন।';
  }
  if (/API_KEY|api key|PERMISSION_DENIED|UNAUTHENTICATED|401|403/i.test(raw)) {
    return 'API Key সঠিক নয় অথবা মেয়াদ শেষ হয়েছে। অনুগ্রহ করে অ্যাডমিন প্যানেল/সেটিংস থেকে API Key যাচাই করুন।';
  }
  if (/ETIMEDOUT|ECONNRESET|ENOTFOUND|fetch failed|network/i.test(raw)) {
    return 'সার্ভারের নেটওয়ার্ক সংযোগে সাময়িক সমস্যা হয়েছে। অনুগ্রহ করে একটু পর আবার চেষ্টা করুন।';
  }

  // Strip raw multi-line JSON payloads from leaking into Telegram messages
  const firstLine = raw.split('\n')[0].trim();
  if (firstLine.startsWith('{') || firstLine.length > 260) {
    return 'প্রসেসিংয়ে সাময়িক প্রযুক্তিগত সমস্যা হয়েছে। অনুগ্রহ করে পুনরায় চেষ্টা করুন।';
  }
  return firstLine || 'প্রসেসিংয়ে ত্রুটি ঘটেছে। অনুগ্রহ করে আবার চেষ্টা করুন।';
}

function getAiClient(apiVersion?: 'v1' | 'v1beta' | 'v1alpha'): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey) {
    throw new Error(
      'GEMINI_API_KEY পাওয়া যায়নি। AI Studio Settings > Secrets প্যানেল থেকে API Key যুক্ত করুন।',
    );
  }
  return new GoogleGenAI({
    apiKey,
    ...(apiVersion ? { apiVersion } : {}),
    httpOptions: {
      ...(apiVersion ? { apiVersion } : {}),
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

export type DetectedScriptLanguage = 'bangla' | 'english' | 'mixed';

export interface BanglaPrepResult {
  valid: boolean;
  detectedLanguage: DetectedScriptLanguage;
  spokenScript: string;
  reason?: string;
}

export function detectScriptLanguage(text: string): {
  language: DetectedScriptLanguage;
  hasBangla: boolean;
  hasLatin: boolean;
} {
  const hasBangla = /[\u0980-\u09FF]/.test(text);
  const hasLatin = /[A-Za-z]/.test(text);
  if (hasBangla && hasLatin) {
    return { language: 'mixed', hasBangla, hasLatin };
  }
  if (hasLatin && !hasBangla) {
    return { language: 'english', hasBangla, hasLatin };
  }
  return { language: 'bangla', hasBangla, hasLatin };
}

async function convertSingleSegmentToBangla(
  ai: GoogleGenAI,
  segment: string,
  detected: DetectedScriptLanguage,
): Promise<string> {
  const candidateModels = ['gemini-4-hydrogen', 'gemini-2.5-flash'];
  for (const model of candidateModels) {
    if (isModelExhausted(model)) continue;
    try {
      const response = await ai.models.generateContent({
        model,
        contents: `Input language profile: ${detected}\n\nScript segment:\n"""\n${segment}\n"""`,
        config: {
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
          systemInstruction:
            'You are an expert Bangladeshi Bengali (Bangla) localization scriptwriter for human AI voiceovers. Convert the given script (which may be Bangla, English, or Mixed Bangla-English) into 100% pure, natural, fluent Bangladeshi Bangla script suitable for natural speech synthesis.\n\nSTRICT RULES:\n1. If the text is English or contains English sentences: translate the exact meaning into natural, fluent spoken Bangladeshi Bangla. Never do stiff word-for-word literal translation, and NEVER drop any fact, number, or key detail.\n2. Brand Names, Website Names, Company Names, Software Names, and URLs: convert them into accurate phonetic Bangla pronunciation (e.g., Google -> গুগল, YouTube -> ইউটিউব, WhatsApp -> হোয়াটসঅ্যাপ, ChatGPT -> চ্যাটজিপিটি, Microsoft -> মাইক্রোসফট, Adobe -> অ্যাডোবি, example.com -> এক্সাম্পল ডট কম).\n3. Technical Terms (e.g., API, Cloud Server, Database, Dashboard, AI, MP3): render with natural Bangla pronunciation and/or clear Bangla meaning so a Bangladeshi listener understands effortlessly.\n4. Existing Bangla text: keep the original Bangla words and meaning unchanged; only fix punctuation (। and ,) and convert digits/percentages into natural spoken Bangla words where helpful.\n5. CRITICAL: The output banglaScript MUST contain ZERO English/Latin letters (A-Z, a-z). Everything must be written in Bengali script so the Bangla voice engine never speaks raw English.',
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              banglaScript: {
                type: Type.STRING,
                description:
                  'Complete natural Bengali script with zero Latin/English letters.',
              },
            },
            required: ['banglaScript'],
          },
        },
      });

      const parsed = JSON.parse((response.text ?? '{}').trim()) as {
        banglaScript?: string;
      };
      return parsed.banglaScript?.trim() || segment;
    } catch (err) {
      if (isQuotaOrRateLimitError(err)) {
        markModelExhausted(model, err);
        continue;
      }
      throw err;
    }
  }
  return segment;
}

/**
 * Smart English-to-Bangla & Mixed-Script Converter + Validator:
 * - Accepts Bangla, English, or Mixed Bangla-English input when smartEnglishToBangla is enabled.
 * - Converts English & Mixed scripts into natural Bangla with phonetic brand/software/website pronunciation.
 * - Keeps existing Bangla text faithful and clear.
 * - Supports arbitrarily long scripts by segmenting cleanly before conversion.
 */
export async function prepareBanglaScript(
  rawScript: string,
  strictBanglaOnly: boolean,
  autoNormalize: boolean,
  smartEnglishToBangla = true,
): Promise<BanglaPrepResult> {
  const trimmed = rawScript.trim();
  if (!trimmed) {
    return {
      valid: false,
      detectedLanguage: 'bangla',
      spokenScript: '',
      reason: 'অনুগ্রহ করে বাংলা বা ইংরেজিতে একটি স্ক্রিপ্ট লিখুন। খালি বার্তা গ্রহণযোগ্য নয়।',
    };
  }

  const detection = detectScriptLanguage(trimmed);

  // Reject unsupported non-Bangla/non-English scripts (Arabic, Devanagari excl. ।/॥, Cyrillic, CJK, etc.)
  const unsupportedScripts = trimmed.match(
    /[\u0600-\u06FF\u0900-\u0963\u0966-\u097F\u0400-\u04FF\u4E00-\u9FFF\u3040-\u30FF\uAC00-\uD7AF]/g,
  );
  if (unsupportedScripts && unsupportedScripts.length > 0) {
    return {
      valid: false,
      detectedLanguage: detection.language,
      spokenScript: trimmed,
      reason:
        'দুঃখিত! শুধুমাত্র বাংলা, ইংরেজি অথবা বাংলা-ইংরেজি মিশ্রিত স্ক্রিপ্ট পাঠান।',
    };
  }

  if (!detection.hasBangla && !detection.hasLatin) {
    return {
      valid: false,
      detectedLanguage: 'bangla',
      spokenScript: trimmed,
      reason: 'অনুগ্রহ করে পাঠযোগ্য বাংলা বা ইংরেজি বাক্য লিখুন।',
    };
  }

  if (strictBanglaOnly && !smartEnglishToBangla) {
    const check = validateBanglaOnlyScript(trimmed);
    if (!check.valid) {
      return {
        valid: false,
        detectedLanguage: detection.language,
        spokenScript: trimmed,
        reason: check.reason,
      };
    }
  }

  const needsConversion =
    detection.hasLatin || (autoNormalize && trimmed.length <= 3500);

  if (!needsConversion) {
    return {
      valid: true,
      detectedLanguage: detection.language,
      spokenScript: trimmed,
    };
  }

  if (!process.env.GEMINI_API_KEY?.trim()) {
    if (detection.hasLatin) {
      return {
        valid: false,
        detectedLanguage: detection.language,
        spokenScript: trimmed,
        reason:
          'ইংরেজি থেকে বাংলায় রূপান্তরের জন্য GEMINI_API_KEY প্রয়োজন। অনুগ্রহ করে বাংলা স্ক্রিপ্ট লিখুন বা API Key যুক্ত করুন।',
      };
    }
    return {
      valid: true,
      detectedLanguage: detection.language,
      spokenScript: trimmed,
    };
  }

  try {
    const ai = getAiClient();
    const segments =
      trimmed.length > 2500 ? chunkBanglaScript(trimmed, 2500) : [trimmed];

    const convertedParts: string[] = [];
    for (const seg of segments) {
      let out = await convertSingleSegmentToBangla(ai, seg, detection.language);
      // If any stray Latin characters survived, run one targeted transliteration cleanup pass
      if (/[A-Za-z]/.test(out)) {
        out = await convertSingleSegmentToBangla(ai, out, 'mixed');
      }
      convertedParts.push(out);
    }

    const finalSpoken = convertedParts.join('\n\n').trim() || trimmed;
    return {
      valid: true,
      detectedLanguage: detection.language,
      spokenScript: finalSpoken,
    };
  } catch (err) {
    if (detection.hasLatin) {
      return {
        valid: false,
        detectedLanguage: detection.language,
        spokenScript: trimmed,
        reason: `ইংরেজি স্ক্রিপ্ট বাংলায় রূপান্তর করতে সমস্যা হয়েছে: ${
          err instanceof Error ? err.message : 'Conversion failed'
        }`,
      };
    }
    return {
      valid: true,
      detectedLanguage: detection.language,
      spokenScript: trimmed,
    };
  }
}

function describeSpeedAndPitch(speed: number, pitch: number): string {
  const paceDesc =
    speed <= 0.85
      ? 'deliberate, unhurried, measured pace'
      : speed >= 1.15
        ? 'brisk, lively, energetic pace'
        : 'natural, balanced conversational pace';
  const pitchDesc =
    pitch <= -2
      ? 'deeper, resonant vocal register'
      : pitch >= 2
        ? 'brighter, elevated vocal register'
        : 'natural mid-range vocal register';
  return `${paceDesc}, ${pitchDesc}`;
}

/**
 * Free Tier Quota-Proof Fallback 1: Microsoft Edge Bangladeshi Neural Voices
 * (bn-BD-PradeepNeural / bn-BD-NabanitaNeural). Fails fast if blocked.
 */
async function tryEdgeNeuralBanglaAudio(
  textChunk: string,
  voice: VoicePersona,
): Promise<Buffer | null> {
  try {
    const { MsEdgeTTS, OUTPUT_FORMAT } = await import('msedge-tts');
    const tts = new MsEdgeTTS();
    const edgeVoice =
      voice.category === 'male' ? 'bn-BD-PradeepNeural' : 'bn-BD-NabanitaNeural';
    await Promise.race([
      tts.setMetadata(
        edgeVoice,
        OUTPUT_FORMAT.AUDIO_24KHZ_48KBITRATE_MONO_MP3,
      ),
      new Promise<never>((_, rej) =>
        setTimeout(() => rej(new Error('edge-metadata-timeout')), 3500),
      ),
    ]);

    const buf = await Promise.race([
      (async () => {
        const { audioStream } = tts.toStream(textChunk);
        const parts: Buffer[] = [];
        for await (const chunk of audioStream) {
          parts.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
        }
        return Buffer.concat(parts);
      })(),
      new Promise<never>((_, rej) =>
        setTimeout(() => rej(new Error('edge-stream-timeout')), 7000),
      ),
    ]);

    return buf.length > 256 ? buf : null;
  } catch {
    return null;
  }
}

/**
 * Free Tier Quota-Proof Fallback 2: Unlimited Bangla TTS via Google Translate TTS
 * stitched and shaped to 24kHz mono 16-bit PCM WAV via FFmpeg.
 */
async function synthesizeWithFreeBanglaFallbackWav(
  textChunk: string,
  voice: VoicePersona,
): Promise<Buffer> {
  const workDir = fs.mkdtempSync(path.join(os.tmpdir(), 'bv-tts-fb-'));
  try {
    // First attempt Neural Edge voice as raw MP3 if reachable
    const mp3Segments: string[] = [];
    const edgeBuf = await tryEdgeNeuralBanglaAudio(textChunk, voice);

    if (edgeBuf) {
      const edgeFile = path.join(workDir, 'edge.mp3');
      fs.writeFileSync(edgeFile, edgeBuf);
      mp3Segments.push(edgeFile);
    } else {
      // Split safely into <=175-char Bangla phrases for Google Translate TTS
      const phrases = chunkBanglaScript(textChunk, 175);
      for (let i = 0; i < phrases.length; i++) {
        const phrase = phrases[i].trim();
        if (!phrase) continue;
        const url =
          `https://translate.google.com/translate_tts?ie=UTF-8&tl=bn&client=tw-ob&q=${encodeURIComponent(phrase)}`;

        let fetched: Buffer | null = null;
        for (let attempt = 0; attempt < 2; attempt++) {
          try {
            const resp = await fetch(url, {
              headers: {
                'User-Agent':
                  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
                Referer: 'https://translate.google.com/',
              },
              signal: AbortSignal.timeout(10_000),
            });
            if (resp.ok) {
              const ab = await resp.arrayBuffer();
              if (ab.byteLength > 200) {
                fetched = Buffer.from(ab);
                break;
              }
            }
          } catch {
            if (attempt === 0) {
              await new Promise((r) => setTimeout(r, 350));
            }
          }
        }

        if (fetched) {
          const segPath = path.join(
            workDir,
            `seg_${String(i).padStart(4, '0')}.mp3`,
          );
          fs.writeFileSync(segPath, fetched);
          mp3Segments.push(segPath);
        }
      }
    }

    if (mp3Segments.length === 0) {
      throw new Error(
        'ফ্রি ব্যাকআপ ভয়েস ইঞ্জিন থেকেও অডিও তৈরি করা যায়নি। কিছুক্ষণ পর আবার চেষ্টা করুন।',
      );
    }

    const outWavPath = path.join(workDir, 'fallback_out.wav');
    let inputPath = mp3Segments[0];

    if (mp3Segments.length > 1) {
      const concatListPath = path.join(workDir, 'concat.txt');
      fs.writeFileSync(
        concatListPath,
        mp3Segments
          .map((p) => `file '${p.replace(/'/g, "'\\''")}'`)
          .join('\n'),
        'utf-8',
      );
      const mergedMp3Path = path.join(workDir, 'merged.mp3');
      await execFileAsync('ffmpeg', [
        '-y',
        '-f',
        'concat',
        '-safe',
        '0',
        '-i',
        concatListPath,
        '-c:a',
        'libmp3lame',
        '-ar',
        '24000',
        '-ac',
        '1',
        '-b:a',
        '128k',
        mergedMp3Path,
      ]);
      inputPath = mergedMp3Path;
    }

    // Acoustic differentiation on free fallback so Male, Female, and Cartoon personas sound distinct
    const filters: string[] = [];
    if (!edgeBuf && voice.category === 'male') {
      const pitchShift = 0.87;
      const shiftedRate = Math.round(24000 * pitchShift);
      filters.push(
        `asetrate=${shiftedRate}`,
        'aresample=24000',
        `atempo=${(1 / pitchShift).toFixed(4)}`,
      );
    } else if (!edgeBuf && voice.category === 'cartoon') {
      const pitchShift = 1.24;
      const shiftedRate = Math.round(24000 * pitchShift);
      filters.push(
        `asetrate=${shiftedRate}`,
        'aresample=24000',
        `atempo=${(1 / pitchShift).toFixed(4)}`,
      );
    }
    filters.push('volume=1.12');

    await execFileAsync('ffmpeg', [
      '-y',
      '-i',
      inputPath,
      '-af',
      filters.join(','),
      '-ar',
      '24000',
      '-ac',
      '1',
      '-c:a',
      'pcm_s16le',
      outWavPath,
    ]);

    return fs.readFileSync(outWavPath);
  } finally {
    fs.rmSync(workDir, { recursive: true, force: true });
  }
}

/**
 * Synthesizes a single Bangla text chunk into a raw 24kHz WAV Buffer:
 * 1. Tries preferred Gemini TTS model
 * 2. On 429 Quota/RESOURCE_EXHAUSTED, automatically rotates to alternate Gemini TTS models
 * 3. If all Gemini TTS quotas are exhausted, transparently falls back to unlimited Free Bangla TTS
 */
export async function synthesizeRawBanglaChunkWav(params: {
  textChunk: string;
  voice: VoicePersona;
  speed: number;
  pitch: number;
  ttsModel: 'gemini-3.8-flash-lite-tts' | 'gemini-3.8-flash-tts';
  partIndex?: number;
  totalParts?: number;
}): Promise<Buffer> {
  const { textChunk, voice, speed, pitch, ttsModel, partIndex, totalParts } =
    params;

  const hasApiKey = Boolean(process.env.GEMINI_API_KEY?.trim());
  if (hasApiKey) {
    const ai = getAiClient('v1beta');
    const prosodyCue = describeSpeedAndPitch(speed, pitch);
    const continuityCue =
      totalParts && totalParts > 1
        ? ` This is continuous narration segment ${(partIndex ?? 0) + 1} of ${totalParts}; maintain strictly uniform vocal timbre, steady volume, and consistent pacing with zero abrupt endings.`
        : '';
    const fullStyle = `${voice.stylePrompt} Deliver strictly in fluent, authentic Bengali (Bangla) pronunciation with human emotion, soft breath transitions, and ${prosodyCue}.${continuityCue}`;

    const candidateModels = Array.from(
      new Set<string>([
        ttsModel,
        ttsModel === 'gemini-3.8-flash-lite-tts'
          ? 'gemini-3.8-flash-tts'
          : 'gemini-3.8-flash-lite-tts',
        'gemini-2.5-flash-preview-tts',
      ]),
    );

    let lastGeminiErr: unknown = null;

    for (const model of candidateModels) {
      if (isModelExhausted(model)) {
        continue;
      }
      try {
        const response = await ai.models.generateContent({
          model,
          contents: [
            {
              role: 'user',
              parts: [
                {
                  text: textChunk,
                  speechMetadata: {
                    style: fullStyle,
                  },
                },
              ],
            },
          ],
          config: {
            responseModalities: ['AUDIO'],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: {
                  voiceName: voice.geminiVoice,
                },
              },
            },
          },
        });

        const parts = response.candidates?.[0]?.content?.parts ?? [];
        const audioPart = parts.find((p) => p.inlineData?.data);
        const base64Audio = audioPart?.inlineData?.data;

        if (base64Audio) {
          return Buffer.from(base64Audio, 'base64');
        }
      } catch (err) {
        lastGeminiErr = err;
        if (isQuotaOrRateLimitError(err)) {
          markModelExhausted(model, err);
          console.warn(
            `[TTS Fallback] Gemini model "${model}" exhausted (429), switching tier...`,
          );
          continue;
        }
        // On non-quota transient error (503/404 model unavailable), try next model/fallback too
        console.warn(
          `[TTS Fallback] Gemini model "${model}" error:`,
          err instanceof Error ? err.message.slice(0, 140) : err,
        );
      }
    }

    if (lastGeminiErr) {
      console.warn(
        '[TTS Fallback] All Gemini TTS models unavailable/exhausted; activating unlimited Bangla TTS fallback.',
      );
    }
  }

  return synthesizeWithFreeBanglaFallbackWav(textChunk, voice);
}

export async function generateCoverArtwork(params: {
  prompt: string;
  aspectRatio: string;
  imageSize: '1K' | '2K' | '4K';
  model: 'gemini-3-pro-image-preview' | 'gemini-nano-banana-2.1';
}): Promise<{ imageDataUrl: string; caption?: string }> {
  const ai = getAiClient();
  const response = await ai.models.generateContent({
    model: params.model,
    contents: {
      parts: [
        {
          text: params.prompt,
        },
      ],
    },
    config: {
      imageConfig: {
        aspectRatio: params.aspectRatio,
        imageSize: params.imageSize,
      },
    },
  });

  let imageDataUrl = '';
  let caption = '';

  for (const part of response.candidates?.[0]?.content?.parts ?? []) {
    if (part.inlineData?.data) {
      const mime = part.inlineData.mimeType ?? 'image/png';
      imageDataUrl = `data:${mime};base64,${part.inlineData.data}`;
    } else if (part.text) {
      caption += part.text;
    }
  }

  if (!imageDataUrl) {
    throw new Error('No image was returned by the model.');
  }

  return { imageDataUrl, caption: caption.trim() || undefined };
}
