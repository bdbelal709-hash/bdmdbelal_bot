import { GoogleGenAI, ThinkingLevel, type Content } from '@google/genai';
import { execFile } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { promisify } from 'node:util';
import {
  formatUserFriendlyError,
  isModelExhausted,
  isQuotaOrRateLimitError,
} from './gemini.ts';
import { botStore } from './store.ts';
import type { AssistantModuleId, BotUser } from './types.ts';

const execFileAsync = promisify(execFile);

function createGeminiClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey) {
    throw new Error(
      'GEMINI_API_KEY কনফিগার করা নেই। অনুগ্রহ করে সার্ভার Environment / Secrets থেকে API Key যুক্ত করুন।',
    );
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

const transientCooldownUntil = new Map<string, number>();

function isTransientBlocked(moduleName: string, model: string): boolean {
  const key = `${moduleName}:${model}`;
  const until = transientCooldownUntil.get(key);
  if (!until) return false;
  if (Date.now() >= until) {
    transientCooldownUntil.delete(key);
    return false;
  }
  return true;
}

export async function withGeminiRetry<T>(
  moduleName: string,
  userId: string | undefined,
  fn: (ai: GoogleGenAI, model: string) => Promise<T>,
): Promise<T> {
  const ai = createGeminiClient();
  const preferred = botStore.getConfig().defaultChatModel ?? 'gemini-4-hydrogen';
  const baseCandidates = Array.from(
    new Set([
      preferred,
      'gemini-4-hydrogen',
      'gemini-3.1-flash-lite',
      'gemini-3.5-flash-lite',
    ]),
  );

  // Skip models in global exhaustion or brief per-module cooldown, but always keep at least primary fallback
  const activeCandidates = baseCandidates.filter(
    (m) => !isModelExhausted(m) && !isTransientBlocked(moduleName, m),
  );
  const candidates =
    activeCandidates.length > 0
      ? activeCandidates
      : ['gemini-4-hydrogen', 'gemini-3.1-flash-lite'];

  let lastErr: unknown;
  for (const model of candidates) {
    for (let attempt = 0; attempt < 2; attempt++) {
      try {
        return await fn(ai, model);
      } catch (err) {
        lastErr = err;
        if (isQuotaOrRateLimitError(err)) {
          if (attempt === 0) {
            await new Promise((r) => setTimeout(r, 1400));
            continue;
          }
          transientCooldownUntil.set(`${moduleName}:${model}`, Date.now() + 15_000);
          break;
        }
        const msg = err instanceof Error ? err.message : String(err);
        if (/503|500|ETIMEDOUT|ECONNRESET|fetch failed/i.test(msg) && attempt === 0) {
          await new Promise((r) => setTimeout(r, 900));
          continue;
        }
        break;
      }
    }
  }
  const finalErr =
    lastErr ??
    new Error('সব AI মডেল সাময়িকভাবে ব্যস্ত রয়েছে। অনুগ্রহ করে কয়েক সেকেন্ড পর আবার চেষ্টা করুন।');
  botStore.logError(moduleName, finalErr, userId);
  throw new Error(formatUserFriendlyError(finalErr));
}

function buildMemoryBlock(user: BotUser): string {
  const mems = user.memories ?? [];
  if (mems.length === 0) return 'No saved user memories yet.';
  return mems.map((m, i) => `${i + 1}. ${m.key}: ${m.value}`).join('\n');
}

function maybeExtractAndStoreMemory(user: BotUser, message: string): string | null {
  const nameMatch =
    message.match(/(?:আমার নাম|my name is|call me|i am)\s+([^\n.,!?]{2,32})/i);
  if (nameMatch?.[1]) {
    const val = nameMatch[1].trim();
    if (val && !/কি|what|who|আপনার/i.test(val)) {
      botStore.upsertUserMemory(user.id, 'Name', val);
      return `Name: ${val}`;
    }
  }

  const prefMatch = message.match(
    /(?:মনে রাখো|মনে রাখবেন|remember that|remember:)\s+([^\n]{3,160})/i,
  );
  if (prefMatch?.[1]) {
    const val = prefMatch[1].trim();
    botStore.upsertUserMemory(user.id, 'Note', val);
    return val;
  }
  return null;
}

export interface AssistantChatResult {
  replyText: string;
  rememberedNote?: string;
  sources: Array<{ title: string; url: string }>;
}

/**
 * Full ChatGPT-grade Conversational AI Assistant with multi-turn memory,
 * image/vision support, reasoning, math, analysis, and optional live search.
 */
export async function runAssistantChat(params: {
  user: BotUser;
  message: string;
  imagePath?: string;
  imageMimeType?: string;
  enableSearch?: boolean;
  moduleTag?: AssistantModuleId;
}): Promise<AssistantChatResult> {
  const { user, message, imagePath, imageMimeType, enableSearch, moduleTag } = params;
  const lang = user.language === 'en' ? 'English' : 'Bengali (Bangla) by default unless the user writes in another language';

  const rememberedNote = maybeExtractAndStoreMemory(user, message) ?? undefined;
  const refreshedUser = botStore.getUserById(user.id) ?? user;

  const systemInstruction =
    `You are an elite, helpful, accurate ChatGPT-grade All-in-One AI Assistant running inside Telegram.\n` +
    `- Preferred language: Respond cleanly in ${lang}. Match the user's language naturally (Bangla, English, or any language they write in).\n` +
    `- Capabilities: Deep reasoning, step-by-step mathematics, software architecture & coding, data analysis, creative writing, translation, and practical problem solving.\n` +
    `- Never fabricate results, citations, or claims. If something requires live info or an unavailable tool, state it honestly.\n` +
    `- Keep formatting crisp and readable for Telegram (clean headings, bullet points, numbered steps, fenced code blocks).\n` +
    `- User Profile: Name="${refreshedUser.firstName}", Username="@${refreshedUser.username}".\n` +
    `- Saved User Memories:\n${buildMemoryBlock(refreshedUser)}`;

  const history: Content[] = (refreshedUser.chatHistory ?? [])
    .slice(-16)
    .map((t) => ({
      role: t.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: t.text }],
    }));

  const currentParts: Array<
    { text: string } | { inlineData: { mimeType: string; data: string } }
  > = [];

  if (imagePath && fs.existsSync(imagePath)) {
    const imgBuf = fs.readFileSync(imagePath);
    if (imgBuf.length <= 15 * 1024 * 1024) {
      currentParts.push({
        inlineData: {
          mimeType: imageMimeType || 'image/jpeg',
          data: imgBuf.toString('base64'),
        },
      });
    }
  }

  currentParts.push({ text: message });

  const { replyText, sources } = await withGeminiRetry(
    moduleTag ?? 'chat',
    refreshedUser.id,
    async (ai, model) => {
      const contents: Content[] = [
        ...history,
        { role: 'user', parts: currentParts },
      ];

      const shouldSearch =
        Boolean(enableSearch) ||
        /(?:আজকের|সর্বশেষ|বর্তমান|দাম কত|খবর|news|latest|today|price|weather|score|2025|2026)/i.test(
          message,
        );

      const res = await ai.models.generateContent({
        model,
        contents,
        config: {
          systemInstruction,
          ...(model === 'gemini-4-hydrogen'
            ? { thinkingConfig: { thinkingLevel: ThinkingLevel.HIGH } }
            : {}),
          ...(shouldSearch ? { tools: [{ googleSearch: {} }] } : {}),
        },
      });

      const outText = (res.text ?? '').trim();
      if (!outText) {
        throw new Error('মডেল থেকে কোনো উত্তর পাওয়া যায়নি।');
      }

      const chunks =
        res.candidates?.[0]?.groundingMetadata?.groundingChunks ?? [];
      const extractedSources: Array<{ title: string; url: string }> = [];
      for (const ch of chunks) {
        if (ch.web?.uri) {
          extractedSources.push({
            title: ch.web.title || ch.web.uri,
            url: ch.web.uri,
          });
        }
      }

      return { replyText: outText, sources: extractedSources.slice(0, 6) };
    },
  );

  botStore.appendChatTurn(refreshedUser.id, {
    role: 'user',
    text: message,
    module: moduleTag ?? 'chat',
    attachmentNote: imagePath ? path.basename(imagePath) : undefined,
  });
  botStore.appendChatTurn(refreshedUser.id, {
    role: 'assistant',
    text: replyText,
    module: moduleTag ?? 'chat',
  });
  botStore.updateUser(refreshedUser.id, {
    lastActiveTask: {
      module: moduleTag ?? 'chat',
      summary: message.slice(0, 80),
      contextText: replyText.slice(0, 600),
      updatedAt: new Date().toISOString(),
    },
  });
  botStore.incrementFeatureUsage(moduleTag ?? 'chat');

  return { replyText, rememberedNote, sources };
}

/**
 * AI Web Research Engine with Google Search Grounding + URL Context Analysis.
 */
export async function runWebResearch(params: {
  user: BotUser;
  queryOrUrl: string;
  deepReport?: boolean;
}): Promise<{
  reportText: string;
  sources: Array<{ title: string; url: string }>;
}> {
  const { user, queryOrUrl, deepReport } = params;
  const urls = queryOrUrl.match(/https?:\/\/[^\s)]+/gi) ?? [];

  const result = await withGeminiRetry('research', user.id, async (ai, model) => {
    const tools =
      urls.length > 0
        ? [{ urlContext: {} }, { googleSearch: {} }]
        : [{ googleSearch: {} }];

    const instruction =
      user.language === 'en'
        ? 'You are an expert AI Web Research Analyst. Synthesize current, verified information from web sources, compare multiple viewpoints when relevant, and cite findings clearly in English.'
        : 'আপনি একজন দক্ষ AI Web Research Analyst। ইন্টারনেট থেকে সর্বশেষ ও নির্ভরযোগ্য তথ্য সংগ্রহ করে একাধিক উৎস তুলনা করে স্পষ্ট বাংলায় (প্রয়োজনীয় ইংরেজি টার্মসহ) বিশ্লেষণমূলক রিপোর্ট তৈরি করুন।';

    const promptText =
      urls.length > 0
        ? `Analyze the webpage(s) and answer thoroughly:\n${queryOrUrl}`
        : deepReport
          ? `Conduct a comprehensive multi-source comparative web research report on: "${queryOrUrl}". Include key facts, pros/cons or comparison, and actionable conclusions.`
          : `Search the web for the latest accurate information and provide a clear summary with verified facts:\n"${queryOrUrl}"`;

    let res;
    let usedUngroundedFallback = false;
    try {
      res = await ai.models.generateContent({
        model,
        contents: promptText,
        config: {
          systemInstruction: instruction,
          tools,
          ...(model === 'gemini-4-hydrogen'
            ? {
                thinkingConfig: {
                  thinkingLevel: deepReport
                    ? ThinkingLevel.XHIGH
                    : ThinkingLevel.HIGH,
                },
              }
            : {}),
        },
      });
    } catch (err) {
      // If search grounding / urlContext fails on free-tier quota or unsupported model,
      // try direct URL fetch or ungrounded synthesis on a working text model cleanly
      if (isQuotaOrRateLimitError(err) && model === 'gemini-4-hydrogen') {
        throw err;
      }
      usedUngroundedFallback = true;
      const targetUrl = urls[0];
      let fetchedSnippet = '';
      if (targetUrl) {
        try {
          const pageResp = await fetch(targetUrl, { signal: AbortSignal.timeout(8000) });
          const html = await pageResp.text();
          fetchedSnippet = html
            .replace(/<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>/gi, ' ')
            .replace(/<[^>]+>/g, ' ')
            .replace(/\s+/g, ' ')
            .trim()
            .slice(0, 12000);
        } catch {
          fetchedSnippet = '';
        }
      }
      res = await ai.models.generateContent({
        model,
        contents: fetchedSnippet && targetUrl
          ? `Webpage URL: ${targetUrl}\nExtracted Page Content:\n${fetchedSnippet}\n\nTask: ${queryOrUrl}`
          : promptText,
        config: { systemInstruction: instruction },
      });
    }

    const rawText = (res.text ?? '').trim();
    if (!rawText) {
      throw new Error('রিসার্চ রিপোর্ট তৈরি করা যায়নি।');
    }
    const text = usedUngroundedFallback && urls.length === 0
      ? `${rawText}\n\n_(নোট: লাইভ Google Search গ্রাউন্ডিং কোটা সাময়িকভাবে পূর্ণ থাকায় AI জ্ঞানভিত্তিক বিশ্লেষণ প্রদান করা হয়েছে।)_`
      : rawText;

    const chunks =
      res.candidates?.[0]?.groundingMetadata?.groundingChunks ?? [];
    const sources: Array<{ title: string; url: string }> = [];
    const seen = new Set<string>();
    for (const ch of chunks) {
      if (ch.web?.uri && !seen.has(ch.web.uri)) {
        seen.add(ch.web.uri);
        sources.push({
          title: ch.web.title || ch.web.uri,
          url: ch.web.uri,
        });
      }
    }

    return { reportText: text, sources: sources.slice(0, 8) };
  });

  botStore.appendChatTurn(user.id, {
    role: 'user',
    text: `[Web Research] ${queryOrUrl}`,
    module: 'research',
  });
  botStore.appendChatTurn(user.id, {
    role: 'assistant',
    text: result.reportText,
    module: 'research',
  });
  botStore.updateUser(user.id, {
    lastActiveTask: {
      module: 'research',
      summary: `Research: ${queryOrUrl.slice(0, 60)}`,
      contextText: result.reportText.slice(0, 500),
      updatedAt: new Date().toISOString(),
    },
  });
  botStore.incrementFeatureUsage('research');

  return result;
}

export interface CodingAssistantOutput {
  explanationAndCode: string;
  generatedFile?: {
    filename: string;
    filePath: string;
    url: string;
    fileSizeBytes: number;
    mimeType: string;
  };
}

function guessExtAndMime(langTag: string, code: string): { ext: string; mime: string } {
  const t = langTag.toLowerCase().trim();
  if (t === 'python' || t === 'py' || /^\s*(?:import |def |from |print\()/m.test(code)) {
    return { ext: '.py', mime: 'text/x-python' };
  }
  if (t === 'html' || /<!doctype html|<html/i.test(code)) {
    return { ext: '.html', mime: 'text/html' };
  }
  if (t === 'css') return { ext: '.css', mime: 'text/css' };
  if (t === 'typescript' || t === 'ts' || t === 'tsx') {
    return { ext: '.ts', mime: 'text/typescript' };
  }
  if (t === 'javascript' || t === 'js' || t === 'jsx') {
    return { ext: '.js', mime: 'application/javascript' };
  }
  if (t === 'json') return { ext: '.json', mime: 'application/json' };
  if (t === 'bash' || t === 'sh') return { ext: '.sh', mime: 'text/x-shellscript' };
  return { ext: '.txt', mime: 'text/plain' };
}

/**
 * AI Coding Assistant: Code generation, debugging, optimization, and
 * downloadable single-file or multi-file .ZIP project creation.
 */
export async function runCodingAssistant(params: {
  user: BotUser;
  prompt: string;
  mode: 'write' | 'debug' | 'project';
  uploadedCodeContext?: string;
}): Promise<CodingAssistantOutput> {
  const { user, prompt, mode, uploadedCodeContext } = params;

  const systemInstruction =
    `You are a Principal Full-Stack Software Engineer & Telegram Bot Architect.\n` +
    `- Support Python, JavaScript/TypeScript, Node.js, HTML/CSS, React, SQL, Bash, and Telegram Bot APIs.\n` +
    `- Provide clean, production-ready, bug-free code with zero placeholders.\n` +
    `- Explain clearly in ${user.language === 'en' ? 'English' : 'Bangla (with English technical identifiers)'}.\n` +
    (mode === 'debug'
      ? '- Analyze root cause, pinpoint exact errors, explain the fix, and provide the corrected complete code.\n'
      : mode === 'project'
        ? '- Generate complete project files cleanly. Put each file inside a fenced block prefixed by `// FILE: relative/path.ext` or `# FILE: relative/path.py` on the first line inside the block so it can be packaged into a ZIP.\n'
        : '- Write complete runnable code inside standard fenced code blocks.\n');

  const fullPrompt = uploadedCodeContext
    ? `Uploaded Code / File Context:\n\`\`\`\n${uploadedCodeContext.slice(0, 12000)}\n\`\`\`\n\nTask:\n${prompt}`
    : prompt;

  const reply = await withGeminiRetry('coding', user.id, async (ai, model) => {
    const res = await ai.models.generateContent({
      model,
      contents: fullPrompt,
      config: {
        systemInstruction,
        ...(model === 'gemini-4-hydrogen'
          ? { thinkingConfig: { thinkingLevel: ThinkingLevel.XHIGH } }
          : {}),
      },
    });
    const out = (res.text ?? '').trim();
    if (!out) throw new Error('কোড জেনারেট করা যায়নি।');
    return out;
  });

  // Extract fenced code blocks to package real downloadable code / ZIP files
  const blockRegex = /```([a-zA-Z0-9_-]*)\n([\s\S]*?)```/g;
  const blocks: Array<{ lang: string; code: string }> = [];
  let m: RegExpExecArray | null;
  while ((m = blockRegex.exec(reply)) !== null) {
    if (m[2]?.trim()) {
      blocks.push({ lang: m[1] || '', code: m[2].trim() });
    }
  }

  let generatedFile: CodingAssistantOutput['generatedFile'];

  if (blocks.length > 1 || (mode === 'project' && blocks.length >= 1)) {
    const stamp = `${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const tmpDir = botStore.getJobWorkDir(`code_${stamp}`);
    try {
      const createdPaths: string[] = [];
      for (let i = 0; i < blocks.length; i++) {
        const blk = blocks[i];
        const firstLine = blk.code.split('\n')[0] ?? '';
        const fileComment = firstLine.match(/^(?:\/\/|#|<!--)\s*FILE:\s*([^\s>]+)/i);
        const { ext } = guessExtAndMime(blk.lang, blk.code);
        const relName = fileComment?.[1]
          ? fileComment[1].replace(/^\/+/, '').replace(/\.\./g, '')
          : `file_${i + 1}${ext}`;
        const dest = path.join(tmpDir, relName);
        fs.mkdirSync(path.dirname(dest), { recursive: true });
        fs.writeFileSync(dest, blk.code, 'utf-8');
        createdPaths.push(relName);
      }

      if (createdPaths.length > 1) {
        const zipName = `project-${stamp}.zip`;
        const zipPath = botStore.getDocFilePath(zipName);
        await execFileAsync('python3', [
          '-c',
          'import os, sys, zipfile\nroot, out_zip = sys.argv[1], sys.argv[2]\nwith zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as zf:\n  for r, _, fs in os.walk(root):\n    for f in fs:\n      fp = os.path.join(r, f)\n      zf.write(fp, os.path.relpath(fp, root))\n',
          tmpDir,
          zipPath,
        ]);
        const stat = fs.statSync(zipPath);
        generatedFile = {
          filename: zipName,
          filePath: zipPath,
          url: `/api/docs/${zipName}`,
          fileSizeBytes: stat.size,
          mimeType: 'application/zip',
        };
      }
    } finally {
      fs.rmSync(tmpDir, { recursive: true, force: true });
    }
  }

  if (!generatedFile && blocks.length === 1 && blocks[0].code.length >= 80) {
    const { ext, mime } = guessExtAndMime(blocks[0].lang, blocks[0].code);
    const fname = `code-${Date.now()}${ext}`;
    const fpath = botStore.getDocFilePath(fname);
    fs.writeFileSync(fpath, blocks[0].code, 'utf-8');
    generatedFile = {
      filename: fname,
      filePath: fpath,
      url: `/api/docs/${fname}`,
      fileSizeBytes: Buffer.byteLength(blocks[0].code, 'utf-8'),
      mimeType: mime,
    };
  }

  botStore.appendChatTurn(user.id, {
    role: 'user',
    text: `[Coding:${mode}] ${prompt}`,
    module: 'coding',
  });
  botStore.appendChatTurn(user.id, {
    role: 'assistant',
    text: reply,
    module: 'coding',
  });
  botStore.updateUser(user.id, {
    lastActiveTask: {
      module: 'coding',
      summary: `Code: ${prompt.slice(0, 60)}`,
      contextText: reply.slice(0, 600),
      updatedAt: new Date().toISOString(),
    },
  });
  botStore.incrementFeatureUsage('coding');

  return {
    explanationAndCode: reply,
    generatedFile,
  };
}
