export type VoiceCategory = 'male' | 'female' | 'cartoon';

export interface VoicePersona {
  id: string;
  category: VoiceCategory;
  emoji: string;
  nameBn: string;
  nameEn: string;
  roleBn: string;
  roleEn: string;
  descriptionBn: string;
  geminiVoice: 'Puck' | 'Charon' | 'Kore' | 'Fenrir' | 'Zephyr';
  stylePrompt: string;
  defaultSpeed: number;
  defaultPitch: number;
  sampleBangla: string;
}

export type UserTier = 'free' | 'premium';
export type UserStatus = 'active' | 'banned';
export type UserRole = 'user' | 'admin';

export type AssistantModuleId =
  | 'chat'
  | 'image'
  | 'video'
  | 'voice'
  | 'documents'
  | 'coding'
  | 'research'
  | 'memory';

export type UserLanguage = 'bn' | 'en';

export interface ChatTurnRecord {
  id: string;
  role: 'user' | 'assistant';
  text: string;
  module?: AssistantModuleId;
  attachmentNote?: string;
  createdAt: string;
}

export interface UserMemoryItem {
  id: string;
  key: string;
  value: string;
  updatedAt: string;
}

export interface ErrorLogEntry {
  id: string;
  module: string;
  userId?: string;
  message: string;
  createdAt: string;
}

export type VideoMode = 'prompt' | 'script' | 'voice' | 'edit_video' | 'image_to_video';

export type VideoTemplateId =
  | 'cinematic_doc'
  | 'viral_reels'
  | 'tech_explainer'
  | 'news_fact'
  | 'emotional_story';

export type VideoAspectRatio = '16:9' | '9:16' | '1:1';
export type VideoResolution = '720p' | '1080p' | '4k';
export type VideoMusicMood =
  | 'none'
  | 'cinematic'
  | 'emotional'
  | 'upbeat'
  | 'tech'
  | 'suspense';
export type VideoVisualMode =
  | 'auto'
  | 'ai_image'
  | 'stock_video'
  | 'cinematic_motion';

export interface VideoTemplateInfo {
  id: VideoTemplateId;
  nameBn: string;
  nameEn: string;
  taglineBn: string;
  badgeText: string;
  accentHex: string;
  secondaryHex: string;
  bgDarkHex: string;
  subtitleFont: string;
  ffmpegColorFilter: string;
}

export interface VideoScene {
  index: number;
  narrationBangla: string;
  subtitleText: string;
  visualPrompt: string;
  searchKeywords: string;
  emotion: 'dramatic' | 'calm' | 'happy' | 'tense' | 'informative' | 'sad';
  motion: 'zoom_in' | 'zoom_out' | 'pan_left' | 'pan_right' | 'pulse';
  transition: 'fade' | 'cut' | 'dissolve';
  startSec?: number;
  endSec?: number;
  durationSec?: number;
  assetPath?: string;
  assetType?: 'video' | 'image';
}

export type VideoJobStatus =
  | 'queued'
  | 'planning'
  | 'voicing'
  | 'visuals'
  | 'rendering'
  | 'completed'
  | 'failed';

export interface VideoDraftContext {
  mode: VideoMode;
  prompt?: string;
  title?: string;
  script?: string;
  uploadedVideoPath?: string;
  uploadedVideoName?: string;
  uploadedVideoDurationSec?: number;
  uploadedImagePath?: string;
  uploadedAudioPath?: string;
  uploadedAudioName?: string;
  uploadedAudioDurationSec?: number;
  templateId?: VideoTemplateId;
  aspectRatio?: VideoAspectRatio;
  resolution?: VideoResolution;
  videoSpeed?: number; // 0 = Auto-Fit to Voiceover duration, else 0.5..2.0
  voiceSpeed?: number;
  voicePitch?: number;
  voiceId?: string;
  musicMood?: VideoMusicMood;
  originalAudioMode?: 'mute' | 'duck' | 'keep';
  includeSubtitles?: boolean;
  includeIntroOutro?: boolean;
  watermarkText?: string;
}

export interface VideoProjectJob {
  id: string;
  userId: string;
  userName: string;
  telegramChatId?: number;
  telegramStatusMessageId?: number;
  mode: VideoMode;
  title: string;
  prompt?: string;
  script: string;
  templateId: VideoTemplateId;
  aspectRatio: VideoAspectRatio;
  resolution: VideoResolution;
  videoSpeed: number;
  voiceId: string;
  voiceNameBn: string;
  voiceSpeed: number;
  voicePitch: number;
  musicMood: VideoMusicMood;
  originalAudioMode: 'mute' | 'duck' | 'keep';
  includeSubtitles: boolean;
  includeIntroOutro: boolean;
  watermarkText?: string;
  uploadedVideoPath?: string;
  uploadedImagePath?: string;
  uploadedAudioPath?: string;
  scenes: VideoScene[];
  status: VideoJobStatus;
  statusText: string;
  progressPct: number;
  currentStep: number;
  totalSteps: number;
  startedAt?: string;
  estimatedTotalSec?: number;
  estimatedRemainingSec?: number;
  elapsedSec?: number;
  durationSec?: number;
  fileSizeBytes?: number;
  outputVideoUrl?: string;
  outputFilename?: string;
  costCharged: number;
  source: 'telegram' | 'simulator' | 'studio';
  error?: string;
  createdAt: string;
  updatedAt: string;
}

export type BotStep =
  | 'idle'
  | 'awaiting_category'
  | 'awaiting_voice'
  | 'awaiting_script'
  | 'collecting_long_script'
  | 'awaiting_preview_confirm'
  | 'awaiting_preview_edit'
  | 'awaiting_payment_method'
  | 'awaiting_payment_amount'
  | 'awaiting_payment_ref'
  | 'awaiting_payment_confirm'
  | 'awaiting_video_prompt'
  | 'awaiting_video_script'
  | 'awaiting_video_voice'
  | 'awaiting_video_upload'
  | 'awaiting_video_edit_script'
  | 'awaiting_video_watermark'
  | 'admin_search_user'
  | 'admin_set_user_limit'
  | 'admin_adjust_balance'
  | 'admin_edit_config'
  | 'admin_edit_payment_number'
  | 'admin_edit_voice_cost'
  | 'cmd_hub_menu'
  | 'cmd_vid_prompt'
  | 'cmd_vid_format'
  | 'cmd_vid_voice_bgm'
  | 'cmd_vid_extra'
  | 'cmd_vid_confirm'
  | 'cmd_dlg_bgm'
  | 'cmd_dlg_script'
  | 'cmd_dlg_confirm'
  | 'cmd_vbgm_voice'
  | 'cmd_vbgm_speed'
  | 'cmd_vbgm_script'
  | 'cmd_seo_topic'
  | 'cmd_preset_input'
  | 'cmd_broadcast_msg'
  | 'cmd_broadcast_confirm'
  | 'assistant_chat'
  | 'img_t2i'
  | 'img_design_prompt'
  | 'img_ref_prompt'
  | 'img_enhance_wait'
  | 'img_upscale_wait'
  | 'img_bg_wait'
  | 'awaiting_video_i2v_photo'
  | 'awaiting_video_i2v_prompt'
  | 'voice_stt_wait'
  | 'voice_translate_wait'
  | 'voice_enhance_wait'
  | 'doc_wait_file'
  | 'doc_qa'
  | 'doc_create_prompt'
  | 'code_chat'
  | 'code_debug'
  | 'code_project'
  | 'research_query'
  | 'research_url'
  | 'memory_add'
  | 'admin_feature_limits';

export interface UserSavedPreset {
  voiceId?: string;
  aspectRatio?: VideoAspectRatio;
  resolution?: VideoResolution;
  musicMood?: VideoMusicMood;
  watermarkText?: string;
  speed?: number;
  pitch?: number;
}

export interface PendingStepContext {
  targetUserId?: string;
  configKey?: string;
  paymentMethod?: string;
  paymentAccountNumber?: string;
  paymentAmount?: number;
  paymentRef?: string;
  paymentMethodLabel?: string;
  paymentAccountId?: string;
  voiceCostEditId?: string;
  longScriptParts?: string[];
  previewRawScript?: string;
  previewBanglaScript?: string;
  previewDetectedLang?: 'bangla' | 'english' | 'mixed';
  videoDraft?: VideoDraftContext;
  dialogueBgmMood?: VideoMusicMood;
  dialogueRawScript?: string;
  voiceBgmMood?: VideoMusicMood;
  voiceBgmVoiceId?: string;
  voiceBgmSpeed?: number;
  voiceBgmPitch?: number;
  broadcastDraftText?: string;
  imageAspectRatio?: '1:1' | '16:9' | '9:16' | '4:3';
  imageDesignKind?: 'logo' | 'banner' | 'poster' | 'thumbnail';
  docCreateFormat?: 'pdf' | 'docx' | 'xlsx' | 'pptx';
  lastRetryAction?: {
    kind: 'chat' | 'image' | 'research' | 'coding' | 'doc';
    prompt: string;
    extra?: string;
  };
}

export interface LastUploadContext {
  type: 'photo' | 'document' | 'audio' | 'video';
  filePath: string;
  filename: string;
  mimeType: string;
  extractedText?: string;
  caption?: string;
  uploadedAt: string;
}

export interface BotUser {
  id: string;
  telegramId: string;
  username: string;
  firstName: string;
  role: UserRole;
  tier: UserTier;
  premiumExpiresAt: string | null;
  status: UserStatus;
  balance: number;
  dailyCount: number;
  totalCount: number;
  lastResetDate: string;
  selectedCategory: VoiceCategory;
  selectedVoiceId: string;
  speed: number;
  pitch: number;
  step: BotStep;
  language?: UserLanguage;
  pendingContext?: PendingStepContext;
  savedPreset?: UserSavedPreset;
  chatHistory?: ChatTurnRecord[];
  memories?: UserMemoryItem[];
  lastUpload?: LastUploadContext;
  lastActiveTask?: {
    module: AssistantModuleId;
    summary: string;
    contextText?: string;
    updatedAt: string;
  };
  referredBy?: string;
  referralCount?: number;
  customDailyLimit: number | null;
  customCharLimit: number | null;
  joinedAt: string;
  lastActiveAt: string;
}

export interface AudioPartOutput {
  url: string;
  filename: string;
  durationSec: number;
  fileSizeBytes: number;
}

export interface VoiceGeneration {
  id: string;
  jobId?: string;
  userId: string;
  userName: string;
  voiceId: string;
  voiceNameBn: string;
  category: VoiceCategory;
  script: string;
  spokenScript: string;
  speed: number;
  pitch: number;
  durationSec: number;
  fileSizeBytes: number;
  audioUrl: string;
  audioParts?: AudioPartOutput[];
  totalChunks?: number;
  costCharged: number;
  source: 'telegram' | 'simulator' | 'studio';
  createdAt: string;
}

export type JobStatus =
  | 'queued'
  | 'processing'
  | 'joining'
  | 'rendering'
  | 'completed'
  | 'failed';

export interface VoiceJob {
  id: string;
  userId: string;
  userName: string;
  telegramChatId?: number;
  telegramStatusMessageId?: number;
  voiceId: string;
  voiceNameBn: string;
  category: VoiceCategory;
  script: string;
  spokenScript: string;
  chunks: string[];
  completedChunkFiles: Record<number, string>;
  speed: number;
  pitch: number;
  ttsModel: 'gemini-3.8-flash-lite-tts' | 'gemini-3.8-flash-tts';
  status: JobStatus;
  statusText: string;
  progressPct?: number;
  currentPart: number;
  totalParts: number;
  startedAt?: string;
  estimatedTotalSec?: number;
  estimatedRemainingSec?: number;
  elapsedSec?: number;
  retryCount: number;
  source: 'telegram' | 'simulator' | 'studio';
  generationId?: string;
  outputParts?: AudioPartOutput[];
  error?: string;
  executionLockId?: string;
  createdAt: string;
  updatedAt: string;
}

export interface PaymentAccount {
  id: string;
  method: string;
  accountNumber: string;
  accountType: string;
  note?: string;
  enabled: boolean;
}

export interface IncomingPaymentSms {
  id: string;
  method: string;
  amount: number;
  trxId: string;
  sender?: string;
  rawText: string;
  status: 'unmatched' | 'claimed';
  claimedByPaymentId?: string;
  claimedByUserName?: string;
  receivedAt: string;
  claimedAt?: string;
}

export interface PaymentRequest {
  id: string;
  userId: string;
  telegramId: string;
  userName: string;
  amount: number;
  method: string;
  accountNumber?: string;
  referenceNote: string;
  trxId?: string;
  autoVerified?: boolean;
  status: 'pending' | 'approved' | 'rejected';
  reviewedBy?: string;
  createdAt: string;
  reviewedAt?: string;
}

export interface TransactionRecord {
  id: string;
  userId: string;
  userName: string;
  type:
    | 'payment_approved'
    | 'admin_add'
    | 'admin_deduct'
    | 'voice_charge'
    | 'video_charge'
    | 'premium_upgrade'
    | 'referral_bonus';
  amount: number;
  balanceAfter: number;
  description: string;
  createdAt: string;
}

export interface DailyStat {
  date: string;
  generations: number;
  characters: number;
  activeUserIds: string[];
}

export interface BotConfig {
  telegramBotToken: string;
  telegramBotUsername: string;
  telegramMode: 'stopped' | 'polling' | 'webhook';
  notificationChannelId: string; // Optional Telegram Channel (@username or -100...) for direct generation alerts
  adminTelegramIds: string[];
  adminClaimCode: string;
  freeDailyLimit: number;
  premiumDailyLimit: number;
  maxScriptCharsFree: number; // 0 = Unlimited (no fixed limit)
  maxScriptCharsPremium: number; // 0 = Unlimited (no fixed limit)
  voiceGenerationCost: number; // Default cost in BDT per generation (0 = free)
  voiceCosts: Record<string, number>; // Per-voice custom cost overrides (voiceId -> BDT)
  videoGenerationCost: number; // Cost in BDT per AI video generation (0 = free)
  pexelsApiKey: string; // Optional Pexels Stock Video API Key for HD B-roll footage
  visualProviderMode: VideoVisualMode; // Visual provider strategy
  paymentAccounts: PaymentAccount[]; // Admin-configured payment numbers (bKash, Nagad, Rocket, etc.)
  paymentInstructions: string; // User-facing instructions explaining how to pay & submit TrxID
  autoVerifyPayments: boolean; // Auto-approve payments matching verified incoming SMS TrxID + Amount
  smsWebhookSecret: string; // Secret token protecting /api/payments/sms-webhook
  premiumMembershipDays: number; // Default duration in days
  smartEnglishToBangla: boolean;
  strictBanglaOnly: boolean;
  ttsModel: 'gemini-3.8-flash-lite-tts' | 'gemini-3.8-flash-tts';
  autoNormalizeBangla: boolean;
  referralBonusBdt?: number;
  enabledFeatures: Record<AssistantModuleId, boolean>;
  defaultChatModel: 'gemini-4-hydrogen' | 'gemini-3.1-flash-lite';
  elevenLabsApiKey?: string;
}

export interface InlineButton {
  text: string;
  callback_data: string;
}

export interface BotMessagePayload {
  id: string;
  sender: 'bot' | 'user';
  text: string;
  timestamp: string;
  buttons?: InlineButton[][];
  jobId?: string;
  videoJobId?: string;
  audio?: {
    generationId: string;
    url: string;
    filePath?: string;
    title: string;
    performer: string;
    durationSec: number;
    fileSizeBytes: number;
  };
  video?: {
    jobId: string;
    url: string;
    title: string;
    durationSec: number;
    fileSizeBytes: number;
  };
  photo?: {
    url: string;
    filePath?: string;
    caption?: string;
  };
  document?: {
    url: string;
    filePath?: string;
    filename: string;
    mimeType?: string;
    fileSizeBytes: number;
  };
}
