import { execFile } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { promisify } from 'node:util';
import { notifyAdminsOnVideoCompleted } from './adminNotify.ts';
import {
  normalizeChunkWavWithFfmpeg,
  probeAudioDurationSec,
} from './audio.ts';
import {
  formatUserFriendlyError,
  prepareBanglaScript,
  synthesizeRawBanglaChunkWav,
} from './gemini.ts';
import { botStore } from './store.ts';
import type {
  BotUser,
  VideoAspectRatio,
  VideoMode,
  VideoMusicMood,
  VideoProjectJob,
  VideoResolution,
  VideoScene,
  VideoTemplateId,
} from './types.ts';
import {
  generateBanglaVideoScriptFromPrompt,
  getVideoTemplate,
  planUnlimitedScenesFromScript,
  transcribeAndPlanScenesFromAudio,
} from './videoDirector.ts';
import { acquireVisualAssetForScene } from './videoProviders.ts';
import {
  assembleScenesVideo,
  probeMediaInfo,
  renderEditedUserVideo,
} from './videoRenderer.ts';
import { chunkBanglaScript, getVoiceById } from './voices.ts';

const execFileAsync = promisify(execFile);

export type VideoJobLifecycleListener = {
  onStatus?: (job: VideoProjectJob) => Promise<void> | void;
  onComplete?: (job: VideoProjectJob) => Promise<void> | void;
  onFail?: (job: VideoProjectJob, errorMessage: string) => Promise<void> | void;
};

export interface EnqueueVideoParams {
  user: BotUser;
  mode: VideoMode;
  title?: string;
  prompt?: string;
  script?: string;
  templateId?: VideoTemplateId;
  aspectRatio?: VideoAspectRatio;
  resolution?: VideoResolution;
  videoSpeed?: number;
  voiceId?: string;
  voiceSpeed?: number;
  voicePitch?: number;
  musicMood?: VideoMusicMood;
  originalAudioMode?: 'mute' | 'duck' | 'keep';
  includeSubtitles?: boolean;
  includeIntroOutro?: boolean;
  watermarkText?: string;
  uploadedVideoPath?: string;
  uploadedImagePath?: string;
  uploadedAudioPath?: string;
  source: 'telegram' | 'simulator' | 'studio';
  telegramChatId?: number;
  listener?: VideoJobLifecycleListener;
}

class VideoJobQueue {
  private activeLocks = new Set<string>();
  private listeners = new Map<string, VideoJobLifecycleListener>();

  registerListener(jobId: string, listener: VideoJobLifecycleListener) {
    this.listeners.set(jobId, listener);
  }

  private async emitStatus(job: VideoProjectJob) {
    job.updatedAt = new Date().toISOString();
    botStore.upsertVideoJob(job);
    const listener = this.listeners.get(job.id);
    if (listener?.onStatus) {
      await Promise.resolve(listener.onStatus(job)).catch(() => {});
    }
  }

  async enqueueVideoJob(
    params: EnqueueVideoParams,
  ): Promise<{ ok: boolean; error?: string; job?: VideoProjectJob }> {
    const eligibility = botStore.canUserGenerateVideo(params.user);
    if (!eligibility.ok) {
      return { ok: false, error: eligibility.reason };
    }

    if (params.mode === 'prompt' && !params.prompt?.trim() && !params.script?.trim()) {
      return { ok: false, error: 'অনুগ্রহ করে ভিডিও তৈরির জন্য একটি প্রম্পট লিখুন।' };
    }
    if (params.mode === 'script' && !params.script?.trim()) {
      return { ok: false, error: 'অনুগ্রহ করে ভিডিওর জন্য সম্পূর্ণ স্ক্রিপ্ট দিন।' };
    }
    if (params.mode === 'voice' && (!params.uploadedAudioPath || !fs.existsSync(params.uploadedAudioPath))) {
      return { ok: false, error: 'অনুগ্রহ করে ভয়েস বা অডিও ফাইল আপলোড করুন।' };
    }
    if (params.mode === 'edit_video' && (!params.uploadedVideoPath || !fs.existsSync(params.uploadedVideoPath))) {
      return { ok: false, error: 'এডিট করার জন্য অনুগ্রহ করে একটি ভিডিও ফাইল আপলোড করুন।' };
    }
    if (params.mode === 'image_to_video' && (!params.uploadedImagePath || !fs.existsSync(params.uploadedImagePath))) {
      return { ok: false, error: 'ভিডিও বানাতে অনুগ্রহ করে একটি ছবি আপলোড করুন।' };
    }

    const cfg = botStore.getConfig();
    const voice = getVoiceById(params.voiceId ?? params.user.selectedVoiceId);
    const tpl = getVideoTemplate(params.templateId);
    const now = new Date().toISOString();
    const jobId = `vjob-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;

    const resBaseSec =
      (params.resolution ?? '1080p') === '4k'
        ? 45
        : (params.resolution ?? '1080p') === '1080p'
          ? 28
          : 20;
    const textLen = (params.script?.trim() || params.prompt?.trim() || '').length;
    const modeExtra =
      params.mode === 'edit_video'
        ? 8
        : params.mode === 'voice'
          ? 12
          : Math.min(45, Math.max(8, Math.round(textLen / 35)));
    const estimatedTotalSec = Math.max(15, resBaseSec + modeExtra);

    const job: VideoProjectJob = {
      id: jobId,
      userId: params.user.id,
      userName: params.user.firstName || params.user.username,
      telegramChatId: params.telegramChatId,
      mode: params.mode,
      title:
        params.title?.trim() ||
        params.prompt?.trim().slice(0, 48) ||
        `${tpl.nameBn} প্রজেক্ট`,
      prompt: params.prompt?.trim() || undefined,
      script: params.script?.trim() || '',
      templateId: tpl.id,
      aspectRatio: params.aspectRatio ?? '16:9',
      resolution: params.resolution ?? '1080p',
      videoSpeed: typeof params.videoSpeed === 'number' ? params.videoSpeed : 0,
      voiceId: voice.id,
      voiceNameBn: `${voice.nameBn} (${voice.roleBn})`,
      voiceSpeed: params.voiceSpeed ?? params.user.speed ?? 1.0,
      voicePitch: params.voicePitch ?? params.user.pitch ?? 0,
      musicMood: params.musicMood ?? 'cinematic',
      originalAudioMode: params.originalAudioMode ?? 'mute',
      includeSubtitles: params.includeSubtitles ?? true,
      includeIntroOutro:
        params.includeIntroOutro ?? (params.mode !== 'edit_video'),
      watermarkText: params.watermarkText?.trim() || undefined,
      uploadedVideoPath: params.uploadedVideoPath,
      uploadedImagePath: params.uploadedImagePath,
      uploadedAudioPath: params.uploadedAudioPath,
      scenes: [],
      status: 'queued',
      statusText: 'ভিডিও প্রজেক্ট কিউতে যুক্ত হয়েছে (অটো-প্রসেস শুরু হচ্ছে...)',
      progressPct: 4,
      currentStep: 0,
      totalSteps: 4,
      startedAt: now,
      estimatedTotalSec,
      estimatedRemainingSec: estimatedTotalSec,
      elapsedSec: 0,
      costCharged: Math.max(0, cfg.videoGenerationCost ?? 0),
      source: params.source,
      createdAt: now,
      updatedAt: now,
    };

    botStore.upsertVideoJob(job);
    if (params.listener) {
      this.listeners.set(jobId, params.listener);
    }

    void this.executeVideoJob(jobId);
    return { ok: true, job };
  }

  private async synthesizeNarrationForScenes(params: {
    job: VideoProjectJob;
    scenes: VideoScene[];
    workDir: string;
  }): Promise<{ narrationPath: string; totalDurationSec: number }> {
    const { job, scenes, workDir } = params;
    const cfg = botStore.getConfig();
    const voice = getVoiceById(job.voiceId);
    const segmentWavPaths: string[] = [];
    let runningTime = 0;

    // Group consecutive non-empty scenes into <=620-char TTS batches
    // so a multi-scene video consumes 1-2 TTS calls instead of 8-15 separate calls.
    type SynthesisBatch =
      | { kind: 'silence'; scene: VideoScene }
      | { kind: 'speech'; scenes: VideoScene[]; combinedText: string };

    const batches: SynthesisBatch[] = [];
    let pendingScenes: VideoScene[] = [];
    let pendingText = '';

    const flushPendingSpeech = () => {
      if (pendingScenes.length > 0 && pendingText.trim()) {
        batches.push({
          kind: 'speech',
          scenes: pendingScenes,
          combinedText: pendingText.trim(),
        });
      }
      pendingScenes = [];
      pendingText = '';
    };

    for (const sc of scenes) {
      const rawText = (sc.narrationBangla || sc.subtitleText || '').trim();
      if (!rawText) {
        flushPendingSpeech();
        batches.push({ kind: 'silence', scene: sc });
        continue;
      }

      const punctuated = /[।.?!৷]$/.test(rawText) ? rawText : `${rawText}।`;
      if (
        pendingScenes.length > 0 &&
        pendingText.length + 1 + punctuated.length > 620
      ) {
        flushPendingSpeech();
      }

      if (!pendingText) {
        pendingText = punctuated;
        pendingScenes = [sc];
      } else {
        pendingText += ` ${punctuated}`;
        pendingScenes.push(sc);
      }

      // If a single scene itself exceeds 620 chars, give it its own batch
      if (pendingText.length >= 620) {
        flushPendingSpeech();
      }
    }
    flushPendingSpeech();

    let completedScenes = 0;
    for (let bIdx = 0; bIdx < batches.length; bIdx++) {
      const batch = batches[bIdx];
      const batchWavPath = path.join(
        workDir,
        `batch_vo_${String(bIdx).padStart(4, '0')}.wav`,
      );

      if (batch.kind === 'silence') {
        await execFileAsync('ffmpeg', [
          '-y',
          '-f',
          'lavfi',
          '-i',
          'anullsrc=r=24000:cl=mono',
          '-t',
          '3.0',
          batchWavPath,
        ]);
        const dur = await probeAudioDurationSec(batchWavPath);
        batch.scene.startSec = Math.round(runningTime * 100) / 100;
        batch.scene.durationSec = Math.max(1.2, Math.round(dur * 100) / 100);
        runningTime += batch.scene.durationSec;
        batch.scene.endSec = Math.round(runningTime * 100) / 100;
        segmentWavPaths.push(batchWavPath);
        completedScenes += 1;
      } else {
        const subChunks = chunkBanglaScript(batch.combinedText, 620);
        const subWavPaths: string[] = [];

        for (let c = 0; c < subChunks.length; c++) {
          const rawWav = await synthesizeRawBanglaChunkWav({
            textChunk: subChunks[c],
            voice,
            speed: job.voiceSpeed,
            pitch: job.voicePitch,
            ttsModel: cfg.ttsModel,
            partIndex: bIdx + c,
            totalParts: Math.max(batches.length, subChunks.length),
          });
          const subOut = path.join(
            workDir,
            `batch_vo_${String(bIdx).padStart(4, '0')}_${c}.wav`,
          );
          await normalizeChunkWavWithFfmpeg({
            rawWavBuffer: rawWav,
            outputWavPath: subOut,
            speed: job.voiceSpeed,
            pitchSemitones: job.voicePitch,
          });
          subWavPaths.push(subOut);
        }

        if (subWavPaths.length === 1) {
          fs.renameSync(subWavPaths[0], batchWavPath);
        } else {
          const listPath = path.join(workDir, `batch_vo_list_${bIdx}.txt`);
          fs.writeFileSync(
            listPath,
            subWavPaths
              .map((p) => `file '${p.replace(/'/g, "'\\''")}'`)
              .join('\n'),
            'utf-8',
          );
          await execFileAsync('ffmpeg', [
            '-y',
            '-f',
            'concat',
            '-safe',
            '0',
            '-i',
            listPath,
            '-c',
            'copy',
            batchWavPath,
          ]);
        }

        const batchDur = Math.max(
          1.2 * batch.scenes.length,
          await probeAudioDurationSec(batchWavPath),
        );
        segmentWavPaths.push(batchWavPath);

        // Allocate scene timings proportionally to spoken text length inside the batch
        const weights = batch.scenes.map((sc) => {
          const t = (sc.narrationBangla || sc.subtitleText || '').replace(
            /\s+/g,
            '',
          );
          return Math.max(6, t.length);
        });
        const totalWeight = weights.reduce((a, b) => a + b, 0) || 1;
        const batchStart = runningTime;
        let allocated = 0;

        for (let sIdx = 0; sIdx < batch.scenes.length; sIdx++) {
          const sc = batch.scenes[sIdx];
          sc.startSec = Math.round(runningTime * 100) / 100;
          const isLastInBatch = sIdx === batch.scenes.length - 1;
          const dur = isLastInBatch
            ? Math.max(1.2, batchDur - allocated)
            : Math.max(1.2, (batchDur * weights[sIdx]) / totalWeight);
          sc.durationSec = Math.round(dur * 100) / 100;
          allocated += sc.durationSec;
          runningTime =
            isLastInBatch
              ? batchStart + batchDur
              : runningTime + sc.durationSec;
          sc.endSec = Math.round(runningTime * 100) / 100;
        }
        completedScenes += batch.scenes.length;
      }

      job.progressPct = Math.max(
        job.progressPct,
        Math.round(18 + (completedScenes / Math.max(1, scenes.length)) * 22),
      );
      job.statusText = `বাংলা AI ভয়েস তৈরি হচ্ছে (${completedScenes}/${scenes.length})`;
      await this.emitStatus(job);
    }

    const fullNarrationPath = path.join(workDir, 'full_narration.wav');
    if (segmentWavPaths.length === 1) {
      fs.copyFileSync(segmentWavPaths[0], fullNarrationPath);
    } else {
      const fullListPath = path.join(workDir, 'full_vo_concat.txt');
      fs.writeFileSync(
        fullListPath,
        segmentWavPaths
          .map((p) => `file '${p.replace(/'/g, "'\\''")}'`)
          .join('\n'),
        'utf-8',
      );
      await execFileAsync('ffmpeg', [
        '-y',
        '-f',
        'concat',
        '-safe',
        '0',
        '-i',
        fullListPath,
        '-ar',
        '44100',
        '-ac',
        '1',
        '-c:a',
        'pcm_s16le',
        fullNarrationPath,
      ]);
    }

    const totalDur = await probeAudioDurationSec(fullNarrationPath);
    return { narrationPath: fullNarrationPath, totalDurationSec: totalDur };
  }

  async executeVideoJob(jobId: string): Promise<void> {
    if (this.activeLocks.has(jobId)) return;
    const job = botStore.getVideoJobById(jobId);
    if (!job || job.status === 'completed') return;

    this.activeLocks.add(jobId);
    const workDir = botStore.getVideoWorkDir(job.id);
    const startMs = job.startedAt
      ? Date.parse(job.startedAt) || Date.now()
      : Date.now();
    job.startedAt = new Date(startMs).toISOString();
    const baselineTotal = job.estimatedTotalSec || 30;

    let stageCapPct = 19;
    const syncTimingAndEta = (explicitPct?: number) => {
      const elapsed = Math.max(0, Math.round((Date.now() - startMs) / 1000));
      job.elapsedSec = elapsed;
      if (typeof explicitPct === 'number') {
        job.progressPct = Math.min(100, Math.max(job.progressPct, explicitPct));
      } else if (job.progressPct < stageCapPct) {
        job.progressPct = Math.min(stageCapPct, job.progressPct + 1);
      }
      const pct = job.progressPct;
      if (pct >= 100) {
        job.estimatedRemainingSec = 0;
        job.estimatedTotalSec = elapsed;
      } else {
        const baselineRem = Math.max(2, baselineTotal - elapsed);
        if (pct >= 15 && elapsed >= 3) {
          const throughputRem = Math.round((elapsed * (100 - pct)) / pct);
          job.estimatedRemainingSec = Math.max(
            1,
            Math.round(throughputRem * 0.55 + baselineRem * 0.45),
          );
        } else {
          job.estimatedRemainingSec = baselineRem;
        }
        job.estimatedTotalSec = elapsed + job.estimatedRemainingSec;
      }
    };

    const heartbeat = setInterval(() => {
      if (job.status === 'completed' || job.status === 'failed') return;
      if (job.status === 'planning') stageCapPct = Math.max(stageCapPct, 24);
      else if (job.status === 'voicing') stageCapPct = 43;
      else if (job.status === 'visuals') stageCapPct = 63;
      else if (job.status === 'rendering') stageCapPct = 98;
      syncTimingAndEta();
      void this.emitStatus(job);
    }, 1000);

    try {
      const cfg = botStore.getConfig();
      const tpl = getVideoTemplate(job.templateId);
      const outFilename = `${job.id}.mp4`;
      const outMp4Path = path.join(botStore.getVideosDir(), outFilename);

      // STEP 1: Planning Script & Scenes
      job.status = 'planning';
      job.currentStep = 1;
      stageCapPct = 22;
      job.statusText = 'AI স্ক্রিপ্ট ও সিন পরিকল্পনা করছে...';
      syncTimingAndEta(10);
      await this.emitStatus(job);

      if (job.mode === 'prompt' && !job.script.trim() && job.prompt) {
        const gen = await generateBanglaVideoScriptFromPrompt({
          prompt: job.prompt,
          templateId: job.templateId,
        });
        job.title = gen.title;
        job.script = gen.banglaScript;
        if (job.musicMood === 'cinematic') {
          job.musicMood = gen.musicMood;
        }
        job.statusText = 'AI স্ক্রিপ্ট তৈরি সম্পন্ন · সিন সাজানো হচ্ছে...';
        syncTimingAndEta(16);
        await this.emitStatus(job);
      }

      if (job.mode === 'edit_video' && job.uploadedVideoPath) {
        const srcVidInfo = await probeMediaInfo(job.uploadedVideoPath);

        // If user gave prompt/script in edit_video mode, prepare Bangla narration
        let narrationPath: string | undefined;
        let narrationDur = srcVidInfo.durationSec;

        if (job.prompt && !job.script.trim()) {
          const gen = await generateBanglaVideoScriptFromPrompt({
            prompt: job.prompt,
            templateId: job.templateId,
            durationHintSec: Math.round(srcVidInfo.durationSec),
          });
          job.title = gen.title;
          job.script = gen.banglaScript;
        }

        if (job.script.trim()) {
          const prep = await prepareBanglaScript(
            job.script,
            cfg.strictBanglaOnly,
            cfg.autoNormalizeBangla,
            cfg.smartEnglishToBangla,
          );
          if (!prep.valid) {
            throw new Error(prep.reason || 'স্ক্রিপ্ট ভ্যালিডেশন ব্যর্থ হয়েছে।');
          }
          job.script = prep.spokenScript.trim();
          job.scenes = await planUnlimitedScenesFromScript({
            script: job.script,
            title: job.title,
            templateId: job.templateId,
          });

          job.status = 'voicing';
          job.currentStep = 2;
          syncTimingAndEta(25);
          job.statusText = 'ভিডিওর জন্য বাংলা ভয়েসওভার তৈরি হচ্ছে...';
          await this.emitStatus(job);

          const synth = await this.synthesizeNarrationForScenes({
            job,
            scenes: job.scenes,
            workDir,
          });
          narrationPath = synth.narrationPath;
          narrationDur = synth.totalDurationSec;
        } else if (
          job.uploadedAudioPath &&
          fs.existsSync(job.uploadedAudioPath)
        ) {
          const audioInfo = await probeMediaInfo(job.uploadedAudioPath);
          narrationPath = job.uploadedAudioPath;
          narrationDur = audioInfo.durationSec;

          if (job.includeSubtitles) {
            const audioBytes = fs.readFileSync(job.uploadedAudioPath);
            const analyzed = await transcribeAndPlanScenesFromAudio({
              audioBuffer: audioBytes,
              mimeType: 'audio/mpeg',
              totalDurationSec: audioInfo.durationSec,
              templateId: job.templateId,
            });
            job.scenes = analyzed.scenes;
          }
        }

        job.status = 'rendering';
        job.currentStep = 4;
        syncTimingAndEta(65);
        job.statusText = 'আপনার ভিডিও স্পিড, ভয়েস ও টেমপ্লেট এডিট হচ্ছে...';
        await this.emitStatus(job);

        const rendered = await renderEditedUserVideo({
          workDir,
          inputVideoPath: job.uploadedVideoPath,
          outputMp4Path: outMp4Path,
          title: job.title,
          scenes: job.scenes,
          narrationAudioPath: narrationPath,
          targetDurationSec: narrationDur,
          videoSpeed: job.videoSpeed,
          originalAudioMode: job.originalAudioMode,
          template: tpl,
          aspectRatio: job.aspectRatio,
          resolution: job.resolution,
          musicMood: job.musicMood,
          includeSubtitles: job.includeSubtitles,
          watermarkText: job.watermarkText,
          onProgress: async (pct, statusText) => {
            syncTimingAndEta(pct);
            job.statusText = statusText;
            await this.emitStatus(job);
          },
        });

        job.durationSec = rendered.durationSec;
        job.fileSizeBytes = rendered.fileSizeBytes;
        job.outputFilename = outFilename;
        job.outputVideoUrl = `/api/videos/${outFilename}`;
        clearInterval(heartbeat);
        job.status = 'completed';
        job.statusText = 'ভিডিও এডিটিং ও রেন্ডারিং সম্পন্ন!';
        syncTimingAndEta(100);
        botStore.recordVideoCompletion(job);
        await this.emitStatus(job);

        const listener = this.listeners.get(job.id);
        if (listener?.onComplete) {
          await Promise.resolve(listener.onComplete(job)).catch(() => {});
        }
        void notifyAdminsOnVideoCompleted(job).catch(() => {});
        fs.rmSync(workDir, { recursive: true, force: true });
        return;
      }

      // MODES 1, 2, 3 (AI Video Generation)
      let narrationPath = '';
      let totalAudioDur = 5;

      if (job.mode === 'voice' && job.uploadedAudioPath) {
        const audioInfo = await probeMediaInfo(job.uploadedAudioPath);
        totalAudioDur = audioInfo.durationSec;

        // Normalize/adjust user voice speed if != 1.0
        const normalizedUserVoice = path.join(workDir, 'user_voice_norm.wav');
        const spd = Math.max(0.5, Math.min(2.0, job.voiceSpeed || 1.0));
        const af =
          Math.abs(spd - 1.0) >= 0.02
            ? `aresample=44100,atempo=${spd.toFixed(3)}`
            : 'aresample=44100';
        await execFileAsync('ffmpeg', [
          '-y',
          '-i',
          job.uploadedAudioPath,
          '-af',
          af,
          '-ac',
          '1',
          '-c:a',
          'pcm_s16le',
          normalizedUserVoice,
        ]);
        narrationPath = normalizedUserVoice;
        totalAudioDur = await probeAudioDurationSec(narrationPath);

        job.status = 'planning';
        job.currentStep = 2;
        syncTimingAndEta(25);
        job.statusText = 'AI আপনার ভয়েস শুনে দৃশ্য নির্বাচন করছে...';
        await this.emitStatus(job);

        const audioBuf = fs.readFileSync(normalizedUserVoice);
        const analysis = await transcribeAndPlanScenesFromAudio({
          audioBuffer: audioBuf,
          mimeType: 'audio/wav',
          totalDurationSec: totalAudioDur,
          templateId: job.templateId,
        });
        job.title = job.title || analysis.title;
        job.script = analysis.transcriptBangla || '(Uploaded Voice Track)';
        if (job.musicMood === 'cinematic' && analysis.musicMood) {
          job.musicMood = analysis.musicMood;
        }
        job.scenes = analysis.scenes;
      } else {
        // Mode 1 (Prompt -> Script) or Mode 2 (Script -> Video)
        const prep = await prepareBanglaScript(
          job.script,
          cfg.strictBanglaOnly,
          cfg.autoNormalizeBangla,
          cfg.smartEnglishToBangla,
        );
        if (!prep.valid || !prep.spokenScript.trim()) {
          throw new Error(prep.reason || 'বৈধ বাংলা বা ইংরেজি স্ক্রিপ্ট দিন।');
        }
        job.script = prep.spokenScript.trim();

        job.scenes = await planUnlimitedScenesFromScript({
          script: job.script,
          title: job.title,
          templateId: job.templateId,
        });
        if (job.scenes.length === 0) {
          throw new Error('স্ক্রিপ্ট থেকে কোনো সিন তৈরি করা যায়নি।');
        }

        // Step 2: Voice synthesis per scene for millisecond sync
        job.status = 'voicing';
        job.currentStep = 2;
        syncTimingAndEta(25);
        job.statusText = `বাংলা AI ভয়েস তৈরি শুরু হয়েছে (${job.scenes.length} সিন)...`;
        await this.emitStatus(job);

        const synth = await this.synthesizeNarrationForScenes({
          job,
          scenes: job.scenes,
          workDir,
        });
        narrationPath = synth.narrationPath;
        totalAudioDur = synth.totalDurationSec;
      }

      // Step 3: Acquire visuals for every scene (Stock Video / Gemini Image / Procedural Artwork)
      job.status = 'visuals';
      job.currentStep = 3;
      syncTimingAndEta(44);
      job.statusText = `সিনগুলোর জন্য AI ভিজ্যুয়াল তৈরি হচ্ছে (0/${job.scenes.length})`;
      await this.emitStatus(job);

      let allowAiImageAttempt = cfg.visualProviderMode !== 'cinematic_motion';
      const pexelsKey =
        cfg.pexelsApiKey?.trim() || process.env.PEXELS_API_KEY?.trim() || '';

      const motions: Array<VideoScene['motion']> = [
        'zoom_in',
        'pan_right',
        'zoom_out',
        'pan_left',
      ];

      for (let i = 0; i < job.scenes.length; i++) {
        const sc = job.scenes[i];
        if (
          job.mode === 'image_to_video' &&
          job.uploadedImagePath &&
          fs.existsSync(job.uploadedImagePath)
        ) {
          sc.assetPath = job.uploadedImagePath;
          sc.assetType = 'image';
          sc.motion = motions[i % motions.length];
        } else {
          const acquired = await acquireVisualAssetForScene({
            scene: sc,
            aspectRatio: job.aspectRatio,
            template: tpl,
            workDir,
            pexelsApiKey: pexelsKey,
            visualMode: cfg.visualProviderMode ?? 'auto',
            allowAiImageAttempt,
          });
          if (acquired.aiImageFailed) {
            // If Gemini image model hit quota/restriction, switch smoothly to procedural art for remaining scenes
            allowAiImageAttempt = false;
          }
          sc.assetPath = acquired.assetPath;
          sc.assetType = acquired.assetType;
        }

        syncTimingAndEta(
          Math.round(44 + ((i + 1) / Math.max(1, job.scenes.length)) * 18),
        );
        job.statusText = `ভিজ্যুয়াল প্রস্তুত হচ্ছে (${i + 1}/${job.scenes.length})`;
        await this.emitStatus(job);
      }
      botStore.incrementFeatureUsage('video');

      // Step 4: Final FFmpeg Composition
      job.status = 'rendering';
      job.currentStep = 4;
      syncTimingAndEta(64);
      job.statusText = 'সিন, সাবটাইটেল ও ব্যাকগ্রাউন্ড মিউজিক রেন্ডার হচ্ছে...';
      await this.emitStatus(job);

      const rendered = await assembleScenesVideo({
        workDir,
        outputMp4Path: outMp4Path,
        title: job.title,
        scenes: job.scenes,
        narrationAudioPath: narrationPath,
        totalAudioDurationSec: totalAudioDur,
        template: tpl,
        aspectRatio: job.aspectRatio,
        resolution: job.resolution,
        musicMood: job.musicMood,
        includeSubtitles: job.includeSubtitles,
        includeIntroOutro: job.includeIntroOutro,
        watermarkText: job.watermarkText,
        onProgress: async (pct, statusText) => {
          syncTimingAndEta(pct);
          job.statusText = statusText;
          await this.emitStatus(job);
        },
      });

      job.durationSec = rendered.durationSec;
      job.fileSizeBytes = rendered.fileSizeBytes;
      job.outputFilename = outFilename;
      job.outputVideoUrl = `/api/videos/${outFilename}`;
      clearInterval(heartbeat);
      job.status = 'completed';
      job.statusText = 'প্রফেশনাল AI ভিডিও সম্পন্ন হয়েছে!';
      syncTimingAndEta(100);
      botStore.recordVideoCompletion(job);
      await this.emitStatus(job);

      const listener = this.listeners.get(job.id);
      if (listener?.onComplete) {
        await Promise.resolve(listener.onComplete(job)).catch(() => {});
      }
      void notifyAdminsOnVideoCompleted(job).catch(() => {});

      fs.rmSync(workDir, { recursive: true, force: true });
    } catch (err) {
      clearInterval(heartbeat);
      const errorMsg = formatUserFriendlyError(err);
      job.status = 'failed';
      job.statusText = 'ভিডিও তৈরি ব্যর্থ হয়েছে';
      job.error = errorMsg;
      job.estimatedRemainingSec = 0;
      job.elapsedSec = Math.max(0, Math.round((Date.now() - startMs) / 1000));
      await this.emitStatus(job);

      const listener = this.listeners.get(job.id);
      if (listener?.onFail) {
        await Promise.resolve(listener.onFail(job, errorMsg)).catch(() => {});
      }
    } finally {
      clearInterval(heartbeat);
      this.activeLocks.delete(jobId);
      this.listeners.delete(jobId);
    }
  }
}

export const videoJobQueue = new VideoJobQueue();
