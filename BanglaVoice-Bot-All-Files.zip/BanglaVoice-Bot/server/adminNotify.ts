import fs from 'node:fs';
import path from 'node:path';
import { botStore } from './store.ts';
import type { VideoProjectJob, VoiceGeneration, VoiceJob } from './types.ts';
import { getVideoTemplate } from './videoDirector.ts';

function formatBytesShort(bytes?: number): string {
  if (!bytes || bytes <= 0) return '0 KB';
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function formatDurationShort(sec?: number): string {
  const s = Math.max(0, Math.round(sec ?? 0));
  if (s < 60) return `${s}s`;
  const m = Math.floor(s / 60);
  const rem = s % 60;
  return `${m}m ${rem}s`;
}

function formatSourceLabel(source: 'telegram' | 'simulator' | 'studio'): string {
  if (source === 'telegram') return 'Telegram Bot';
  if (source === 'simulator') return 'Bot Simulator';
  return 'Web Studio';
}

export function normalizeTelegramChannelTarget(raw: string): string {
  const trimmed = raw.trim();
  if (!trimmed || /^(?:none|off|clear|null)$/i.test(trimmed)) return '';
  // Do not corrupt private invite links like https://t.me/+...
  if (/t\.me\/\+/i.test(trimmed)) {
    return trimmed;
  }
  const urlMatch = trimmed.match(/^(?:https?:\/\/)?t\.me\/([A-Za-z0-9_]{4,})$/i);
  if (urlMatch?.[1]) {
    return `@${urlMatch[1]}`;
  }
  if (/^[A-Za-z][A-Za-z0-9_]{3,}$/.test(trimmed)) {
    return `@${trimmed}`;
  }
  return trimmed;
}

async function tgSendMessage(
  token: string,
  chatId: string,
  text: string,
): Promise<{ ok: boolean; description?: string }> {
  const safeText = text.length > 4000 ? `${text.slice(0, 3990)}\n...` : text;
  const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      chat_id: chatId,
      text: safeText,
    }),
    signal: AbortSignal.timeout(12000),
  });
  return (await res.json()) as { ok: boolean; description?: string };
}

async function tgSendAudioFile(params: {
  token: string;
  chatId: string;
  filePath: string;
  filename: string;
  caption: string;
  title: string;
}): Promise<void> {
  if (!fs.existsSync(params.filePath)) return;
  const stat = fs.statSync(params.filePath);
  if (stat.size > 48 * 1024 * 1024) return;
  const bytes = fs.readFileSync(params.filePath);
  const form = new FormData();
  form.append('chat_id', params.chatId);
  form.append('caption', params.caption.slice(0, 1000));
  form.append('title', params.title);
  form.append('performer', 'BanglaVoice AI');
  form.append(
    'audio',
    new Blob([new Uint8Array(bytes)], { type: 'audio/mpeg' }),
    params.filename,
  );
  const res = await fetch(`https://api.telegram.org/bot${params.token}/sendAudio`, {
    method: 'POST',
    body: form,
    signal: AbortSignal.timeout(45000),
  });
  if (!res.ok) {
    const errText = await res.text().catch(() => '');
    console.error(`sendAudio failed for ${params.chatId}:`, errText);
  }
}

async function tgSendVideoFile(params: {
  token: string;
  chatId: string;
  filePath: string;
  filename: string;
  caption: string;
}): Promise<boolean> {
  if (!fs.existsSync(params.filePath)) return false;
  const stat = fs.statSync(params.filePath);
  if (stat.size > 48 * 1024 * 1024) return false;
  const bytes = fs.readFileSync(params.filePath);
  const form = new FormData();
  form.append('chat_id', params.chatId);
  form.append('caption', params.caption.slice(0, 1000));
  form.append('supports_streaming', 'true');
  form.append(
    'video',
    new Blob([new Uint8Array(bytes)], { type: 'video/mp4' }),
    params.filename,
  );
  const res = await fetch(`https://api.telegram.org/bot${params.token}/sendVideo`, {
    method: 'POST',
    body: form,
    signal: AbortSignal.timeout(60000),
  });
  if (!res.ok) {
    const errText = await res.text().catch(() => '');
    console.error(`sendVideo failed for ${params.chatId}:`, errText);
    return false;
  }
  return true;
}

export async function sendTestChannelNotification(
  channelInput?: string,
): Promise<{ ok: boolean; channelId: string; error?: string }> {
  const cfg = botStore.getConfig();
  const token = cfg.telegramBotToken?.trim();
  if (!token) {
    return {
      ok: false,
      channelId: '',
      error: 'Telegram Bot Token সেট করা নেই।',
    };
  }

  const target = normalizeTelegramChannelTarget(
    channelInput ?? cfg.notificationChannelId ?? '',
  );
  if (!target) {
    return {
      ok: false,
      channelId: '',
      error: 'সঠিক Channel Username (@channel) অথবা Channel ID (-100...) লিখুন।',
    };
  }

  if (/t\.me\/\+/i.test(target)) {
    return {
      ok: false,
      channelId: target,
      error:
        'প্রাইভেট চ্যানেলের ইনভাইট লিংক (t.me/+...) সরাসরি বট এপিআই-তে কাজ করে না। চ্যানেলে বটটিকে Admin হিসেবে যুক্ত করে চ্যানেলের যেকোনো ১টি পোস্ট এই বটের ইনবক্সে Forward করুন অথবা চ্যানেলে /connect লিখুন — বট নিজে থেকেই -100... আইডি নিয়ে নেবে!',
    };
  }

  try {
    const data = await tgSendMessage(
      token,
      target,
      `✅ চ্যানেল সংযোগ সফল হয়েছে!\nএখন থেকে বটে তৈরি নতুন অডিও এবং AI ভিডিও সরাসরি এই চ্যানেলে আপলোড হবে (ইউজারের কোনো পার্সোনাল তথ্য ছাড়াই)।`,
    );
    if (!data.ok) {
      return {
        ok: false,
        channelId: target,
        error:
          data.description ||
          'চ্যানেলে মেসেজ পাঠানো যায়নি। বটটিকে ওই চ্যানেলের Administrator হিসেবে যুক্ত করুন।',
      };
    }
    return { ok: true, channelId: target };
  } catch (err) {
    return {
      ok: false,
      channelId: target,
      error: err instanceof Error ? err.message : 'Telegram request failed',
    };
  }
}

/**
 * Dual delivery on Voice/Audio completion:
 * 1) Channel: Sends ONLY the clean Audio MP3(s) with zero user personal data.
 * 2) Admin Inbox: Sends User Name/Username/ID + Details + the Audio MP3(s).
 */
export async function notifyAdminsOnVoiceCompleted(
  job: VoiceJob,
  generation: VoiceGeneration,
): Promise<void> {
  const cfg = botStore.getConfig();
  const token = cfg.telegramBotToken?.trim();
  if (!token) return;

  const parts =
    generation.audioParts && generation.audioParts.length > 0
      ? generation.audioParts
      : [
          {
            filename: path.basename(generation.audioUrl),
            url: generation.audioUrl,
            durationSec: generation.durationSec,
            fileSizeBytes: generation.fileSizeBytes,
          },
        ];

  // 1. Post cleanly to Channel (ZERO personal user info)
  const channelTarget = normalizeTelegramChannelTarget(
    cfg.notificationChannelId ?? '',
  );
  if (channelTarget && !/t\.me\/\+/i.test(channelTarget)) {
    for (let idx = 0; idx < parts.length; idx++) {
      const part = parts[idx];
      const filePath = path.join(botStore.getAudioDir(), part.filename);
      const partSuffix =
        parts.length > 1 ? ` (Part ${idx + 1}/${parts.length})` : '';
      const cleanCaption =
        `🎧 বাংলা AI ভয়েস${partSuffix}\n` +
        `🎙️ কণ্ঠস্বর: ${generation.voiceNameBn}\n` +
        `⏱️ দৈর্ঘ্য: ${formatDurationShort(part.durationSec)} · স্পিড: ${generation.speed}x`;

      await tgSendAudioFile({
        token,
        chatId: channelTarget,
        filePath,
        filename: part.filename,
        caption: cleanCaption,
        title: `Bangla AI Voice${partSuffix}`,
      }).catch(() => {});
    }
  }

  // 2. Send User Username + Details + Audio MP3 to Admin Inbox(es)
  const adminIds = botStore
    .listAdminTelegramIds()
    .map((id) => id.trim())
    .filter((id) => id.length > 0 && !id.startsWith('sim_'));

  if (adminIds.length === 0) return;

  const user = botStore.getUserById(job.userId);
  const usernameHandle = user?.username ? `@${user.username}` : 'নেই';
  const tgId = user?.telegramId ?? job.userId;
  const scriptSnippet = generation.script.replace(/\s+/g, ' ').trim();
  const preview =
    scriptSnippet.length > 180
      ? `${scriptSnippet.slice(0, 180)}...`
      : scriptSnippet;

  const adminText =
    `🔔 নতুন অডিও / ভয়েস জেনারেট হয়েছে!\n\n` +
    `👤 ইউজার: ${job.userName}\n` +
    `🔗 ইউজারনেম: ${usernameHandle} (ID: ${tgId})\n` +
    `🎙️ কণ্ঠস্বর: ${generation.voiceNameBn}\n` +
    `⏱️ দৈর্ঘ্য: ${formatDurationShort(generation.durationSec)} · স্পিড: ${generation.speed}x · সাইজ: ${formatBytesShort(generation.fileSizeBytes)}\n` +
    `💰 চার্জ: ৳${generation.costCharged} · ব্যালেন্স: ৳${(user?.balance ?? 0).toFixed(2)}\n` +
    `📍 সোর্স: ${formatSourceLabel(job.source)}\n` +
    (preview ? `📝 স্ক্রিপ্ট: "${preview}"` : '');

  await Promise.allSettled(
    adminIds.map(async (chatId) => {
      await tgSendMessage(token, chatId, adminText).catch(() => {});
      for (let idx = 0; idx < parts.length; idx++) {
        const part = parts[idx];
        const filePath = path.join(botStore.getAudioDir(), part.filename);
        const partSuffix =
          parts.length > 1 ? ` (Part ${idx + 1}/${parts.length})` : '';
        await tgSendAudioFile({
          token,
          chatId,
          filePath,
          filename: part.filename,
          caption: `👤 ${job.userName} (${usernameHandle}) · ${generation.voiceNameBn}${partSuffix}`,
          title: `${job.userName} - ${generation.voiceNameBn}${partSuffix}`,
        }).catch(() => {});
      }
    }),
  );
}

/**
 * Dual delivery on AI Video completion:
 * 1) Channel: Sends ONLY the clean MP4 video with zero user personal data.
 * 2) Admin Inbox: Sends User Name/Username/ID + Details + the MP4 video.
 */
export async function notifyAdminsOnVideoCompleted(
  job: VideoProjectJob,
): Promise<void> {
  const cfg = botStore.getConfig();
  const token = cfg.telegramBotToken?.trim();
  if (!token || !job.outputFilename) return;

  const tpl = getVideoTemplate(job.templateId);
  const filePath = botStore.getVideoFilePath(job.outputFilename);
  const publicBase =
    process.env.APP_URL?.trim() || `http://localhost:${process.env.PORT || 3000}`;

  // 1. Post cleanly to Channel (ZERO personal user info)
  const channelTarget = normalizeTelegramChannelTarget(
    cfg.notificationChannelId ?? '',
  );
  if (channelTarget && !/t\.me\/\+/i.test(channelTarget)) {
    const cleanCaption =
      `🎬 ${job.title}\n` +
      `🎨 টেমপ্লেট: ${tpl.nameBn}\n` +
      `📐 ${job.aspectRatio} (${job.resolution.toUpperCase()}) · ⏱️ ${formatDurationShort(job.durationSec)}`;

    const sentVideo = await tgSendVideoFile({
      token,
      chatId: channelTarget,
      filePath,
      filename: job.outputFilename,
      caption: cleanCaption,
    }).catch(() => false);

    if (!sentVideo && job.outputVideoUrl) {
      await tgSendMessage(
        token,
        channelTarget,
        `${cleanCaption}\n📦 ডাউনলোড: ${publicBase}${job.outputVideoUrl}?download=1`,
      ).catch(() => {});
    }
  }

  // 2. Send User Username + Details + Video MP4 to Admin Inbox(es)
  const adminIds = botStore
    .listAdminTelegramIds()
    .map((id) => id.trim())
    .filter((id) => id.length > 0 && !id.startsWith('sim_'));

  if (adminIds.length === 0) return;

  const user = botStore.getUserById(job.userId);
  const usernameHandle = user?.username ? `@${user.username}` : 'নেই';
  const tgId = user?.telegramId ?? job.userId;
  const modeLabel =
    job.mode === 'prompt'
      ? 'Prompt → AI Video'
      : job.mode === 'script'
        ? 'Script → AI Video'
        : job.mode === 'voice'
          ? 'Voice → AI Video'
          : 'Smart Video Edit';

  const adminText =
    `🎬 নতুন AI ভিডিও জেনারেট হয়েছে!\n\n` +
    `👤 ইউজার: ${job.userName}\n` +
    `🔗 ইউজারনেম: ${usernameHandle} (ID: ${tgId})\n` +
    `🎞️ প্রজেক্ট: ${job.title}\n` +
    `⚙️ মোড: ${modeLabel} · ${job.aspectRatio} (${job.resolution.toUpperCase()})\n` +
    `🎨 টেমপ্লেট: ${tpl.nameBn}\n` +
    `⏱️ দৈর্ঘ্য: ${formatDurationShort(job.durationSec)} · সাইজ: ${formatBytesShort(job.fileSizeBytes)}\n` +
    `💰 চার্জ: ৳${job.costCharged} · ব্যালেন্স: ৳${(user?.balance ?? 0).toFixed(2)}\n` +
    `📍 সোর্স: ${formatSourceLabel(job.source)}`;

  await Promise.allSettled(
    adminIds.map(async (chatId) => {
      await tgSendMessage(token, chatId, adminText).catch(() => {});
      const sentVid = await tgSendVideoFile({
        token,
        chatId,
        filePath,
        filename: job.outputFilename!,
        caption: `👤 ${job.userName} (${usernameHandle}) · ${job.title}`,
      }).catch(() => false);
      if (!sentVid && job.outputVideoUrl) {
        await tgSendMessage(
          token,
          chatId,
          `📦 ভিডিও ফাইল (৫০MB+): ${publicBase}${job.outputVideoUrl}?download=1`,
        ).catch(() => {});
      }
    }),
  );
}
