import { Resvg } from '@resvg/resvg-js';
import { execFile } from 'node:child_process';
import fs from 'node:fs';
import { promisify } from 'node:util';
import sharp from 'sharp';
import { withGeminiRetry } from './aiAssistant.ts';
import { botStore } from './store.ts';
import type { BotUser } from './types.ts';

const execFileAsync = promisify(execFile);

const NOTO_FONT_FILES = [
  '/usr/share/fonts/truetype/noto/NotoSansBengali-Bold.ttf',
  '/usr/share/fonts/truetype/noto/NotoSansBengali-Regular.ttf',
  '/usr/share/fonts/truetype/noto/NotoSerifBengali-Bold.ttf',
  '/usr/share/fonts/truetype/noto/NotoSerifBengali-Regular.ttf',
].filter((p) => fs.existsSync(p));

export interface GeneratedImageResult {
  filename: string;
  filePath: string;
  url: string;
  width: number;
  height: number;
  fileSizeBytes: number;
  engineLabel: string;
  caption: string;
}

function dimensionsForRatio(aspectRatio: '1:1' | '16:9' | '9:16' | '4:3'): {
  width: number;
  height: number;
} {
  switch (aspectRatio) {
    case '16:9':
      return { width: 1280, height: 720 };
    case '9:16':
      return { width: 768, height: 1344 };
    case '4:3':
      return { width: 1152, height: 864 };
    case '1:1':
    default:
      return { width: 1024, height: 1024 };
  }
}

/**
 * Translates / refines a Bangla or English image prompt into rich descriptive
 * English prompt for open-source Flux Text-to-Image generation.
 */
async function refineImagePromptToEnglish(
  user: BotUser,
  rawPrompt: string,
): Promise<string> {
  if (!/[\u0980-\u09FF]/.test(rawPrompt) && rawPrompt.length >= 16) {
    return rawPrompt;
  }
  try {
    return await withGeminiRetry('image', user.id, async (ai, model) => {
      const res = await ai.models.generateContent({
        model,
        contents: `Translate and expand this image generation prompt into a vivid, concise English visual prompt (under 65 words, no quotes, no markdown):\n"${rawPrompt}"`,
      });
      return (res.text ?? rawPrompt).trim();
    });
  } catch {
    return rawPrompt;
  }
}

/**
 * Free Open-Source Text-to-Image Engine (Pollinations Flux).
 * Never fakes success: validates actual raster image bytes via Sharp.
 */
export async function generateAiImage(params: {
  user: BotUser;
  prompt: string;
  aspectRatio?: '1:1' | '16:9' | '9:16' | '4:3';
}): Promise<GeneratedImageResult> {
  const ratio = params.aspectRatio ?? '1:1';
  const { width, height } = dimensionsForRatio(ratio);
  const refinedPrompt = await refineImagePromptToEnglish(params.user, params.prompt);
  const seed = Math.floor(Math.random() * 999_999);

  const url =
    `https://image.pollinations.ai/prompt/${encodeURIComponent(refinedPrompt)}` +
    `?width=${width}&height=${height}&seed=${seed}&nologo=true&model=flux`;

  let imageBuf: Buffer | null = null;
  let lastError = 'Image engine unreachable';

  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      const resp = await fetch(url, {
        signal: AbortSignal.timeout(45_000),
        headers: {
          'User-Agent': 'BanglaVoiceAIStudio/1.0',
        },
      });
      if (!resp.ok) {
        lastError = `HTTP ${resp.status}`;
        continue;
      }
      const ctype = resp.headers.get('content-type') || '';
      const ab = await resp.arrayBuffer();
      const buf = Buffer.from(ab);
      if (!ctype.startsWith('image/') && buf.length < 2048) {
        lastError = 'Invalid non-image response from generator';
        continue;
      }
      // Verify it is a real decodable raster image
      const meta = await sharp(buf).metadata();
      if (!meta.width || !meta.height) {
        lastError = 'Corrupt image stream';
        continue;
      }
      imageBuf = await sharp(buf).png({ compressionLevel: 7 }).toBuffer();
      break;
    } catch (err) {
      lastError = err instanceof Error ? err.message : String(err);
      if (attempt === 0) await new Promise((r) => setTimeout(r, 1000));
    }
  }

  if (!imageBuf) {
    botStore.logError('image:t2i', lastError, params.user.id);
    throw new Error(
      `ফ্রি AI ইমেজ ইঞ্জিন থেকে ছবি তৈরি করা যায়নি (${lastError})। অনুগ্রহ করে একটু পর Retry করুন অথবা Graphic Design (Logo/Banner/Poster) মোড ব্যবহার করুন।`,
    );
  }

  const filename = `img-${Date.now()}-${Math.random().toString(36).slice(2, 6)}.png`;
  const filePath = botStore.getImageFilePath(filename);
  fs.writeFileSync(filePath, imageBuf);

  botStore.incrementFeatureUsage('image');
  botStore.updateUser(params.user.id, {
    lastActiveTask: {
      module: 'image',
      summary: `Image: ${params.prompt.slice(0, 55)}`,
      contextText: refinedPrompt,
      updatedAt: new Date().toISOString(),
    },
  });

  return {
    filename,
    filePath,
    url: `/api/images/${filename}`,
    width,
    height,
    fileSizeBytes: imageBuf.length,
    engineLabel: 'Open Flux AI Image Engine',
    caption: `🎨 ${params.prompt.slice(0, 120)} (${width}×${height})`,
  };
}

/**
 * Generates razor-sharp vector-to-PNG Logos, Banners, Posters & YouTube Thumbnails
 * via Gemini SVG Designer + Resvg (supports crisp Bangla Noto Sans Bengali + English!).
 */
export async function generateGraphicDesignPng(params: {
  user: BotUser;
  designKind: 'logo' | 'banner' | 'poster' | 'thumbnail';
  prompt: string;
}): Promise<GeneratedImageResult> {
  const dims =
    params.designKind === 'logo'
      ? { width: 1024, height: 1024 }
      : params.designKind === 'banner'
        ? { width: 1500, height: 500 }
        : params.designKind === 'poster'
          ? { width: 1080, height: 1350 }
          : { width: 1280, height: 720 };

  const svgCode = await withGeminiRetry('image:design', params.user.id, async (ai, model) => {
    const res = await ai.models.generateContent({
      model,
      contents:
        `Design Type: ${params.designKind.toUpperCase()} (${dims.width}x${dims.height})\n` +
        `Brief: "${params.prompt}"`,
      config: {
        systemInstruction:
          `You are an award-winning Brand & Graphic Designer. Output ONLY a complete, valid, self-contained <svg xmlns="http://www.w3.org/2000/svg" width="${dims.width}" height="${dims.height}" viewBox="0 0 ${dims.width} ${dims.height}">...</svg> document (no markdown fences, no commentary).\n` +
          `RULES:\n` +
          `1. Use rich gradients, bold modern geometry, clean vector emblems/icons, grid accents, and clear visual hierarchy.\n` +
          `2. Use font-family="Noto Sans Bengali, sans-serif" on all <text> elements so Bengali & English text render sharply.\n` +
          `3. Never use external image URLs or <foreignObject>. Use pure SVG shapes, paths, gradients, and text.\n` +
          `4. Ensure high contrast so text is effortlessly readable.`,
      },
    });
    const raw = (res.text ?? '').trim();
    const match = raw.match(/<svg[\s\S]*<\/svg>/i);
    if (!match?.[0]) {
      throw new Error('SVG গ্রাফিক ডিজাইন তৈরি করা যায়নি।');
    }
    return match[0];
  });

  const resvg = new Resvg(svgCode, {
    font: {
      fontFiles: NOTO_FONT_FILES,
      loadSystemFonts: true,
      defaultFontFamily: 'Noto Sans Bengali',
    },
  });
  const pngBytes = resvg.render().asPng();
  const finalBuf = await sharp(pngBytes)
    .resize(dims.width, dims.height, { fit: 'cover' })
    .png({ compressionLevel: 6 })
    .toBuffer();

  const filename = `design-${params.designKind}-${Date.now()}.png`;
  const filePath = botStore.getImageFilePath(filename);
  fs.writeFileSync(filePath, finalBuf);

  botStore.incrementFeatureUsage('image');

  return {
    filename,
    filePath,
    url: `/api/images/${filename}`,
    width: dims.width,
    height: dims.height,
    fileSizeBytes: finalBuf.length,
    engineLabel: 'AI SVG Studio + Resvg HD',
    caption: `🖌️ ${params.designKind.toUpperCase()} ডিজাইন সম্পন্ন (${dims.width}×${dims.height})`,
  };
}

/**
 * Reference-Guided Redesign: Uses Gemini Vision to extract composition/style/colors
 * from the uploaded reference image + user instructions, then generates a new image.
 */
export async function redesignFromReferenceImage(params: {
  user: BotUser;
  referenceImagePath: string;
  referenceMimeType: string;
  instruction: string;
  aspectRatio?: '1:1' | '16:9' | '9:16' | '4:3';
}): Promise<GeneratedImageResult> {
  const refBuf = fs.readFileSync(params.referenceImagePath);
  const combinedPrompt = await withGeminiRetry(
    'image:ref',
    params.user.id,
    async (ai, model) => {
      const res = await ai.models.generateContent({
        model,
        contents: {
          parts: [
            {
              inlineData: {
                mimeType: params.referenceMimeType || 'image/jpeg',
                data: refBuf.toString('base64'),
              },
            },
            {
              text:
                `Analyze this reference image's exact composition, subject, lighting, color palette, and artistic style, then combine it with the user's change request: "${params.instruction}". ` +
                `Return ONLY one crisp, detailed English image-generation prompt (under 75 words) describing the new redesigned artwork.`,
            },
          ],
        },
      });
      return (res.text ?? params.instruction).trim();
    },
  );

  return await generateAiImage({
    user: params.user,
    prompt: combinedPrompt,
    aspectRatio: params.aspectRatio ?? '1:1',
  });
}

/**
 * Real Photo Enhancement & Color Restoration via Sharp.
 */
export async function enhanceAndRestorePhoto(params: {
  user: BotUser;
  inputPath: string;
}): Promise<GeneratedImageResult> {
  const inputBuf = fs.readFileSync(params.inputPath);
  const outBuf = await sharp(inputBuf)
    .rotate()
    .median(3)
    .normalize()
    .modulate({ brightness: 1.04, saturation: 1.16 })
    .sharpen({ sigma: 1.2, m1: 1.0, m2: 2.0 })
    .png({ compressionLevel: 6 })
    .toBuffer();

  const meta = await sharp(outBuf).metadata();
  const filename = `enhanced-${Date.now()}.png`;
  const filePath = botStore.getImageFilePath(filename);
  fs.writeFileSync(filePath, outBuf);
  botStore.incrementFeatureUsage('image');

  return {
    filename,
    filePath,
    url: `/api/images/${filename}`,
    width: meta.width ?? 1024,
    height: meta.height ?? 1024,
    fileSizeBytes: outBuf.length,
    engineLabel: 'Sharp Studio Enhance & Restore',
    caption: `✨ ছবি Enhance & Restore সম্পন্ন (${meta.width}×${meta.height})`,
  };
}

/**
 * Real 2x HD Upscaling via Sharp Lanczos3 + Detail Sharpening.
 */
export async function upscalePhoto2x(params: {
  user: BotUser;
  inputPath: string;
}): Promise<GeneratedImageResult> {
  const meta = await sharp(params.inputPath).rotate().metadata();
  const srcW = meta.width ?? 800;
  const srcH = meta.height ?? 800;
  const targetW = Math.min(3840, srcW * 2);
  const targetH = Math.min(3840, srcH * 2);

  const outBuf = await sharp(params.inputPath)
    .rotate()
    .resize(targetW, targetH, {
      kernel: sharp.kernel.lanczos3,
      fit: 'inside',
    })
    .sharpen({ sigma: 1.4, m1: 1.2, m2: 2.4 })
    .png({ compressionLevel: 6 })
    .toBuffer();

  const outMeta = await sharp(outBuf).metadata();
  const filename = `upscaled-${Date.now()}.png`;
  const filePath = botStore.getImageFilePath(filename);
  fs.writeFileSync(filePath, outBuf);
  botStore.incrementFeatureUsage('image');

  return {
    filename,
    filePath,
    url: `/api/images/${filename}`,
    width: outMeta.width ?? targetW,
    height: outMeta.height ?? targetH,
    fileSizeBytes: outBuf.length,
    engineLabel: 'Sharp Lanczos3 2x HD Upscaler',
    caption: `📐 2x HD Upscale সম্পন্ন: ${srcW}×${srcH} → ${outMeta.width}×${outMeta.height}`,
  };
}

/**
 * Edge-based Studio Background Removal (transparent PNG) via ImageMagick.
 * Works best on clean/solid studio backgrounds; honestly advises user on complex scenes.
 */
export async function removeSolidBackgroundLocal(params: {
  user: BotUser;
  inputPath: string;
  replaceColor?: string;
}): Promise<GeneratedImageResult> {
  const filename = `nobg-${Date.now()}.png`;
  const outPath = botStore.getImageFilePath(filename);

  const args = [
    params.inputPath,
    '-alpha',
    'set',
    '-fuzz',
    '14%',
    '-fill',
    params.replaceColor || 'none',
    '-draw',
    'color 1,1 floodfill',
  ];
  args.push(outPath);

  await execFileAsync('convert', args);
  const outBuf = fs.readFileSync(outPath);
  const meta = await sharp(outBuf).metadata();
  botStore.incrementFeatureUsage('image');

  return {
    filename,
    filePath: outPath,
    url: `/api/images/${filename}`,
    width: meta.width ?? 1024,
    height: meta.height ?? 1024,
    fileSizeBytes: outBuf.length,
    engineLabel: 'ImageMagick Studio BG Tool',
    caption:
      '✂️ স্টুডিও ব্যাকগ্রাউন্ড রিমুভ/পরিবর্তন সম্পন্ন (সলিড ব্যাকগ্রাউন্ডের জন্য সবচেয়ে ভালো কাজ করে; জটিল Generative Object/BG Removal-এর জন্য Paid Image API প্রয়োজন)।',
  };
}
