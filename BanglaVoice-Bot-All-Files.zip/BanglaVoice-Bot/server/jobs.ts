import fs from 'node:fs';
import path from 'node:path';
import { notifyAdminsOnVoiceCompleted } from './adminNotify.ts';
import {
  mergeChunksToMp3WithFfmpeg,
  normalizeChunkWavWithFfmpeg,
} from './audio.ts';
import {
  formatUserFriendlyError,
  prepareBanglaScript,
  synthesizeRawBanglaChunkWav,
} from './gemini.ts';
import { botStore } from './store.ts';
import type {
  AudioPartOutput,
  BotUser,
  VoiceGeneration,
  VoiceJob,
} from './types.ts';
import { chunkBanglaScript, getVoiceById } from './voices.ts';

export type JobLifecycleListener = {
  onStatus?: (job: VoiceJob) => Promise<void> | void;
  onComplete?: (
    job: VoiceJob,
    generation: VoiceGeneration,
    parts: AudioPartOutput[],
  ) => Promise<void> | void;
  onFail?: (job: VoiceJob, errorMessage: string) => Promise<void> | void;
};

class VoiceJobQueue {
  private activeLocks = new Set<string>();
  private listeners = new Map<string, JobLifecycleListener>();

  registerListener(jobId: string, listener: JobLifecycleListener) {
    this.listeners.set(jobId, listener);
  }

  private async emitStatus(job: VoiceJob) {
    job.updatedAt = new Date().toISOString();
    botStore.upsertJob(job);
    const listener = this.listeners.get(job.id);
    if (listener?.onStatus) {
      await Promise.resolve(listener.onStatus(job)).catch(() => {});
    }
  }

  async enqueueVoiceJob(params: {
    user: BotUser;
    script: string;
    originalScript?: string;
    preConvertedBangla?: boolean;
    source: 'telegram' | 'simulator' | 'studio';
    voiceId?: string;
    speed?: number;
    pitch?: number;
    telegramChatId?: number;
    telegramStatusMessageId?: number;
    listener?: JobLifecycleListener;
  }): Promise<{ ok: boolean; error?: string; job?: VoiceJob }> {
    const { user, script, source } = params;
    const config = botStore.getConfig();
    const voice = getVoiceById(params.voiceId ?? user.selectedVoiceId);

    const eligibility = botStore.canUserGenerate(user, voice.id);
    if (!eligibility.ok) {
      return { ok: false, error: eligibility.reason };
    }

    const maxChars = botStore.getUserMaxChars(user);
    if (maxChars > 0 && script.trim().length > maxChars) {
      return {
        ok: false,
        error: `আপনার স্ক্রিপ্টটি ${script.trim().length} অক্ষরের, যা আপনার প্ল্যানের সর্বোচ্চ সীমা (${maxChars} অক্ষর) অতিক্রম করেছে।`,
      };
    }

    let finalSpokenScript = script.trim();
    const hasLatin = /[A-Za-z]/.test(finalSpokenScript);

    if (!params.preConvertedBangla || hasLatin) {
      const prep = await prepareBanglaScript(
        finalSpokenScript,
        config.strictBanglaOnly,
        params.preConvertedBangla ? false : config.autoNormalizeBangla,
        config.smartEnglishToBangla,
      );
      if (!prep.valid) {
        return { ok: false, error: prep.reason };
      }
      finalSpokenScript = prep.spokenScript;
    }

    const chunks = chunkBanglaScript(finalSpokenScript, 650);
    if (chunks.length === 0) {
      return {
        ok: false,
        error: 'অনুগ্রহ করে বাংলা ভাষায় একটি বৈধ স্ক্রিপ্ট পাঠান।',
      };
    }

    const speed = params.speed ?? user.speed;
    const pitch = params.pitch ?? user.pitch;
    const now = new Date().toISOString();
    const jobId = `job-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const estimatedTotalSec = Math.max(5, Math.round(chunks.length * 4.2 + 3));

    const job: VoiceJob = {
      id: jobId,
      userId: user.id,
      userName: user.firstName || user.username,
      telegramChatId: params.telegramChatId,
      telegramStatusMessageId: params.telegramStatusMessageId,
      voiceId: voice.id,
      voiceNameBn: `${voice.nameBn} (${voice.roleBn})`,
      category: voice.category,
      script: (params.originalScript ?? script).trim(),
      spokenScript: finalSpokenScript,
      chunks,
      completedChunkFiles: {},
      speed,
      pitch,
      ttsModel: config.ttsModel,
      status: 'queued',
      statusText: 'স্ক্রিপ্ট গ্রহণ করা হয়েছে (প্রসেসিং শুরু হচ্ছে...)',
      progressPct: 5,
      currentPart: 0,
      totalParts: chunks.length,
      startedAt: now,
      estimatedTotalSec,
      estimatedRemainingSec: estimatedTotalSec,
      elapsedSec: 0,
      retryCount: 0,
      source,
      createdAt: now,
      updatedAt: now,
    };

    botStore.upsertJob(job);
    if (params.listener) {
      this.listeners.set(jobId, params.listener);
    }

    // Run asynchronously in background worker loop
    void this.executeJob(jobId);

    return { ok: true, job };
  }

  async executeJob(jobId: string): Promise<void> {
    if (this.activeLocks.has(jobId)) {
      return; // Prevent duplicate execution of the same job
    }
    const existing = botStore.getJobById(jobId);
    if (!existing || existing.status === 'completed') {
      return;
    }

    this.activeLocks.add(jobId);
    const lockToken = `exec-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    existing.executionLockId = lockToken;
    const startMs = existing.startedAt
      ? Date.parse(existing.startedAt) || Date.now()
      : Date.now();
    existing.startedAt = new Date(startMs).toISOString();
    const baselineTotal =
      existing.estimatedTotalSec ||
      Math.max(5, Math.round(existing.chunks.length * 4.2 + 3));
    existing.estimatedTotalSec = baselineTotal;

    let stageCapPct = 18;
    const syncTimingAndEta = (explicitPct?: number) => {
      const elapsed = Math.max(0, Math.round((Date.now() - startMs) / 1000));
      existing.elapsedSec = elapsed;
      const curPct = existing.progressPct ?? 5;
      if (typeof explicitPct === 'number') {
        existing.progressPct = Math.min(100, Math.max(curPct, explicitPct));
      } else if (curPct < stageCapPct) {
        existing.progressPct = Math.min(stageCapPct, curPct + 2);
      }

      const pct = existing.progressPct ?? 5;
      if (pct >= 100) {
        existing.estimatedRemainingSec = 0;
        existing.estimatedTotalSec = elapsed;
      } else {
        const baselineRem = Math.max(2, baselineTotal - elapsed);
        if (pct >= 16 && elapsed >= 2) {
          const throughputRem = Math.round((elapsed * (100 - pct)) / pct);
          existing.estimatedRemainingSec = Math.max(
            1,
            Math.round(throughputRem * 0.6 + baselineRem * 0.4),
          );
        } else {
          existing.estimatedRemainingSec = baselineRem;
        }
        existing.estimatedTotalSec = elapsed + existing.estimatedRemainingSec;
      }
    };

    const heartbeat = setInterval(() => {
      if (existing.status === 'completed' || existing.status === 'failed') return;
      syncTimingAndEta();
      void this.emitStatus(existing);
    }, 1000);

    try {
      const voice = getVoiceById(existing.voiceId);
      const workDir = botStore.getJobWorkDir(existing.id);

      existing.status = 'processing';
      existing.statusText = 'অটো-প্রসেসিং শুরু হয়েছে...';
      stageCapPct = 19;
      syncTimingAndEta(10);
      await this.emitStatus(existing);

      existing.statusText = 'বাংলা AI ভয়েস জেনারেট হচ্ছে...';
      syncTimingAndEta(14);
      await this.emitStatus(existing);

      for (let i = 0; i < existing.chunks.length; i++) {
        const chunkPath = path.join(
          workDir,
          `chunk_${String(i).padStart(4, '0')}.wav`,
        );

        const partFloor = Math.round(14 + (i / Math.max(1, existing.totalParts)) * 68);
        const partCeil = Math.round(14 + ((i + 1) / Math.max(1, existing.totalParts)) * 68);
        stageCapPct = Math.max(partFloor + 2, partCeil - 2);

        // Resume support: skip chunks already verified on disk
        if (
          existing.completedChunkFiles[i] &&
          fs.existsSync(chunkPath) &&
          fs.statSync(chunkPath).size > 128
        ) {
          existing.currentPart = i + 1;
          syncTimingAndEta(partCeil);
          continue;
        }

        existing.currentPart = i + 1;
        existing.statusText = `ভয়েস পার্ট তৈরি হচ্ছে (${i + 1}/${existing.totalParts})`;
        syncTimingAndEta(partFloor + 2);
        await this.emitStatus(existing);

        let lastError: unknown = null;
        let success = false;
        const maxAttempts = 3;

        for (let attempt = 1; attempt <= maxAttempts; attempt++) {
          try {
            const rawWav = await synthesizeRawBanglaChunkWav({
              textChunk: existing.chunks[i],
              voice,
              speed: existing.speed,
              pitch: existing.pitch,
              ttsModel: existing.ttsModel,
              partIndex: i,
              totalParts: existing.totalParts,
            });

            await normalizeChunkWavWithFfmpeg({
              rawWavBuffer: rawWav,
              outputWavPath: chunkPath,
              speed: existing.speed,
              pitchSemitones: existing.pitch,
            });

            if (!fs.existsSync(chunkPath) || fs.statSync(chunkPath).size < 128) {
              throw new Error(`Chunk ${i + 1} output audio is empty.`);
            }

            existing.completedChunkFiles[i] = chunkPath;
            syncTimingAndEta(partCeil);
            botStore.upsertJob(existing);
            success = true;
            break;
          } catch (err) {
            lastError = err;
            existing.retryCount += 1;
            botStore.upsertJob(existing);
            if (attempt < maxAttempts) {
              await new Promise((r) => setTimeout(r, 1500 * attempt));
            }
          }
        }

        if (!success) {
          throw lastError instanceof Error
            ? lastError
            : new Error(`Part ${i + 1} synthesis failed after retries.`);
        }
      }

      // Integrity check: ensure NO chunk is missing before joining
      const orderedPaths: string[] = [];
      for (let i = 0; i < existing.chunks.length; i++) {
        const p = existing.completedChunkFiles[i];
        if (!p || !fs.existsSync(p) || fs.statSync(p).size < 128) {
          throw new Error(
            `অডিও অংশ ${i + 1}/${existing.totalParts} অসম্পূর্ণ থাকায় ফাইল তৈরি স্থগিত করা হয়েছে।`,
          );
        }
        orderedPaths.push(p);
      }

      existing.status = 'joining';
      existing.statusText = 'সব অডিও অংশ একত্রিত করা হচ্ছে...';
      stageCapPct = 90;
      syncTimingAndEta(86);
      await this.emitStatus(existing);

      existing.status = 'rendering';
      existing.statusText = 'ফাইনাল HD MP3 রেন্ডারিং চলছে...';
      stageCapPct = 97;
      syncTimingAndEta(93);
      await this.emitStatus(existing);

      const genId = `gen-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
      const renderedParts = await mergeChunksToMp3WithFfmpeg({
        chunkWavPaths: orderedPaths,
        outputDir: botStore.getAudioDir(),
        baseFilename: genId,
      });

      const outputParts: AudioPartOutput[] = renderedParts.map((part) => ({
        url: `/api/audio/${part.filename}`,
        filename: part.filename,
        durationSec: part.durationSec,
        fileSizeBytes: part.fileSizeBytes,
      }));

      const totalDuration =
        Math.round(
          outputParts.reduce((sum, p) => sum + p.durationSec, 0) * 10,
        ) / 10;
      const totalBytes = outputParts.reduce(
        (sum, p) => sum + p.fileSizeBytes,
        0,
      );

      const voiceCost = botStore.getVoiceEffectiveCost(existing.voiceId);
      const generation: VoiceGeneration = {
        id: genId,
        jobId: existing.id,
        userId: existing.userId,
        userName: existing.userName,
        voiceId: existing.voiceId,
        voiceNameBn: existing.voiceNameBn,
        category: existing.category,
        script: existing.script,
        spokenScript: existing.spokenScript,
        speed: existing.speed,
        pitch: existing.pitch,
        durationSec: totalDuration,
        fileSizeBytes: totalBytes,
        audioUrl: outputParts[0].url,
        audioParts: outputParts,
        totalChunks: existing.totalParts,
        costCharged: voiceCost,
        source: existing.source,
        createdAt: new Date().toISOString(),
      };

      botStore.recordGeneration(generation);

      clearInterval(heartbeat);
      existing.status = 'completed';
      existing.statusText = 'ভয়েস তৈরি সম্পূর্ণ হয়েছে!';
      existing.generationId = generation.id;
      existing.outputParts = outputParts;
      syncTimingAndEta(100);
      await this.emitStatus(existing);

      const listener = this.listeners.get(existing.id);
      if (listener?.onComplete) {
        await Promise.resolve(
          listener.onComplete(existing, generation, outputParts),
        ).catch(() => {});
      }

      void notifyAdminsOnVoiceCompleted(existing, generation).catch(() => {});

      // Cleanup temporary chunk WAV workdir once merged MP3 is finalized
      fs.rmSync(workDir, { recursive: true, force: true });
    } catch (err) {
      clearInterval(heartbeat);
      const errorMsg = formatUserFriendlyError(err);
      existing.status = 'failed';
      existing.statusText = 'ভয়েস তৈরি ব্যর্থ হয়েছে';
      existing.error = errorMsg;
      existing.estimatedRemainingSec = 0;
      existing.elapsedSec = Math.max(0, Math.round((Date.now() - startMs) / 1000));
      await this.emitStatus(existing);

      const listener = this.listeners.get(existing.id);
      if (listener?.onFail) {
        await Promise.resolve(listener.onFail(existing, errorMsg)).catch(
          () => {},
        );
      }
    } finally {
      clearInterval(heartbeat);
      this.activeLocks.delete(jobId);
      this.listeners.delete(jobId);
    }
  }

  /**
   * Resumes any interrupted background jobs after a server restart.
   */
  resumePendingJobs(
    attachListener?: (job: VoiceJob) => JobLifecycleListener | undefined,
  ) {
    const incomplete = botStore.listIncompleteJobs();
    for (const job of incomplete) {
      const listener = attachListener?.(job);
      if (listener) {
        this.listeners.set(job.id, listener);
      }
      void this.executeJob(job.id);
    }
  }
}

export const voiceJobQueue = new VoiceJobQueue();
