import fs from 'node:fs';
import path from 'node:path';
import type {
  AssistantModuleId,
  BotConfig,
  BotUser,
  ChatTurnRecord,
  DailyStat,
  ErrorLogEntry,
  IncomingPaymentSms,
  PaymentRequest,
  TransactionRecord,
  UserRole,
  UserSavedPreset,
  UserStatus,
  UserTier,
  VideoProjectJob,
  VoiceCategory,
  VoiceGeneration,
  VoiceJob,
} from './types.ts';
import { VOICE_CATALOG } from './voices.ts';

const DATA_DIR = path.resolve(process.cwd(), 'data');
const AUDIO_DIR = path.join(DATA_DIR, 'audio');
const JOBS_DIR = path.join(DATA_DIR, 'jobs');
const VIDEOS_DIR = path.join(DATA_DIR, 'videos');
const UPLOADS_DIR = path.join(DATA_DIR, 'uploads');
const IMAGES_DIR = path.join(DATA_DIR, 'images');
const DOCS_DIR = path.join(DATA_DIR, 'docs');
const STORE_PATH = path.join(DATA_DIR, 'bot-store.json');

interface PersistedStore {
  users: BotUser[];
  generations: VoiceGeneration[];
  dailyStats: Record<string, DailyStat>;
  paymentRequests: PaymentRequest[];
  incomingPaymentSms: IncomingPaymentSms[];
  transactions: TransactionRecord[];
  jobs: VoiceJob[];
  videoJobs: VideoProjectJob[];
  errorLogs?: ErrorLogEntry[];
  featureUsage?: Record<AssistantModuleId, number>;
  config: BotConfig;
}

const DEFAULT_ENABLED_FEATURES: Record<AssistantModuleId, boolean> = {
  chat: true,
  image: true,
  video: true,
  voice: true,
  documents: true,
  coding: true,
  research: true,
  memory: true,
};

const DEFAULT_FEATURE_USAGE: Record<AssistantModuleId, number> = {
  chat: 0,
  image: 0,
  video: 0,
  voice: 0,
  documents: 0,
  coding: 0,
  research: 0,
  memory: 0,
};

function generateWebhookSecret(): string {
  return `BV-SMS-${Math.random().toString(36).slice(2, 8).toUpperCase()}${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
}

export function extractTrxId(input: string): string | null {
  const cleaned = input.trim();
  if (!cleaned) return null;

  // 1. Explicit label match: TrxID 9X82AB12, TxnId: 1234567890, Transaction ID: ...
  const labeled = cleaned.match(
    /(?:trx\s*id|txn\s*id|transaction\s*id|tid|trx|ref(?:erence)?)\s*[:#-]?\s*([A-Za-z0-9]{6,20})/i,
  );
  if (labeled?.[1]) {
    const candidate = labeled[1].toUpperCase();
    // Skip if it's purely a BD mobile number
    if (!/^(?:88)?01[3-9]\d{8}$/.test(candidate)) {
      return candidate;
    }
  }

  // 2. Strip BD phone numbers before looking for bare alphanumeric TrxID
  const withoutPhones = cleaned.replace(/(?:\+?88)?01[3-9]\d{8}/g, ' ');
  const tokens = withoutPhones.match(/\b[A-Za-z0-9]{6,20}\b/g) ?? [];
  // Prefer token containing BOTH letters and digits (standard bKash/Nagad format)
  const mixedToken = tokens.find(
    (t) => /[A-Za-z]/.test(t) && /\d/.test(t),
  );
  if (mixedToken) {
    return mixedToken.toUpperCase();
  }

  // 3. Fallback if user only sent a standalone code/number >= 7 chars (e.g. Rocket TxnId)
  const longDigitToken = tokens.find((t) => /^\d{7,16}$/.test(t));
  if (longDigitToken) {
    return longDigitToken.toUpperCase();
  }

  return null;
}

export function parsePaymentSms(params: {
  rawText: string;
  method?: string;
  amount?: number;
  trxId?: string;
  sender?: string;
}): {
  method: string;
  amount: number;
  trxId: string;
  sender?: string;
} {
  const raw = params.rawText.trim();
  const lower = raw.toLowerCase();

  let method = params.method?.trim() || '';
  if (!method) {
    if (/bkash|বিকাশ/.test(lower)) method = 'bKash';
    else if (/nagad|নগদ/.test(lower)) method = 'Nagad';
    else if (/rocket|dbbl|রকেট/.test(lower)) method = 'Rocket';
    else if (/upay|উপায়/.test(lower)) method = 'Upay';
    else method = 'Mobile Banking';
  }

  let amount =
    typeof params.amount === 'number' && !Number.isNaN(params.amount) && params.amount > 0
      ? params.amount
      : 0;
  if (!amount) {
    const amtMatch =
      raw.match(/(?:tk|bdt|amount|টাকা)\s*[:.]?\s*([\d,]+(?:\.\d{1,2})?)/i) ??
      raw.match(/([\d,]+(?:\.\d{1,2})?)\s*(?:tk|bdt|টাকা)/i);
    if (amtMatch?.[1]) {
      amount = Number.parseFloat(amtMatch[1].replace(/,/g, ''));
    }
  }

  const trxId = (
    params.trxId?.trim().toUpperCase() ||
    extractTrxId(raw) ||
    ''
  ).replace(/[^A-Z0-9]/g, '');

  let sender = params.sender?.trim() || undefined;
  if (!sender) {
    const phoneMatch = raw.match(/(?:\+?88)?(01[3-9]\d{8})/);
    if (phoneMatch?.[1]) {
      sender = phoneMatch[1];
    }
  }

  return { method, amount, trxId, sender };
}

function getTodayKey(): string {
  return new Date().toISOString().slice(0, 10);
}

function defaultConfig(): BotConfig {
  const envToken = process.env.TELEGRAM_BOT_TOKEN?.trim() ?? '';
  const envChannel = process.env.TELEGRAM_NOTIFICATION_CHANNEL?.trim() ?? '';
  const envAdmins = (process.env.TELEGRAM_ADMIN_IDS ?? '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
  const adminTelegramIds = Array.from(new Set(['7867755382', ...envAdmins]));
  return {
    telegramBotToken: envToken,
    telegramBotUsername: '',
    telegramMode: envToken ? 'polling' : 'stopped',
    notificationChannelId: envChannel,
    adminTelegramIds,
    adminClaimCode: 'ADMIN2026',
    freeDailyLimit: 10,
    premiumDailyLimit: 200,
    maxScriptCharsFree: 0, // 0 = Unlimited (no fixed duration/character cap)
    maxScriptCharsPremium: 0, // 0 = Unlimited
    voiceGenerationCost: 0, // 0 = Free default; admin can enable global or per-voice cost anytime
    voiceCosts: {}, // Per-voice custom BDT charge overrides (voiceId -> BDT)
    videoGenerationCost: 0, // 0 = Free default; admin can set video generation cost
    pexelsApiKey: process.env.PEXELS_API_KEY?.trim() ?? '',
    visualProviderMode: 'auto',
    paymentAccounts: [], // Admin-configured payment methods & account numbers
    paymentInstructions:
      '১. উপরের যেকোনো একটি সক্রিয় নম্বর কপি করে আপনার bKash / Nagad / Rocket অ্যাপ থেকে Send Money করুন (Agent নম্বর হলে Cash Out করুন)।\n' +
      '২. টাকা পাঠানো সফল হলে মেসেজ বা অ্যাপ থেকে Transaction ID (TrxID) সংগ্রহ করুন।\n' +
      '৩. নিচের ঘরে কত টাকা পাঠিয়েছেন এবং আপনার সেন্ডার নম্বর বা TrxID লিখুন।\n' +
      '৪. সব তথ্য রিভিউ ও কনফার্ম করলে অ্যাডমিন যাচাই করে আপনার ব্যালেন্স যুক্ত করে দেবেন।',
    autoVerifyPayments: true,
    smsWebhookSecret: generateWebhookSecret(),
    premiumMembershipDays: 30,
    smartEnglishToBangla: true,
    strictBanglaOnly: false,
    ttsModel: 'gemini-3.8-flash-lite-tts',
    autoNormalizeBangla: true,
    referralBonusBdt: 20,
    enabledFeatures: { ...DEFAULT_ENABLED_FEATURES },
    defaultChatModel: 'gemini-4-hydrogen',
  };
}

function createInitialStore(): PersistedStore {
  const now = new Date().toISOString();
  const today = getTodayKey();
  return {
    users: [
      {
        id: 'sim-user-1',
        telegramId: 'sim_1001',
        username: 'banglavoice_tester',
        firstName: 'স্টুডিও টেস্টার',
        role: 'admin',
        tier: 'free',
        premiumExpiresAt: null,
        status: 'active',
        balance: 0,
        dailyCount: 0,
        totalCount: 0,
        lastResetDate: today,
        selectedCategory: 'female',
        selectedVoiceId: 'female-nusrat',
        speed: 1.0,
        pitch: 0,
        step: 'idle',
        customDailyLimit: null,
        customCharLimit: null,
        joinedAt: now,
        lastActiveAt: now,
      },
    ],
    generations: [],
    dailyStats: {
      [today]: {
        date: today,
        generations: 0,
        characters: 0,
        activeUserIds: [],
      },
    },
    paymentRequests: [],
    incomingPaymentSms: [],
    transactions: [],
    jobs: [],
      videoJobs: [],
    errorLogs: [],
    featureUsage: { ...DEFAULT_FEATURE_USAGE },
    config: defaultConfig(),
  };
}

function ensureDirectories() {
  for (const dir of [
    DATA_DIR,
    AUDIO_DIR,
    JOBS_DIR,
    VIDEOS_DIR,
    UPLOADS_DIR,
    IMAGES_DIR,
    DOCS_DIR,
  ]) {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  }
}

class BotStore {
  private data: PersistedStore;

  constructor() {
    ensureDirectories();
    if (fs.existsSync(STORE_PATH)) {
      try {
        const raw = fs.readFileSync(STORE_PATH, 'utf-8');
        const parsed = JSON.parse(raw) as Partial<PersistedStore>;
        const initial = createInitialStore();
        const mergedConfig: BotConfig = {
          ...initial.config,
          ...(parsed.config ?? {}),
        };
        // Remove legacy 600/3000 fixed restriction if still set at initial defaults
        if (mergedConfig.maxScriptCharsFree === 600) {
          mergedConfig.maxScriptCharsFree = 0;
        }
        if (mergedConfig.maxScriptCharsPremium === 3000) {
          mergedConfig.maxScriptCharsPremium = 0;
        }
        // Enable Smart English -> Bangla Conversion when migrating from older config
        if (parsed.config && parsed.config.smartEnglishToBangla === undefined) {
          mergedConfig.smartEnglishToBangla = true;
          mergedConfig.strictBanglaOnly = false;
        }
        mergedConfig.voiceCosts =
          mergedConfig.voiceCosts && typeof mergedConfig.voiceCosts === 'object'
            ? mergedConfig.voiceCosts
            : {};
        mergedConfig.paymentAccounts = Array.isArray(mergedConfig.paymentAccounts)
          ? mergedConfig.paymentAccounts
          : [];
        if (typeof mergedConfig.paymentInstructions !== 'string') {
          mergedConfig.paymentInstructions = initial.config.paymentInstructions;
        }
        if (typeof mergedConfig.autoVerifyPayments !== 'boolean') {
          mergedConfig.autoVerifyPayments = true;
        }
        if (!mergedConfig.smsWebhookSecret) {
          mergedConfig.smsWebhookSecret = generateWebhookSecret();
        }

        if (typeof mergedConfig.videoGenerationCost !== 'number') {
          mergedConfig.videoGenerationCost = 0;
        }
        if (typeof mergedConfig.pexelsApiKey !== 'string') {
          mergedConfig.pexelsApiKey = process.env.PEXELS_API_KEY?.trim() ?? '';
        }
        if (!mergedConfig.visualProviderMode) {
          mergedConfig.visualProviderMode = 'auto';
        }
        if (typeof mergedConfig.notificationChannelId !== 'string') {
          mergedConfig.notificationChannelId = '';
        }
        if (typeof mergedConfig.referralBonusBdt !== 'number') {
          mergedConfig.referralBonusBdt = 20;
        }
        mergedConfig.enabledFeatures = {
          ...DEFAULT_ENABLED_FEATURES,
          ...(mergedConfig.enabledFeatures ?? {}),
        };
        if (!mergedConfig.defaultChatModel) {
          mergedConfig.defaultChatModel = 'gemini-4-hydrogen';
        }

        const migratedUsers = (parsed.users ?? initial.users).map((u) => ({
          ...u,
          role: u.role ?? (u.id === 'sim-user-1' ? 'admin' : 'user'),
          premiumExpiresAt: u.premiumExpiresAt ?? null,
          balance: typeof u.balance === 'number' ? u.balance : 0,
          customCharLimit: u.customCharLimit ?? null,
        }));

        this.data = {
          users: migratedUsers,
          generations: (parsed.generations ?? []).map((g) => ({
            ...g,
            costCharged: g.costCharged ?? 0,
          })),
          dailyStats: parsed.dailyStats ?? initial.dailyStats,
          paymentRequests: parsed.paymentRequests ?? [],
          incomingPaymentSms: parsed.incomingPaymentSms ?? [],
          transactions: parsed.transactions ?? [],
          jobs: parsed.jobs ?? [],
          videoJobs: parsed.videoJobs ?? [],
          errorLogs: parsed.errorLogs ?? [],
          featureUsage: {
            ...DEFAULT_FEATURE_USAGE,
            ...(parsed.featureUsage ?? {}),
          },
          config: mergedConfig,
        };

        if (
          process.env.TELEGRAM_BOT_TOKEN &&
          !this.data.config.telegramBotToken
        ) {
          this.data.config.telegramBotToken =
            process.env.TELEGRAM_BOT_TOKEN.trim();
        }
        if (
          process.env.TELEGRAM_NOTIFICATION_CHANNEL &&
          !this.data.config.notificationChannelId
        ) {
          this.data.config.notificationChannelId =
            process.env.TELEGRAM_NOTIFICATION_CHANNEL.trim();
        }
        if (process.env.TELEGRAM_ADMIN_IDS) {
          const extraAdmins = process.env.TELEGRAM_ADMIN_IDS.split(',')
            .map((s) => s.trim())
            .filter(Boolean);
          this.data.config.adminTelegramIds = Array.from(
            new Set([...this.data.config.adminTelegramIds, ...extraAdmins]),
          );
        }
        this.save();
      } catch {
        this.data = createInitialStore();
        this.save();
      }
    } else {
      this.data = createInitialStore();
      this.save();
    }
  }

  private save() {
    ensureDirectories();
    const tmpPath = `${STORE_PATH}.tmp`;
    fs.writeFileSync(tmpPath, JSON.stringify(this.data, null, 2), 'utf-8');
    fs.renameSync(tmpPath, STORE_PATH);
  }

  getAudioDir(): string {
    ensureDirectories();
    return AUDIO_DIR;
  }

  getJobWorkDir(jobId: string): string {
    const dir = path.join(JOBS_DIR, path.basename(jobId));
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    return dir;
  }

  getAudioFilePath(filename: string): string {
    const safeName = path.basename(filename);
    return path.join(AUDIO_DIR, safeName);
  }

  getVideosDir(): string {
    ensureDirectories();
    return VIDEOS_DIR;
  }

  getVideoFilePath(filename: string): string {
    const safeName = path.basename(filename);
    return path.join(VIDEOS_DIR, safeName);
  }

  getUploadsDir(): string {
    ensureDirectories();
    return UPLOADS_DIR;
  }

  getUploadFilePath(filename: string): string {
    const safeName = path.basename(filename);
    return path.join(UPLOADS_DIR, safeName);
  }

  getImagesDir(): string {
    ensureDirectories();
    return IMAGES_DIR;
  }

  getImageFilePath(filename: string): string {
    ensureDirectories();
    return path.join(IMAGES_DIR, path.basename(filename));
  }

  getDocsDir(): string {
    ensureDirectories();
    return DOCS_DIR;
  }

  getDocFilePath(filename: string): string {
    ensureDirectories();
    return path.join(DOCS_DIR, path.basename(filename));
  }

  getVideoWorkDir(jobId: string): string {
    const dir = path.join(JOBS_DIR, `vid_${path.basename(jobId)}`);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    return dir;
  }

  saveAudioFile(id: string, mp3Buffer: Buffer): string {
    ensureDirectories();
    const filename = `${id}.mp3`;
    fs.writeFileSync(path.join(AUDIO_DIR, filename), mp3Buffer);
    return `/api/audio/${filename}`;
  }

  getConfig(): BotConfig {
    return { ...this.data.config };
  }

  getPublicConfig(): Omit<
    BotConfig,
    'telegramBotToken' | 'adminClaimCode' | 'pexelsApiKey' | 'elevenLabsApiKey'
  > & {
    hasTelegramToken: boolean;
    telegramBotTokenMasked: string;
    hasPexelsKey: boolean;
    pexelsApiKeyMasked: string;
    adminClaimCode: string;
  } {
    const token = this.data.config.telegramBotToken;
    const masked =
      token.length > 10
        ? `${token.slice(0, 6)}...${token.slice(-4)}`
        : token
          ? '••••••••'
          : '';
    const pexelsKey = this.data.config.pexelsApiKey ?? '';
    const pexelsMasked =
      pexelsKey.length > 8
        ? `${pexelsKey.slice(0, 4)}...${pexelsKey.slice(-4)}`
        : pexelsKey
          ? '••••••••'
          : '';
    return {
      telegramBotUsername: this.data.config.telegramBotUsername,
      telegramMode: this.data.config.telegramMode,
      notificationChannelId: this.data.config.notificationChannelId ?? '',
      adminTelegramIds: [...this.data.config.adminTelegramIds],
      adminClaimCode: this.data.config.adminClaimCode,
      freeDailyLimit: this.data.config.freeDailyLimit,
      premiumDailyLimit: this.data.config.premiumDailyLimit,
      maxScriptCharsFree: this.data.config.maxScriptCharsFree,
      maxScriptCharsPremium: this.data.config.maxScriptCharsPremium,
      voiceGenerationCost: this.data.config.voiceGenerationCost,
      voiceCosts: { ...(this.data.config.voiceCosts ?? {}) },
      videoGenerationCost: this.data.config.videoGenerationCost ?? 0,
      visualProviderMode: this.data.config.visualProviderMode ?? 'auto',
      hasPexelsKey: Boolean(pexelsKey),
      pexelsApiKeyMasked: pexelsMasked,
      paymentAccounts: [...(this.data.config.paymentAccounts ?? [])],
      paymentInstructions: this.data.config.paymentInstructions ?? '',
      autoVerifyPayments: this.data.config.autoVerifyPayments ?? true,
      smsWebhookSecret: this.data.config.smsWebhookSecret ?? '',
      premiumMembershipDays: this.data.config.premiumMembershipDays,
      smartEnglishToBangla: this.data.config.smartEnglishToBangla,
      strictBanglaOnly: this.data.config.strictBanglaOnly,
      ttsModel: this.data.config.ttsModel,
      autoNormalizeBangla: this.data.config.autoNormalizeBangla,
      referralBonusBdt: this.data.config.referralBonusBdt ?? 20,
      enabledFeatures: {
        ...DEFAULT_ENABLED_FEATURES,
        ...(this.data.config.enabledFeatures ?? {}),
      },
      defaultChatModel: this.data.config.defaultChatModel ?? 'gemini-4-hydrogen',
      hasTelegramToken: Boolean(token),
      telegramBotTokenMasked: masked,
    };
  }

  updateConfig(patch: Partial<BotConfig>): BotConfig {
    this.data.config = { ...this.data.config, ...patch };
    this.save();
    return this.getConfig();
  }

  private resetDailyAndMembershipIfNeeded(user: BotUser) {
    const today = getTodayKey();
    if (user.lastResetDate !== today) {
      user.dailyCount = 0;
      user.lastResetDate = today;
    }
    if (
      user.tier === 'premium' &&
      user.premiumExpiresAt &&
      Date.now() > Date.parse(user.premiumExpiresAt)
    ) {
      user.tier = 'free';
      user.premiumExpiresAt = null;
    }
  }

  isAdmin(user: BotUser): boolean {
    if (user.role === 'admin') return true;
    return this.data.config.adminTelegramIds.includes(user.telegramId);
  }

  authorizeTelegramAdmin(userId: string): BotUser | null {
    const user = this.data.users.find((u) => u.id === userId);
    if (!user) return null;
    user.role = 'admin';
    if (!this.data.config.adminTelegramIds.includes(user.telegramId)) {
      this.data.config.adminTelegramIds.push(user.telegramId);
    }
    this.save();
    return { ...user };
  }

  revokeTelegramAdmin(userId: string): BotUser | null {
    const user = this.data.users.find((u) => u.id === userId);
    if (!user) return null;
    user.role = 'user';
    this.data.config.adminTelegramIds =
      this.data.config.adminTelegramIds.filter((id) => id !== user.telegramId);
    this.save();
    return { ...user };
  }

  getOrCreateUser(params: {
    telegramId: string;
    username?: string;
    firstName?: string;
  }): BotUser {
    let user = this.data.users.find((u) => u.telegramId === params.telegramId);
    const now = new Date().toISOString();
    const today = getTodayKey();

    if (!user) {
      const isConfiguredAdmin = this.data.config.adminTelegramIds.includes(
        params.telegramId,
      );
      user = {
        id: `usr-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        telegramId: params.telegramId,
        username: params.username ?? `user_${params.telegramId}`,
        firstName: params.firstName ?? 'ব্যবহারকারী',
        role: isConfiguredAdmin ? 'admin' : 'user',
        tier: 'free',
        premiumExpiresAt: null,
        status: 'active',
        balance: 0,
        dailyCount: 0,
        totalCount: 0,
        lastResetDate: today,
        selectedCategory: 'female',
        selectedVoiceId: VOICE_CATALOG.find((v) => v.category === 'female')!.id,
        speed: 1.0,
        pitch: 0,
        step: 'idle',
        customDailyLimit: null,
        customCharLimit: null,
        joinedAt: now,
        lastActiveAt: now,
      };
      this.data.users.unshift(user);
      this.save();
    } else {
      this.resetDailyAndMembershipIfNeeded(user);
      if (params.username) user.username = params.username;
      if (params.firstName) user.firstName = params.firstName;
      user.lastActiveAt = now;
      this.save();
    }

    return user;
  }

  getUserById(id: string): BotUser | undefined {
    const user = this.data.users.find((u) => u.id === id);
    if (user) {
      this.resetDailyAndMembershipIfNeeded(user);
    }
    return user;
  }

  findUserByTelegramIdOrUsername(query: string): BotUser | undefined {
    const clean = query.trim().replace(/^@/, '').toLowerCase();
    const user = this.data.users.find(
      (u) =>
        u.telegramId.toLowerCase() === clean ||
        u.username.toLowerCase() === clean ||
        u.id.toLowerCase() === clean,
    );
    if (user) {
      this.resetDailyAndMembershipIfNeeded(user);
    }
    return user;
  }

  listUsers(): BotUser[] {
    for (const user of this.data.users) {
      this.resetDailyAndMembershipIfNeeded(user);
    }
    return [...this.data.users];
  }

  listAdminTelegramIds(): string[] {
    const set = new Set<string>(this.data.config.adminTelegramIds);
    for (const u of this.data.users) {
      if (u.role === 'admin' && !u.telegramId.startsWith('sim_')) {
        set.add(u.telegramId);
      }
    }
    return Array.from(set);
  }

  updateUser(
    id: string,
    patch: Partial<{
      role: UserRole;
      tier: UserTier;
      premiumExpiresAt: string | null;
      status: UserStatus;
      balance: number;
      selectedCategory: VoiceCategory;
      selectedVoiceId: string;
      speed: number;
      pitch: number;
      step: BotUser['step'];
      language: BotUser['language'];
      pendingContext: BotUser['pendingContext'];
      savedPreset: UserSavedPreset;
      chatHistory: ChatTurnRecord[];
      memories: BotUser['memories'];
      lastUpload: BotUser['lastUpload'];
      lastActiveTask: BotUser['lastActiveTask'];
      referredBy: string;
      referralCount: number;
      customDailyLimit: number | null;
      customCharLimit: number | null;
      dailyCount: number;
    }>,
  ): BotUser | null {
    const user = this.data.users.find((u) => u.id === id);
    if (!user) return null;
    this.resetDailyAndMembershipIfNeeded(user);
    Object.assign(user, patch, { lastActiveAt: new Date().toISOString() });
    this.save();
    return { ...user };
  }

  activatePremium(userId: string, days?: number): BotUser | null {
    const durationDays = days ?? this.data.config.premiumMembershipDays ?? 30;
    const expires = new Date(
      Date.now() + durationDays * 24 * 60 * 60 * 1000,
    ).toISOString();
    return this.updateUser(userId, {
      tier: 'premium',
      premiumExpiresAt: expires,
    });
  }

  deactivatePremium(userId: string): BotUser | null {
    return this.updateUser(userId, {
      tier: 'free',
      premiumExpiresAt: null,
    });
  }

  getUserEffectiveDailyLimit(user: BotUser): number {
    if (user.customDailyLimit !== null && user.customDailyLimit >= 0) {
      return user.customDailyLimit;
    }
    return user.tier === 'premium'
      ? this.data.config.premiumDailyLimit
      : this.data.config.freeDailyLimit;
  }

  /**
   * Returns 0 when Unlimited (no fixed duration/character cap).
   */
  getUserMaxChars(user: BotUser): number {
    if (user.customCharLimit !== null && user.customCharLimit >= 0) {
      return user.customCharLimit;
    }
    return user.tier === 'premium'
      ? this.data.config.maxScriptCharsPremium
      : this.data.config.maxScriptCharsFree;
  }

  getVoiceEffectiveCost(voiceId?: string): number {
    if (
      voiceId &&
      this.data.config.voiceCosts &&
      typeof this.data.config.voiceCosts[voiceId] === 'number' &&
      !Number.isNaN(this.data.config.voiceCosts[voiceId])
    ) {
      return Math.max(0, this.data.config.voiceCosts[voiceId]);
    }
    return Math.max(0, this.data.config.voiceGenerationCost ?? 0);
  }

  canUserGenerate(
    user: BotUser,
    voiceId?: string,
  ): { ok: boolean; reason?: string } {
    this.resetDailyAndMembershipIfNeeded(user);
    if (user.status === 'banned') {
      return {
        ok: false,
        reason:
          'আপনার অ্যাকাউন্টটি অ্যাডমিন কর্তৃক নিষিদ্ধ (Banned) করা হয়েছে। অনুগ্রহ করে সাপোর্টে যোগাযোগ করুন।',
      };
    }
    const limit = this.getUserEffectiveDailyLimit(user);
    if (limit > 0 && user.dailyCount >= limit) {
      return {
        ok: false,
        reason: `আপনার আজকের ভয়েস জেনারেট করার সীমা (${limit}টি) শেষ হয়ে গেছে। প্রিমিয়াম প্ল্যান বা অতিরিক্ত লিমিটের জন্য অ্যাডমিনের সাথে যোগাযোগ করুন।`,
      };
    }
    const cost = this.getVoiceEffectiveCost(voiceId ?? user.selectedVoiceId);
    if (cost > 0 && user.balance < cost) {
      return {
        ok: false,
        reason: `এই ভয়েসটি দিয়ে অডিও তৈরি করতে ৳${cost} প্রয়োজন। আপনার বর্তমান ব্যালেন্স ৳${user.balance.toFixed(2)}। অনুগ্রহ করে ব্যালেন্স রিচার্জ (Payment Request) করুন।`,
      };
    }
    return { ok: true };
  }

  canUserGenerateVideo(user: BotUser): { ok: boolean; reason?: string } {
    this.resetDailyAndMembershipIfNeeded(user);
    if (user.status === 'banned') {
      return {
        ok: false,
        reason:
          'আপনার অ্যাকাউন্টটি অ্যাডমিন কর্তৃক নিষিদ্ধ (Banned) করা হয়েছে। অনুগ্রহ করে সাপোর্টে যোগাযোগ করুন।',
      };
    }
    const cost = Math.max(0, this.data.config.videoGenerationCost ?? 0);
    if (cost > 0 && user.balance < cost) {
      return {
        ok: false,
        reason: `একটি প্রফেশনাল AI ভিডিও তৈরি করতে ৳${cost} প্রয়োজন। আপনার বর্তমান ব্যালেন্স ৳${user.balance.toFixed(2)}। অনুগ্রহ করে ব্যালেন্স রিচার্জ করুন।`,
      };
    }
    return { ok: true };
  }

  // -------------------------------------------------------------------------
  // Balance, Payments & Transactions
  // -------------------------------------------------------------------------

  adjustBalance(params: {
    userId: string;
    amountDelta: number; // positive to add, negative to deduct
    type: TransactionRecord['type'];
    description: string;
  }): { user: BotUser; transaction: TransactionRecord } {
    const user = this.data.users.find((u) => u.id === params.userId);
    if (!user) {
      throw new Error('User not found');
    }
    const nextBalance = Math.max(
      0,
      Math.round((user.balance + params.amountDelta) * 100) / 100,
    );
    user.balance = nextBalance;
    user.lastActiveAt = new Date().toISOString();

    const tx: TransactionRecord = {
      id: `tx-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      userId: user.id,
      userName: user.firstName || user.username,
      type: params.type,
      amount: params.amountDelta,
      balanceAfter: nextBalance,
      description: params.description,
      createdAt: new Date().toISOString(),
    };

    this.data.transactions.unshift(tx);
    if (this.data.transactions.length > 1000) {
      this.data.transactions = this.data.transactions.slice(0, 1000);
    }
    this.save();
    return { user: { ...user }, transaction: tx };
  }

  isTrxIdAlreadyUsed(trxId: string): boolean {
    const normalized = trxId.trim().toUpperCase();
    if (!normalized) return false;
    const claimedSms = this.data.incomingPaymentSms.some(
      (s) => s.trxId === normalized && s.status === 'claimed',
    );
    if (claimedSms) return true;
    return this.data.paymentRequests.some(
      (p) =>
        p.status === 'approved' &&
        (p.trxId ?? extractTrxId(p.referenceNote) ?? '').toUpperCase() ===
          normalized,
    );
  }

  createPaymentRequest(params: {
    user: BotUser;
    amount: number;
    method: string;
    accountNumber?: string;
    referenceNote: string;
  }): PaymentRequest {
    const trxId = extractTrxId(params.referenceNote) ?? undefined;
    const req: PaymentRequest = {
      id: `pay-${Date.now().toString().slice(-6)}-${Math.random().toString(36).slice(2, 5).toUpperCase()}`,
      userId: params.user.id,
      telegramId: params.user.telegramId,
      userName: params.user.firstName || params.user.username,
      amount: Math.max(1, Math.round(params.amount * 100) / 100),
      method: params.method || 'Manual Transfer',
      ...(params.accountNumber ? { accountNumber: params.accountNumber } : {}),
      referenceNote: params.referenceNote,
      ...(trxId ? { trxId } : {}),
      status: 'pending',
      createdAt: new Date().toISOString(),
    };
    this.data.paymentRequests.unshift(req);
    this.save();
    return req;
  }

  submitPaymentRequestAndAutoVerify(params: {
    user: BotUser;
    amount: number;
    method: string;
    accountNumber?: string;
    referenceNote: string;
  }): {
    payment: PaymentRequest;
    autoApproved: boolean;
    user?: BotUser;
    transaction?: TransactionRecord;
  } {
    const extracted = extractTrxId(params.referenceNote);
    if (extracted && this.isTrxIdAlreadyUsed(extracted)) {
      throw new Error(
        `এই Transaction ID (${extracted}) ইতিমধ্যে একবার ব্যবহৃত হয়েছে। অনুগ্রহ করে সঠিক নতুন TrxID দিন।`,
      );
    }

    const payment = this.createPaymentRequest(params);

    if (this.data.config.autoVerifyPayments && extracted) {
      const matchedSms = this.data.incomingPaymentSms.find(
        (sms) =>
          sms.status === 'unmatched' &&
          sms.trxId === extracted &&
          Math.abs(sms.amount - payment.amount) < 0.01,
      );

      if (matchedSms) {
        matchedSms.status = 'claimed';
        matchedSms.claimedByPaymentId = payment.id;
        matchedSms.claimedByUserName = payment.userName;
        matchedSms.claimedAt = new Date().toISOString();

        const review = this.reviewPaymentRequest({
          paymentId: payment.id,
          decision: 'approved',
          reviewedBy: 'Auto SMS Verify',
          autoVerified: true,
        });
        return {
          payment: review.payment,
          autoApproved: true,
          user: review.user,
          transaction: review.transaction,
        };
      }
    }

    return { payment, autoApproved: false };
  }

  ingestIncomingPaymentSms(params: {
    rawText: string;
    method?: string;
    amount?: number;
    trxId?: string;
    sender?: string;
  }): {
    sms: IncomingPaymentSms;
    duplicateSms: boolean;
    matchedPayment?: PaymentRequest;
    user?: BotUser;
    transaction?: TransactionRecord;
  } {
    const parsed = parsePaymentSms(params);
    if (!parsed.trxId) {
      throw new Error('SMS থেকে কোনো Transaction ID (TrxID) পাওয়া যায়নি।');
    }
    if (!parsed.amount || parsed.amount <= 0) {
      throw new Error('SMS থেকে সঠিক টাকার পরিমাণ (Amount) পাওয়া যায়নি।');
    }

    const existingSms = this.data.incomingPaymentSms.find(
      (s) => s.trxId === parsed.trxId,
    );
    if (existingSms) {
      return { sms: { ...existingSms }, duplicateSms: true };
    }

    const sms: IncomingPaymentSms = {
      id: `sms-${Date.now().toString().slice(-6)}-${Math.random().toString(36).slice(2, 5).toUpperCase()}`,
      method: parsed.method,
      amount: Math.round(parsed.amount * 100) / 100,
      trxId: parsed.trxId,
      ...(parsed.sender ? { sender: parsed.sender } : {}),
      rawText: params.rawText.trim(),
      status: 'unmatched',
      receivedAt: new Date().toISOString(),
    };

    this.data.incomingPaymentSms.unshift(sms);
    if (this.data.incomingPaymentSms.length > 500) {
      this.data.incomingPaymentSms = this.data.incomingPaymentSms.slice(0, 500);
    }

    // Check if there is already a pending payment request waiting for this exact TrxID + Amount
    if (this.data.config.autoVerifyPayments) {
      const pendingMatch = this.data.paymentRequests.find(
        (p) =>
          p.status === 'pending' &&
          (p.trxId ?? extractTrxId(p.referenceNote) ?? '').toUpperCase() ===
            sms.trxId &&
          Math.abs(p.amount - sms.amount) < 0.01,
      );

      if (pendingMatch) {
        sms.status = 'claimed';
        sms.claimedByPaymentId = pendingMatch.id;
        sms.claimedByUserName = pendingMatch.userName;
        sms.claimedAt = new Date().toISOString();

        const review = this.reviewPaymentRequest({
          paymentId: pendingMatch.id,
          decision: 'approved',
          reviewedBy: 'Auto SMS Verify',
          autoVerified: true,
        });
        return {
          sms: { ...sms },
          duplicateSms: false,
          matchedPayment: review.payment,
          user: review.user,
          transaction: review.transaction,
        };
      }
    }

    this.save();
    return { sms: { ...sms }, duplicateSms: false };
  }

  listIncomingPaymentSms(limit = 50): IncomingPaymentSms[] {
    return this.data.incomingPaymentSms.slice(0, limit);
  }

  regenerateSmsWebhookSecret(): string {
    const next = generateWebhookSecret();
    this.data.config.smsWebhookSecret = next;
    this.save();
    return next;
  }

  reviewPaymentRequest(params: {
    paymentId: string;
    decision: 'approved' | 'rejected';
    reviewedBy: string;
    autoVerified?: boolean;
  }): {
    payment: PaymentRequest;
    user?: BotUser;
    transaction?: TransactionRecord;
  } {
    const payment = this.data.paymentRequests.find(
      (p) => p.id === params.paymentId,
    );
    if (!payment) {
      throw new Error('Payment request not found');
    }
    if (payment.status !== 'pending') {
      throw new Error(`Payment request already ${payment.status}`);
    }

    payment.status = params.decision;
    payment.reviewedBy = params.reviewedBy;
    if (params.autoVerified) {
      payment.autoVerified = true;
    }
    payment.reviewedAt = new Date().toISOString();

    if (params.decision === 'approved') {
      const { user, transaction } = this.adjustBalance({
        userId: payment.userId,
        amountDelta: payment.amount,
        type: 'payment_approved',
        description: `${params.autoVerified ? 'অটো ভেরিফাইড পেমেন্ট' : 'পেমেন্ট অনুমোদিত'} (${payment.id} · ${payment.referenceNote})`,
      });
      this.save();
      return { payment: { ...payment }, user, transaction };
    }

    this.save();
    return { payment: { ...payment } };
  }

  listPaymentRequests(status?: PaymentRequest['status']): PaymentRequest[] {
    const list = status
      ? this.data.paymentRequests.filter((p) => p.status === status)
      : this.data.paymentRequests;
    return [...list];
  }

  listTransactions(userId?: string, limit = 100): TransactionRecord[] {
    const list = userId
      ? this.data.transactions.filter((t) => t.userId === userId)
      : this.data.transactions;
    return list.slice(0, limit);
  }

  // -------------------------------------------------------------------------
  // Voice Generations & Background Jobs
  // -------------------------------------------------------------------------

  recordGeneration(gen: VoiceGeneration) {
    const user = this.data.users.find((u) => u.id === gen.userId);
    const today = getTodayKey();
    if (user) {
      this.resetDailyAndMembershipIfNeeded(user);
      user.dailyCount += 1;
      user.totalCount += 1;
      user.lastActiveAt = gen.createdAt;
    }

    this.data.generations.unshift(gen);
    if (this.data.generations.length > 1000) {
      this.data.generations = this.data.generations.slice(0, 1000);
    }

    if (!this.data.dailyStats[today]) {
      this.data.dailyStats[today] = {
        date: today,
        generations: 0,
        characters: 0,
        activeUserIds: [],
      };
    }
    const stat = this.data.dailyStats[today];
    stat.generations += 1;
    stat.characters += gen.script.length;
    if (!stat.activeUserIds.includes(gen.userId)) {
      stat.activeUserIds.push(gen.userId);
    }

    if (gen.costCharged > 0 && user) {
      this.adjustBalance({
        userId: user.id,
        amountDelta: -gen.costCharged,
        type: 'voice_charge',
        description: `ভয়েস জেনারেশন (${gen.voiceNameBn})`,
      });
      return;
    }

    this.save();
  }

  listGenerations(userId?: string, limit = 50): VoiceGeneration[] {
    const list = userId
      ? this.data.generations.filter((g) => g.userId === userId)
      : this.data.generations;
    return list.slice(0, limit);
  }

  getGenerationById(id: string): VoiceGeneration | undefined {
    return this.data.generations.find((g) => g.id === id);
  }

  upsertJob(job: VoiceJob) {
    const idx = this.data.jobs.findIndex((j) => j.id === job.id);
    if (idx >= 0) {
      this.data.jobs[idx] = job;
    } else {
      this.data.jobs.unshift(job);
      if (this.data.jobs.length > 200) {
        this.data.jobs = this.data.jobs.slice(0, 200);
      }
    }
    this.save();
  }

  getJobById(jobId: string): VoiceJob | undefined {
    return this.data.jobs.find((j) => j.id === jobId);
  }

  listJobs(limit = 50): VoiceJob[] {
    return this.data.jobs.slice(0, limit);
  }

  listIncompleteJobs(): VoiceJob[] {
    return this.data.jobs.filter(
      (j) =>
        j.status === 'queued' ||
        j.status === 'processing' ||
        j.status === 'joining' ||
        j.status === 'rendering',
    );
  }

  // -------------------------------------------------------------------------
  // AI Video Generator & Interactive Video Editor Jobs
  // -------------------------------------------------------------------------

  upsertVideoJob(job: VideoProjectJob) {
    const idx = this.data.videoJobs.findIndex((j) => j.id === job.id);
    if (idx >= 0) {
      this.data.videoJobs[idx] = job;
    } else {
      this.data.videoJobs.unshift(job);
      if (this.data.videoJobs.length > 150) {
        this.data.videoJobs = this.data.videoJobs.slice(0, 150);
      }
    }
    this.save();
  }

  getVideoJobById(jobId: string): VideoProjectJob | undefined {
    return this.data.videoJobs.find((j) => j.id === jobId);
  }

  listVideoJobs(userId?: string, limit = 30): VideoProjectJob[] {
    const list = userId
      ? this.data.videoJobs.filter((j) => j.userId === userId)
      : this.data.videoJobs;
    return list.slice(0, limit);
  }

  listIncompleteVideoJobs(): VideoProjectJob[] {
    return this.data.videoJobs.filter(
      (j) =>
        j.status === 'queued' ||
        j.status === 'planning' ||
        j.status === 'voicing' ||
        j.status === 'visuals' ||
        j.status === 'rendering',
    );
  }

  recordVideoCompletion(job: VideoProjectJob) {
    const user = this.data.users.find((u) => u.id === job.userId);
    if (user) {
      this.resetDailyAndMembershipIfNeeded(user);
      user.dailyCount += 1;
      user.totalCount += 1;
      user.lastActiveAt = new Date().toISOString();
    }

    if (job.costCharged > 0 && user) {
      this.adjustBalance({
        userId: user.id,
        amountDelta: -job.costCharged,
        type: 'video_charge',
        description: `AI ভিডিও তৈরি (${job.title.slice(0, 32)})`,
      });
    } else {
      this.save();
    }
  }

  getDashboardStats() {
    const users = this.listUsers();
    const today = getTodayKey();
    const todayStat = this.data.dailyStats[today] ?? {
      date: today,
      generations: 0,
      characters: 0,
      activeUserIds: [],
    };

    const series: Array<{
      date: string;
      generations: number;
      characters: number;
      activeUsers: number;
    }> = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const key = d.toISOString().slice(0, 10);
      const s = this.data.dailyStats[key];
      series.push({
        date: key,
        generations: s?.generations ?? 0,
        characters: s?.characters ?? 0,
        activeUsers: s?.activeUserIds.length ?? 0,
      });
    }

    const totalBalance = users.reduce((sum, u) => sum + (u.balance || 0), 0);

    return {
      totalUsers: users.length,
      activeUsers: users.filter((u) => u.status === 'active').length,
      freeUsers: users.filter((u) => u.tier === 'free').length,
      premiumUsers: users.filter((u) => u.tier === 'premium').length,
      bannedUsers: users.filter((u) => u.status === 'banned').length,
      totalVoicesGenerated: this.data.generations.length,
      totalVideosGenerated: this.data.videoJobs.filter(
        (v) => v.status === 'completed',
      ).length,
      todayGenerations: todayStat.generations,
      todayCharacters: todayStat.characters,
      pendingPayments: this.data.paymentRequests.filter(
        (p) => p.status === 'pending',
      ).length,
      totalBalance: Math.round(totalBalance * 100) / 100,
      activeJobs:
        this.listIncompleteJobs().length + this.listIncompleteVideoJobs().length,
      featureUsage: {
        ...DEFAULT_FEATURE_USAGE,
        ...(this.data.featureUsage ?? {}),
      },
      errorCount: (this.data.errorLogs ?? []).length,
      dailySeries: series,
    };
  }

  // -------------------------------------------------------------------------
  // AI Assistant Memory, Chat History, Feature Controls & Error Logs
  // -------------------------------------------------------------------------

  isFeatureEnabled(module: AssistantModuleId): boolean {
    const map = this.data.config.enabledFeatures ?? DEFAULT_ENABLED_FEATURES;
    return map[module] !== false;
  }

  incrementFeatureUsage(module: AssistantModuleId) {
    if (!this.data.featureUsage) {
      this.data.featureUsage = { ...DEFAULT_FEATURE_USAGE };
    }
    this.data.featureUsage[module] = (this.data.featureUsage[module] ?? 0) + 1;
    this.save();
  }

  logError(module: string, err: unknown, userId?: string) {
    const rawMsg =
      err instanceof Error ? err.message : typeof err === 'string' ? err : String(err ?? 'Unknown error');
    const entry: ErrorLogEntry = {
      id: `err-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      module,
      userId,
      message: rawMsg.slice(0, 400),
      createdAt: new Date().toISOString(),
    };
    if (!this.data.errorLogs) this.data.errorLogs = [];
    this.data.errorLogs.unshift(entry);
    if (this.data.errorLogs.length > 100) {
      this.data.errorLogs = this.data.errorLogs.slice(0, 100);
    }
    this.save();
  }

  getErrorLogs(limit = 30): ErrorLogEntry[] {
    return (this.data.errorLogs ?? []).slice(0, limit);
  }

  clearErrorLogs() {
    this.data.errorLogs = [];
    this.save();
  }

  appendChatTurn(
    userId: string,
    turn: Omit<ChatTurnRecord, 'id' | 'createdAt'>,
  ): BotUser | null {
    const user = this.data.users.find((u) => u.id === userId);
    if (!user) return null;
    if (!user.chatHistory) user.chatHistory = [];
    user.chatHistory.push({
      id: `turn-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      role: turn.role,
      text: turn.text.slice(0, 4000),
      module: turn.module,
      attachmentNote: turn.attachmentNote,
      createdAt: new Date().toISOString(),
    });
    if (user.chatHistory.length > 24) {
      user.chatHistory = user.chatHistory.slice(-24);
    }
    user.lastActiveAt = new Date().toISOString();
    this.save();
    return { ...user };
  }

  clearChatHistory(userId: string): BotUser | null {
    const user = this.data.users.find((u) => u.id === userId);
    if (!user) return null;
    user.chatHistory = [];
    this.save();
    return { ...user };
  }

  upsertUserMemory(userId: string, key: string, value: string): BotUser | null {
    const user = this.data.users.find((u) => u.id === userId);
    if (!user) return null;
    if (!user.memories) user.memories = [];
    const cleanKey = key.trim().slice(0, 48);
    const cleanVal = value.trim().slice(0, 260);
    if (!cleanKey || !cleanVal) return { ...user };
    const existing = user.memories.find(
      (m) => m.key.toLowerCase() === cleanKey.toLowerCase(),
    );
    if (existing) {
      existing.value = cleanVal;
      existing.updatedAt = new Date().toISOString();
    } else {
      user.memories.push({
        id: `mem-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
        key: cleanKey,
        value: cleanVal,
        updatedAt: new Date().toISOString(),
      });
      if (user.memories.length > 25) {
        user.memories = user.memories.slice(-25);
      }
    }
    this.save();
    return { ...user };
  }

  deleteUserMemory(userId: string, idOrIndex: string): boolean {
    const user = this.data.users.find((u) => u.id === userId);
    if (!user || !user.memories?.length) return false;
    const num = Number.parseInt(idOrIndex, 10);
    if (!Number.isNaN(num) && num >= 1 && num <= user.memories.length) {
      user.memories.splice(num - 1, 1);
      this.save();
      return true;
    }
    const before = user.memories.length;
    user.memories = user.memories.filter((m) => m.id !== idOrIndex);
    if (user.memories.length !== before) {
      this.save();
      return true;
    }
    return false;
  }

  clearUserMemories(userId: string): BotUser | null {
    const user = this.data.users.find((u) => u.id === userId);
    if (!user) return null;
    user.memories = [];
    this.save();
    return { ...user };
  }
}

export const botStore = new BotStore();
