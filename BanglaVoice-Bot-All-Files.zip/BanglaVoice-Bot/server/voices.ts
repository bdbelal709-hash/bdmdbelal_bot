import type { VoiceCategory, VoicePersona } from './types.ts';

export const VOICE_CATALOG: VoicePersona[] = [
  {
    id: 'male-arif',
    category: 'male',
    emoji: '📰',
    nameBn: 'আরিফ',
    nameEn: 'Arif',
    roleBn: 'সংবাদ ও ডকুমেন্টারি',
    roleEn: 'News & Documentary',
    descriptionBn: 'গম্ভীর, স্পষ্ট ও বিশ্বাসযোগ্য কণ্ঠস্বর — সংবাদ পাঠ ও ডকুমেন্টারির জন্য আদর্শ।',
    geminiVoice: 'Charon',
    stylePrompt:
      'Speak in standard, fluent Bangladeshi Bangla with the poised, crisp, authoritative tone of a senior television news anchor and documentary narrator. Maintain natural human breathing, clear consonant articulation, and zero robotic cadence.',
    defaultSpeed: 1.0,
    defaultPitch: -1,
    sampleBangla:
      'আসসালামু আলাইকুম! আমি আরিফ বলছি। এই অত্যাধুনিক বাংলা এআই ভয়েস বটটি তৈরি করেছেন দক্ষ ডেভলপার বেলাল হোসেন। আপনার যেকোনো সংবাদ, ডকুমেন্টারি ও প্রফেশনাল ভিডিওর জন্য প্রাণবন্ত ও বিশ্বাসযোগ্য কণ্ঠ দিতে আমি সম্পূর্ণ প্রস্তুত।',
  },
  {
    id: 'male-tanvir',
    category: 'male',
    emoji: '📢',
    nameBn: 'তানভীর',
    nameEn: 'Tanvir',
    roleBn: 'বিজ্ঞাপন ও প্রোমো',
    roleEn: 'Commercial & Promo',
    descriptionBn: 'প্রাণবন্ত ও আকর্ষণীয় কণ্ঠস্বর — বিজ্ঞাপন, প্রোমো এবং ভিডিও ভয়েসওভারের জন্য উপযুক্ত।',
    geminiVoice: 'Puck',
    stylePrompt:
      'Speak in fluent, energetic Bangladeshi Bangla like a professional commercial voiceover artist. Warm, persuasive, dynamic intonation with natural human emphasis on key Bangla phrases.',
    defaultSpeed: 1.05,
    defaultPitch: 1,
    sampleBangla:
      'হ্যালো! আমি তানভীর। ডেভলপার বেলাল হোসেনের তৈরি এই স্মার্ট এআই স্টুডিওর মাধ্যমে এখন আপনার ব্যবসা, প্রোডাক্ট ও বিজ্ঞাপনের জন্য আকর্ষণীয় কণ্ঠে অডিও ও ভিডিও বানিয়ে নিতে পারবেন মাত্র কয়েক সেকেন্ডেই!',
  },
  {
    id: 'male-sadiq',
    category: 'male',
    emoji: '📖',
    nameBn: 'সাদিক',
    nameEn: 'Sadiq',
    roleBn: 'গল্প ও কথোপকথন',
    roleEn: 'Story & Conversation',
    descriptionBn: 'শান্ত, আবেগপূর্ণ ও প্রাকৃতিক কণ্ঠস্বর — গল্প বলা ও সাধারণ কথোপকথনের জন্য সেরা।',
    geminiVoice: 'Fenrir',
    stylePrompt:
      'Speak in warm, relaxed, deeply human Bangladeshi Bangla like an intimate storyteller or podcast host having a calm evening conversation. Gentle pauses at commas and periods.',
    defaultSpeed: 0.95,
    defaultPitch: -1,
    sampleBangla:
      'শুভ সন্ধ্যা! আমি সাদিক। আমাদের প্রিয় ডেভলপার বেলাল হোসেনের তৈরি এই বটের মাধ্যমে আপনার লেখা প্রতিটি গল্প ও কবিতা এখন শোনাবে একদম বাস্তব মানুষের মতো আন্তরিক ও জীবন্ত।',
  },
  {
    id: 'male-nafis',
    category: 'male',
    emoji: '🎓',
    nameBn: 'নাফিস',
    nameEn: 'Nafis',
    roleBn: 'ভিডিও ও টিউটোরিয়াল',
    roleEn: 'Video & Explainer',
    descriptionBn: 'পরিষ্কার ও বন্ধুত্বপূর্ণ কণ্ঠস্বর — ইউটিউব ভিডিও এবং শিক্ষামূলক কনটেন্টের জন্য উপযোগী।',
    geminiVoice: 'Puck',
    stylePrompt:
      'Speak in clear, friendly, approachable Bangladeshi Bangla like a modern educational content creator. Natural conversational pacing, bright clarity, and effortless flow.',
    defaultSpeed: 1.0,
    defaultPitch: 0,
    sampleBangla:
      'আসসালামু আলাইকুম বন্ধুরা, আমি নাফিস! ডেভলপার বেলাল হোসেন এই চমৎকার বাংলা এআই বটটি তৈরি করেছেন যেন আপনারা খুব সহজেই ইউটিউব টিউটোরিয়াল ও শিক্ষামূলক ভিডিওর ভয়েসওভার তৈরি করতে পারেন।',
  },
  {
    id: 'female-nusrat',
    category: 'female',
    emoji: '🌸',
    nameBn: 'নুসরাত',
    nameEn: 'Nusrat',
    roleBn: 'মিষ্টি ও স্বাভাবিক',
    roleEn: 'Sweet & Natural',
    descriptionBn: 'মিষ্টি, পরিষ্কার ও আন্তরিক নারী কণ্ঠস্বর — সাধারণ কথোপকথন ও ভিডিওর জন্য চমৎকার।',
    geminiVoice: 'Kore',
    stylePrompt:
      'Speak in sweet, gentle, natural Bangladeshi Bangla with a warm conversational female tone. Crisp, graceful pronunciation, natural breath pauses, and pleasant melodic flow.',
    defaultSpeed: 1.0,
    defaultPitch: 0,
    sampleBangla:
      'শুভ সকাল! আমি নুসরাত বলছি। ডেভলপার বেলাল হোসেনের তৈরি এই অসাধারণ বাংলা ভয়েস প্ল্যাটফর্মে আপনাকে স্বাগতম। আপনার প্রতিটি বাংলা লেখা এখন আমার কণ্ঠে ফুটে উঠবে দারুণ মিষ্টি ও স্বাভাবিক সুরে।',
  },
  {
    id: 'female-tasnim',
    category: 'female',
    emoji: '🎙️',
    nameBn: 'তাসনিম',
    nameEn: 'Tasnim',
    roleBn: 'সংবাদ ও কর্পোরেট',
    roleEn: 'News & Corporate',
    descriptionBn: 'প্রফেশনাল ও মার্জিত নারী কণ্ঠস্বর — সংবাদ, উপস্থাপনা এবং কর্পোরেট ভিডিওর জন্য উপযুক্ত।',
    geminiVoice: 'Zephyr',
    stylePrompt:
      'Speak in poised, articulate, studio-quality standard Bangla like a professional female broadcast journalist and corporate narrator. Balanced cadence and crystal clear diction.',
    defaultSpeed: 1.0,
    defaultPitch: 0,
    sampleBangla:
      'স্বাগতম, আমি তাসনিম। ডেভলপার বেলাল হোসেনের নির্মিত এই আধুনিক বাংলা এআই ভয়েস ও ভিডিও বট কর্পোরেট প্রেজেন্টেশন এবং সংবাদ উপস্থাপনার জন্য নিয়ে এসেছে স্টুডিও মানের নিখুঁত কণ্ঠস্বর।',
  },
  {
    id: 'female-mahira',
    category: 'female',
    emoji: '✨',
    nameBn: 'মাহিরা',
    nameEn: 'Mahira',
    roleBn: 'বিজ্ঞাপন ও রিলস',
    roleEn: 'Ads & Social Reels',
    descriptionBn: 'প্রাণবন্ত ও উজ্জ্বল কণ্ঠস্বর — বিজ্ঞাপন, প্রোডাক্ট রিভিউ ও শর্ট ভিডিওর জন্য দারুণ।',
    geminiVoice: 'Zephyr',
    stylePrompt:
      'Speak in lively, expressive, cheerful Bangladeshi Bangla like a charismatic commercial host. Engaging rhythm, smiling vocal quality, and clear emphasis.',
    defaultSpeed: 1.08,
    defaultPitch: 1,
    sampleBangla:
      'হেই এভরিওয়ান! আমি মাহিরা! ডেভলপার বেলাল হোসেনের এই দারুণ এআই বট দিয়ে এখন রিলস, শর্টস ও প্রোডাক্ট রিভিউ হবে আরও বেশি প্রাণবন্ত এবং দর্শকপ্রিয়!',
  },
  {
    id: 'female-sumaiya',
    category: 'female',
    emoji: '🌙',
    nameBn: 'সুমাইয়া',
    nameEn: 'Sumaiya',
    roleBn: 'গল্প ও পডকাস্ট',
    roleEn: 'Story & Podcast',
    descriptionBn: 'কোমল ও আবেগঘন কণ্ঠস্বর — অডিওবুক, কবিতা ও পডকাস্টের জন্য আদর্শ।',
    geminiVoice: 'Kore',
    stylePrompt:
      'Speak in soft, expressive, soothing Bangladeshi Bangla like an audiobook and poetry narrator. Warm emotional resonance and natural thoughtful pauses.',
    defaultSpeed: 0.95,
    defaultPitch: -1,
    sampleBangla:
      'নীরব রাতের স্নিগ্ধ আলোয় আপনাকে স্বাগতম, আমি সুমাইয়া। ডেভলপার বেলাল হোসেনের তৈরি এই বটের মাধ্যমে আপনার প্রিয় অডিওবুক, কবিতা ও পডকাস্ট হয়ে উঠবে এক অনন্য অনুভূতির জগত।',
  },
  {
    id: 'male-emotional',
    category: 'male',
    emoji: '💔',
    nameBn: 'রাহাত',
    nameEn: 'Rahat',
    roleBn: 'ইমোশনাল ও হৃদয়স্পর্শী',
    roleEn: 'Emotional & Heartfelt',
    descriptionBn: 'গভীর আবেগ, কোমলতা ও হৃদয়ছোঁয়া বাংলা কণ্ঠস্বর — ভালোবাসা, কষ্ট ও আবেগঘন গল্পের জন্য।',
    geminiVoice: 'Fenrir',
    stylePrompt:
      'Speak in deeply emotional, tender, heartfelt Bangladeshi Bangla with genuine human warmth, soft melancholic resonance, delicate breath pauses, and sincere emotion as if sharing a deeply personal confession.',
    defaultSpeed: 0.92,
    defaultPitch: -1,
    sampleBangla:
      'কিছু না বলা অনুভূতি শুধু হৃদয়ের গভীরেই থেকে যায়... আমি রাহাত বলছি। ডেভলপার বেলাল হোসেন এই বিশেষ ইমোশনাল কণ্ঠটি সাজিয়েছেন আপনার মনের গভীরের গল্প ও অনুভূতিগুলো সবার মাঝে ছুঁয়ে দেওয়ার জন্য।',
  },
  {
    id: 'male-viral-emotional',
    category: 'male',
    emoji: '🔥',
    nameBn: 'আরিয়ান',
    nameEn: 'Aryan Viral',
    roleBn: 'ইমোশনাল ভাইরাল ভয়েস',
    roleEn: 'Viral Emotional Reels',
    descriptionBn: 'একদম ভাইরাল রিলস/শর্টস স্টাইলের রোমাঞ্চকর ও হৃদয়স্পর্শী কণ্ঠস্বর — শুনেই মনে দাগ কাটে।',
    geminiVoice: 'Charon',
    stylePrompt:
      'Deliver an intensely gripping, goosebump-inducing viral Bangladeshi Bangla emotional monologue. Start softly with raw vulnerability, build dramatic emotional intensity on key words with poignant pauses, soulful breathy warmth, and unforgettable cinematic gravitas made for viral Reels and TikTok.',
    defaultSpeed: 0.94,
    defaultPitch: 0,
    sampleBangla:
      'সময় বদলায়, মানুষও বদলায়... কিন্তু সত্যিকারের সৃষ্টি কখনো হারায় না। আমি আরিয়ান বলছি! ডেভলপার বেলাল হোসেনের তৈরি এই ইমোশনাল ভাইরাল কণ্ঠ দিয়ে আপনার প্রতিটি রিলস ও ভিডিও জয় করবে কোটি মানুষের হৃদয়।',
  },
  {
    id: 'female-viral-emotional',
    category: 'female',
    emoji: '💫',
    nameBn: 'মেহেক',
    nameEn: 'Mehek Viral',
    roleBn: 'ইমোশনাল ভাইরাল (নারী)',
    roleEn: 'Viral Emotional Female',
    descriptionBn: 'হৃদয়ছোঁয়া ও আবেগঘন ভাইরাল নারী কণ্ঠস্বর — ইমোশনাল রিলস, শায়েরি ও জীবনমুখী গল্পের জন্য সেরা।',
    geminiVoice: 'Kore',
    stylePrompt:
      'Deliver a deeply moving, poetic, viral-style emotional female Bangladeshi Bangla narration. Tender tremulous warmth, soulful expressive rises and soft intimate whispers with natural emotional pauses.',
    defaultSpeed: 0.94,
    defaultPitch: 0,
    sampleBangla:
      'চোখের আড়ালে লুকানো প্রতিটি কষ্টই একদিন শক্তিতে বদলে যায়। আমি মেহেক বলছি—ডেভলপার বেলাল হোসেনের তৈরি এই ভাইরাল ইমোশনাল ভয়েসে আপনার প্রতিটি শায়েরি ও গল্প হয়ে উঠবে অবিস্মরণীয়।',
  },
  {
    id: 'cartoon-oggy',
    category: 'cartoon',
    emoji: '🐱',
    nameBn: 'অগি',
    nameEn: 'Oggy',
    roleBn: 'Oggy কার্টুন ভয়েস',
    roleEn: 'Oggy Cartoon Style',
    descriptionBn: 'দুষ্টু-মিষ্টি ও মজার অগি কার্টুন স্টাইল বাংলা কণ্ঠস্বর — কমেডি ও কার্টুন ভিডিওর জন্য দারুণ।',
    geminiVoice: 'Puck',
    stylePrompt:
      'Perform in a quirky, bouncy, animated Oggy-style cartoon character voice speaking fluent Bangladeshi Bangla. Playful, dramatic comedic exaggeration, funny reactive pitch swings, and lively cartoon charm.',
    defaultSpeed: 1.08,
    defaultPitch: 2,
    sampleBangla:
      'আরেহ বাপ রে বাপ! আমি অগি বলছি! ডেভলপার বেলাল হোসেন আমাদের বটে এত মজার কার্টুন ভয়েস বানিয়েছেন যে ওই দুষ্টু তেলাপোকাগুলোও এখন বাংলা কমেডি শুনে হাসতে হাসতে গড়াগড়ি খাবে!',
  },
  {
    id: 'cartoon-tomjerry',
    category: 'cartoon',
    emoji: '🐭',
    nameBn: 'টম অ্যান্ড জেরি',
    nameEn: 'Tom & Jerry',
    roleBn: 'Tom & Jerry কার্টুন',
    roleEn: 'Tom & Jerry Cartoon',
    descriptionBn: 'স্ল্যাপস্টিক কমেডি ও টম-জেরি স্টাইলের এক্সপ্রেসিভ বাংলা কার্টুন কণ্ঠস্বর।',
    geminiVoice: 'Fenrir',
    stylePrompt:
      'Perform like a classic slapstick Tom & Jerry cartoon narrator and character speaking lively Bangladeshi Bangla. Over-the-top animated energy, sneaky comic mischief, dramatic gasps, and playful cartoon timing.',
    defaultSpeed: 1.12,
    defaultPitch: 1,
    sampleBangla:
      'চুপ চুপ! জেরি পা টিপে টিপে আসছে... আমি টম বলছি! ডেভলপার বেলাল হোসেনের তৈরি এই সুপারহিট বট দিয়ে এখন কার্টুন দুনিয়ার সব দুষ্টুমি আর হাসির গল্প বানানো যাবে বাংলাতেই!',
  },
  {
    id: 'cartoon-doraemon',
    category: 'cartoon',
    emoji: '🤖',
    nameBn: 'ডোরেমন',
    nameEn: 'Doraemon',
    roleBn: 'Doraemon কার্টুন ভয়েস',
    roleEn: 'Doraemon Cartoon Style',
    descriptionBn: 'প্রাণবন্ত, মজাদার ও বন্ধুত্বপূর্ণ ডোরেমন কার্টুন ভয়েস — গ্যাজেট ও বাচ্চাদের গল্পের জন্য।',
    geminiVoice: 'Puck',
    stylePrompt:
      'Perform in a cheerful, lovable, slightly raspy-bright Doraemon robotic-cat cartoon voice speaking fluent Bangladeshi Bangla. Enthusiastic mentor energy, playful excitement when revealing cool gadgets, and warm comic friendliness.',
    defaultSpeed: 1.06,
    defaultPitch: 2,
    sampleBangla:
      'হ্যালো বন্ধুরা, আমি ডোরেমন বলছি! একদম চিন্তা করো না—ডেভলপার বেলাল হোসেনের এই জাদুকরী বটের পকেটে রয়েছে দারুণ সব বাংলা ভয়েস আর অ্যানিমেশন গ্যাজেট! চলো আজই নতুন কার্টুন বানাই!',
  },
  {
    id: 'cartoon-nobita',
    category: 'cartoon',
    emoji: '👦',
    nameBn: 'নোবিতা',
    nameEn: 'Nobita',
    roleBn: 'Nobita কার্টুন ভয়েস',
    roleEn: 'Nobita Cartoon Style',
    descriptionBn: 'মিষ্টি ও আবেগী নোবিতা কার্টুন চরিত্রের বাংলা কণ্ঠস্বর — ফানি ডাবিং ও স্টোরির জন্য।',
    geminiVoice: 'Kore',
    stylePrompt:
      'Perform in an innocent, expressive Nobita young-boy cartoon voice speaking fluent Bangladeshi Bangla. Wide-eyed naive curiosity, dramatic pleading urgency, and relatable kid-like comedic reactions.',
    defaultSpeed: 1.06,
    defaultPitch: 2,
    sampleBangla:
      'ওই যে দেখো ডোরেমন! আমি নোবিতা বলছি—ডেভলপার বেলাল হোসেন আমার কণ্ঠটাও এই বটে যুক্ত করে দিয়েছেন! এখন জিয়ান আর সুনিও-কে নিয়ে বানাব দারুণ সব মজার বাংলা কার্টুন!',
  },
  {
    id: 'cartoon-shinchan',
    category: 'cartoon',
    emoji: '😜',
    nameBn: 'শিনচ্যান',
    nameEn: 'Shinchan',
    roleBn: 'Shinchan কার্টুন ভয়েস',
    roleEn: 'Shinchan Cartoon Style',
    descriptionBn: 'চঞ্চল, ফাজিল ও হাস্যরসাত্মক শিনচ্যান কার্টুন ভয়েস — শর্ট কমেডি ও রোস্ট ভিডিওর জন্য।',
    geminiVoice: 'Zephyr',
    stylePrompt:
      'Perform in a cheeky, mischievous, playful Shinchan five-year-old cartoon voice speaking fluent Bangladeshi Bangla. Sassy comedic inflection, funny dramatic pauses, and upbeat naughty kid energy.',
    defaultSpeed: 1.1,
    defaultPitch: 2,
    sampleBangla:
      'হিহিহি! আমি দুষ্টু শিনচ্যান বলছি! ডেভলপার বেলাল হোসেন আমাকেও এই বটে নিয়ে এসেছেন—এখন চকলেট খাওয়া বাদ দিয়ে চলো সবাই মিলে মজার মজার বাংলা কমেডি ভিডিও বানাই!',
  },
];

export function getVoiceById(id: string): VoicePersona {
  return VOICE_CATALOG.find((v) => v.id === id) ?? VOICE_CATALOG[0];
}

export function getVoicesByCategory(category: VoiceCategory): VoicePersona[] {
  return VOICE_CATALOG.filter((v) => v.category === category);
}

export interface BanglaValidationResult {
  valid: boolean;
  reason?: string;
}

/**
 * Enforces the strict Bangla-only script requirement:
 * - Must contain Bengali Unicode characters (\u0980-\u09FF).
 * - Rejects English/Latin letters and other non-Bangla writing systems.
 */
export function validateBanglaOnlyScript(input: string): BanglaValidationResult {
  const trimmed = input.trim();
  if (!trimmed) {
    return {
      valid: false,
      reason: 'অনুগ্রহ করে বাংলা ভাষায় একটি স্ক্রিপ্ট লিখুন। খালি বার্তা গ্রহণযোগ্য নয়।',
    };
  }

  const banglaChars = trimmed.match(/[\u0980-\u09FF]/g) ?? [];
  if (banglaChars.length < 2) {
    return {
      valid: false,
      reason:
        'দুঃখিত! শুধুমাত্র বাংলা ভাষায় স্ক্রিপ্ট পাঠান। ইংরেজি বা অন্য কোনো ভাষায় ভয়েস তৈরি করা যাবে না।',
    };
  }

  const latinLetters = trimmed.match(/[A-Za-z]/g) ?? [];
  if (latinLetters.length > 0) {
    return {
      valid: false,
      reason:
        'দুঃখিত! আপনার স্ক্রিপ্টে ইংরেজি অক্ষর পাওয়া গেছে। শুধুমাত্র বাংলা ভাষায় স্ক্রিপ্ট লিখুন—ইংরেজি বা অন্য কোনো ভাষায় ভয়েস তৈরি করা যাবে না।',
    };
  }

  const otherScripts = trimmed.match(
    /[\u0600-\u06FF\u0900-\u0963\u0966-\u097F\u0400-\u04FF\u4E00-\u9FFF\u3040-\u30FF\uAC00-\uD7AF]/g,
  );
  if (otherScripts && otherScripts.length > 0) {
    return {
      valid: false,
      reason:
        'দুঃখিত! বাংলা ছাড়া অন্য কোনো ভাষার অক্ষর ব্যবহার করা যাবে না। শুধুমাত্র বাংলায় স্ক্রিপ্ট পাঠান।',
    };
  }

  return { valid: true };
}

/**
 * Splits arbitrarily long Bangla scripts into meaningful sentence/clause chunks
 * (default max ~650 chars per chunk) so Gemini TTS maintains consistent pronunciation
 * and never cuts off words or sentences across 2min, 10min, 30min, or 1hr+ scripts.
 */
export function chunkBanglaScript(
  script: string,
  maxChunkChars = 650,
): string[] {
  const clean = script
    .replace(/\r\n/g, '\n')
    .replace(/[ \t]+/g, ' ')
    .trim();
  if (!clean) return [];
  if (clean.length <= maxChunkChars) return [clean];

  const paragraphs = clean
    .split(/\n+/)
    .map((p) => p.trim())
    .filter(Boolean);

  const rawSegments: string[] = [];

  for (const para of paragraphs) {
    // Split on Bangla and English sentence terminators while keeping punctuation attached
    const sentences = para
      .split(/(?<=[।.?!৷])\s+/)
      .map((s) => s.trim())
      .filter(Boolean);

    for (const sentence of sentences) {
      if (sentence.length <= maxChunkChars) {
        rawSegments.push(sentence);
      } else {
        // Split overly long sentence at clause punctuation (, ; : — -)
        const clauses = sentence
          .split(/(?<=[,;:\u2014-])\s+/)
          .map((c) => c.trim())
          .filter(Boolean);

        for (const clause of clauses) {
          if (clause.length <= maxChunkChars) {
            rawSegments.push(clause);
          } else {
            // Word-safe fallback split so no Bangla word is ever cut in half
            const words = clause.split(/\s+/);
            let buf = '';
            for (const w of words) {
              if (!buf) {
                buf = w;
              } else if (buf.length + 1 + w.length <= maxChunkChars) {
                buf += ` ${w}`;
              } else {
                rawSegments.push(buf);
                buf = w;
              }
            }
            if (buf) rawSegments.push(buf);
          }
        }
      }
    }
  }

  // Greedily pack adjacent segments up to maxChunkChars for smooth natural flow
  const chunks: string[] = [];
  let current = '';
  for (const seg of rawSegments) {
    if (!current) {
      current = seg;
    } else if (current.length + 1 + seg.length <= maxChunkChars) {
      current += ` ${seg}`;
    } else {
      chunks.push(current);
      current = seg;
    }
  }
  if (current) chunks.push(current);

  return chunks;
}
