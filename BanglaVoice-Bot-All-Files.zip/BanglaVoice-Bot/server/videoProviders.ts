import { GoogleGenAI } from '@google/genai';
import { Resvg } from '@resvg/resvg-js';
import { execFile } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { promisify } from 'node:util';
import {
  isModelExhausted,
  isQuotaOrRateLimitError,
  markModelExhausted,
} from './gemini.ts';
import type {
  VideoAspectRatio,
  VideoMusicMood,
  VideoScene,
  VideoTemplateInfo,
  VideoVisualMode,
} from './types.ts';

const execFileAsync = promisify(execFile);

const NOTO_FONT_FILES = [
  '/usr/share/fonts/truetype/noto/NotoSansBengali-Bold.ttf',
  '/usr/share/fonts/truetype/noto/NotoSansBengali-Regular.ttf',
  '/usr/share/fonts/truetype/noto/NotoSerifBengali-Bold.ttf',
  '/usr/share/fonts/truetype/noto/NotoSerifBengali-Regular.ttf',
].filter((p) => fs.existsSync(p));

function renderSvgToPngFile(svg: string, outputPath: string): void {
  const resvg = new Resvg(svg, {
    font: {
      fontFiles: NOTO_FONT_FILES,
      loadSystemFonts: true,
      defaultFontFamily: 'Noto Sans Bengali',
    },
  });
  const rendered = resvg.render();
  fs.writeFileSync(outputPath, rendered.asPng());
}

function getTargetImageDimensions(aspectRatio: VideoAspectRatio): {
  width: number;
  height: number;
  pexelsOrientation: 'landscape' | 'portrait' | 'square';
} {
  if (aspectRatio === '9:16') {
    return { width: 720, height: 1280, pexelsOrientation: 'portrait' };
  }
  if (aspectRatio === '1:1') {
    return { width: 1080, height: 1080, pexelsOrientation: 'square' };
  }
  return { width: 1280, height: 720, pexelsOrientation: 'landscape' };
}

async function tryFetchPexelsStockVideo(params: {
  query: string;
  apiKey: string;
  aspectRatio: VideoAspectRatio;
  outputPath: string;
}): Promise<boolean> {
  if (!params.apiKey.trim()) return false;
  const { pexelsOrientation } = getTargetImageDimensions(params.aspectRatio);

  try {
    const url =
      `https://api.pexels.com/videos/search?query=${encodeURIComponent(params.query || 'nature')}` +
      `&orientation=${pexelsOrientation}&per_page=3&size=medium`;
    const res = await fetch(url, {
      headers: { Authorization: params.apiKey.trim() },
      signal: AbortSignal.timeout(10000),
    });
    if (!res.ok) return false;
    const data = (await res.json()) as {
      videos?: Array<{
        video_files?: Array<{
          link?: string;
          quality?: string;
          width?: number;
          file_type?: string;
        }>;
      }>;
    };
    const firstVideo = data.videos?.[0];
    const files = firstVideo?.video_files ?? [];
    const chosen =
      files.find((f) => f.file_type === 'video/mp4' && (f.width ?? 0) >= 720) ??
      files.find((f) => f.file_type === 'video/mp4') ??
      files[0];

    if (!chosen?.link) return false;

    const dl = await fetch(chosen.link, { signal: AbortSignal.timeout(20000) });
    if (!dl.ok) return false;
    const buf = Buffer.from(await dl.arrayBuffer());
    if (buf.length < 10_000) return false;
    fs.writeFileSync(params.outputPath, buf);
    return true;
  } catch {
    return false;
  }
}

async function tryGenerateGeminiSceneImage(params: {
  prompt: string;
  aspectRatio: VideoAspectRatio;
  outputPath: string;
}): Promise<boolean> {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey) return false;

  const ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });

  const models = ['gemini-2.5-flash-image', 'gemini-3-pro-image-preview'];
  for (const model of models) {
    if (isModelExhausted(model)) continue;
    try {
      const response = await ai.models.generateContent({
        model,
        contents: {
          parts: [
            {
              text: `${params.prompt}. High-resolution cinematic film still, photorealistic lighting, shallow depth of field, zero embedded text or words.`,
            },
          ],
        },
        config: {
          imageConfig: {
            aspectRatio: params.aspectRatio,
          },
        },
      });
      const parts = response.candidates?.[0]?.content?.parts ?? [];
      const imgPart = parts.find((p) => p.inlineData?.data);
      if (imgPart?.inlineData?.data) {
        fs.writeFileSync(
          params.outputPath,
          Buffer.from(imgPart.inlineData.data, 'base64'),
        );
        return true;
      }
    } catch (err) {
      if (isQuotaOrRateLimitError(err)) {
        markModelExhausted(model, err);
      }
      // Fall through to next model or procedural high-res artwork
    }
  }
  return false;
}

type ThemeKind = 'war' | 'ocean' | 'tech' | 'city' | 'nature' | 'emotional';

function detectSceneTheme(keywords: string, emotion: VideoScene['emotion']): ThemeKind {
  const q = `${keywords} ${emotion}`.toLowerCase();
  if (/war|battle|fire|smoke|explosion|soldier|fight|tense/.test(q)) return 'war';
  if (/ocean|sea|river|water|rain|wave|storm|blue/.test(q)) return 'ocean';
  if (/tech|ai|cyber|digital|robot|code|network|computer|informative/.test(q)) return 'tech';
  if (/city|skyline|urban|finance|money|office|modern|night/.test(q)) return 'city';
  if (/nature|mountain|forest|sunrise|sun|tree|sky|calm|happy/.test(q)) return 'nature';
  return 'emotional';
}

function buildThemeSvg(params: {
  width: number;
  height: number;
  theme: ThemeKind;
  template: VideoTemplateInfo;
  sceneIndex: number;
}): string {
  const { width: W, height: H, theme, template, sceneIndex } = params;
  const shiftX = ((sceneIndex * 137) % 40) - 20;
  const palettes: Record<ThemeKind, { bg1: string; bg2: string; glow: string; silhouette: string }> = {
    war: { bg1: '#180c09', bg2: '#3f150b', glow: '#f97316', silhouette: '#0d0604' },
    ocean: { bg1: '#041424', bg2: '#0b3650', glow: '#38bdf8', silhouette: '#020b14' },
    tech: { bg1: '#04121c', bg2: '#0c2a3a', glow: '#14b8a6', silhouette: '#030c12' },
    city: { bg1: '#0c1020', bg2: '#1e293b', glow: '#60a5fa', silhouette: '#060911' },
    nature: { bg1: '#071b16', bg2: '#134e4a', glow: '#34d399', silhouette: '#04100d' },
    emotional: {
      bg1: template.bgDarkHex,
      bg2: '#2e1d14',
      glow: template.secondaryHex,
      silhouette: '#090707',
    },
  };
  const pal = palettes[theme];

  const stars = Array.from({ length: 28 })
    .map((_, idx) => {
      const cx = ((idx * 193 + sceneIndex * 71) % 96) + 2;
      const cy = ((idx * 127 + sceneIndex * 43) % 58) + 3;
      const r = (idx % 3) + 1;
      const op = (0.18 + ((idx * 19) % 45) / 100).toFixed(2);
      return `<circle cx="${(cx * W) / 100}" cy="${(cy * H) / 100}" r="${r}" fill="#ffffff" opacity="${op}" />`;
    })
    .join('\n');

  let midground = '';
  if (theme === 'tech') {
    const lines = Array.from({ length: 12 })
      .map((_, i) => {
        const y = Math.round((H * (i + 3)) / 15);
        return `<line x1="0" y1="${y}" x2="${W}" y2="${y}" stroke="${pal.glow}" stroke-opacity="0.16" stroke-width="1.5" />`;
      })
      .join('');
    const cols = Array.from({ length: 12 })
      .map((_, i) => {
        const x = Math.round((W * (i + 1)) / 13);
        return `<line x1="${x}" y1="0" x2="${x}" y2="${H}" stroke="${template.accentHex}" stroke-opacity="0.15" stroke-width="1.5" />`;
      })
      .join('');
    midground = `${lines}${cols}
      <circle cx="${Math.round(W * 0.5)}" cy="${Math.round(H * 0.44)}" r="${Math.round(Math.min(W, H) * 0.22)}" fill="none" stroke="${pal.glow}" stroke-opacity="0.35" stroke-width="3" stroke-dasharray="14 8" />
      <circle cx="${Math.round(W * 0.5)}" cy="${Math.round(H * 0.44)}" r="${Math.round(Math.min(W, H) * 0.14)}" fill="${pal.glow}" fill-opacity="0.12" stroke="${template.secondaryHex}" stroke-opacity="0.5" stroke-width="2" />`;
  } else if (theme === 'ocean') {
    midground = `
      <path d="M0,${H * 0.62} Q${W * 0.25},${H * 0.56} ${W * 0.5},${H * 0.62} T${W},${H * 0.60} L${W},${H} L0,${H} Z" fill="${pal.glow}" fill-opacity="0.16" />
      <path d="M0,${H * 0.70} Q${W * 0.3},${H * 0.65} ${W * 0.6},${H * 0.71} T${W},${H * 0.68} L${W},${H} L0,${H} Z" fill="${template.accentHex}" fill-opacity="0.28" />
      <path d="M0,${H * 0.79} Q${W * 0.35},${H * 0.74} ${W * 0.7},${H * 0.80} T${W},${H * 0.77} L${W},${H} L0,${H} Z" fill="${pal.silhouette}" fill-opacity="0.88" />`;
  } else if (theme === 'city') {
    const bars = Array.from({ length: 16 })
      .map((_, i) => {
        const bw = Math.ceil(W / 15);
        const bh = Math.round(H * (0.18 + (((i * 29 + sceneIndex * 11) % 24) / 100)));
        const bx = i * bw;
        const by = H - bh;
        return `<rect x="${bx}" y="${by}" width="${bw - 3}" height="${bh}" fill="${pal.silhouette}" opacity="0.92" />
                <rect x="${bx + 6}" y="${by + 12}" width="${Math.max(4, bw - 18)}" height="4" fill="${pal.glow}" opacity="0.32" />`;
      })
      .join('');
    midground = bars;
  } else {
    // Mountains / cinematic horizon ridges
    midground = `
      <polygon points="0,${H} 0,${H * 0.68} ${W * 0.22},${H * 0.52} ${W * 0.45},${H * 0.64} ${W * 0.72},${H * 0.48} ${W},${H * 0.63} ${W},${H}" fill="${template.accentHex}" fill-opacity="0.24" />
      <polygon points="0,${H} 0,${H * 0.76} ${W * 0.32},${H * 0.62} ${W * 0.58},${H * 0.74} ${W * 0.84},${H * 0.58} ${W},${H * 0.72} ${W},${H}" fill="${pal.silhouette}" fill-opacity="0.90" />`;
  }

  return `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
    <defs>
      <linearGradient id="sky" x1="0" y1="0" x2="0.2" y2="1">
        <stop offset="0%" stop-color="${pal.bg1}" />
        <stop offset="55%" stop-color="${pal.bg2}" />
        <stop offset="100%" stop-color="${pal.silhouette}" />
      </linearGradient>
      <radialGradient id="orb" cx="${0.5 + shiftX / 100}" cy="0.38" r="0.48">
        <stop offset="0%" stop-color="${pal.glow}" stop-opacity="0.58" />
        <stop offset="50%" stop-color="${template.accentHex}" stop-opacity="0.18" />
        <stop offset="100%" stop-color="${pal.bg1}" stop-opacity="0" />
      </radialGradient>
      <linearGradient id="vignette" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="#000000" stop-opacity="0.25" />
        <stop offset="70%" stop-color="#000000" stop-opacity="0" />
        <stop offset="100%" stop-color="#000000" stop-opacity="0.55" />
      </linearGradient>
    </defs>
    <rect width="${W}" height="${H}" fill="url(#sky)" />
    <rect width="${W}" height="${H}" fill="url(#orb)" />
    ${stars}
    <circle cx="${Math.round(W * (0.5 + shiftX / 120))}" cy="${Math.round(H * 0.36)}" r="${Math.round(Math.min(W, H) * 0.10)}" fill="${pal.glow}" fill-opacity="0.24" />
    ${midground}
    <rect width="${W}" height="${H}" fill="url(#vignette)" />
  </svg>`;
}

async function generateProceduralSceneImage(params: {
  scene: VideoScene;
  aspectRatio: VideoAspectRatio;
  template: VideoTemplateInfo;
  outputPath: string;
}): Promise<void> {
  const { width, height } = getTargetImageDimensions(params.aspectRatio);
  const theme = detectSceneTheme(params.scene.searchKeywords, params.scene.emotion);
  const svg = buildThemeSvg({
    width,
    height,
    theme,
    template: params.template,
    sceneIndex: params.scene.index,
  });
  renderSvgToPngFile(svg, params.outputPath);
}

/**
 * Vendor-Independent Scene Visual Resolver:
 * Tier 1: Stock HD Video B-Roll (Pexels API if key set)
 * Tier 2: Gemini AI Image Generation (if enabled & key supports image model)
 * Tier 3: Procedural Thematic SVG Artwork rendered cleanly via ImageMagick -> PNG
 */
export async function acquireVisualAssetForScene(params: {
  scene: VideoScene;
  aspectRatio: VideoAspectRatio;
  template: VideoTemplateInfo;
  workDir: string;
  pexelsApiKey: string;
  visualMode: VideoVisualMode;
  allowAiImageAttempt: boolean;
}): Promise<{
  assetPath: string;
  assetType: 'video' | 'image';
  aiImageFailed: boolean;
}> {
  const { scene, aspectRatio, template, workDir, pexelsApiKey, visualMode } =
    params;
  const idxPad = String(scene.index).padStart(4, '0');
  const videoOut = path.join(workDir, `scene_raw_${idxPad}.mp4`);
  const imgOut = path.join(workDir, `scene_raw_${idxPad}.png`);

  // Tier 1: Stock HD Video (Pexels)
  if (
    (visualMode === 'stock_video' || visualMode === 'auto') &&
    pexelsApiKey.trim()
  ) {
    const okVideo = await tryFetchPexelsStockVideo({
      query: scene.searchKeywords,
      apiKey: pexelsApiKey,
      aspectRatio,
      outputPath: videoOut,
    });
    if (okVideo) {
      return { assetPath: videoOut, assetType: 'video', aiImageFailed: false };
    }
  }

  // Tier 2: Gemini AI Scene Image
  let aiImageFailed = false;
  if (
    (visualMode === 'ai_image' || visualMode === 'auto') &&
    params.allowAiImageAttempt
  ) {
    const okImg = await tryGenerateGeminiSceneImage({
      prompt: scene.visualPrompt,
      aspectRatio,
      outputPath: imgOut,
    });
    if (okImg) {
      return { assetPath: imgOut, assetType: 'image', aiImageFailed: false };
    }
    aiImageFailed = true;
  }

  // Tier 3: Guaranteed Thematic High-Res Artwork
  await generateProceduralSceneImage({
    scene,
    aspectRatio,
    template,
    outputPath: imgOut,
  });
  return { assetPath: imgOut, assetType: 'image', aiImageFailed };
}

/**
 * Generates clean, atmospheric royalty-free ambient background music via FFmpeg.
 */
export async function generateAmbientMusicTrack(params: {
  mood: VideoMusicMood;
  durationSec: number;
  outputPath: string;
}): Promise<string | null> {
  if (params.mood === 'none') return null;

  const dur = Math.max(4, Math.ceil(params.durationSec) + 2);
  let expr = '';
  switch (params.mood) {
    case 'emotional':
      // Warm soft pad in A minor
      expr =
        '0.22*sin(2*PI*220*t)*(0.6+0.4*sin(2*PI*0.18*t))+0.16*sin(2*PI*261.63*t)+0.12*sin(2*PI*329.63*t)';
      break;
    case 'upbeat':
      // Energetic pulse pad in C major
      expr =
        '0.20*sin(2*PI*261.63*t)*(0.5+0.5*sin(2*PI*2.0*t))+0.15*sin(2*PI*392.0*t)+0.12*sin(2*PI*523.25*t)';
      break;
    case 'tech':
      // Modern ambient synth arpeggio texture
      expr =
        '0.18*sin(2*PI*196*t)+0.14*sin(2*PI*293.66*t)*(0.5+0.5*sin(2*PI*1.5*t))+0.10*sin(2*PI*440*t)';
      break;
    case 'suspense':
      // Deep low tension drone
      expr =
        '0.26*sin(2*PI*98*t)+0.18*sin(2*PI*103.83*t)*(0.5+0.5*sin(2*PI*0.35*t))+0.10*sin(2*PI*146.83*t)';
      break;
    case 'cinematic':
    default:
      // Wide orchestral drone pad in D minor
      expr =
        '0.24*sin(2*PI*146.83*t)*(0.65+0.35*sin(2*PI*0.15*t))+0.16*sin(2*PI*220*t)+0.12*sin(2*PI*349.23*t)';
      break;
  }

  await execFileAsync('ffmpeg', [
    '-y',
    '-f',
    'lavfi',
    '-i',
    `aevalsrc=${expr}:d=${dur}:s=44100`,
    '-af',
    `lowpass=f=900,afade=t=in:st=0:d=1.2,afade=t=out:st=${Math.max(1, dur - 1.5)}:d=1.5`,
    '-c:a',
    'aac',
    '-b:a',
    '128k',
    params.outputPath,
  ]);

  return fs.existsSync(params.outputPath) ? params.outputPath : null;
}

/**
 * Generates an atmospheric Intro or Outro title card PNG via SVG + ImageMagick.
 */
export async function generateTemplateTitleCardImage(params: {
  title: string;
  subtitle: string;
  aspectRatio: VideoAspectRatio;
  template: VideoTemplateInfo;
  outputPath: string;
}): Promise<void> {
  const { width: W, height: H } = getTargetImageDimensions(params.aspectRatio);
  const escapeXml = (s: string) =>
    s
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');

  const safeTitle = escapeXml(params.title.slice(0, 56));
  const safeSub = escapeXml(params.subtitle.slice(0, 72));
  const titleFontSize = Math.round(Math.min(W, H) * 0.056);
  const subFontSize = Math.round(Math.min(W, H) * 0.028);

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}">
    <defs>
      <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="${params.template.bgDarkHex}" />
        <stop offset="100%" stop-color="#020617" />
      </linearGradient>
      <radialGradient id="glow" cx="0.5" cy="0.5" r="0.55">
        <stop offset="0%" stop-color="${params.template.accentHex}" stop-opacity="0.45" />
        <stop offset="100%" stop-color="${params.template.bgDarkHex}" stop-opacity="0" />
      </radialGradient>
    </defs>
    <rect width="${W}" height="${H}" fill="url(#bg)" />
    <rect width="${W}" height="${H}" fill="url(#glow)" />
    <rect x="${Math.round(W * 0.08)}" y="${Math.round(H * 0.14)}" width="${Math.round(W * 0.84)}" height="${Math.round(H * 0.72)}" rx="18" fill="none" stroke="${params.template.secondaryHex}" stroke-opacity="0.35" stroke-width="2" />
    <rect x="${Math.round(W * 0.43)}" y="${Math.round(H * 0.33)}" width="${Math.round(W * 0.14)}" height="4" rx="2" fill="${params.template.secondaryHex}" />
    <text x="50%" y="49%" text-anchor="middle" fill="#ffffff" font-family="Noto Sans Bengali, sans-serif" font-weight="bold" font-size="${titleFontSize}">${safeTitle}</text>
    <text x="50%" y="59%" text-anchor="middle" fill="#cbd5e1" font-family="Noto Sans Bengali, sans-serif" font-size="${subFontSize}">${safeSub}</text>
  </svg>`;

  renderSvgToPngFile(svg, params.outputPath);
}
