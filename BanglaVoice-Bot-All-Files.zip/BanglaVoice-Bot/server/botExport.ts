import { execFile } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { promisify } from 'node:util';

const execFileAsync = promisify(execFile);

export interface BotExportArchive {
  zipPath: string;
  filename: string;
  fileSizeBytes: number;
  fileCount: number;
}

const DEPLOY_GUIDE_TEXT = `============================================================
BanglaVoice Bot Studio — Unified All-in-One Source Package
Developer: বেলাল হোসেন (Belal Hossain)
============================================================

এই একটিমাত্র ZIP ফাইলের ভেতরে 'BanglaVoice-Bot/' ফোল্ডারের অধীনে
আপনার সমস্ত বট ফাইল (Telegram Bot + Voice Studio + Voice Demo +
AI Video Generator + Smart Video Editor + Admin Panel + Auto Payment)
একত্রিত করে রাখা হয়েছে।

১) লোকাল কম্পিউটার বা VPS-এ চালাতে:
   - Node.js 22+ এবং FFmpeg ইনস্টল করুন।
   - 'BanglaVoice-Bot/' ফোল্ডারে ঢুকে .env.example থেকে .env তৈরি করুন:
       GEMINI_API_KEY=...
       TELEGRAM_BOT_TOKEN=...
       TELEGRAM_ADMIN_IDS=7867755382
   - কমান্ড চালান:
       npm install
       npm run build
       npm start

২) Render / Railway / Fly.io-তে ২৪ ঘণ্টা ফ্রি/ক্লাউড চালাতে:
   - Dockerfile অথবা render.yaml ব্যবহার করুন।
   - Environment Variables সেট করে Deploy করুন।
   - Deploy হওয়ার পর Admin Panel -> Webhook সেট (24/7) বাটনে ক্লিক করুন
     অথবা /api/health URL-টি UptimeRobot-এ যুক্ত করুন।

নিরাপত্তার জন্য কোনো ব্যক্তিগত API Key বা ডাটাবেস পাসওয়ার্ড এই প্যাকেজে
রাখা হয়নি — আপনার সার্ভারের Environment Variables (.env)-এ সেট করুন।
`;

/**
 * Keeps ONE single canonical ZIP package in ONE fixed folder (`data/bot-package/BanglaVoice-Bot-All-Files.zip`),
 * removes any older scattered ZIP archives, and puts all project files cleanly inside one root folder
 * `BanglaVoice-Bot/` so every update stays unified in one place.
 */
export async function buildBotSourcePackageZip(): Promise<BotExportArchive> {
  const rootDir = process.cwd();
  const packageDir = path.join(rootDir, 'data', 'bot-package');
  fs.mkdirSync(packageDir, { recursive: true });

  const filename = 'BanglaVoice-Bot-All-Files.zip';
  const zipPath = path.join(packageDir, filename);

  // Clean any legacy or duplicate ZIP archives so only ONE canonical ZIP exists
  for (const oldName of fs.readdirSync(packageDir)) {
    if (oldName.endsWith('.zip') || oldName.endsWith('.txt')) {
      fs.unlinkSync(path.join(packageDir, oldName));
    }
  }
  const legacyTmpDir = path.join(os.tmpdir(), 'banglavoice-bot-export');
  if (fs.existsSync(legacyTmpDir)) {
    fs.rmSync(legacyTmpDir, { recursive: true, force: true });
  }

  const guidePath = path.join(packageDir, 'DEPLOY_GUIDE.txt');
  fs.writeFileSync(guidePath, DEPLOY_GUIDE_TEXT, 'utf-8');

  const pyScript = `
import os, sys, zipfile

root = sys.argv[1]
out_zip = sys.argv[2]
guide = sys.argv[3]
bundle_root = 'BanglaVoice-Bot'

include_files = [
  'package.json',
  'package-lock.json',
  'tsconfig.json',
  'vite.config.ts',
  'index.html',
  'metadata.json',
  'Dockerfile',
  'render.yaml',
  '.dockerignore',
  '.env.example',
  'server.ts',
]

include_dirs = ['server', 'src']
skip_names = {'.DS_Store', '.env', '.env.local', 'Thumbs.db'}

count = 0
with zipfile.ZipFile(out_zip, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as zf:
    zf.write(guide, f'{bundle_root}/DEPLOY_GUIDE.txt')
    count += 1
    for f in include_files:
        fp = os.path.join(root, f)
        if os.path.isfile(fp):
            zf.write(fp, f'{bundle_root}/{f}')
            count += 1
    for d in include_dirs:
        dp = os.path.join(root, d)
        if not os.path.isdir(dp):
            continue
        for cur_root, dirs, files in os.walk(dp):
            dirs[:] = [x for x in dirs if x not in ('node_modules', 'dist', '.git')]
            for fn in files:
                if fn in skip_names or fn.endswith('.log') or fn.endswith('.zip'):
                    continue
                full = os.path.join(cur_root, fn)
                rel = os.path.relpath(full, root).replace('\\\\', '/')
                zf.write(full, f'{bundle_root}/{rel}')
                count += 1
print(count)
`.trim();

  try {
    const { stdout } = await execFileAsync('python3', [
      '-c',
      pyScript,
      rootDir,
      zipPath,
      guidePath,
    ]);

    const fileCount = Number.parseInt(stdout.trim(), 10) || 0;
    const stat = fs.statSync(zipPath);

    return {
      zipPath,
      filename,
      fileSizeBytes: stat.size,
      fileCount,
    };
  } finally {
    if (fs.existsSync(guidePath)) {
      fs.unlinkSync(guidePath);
    }
  }
}
