import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';
import { execFile } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { promisify } from 'node:util';
import { notifyAdminsOnVoiceCompleted } from './adminNotify.ts';
import {
  mergeChunksToMp3WithFfmpeg,
  normalizeChunkWavWithFfmpeg,
  probeAudioDurationSec,
} from './audio.ts';
import {
  isModelExhausted,
  isQuotaOrRateLimitError,
  markModelExhausted,
  prepareBanglaScript,
  synthesizeRawBanglaChunkWav,
} from './gemini.ts';
import { botStore } from './store.ts';
import type {
  BotUser,
  VideoMusicMood,
  VoiceGeneration,
  VoiceJob,
  VoicePersona,
} from './types.ts';
import { generateAmbientMusicTrack } from './videoProviders.ts';
import { VOICE_CATALOG, chunkBanglaScript, getVoiceById } from './voices.ts';

const execFileAsync = promisify(execFile);

const VOICE_ALIASES: Record<string, string> = {
  // Male
  arif: 'male-arif',
  আরিফ: 'male-arif',
  tanvir: 'male-tanvir',
  তানভীর: 'male-tanvir',
  sadiq: 'male-sadiq',
  সাদিক: 'male-sadiq',
  nafis: 'male-nafis',
  নাফিস: 'male-nafis',
  rahat: 'male-emotional',
  রাহাত: 'male-emotional',
  emotional: 'male-emotional',
  ইমোশনাল: 'male-emotional',
  aryan: 'male-viral-emotional',
  viral: 'male-viral-emotional',
  আরিয়ান: 'male-viral-emotional',
  ভাইরাল: 'male-viral-emotional',
  // Female
  nusrat: 'female-nusrat',
  নুসরাত: 'female-nusrat',
  tasnim: 'female-tasnim',
  তাসনিম: 'female-tasnim',
  mahira: 'female-mahira',
  মাহিরা: 'female-mahira',
  sumaiya: 'female-sumaiya',
  সুমাইয়া: 'female-sumaiya',
  mehek: 'female-viral-emotional',
  মেহেক: 'female-viral-emotional',
  // Cartoon
  oggy: 'cartoon-oggy',
  অগি: 'cartoon-oggy',
  ওগি: 'cartoon-oggy',
  tom: 'cartoon-tomjerry',
  jerry: 'cartoon-tomjerry',
  tomjerry: 'cartoon-tomjerry',
  টম: 'cartoon-tomjerry',
  জেরি: 'cartoon-tomjerry',
  doraemon: 'cartoon-doraemon',
  ডোরেমন: 'cartoon-doraemon',
  ডরিমন: 'cartoon-doraemon',
  nobita: 'cartoon-nobita',
  নোবিতা: 'cartoon-nobita',
  নবিতা: 'cartoon-nobita',
  shinchan: 'cartoon-shinchan',
  শিনচ্যান: 'cartoon-shinchan',
  সিনচ্যান: 'cartoon-shinchan',
};

export function resolveVoiceFromCommandToken(
  input: string,
  fallbackId = 'male-arif',
): VoicePersona {
  const clean = input.trim().toLowerCase();
  if (!clean) return getVoiceById(fallbackId);

  const exact = VOICE_CATALOG.find(
    (v) =>
      v.id.toLowerCase() === clean ||
      v.nameBn.toLowerCase() === clean ||
      v.nameEn.toLowerCase() === clean,
  );
  if (exact) return exact;

  if (VOICE_ALIASES[clean]) {
    return getVoiceById(VOICE_ALIASES[clean]);
  }

  for (const [alias, id] of Object.entries(VOICE_ALIASES)) {
    if (clean.includes(alias)) {
      return getVoiceById(id);
    }
  }

  return getVoiceById(fallbackId);
}

export function resolveMusicMoodFromToken(input: string): VideoMusicMood {
  const clean = input.trim().toLowerCase();
  if (!clean || /(?:none|off|no|নাই|বন্ধ|ছাড়া)/i.test(clean)) return 'none';
  if (/(?:emotion|sad|ইমোশনাল|দুঃখ|কষ্ট)/i.test(clean)) return 'emotional';
  if (/(?:upbeat|funny|cartoon|happy|ফানি|কার্টুন|হ্যাপি|মজার)/i.test(clean))
    return 'upbeat';
  if (/(?:tech|ai|টেক)/i.test(clean)) return 'tech';
  if (/(?:suspense|thriller|horror|ভয়|সাসপেন্স|রহস্য)/i.test(clean))
    return 'suspense';
  if (/(?:cinematic|epic|সিনেম্যাটিক|ডকু)/i.test(clean)) return 'cinematic';
  return 'cinematic';
}

export interface ParsedDialogueLine {
  speakerLabel: string;
  voice: VoicePersona;
  text: string;
}

/**
 * Parses multi-speaker script lines like:
 *   ডোরেমন: হ্যালো নোবিতা!
 *   নোবিতা: চলো শুরু করি।
 */
export function parseMultiVoiceDialogue(
  rawScript: string,
  fallbackVoiceId: string,
): ParsedDialogueLine[] {
  const rawLines = rawScript
    .replace(/\r\n/g, '\n')
    .split('\n')
    .map((l) => l.trim())
    .filter(Boolean);

  const parsed: ParsedDialogueLine[] = [];
  let lastVoice = getVoiceById(fallbackVoiceId);
  let lastLabel = lastVoice.nameBn;

  for (const line of rawLines) {
    const match = line.match(/^([^:：\-\n]{1,32})\s*[:：]\s*(.+)$/);
    if (match) {
      const candidateLabel = match[1].trim();
      const body = match[2].trim();
      const matchedVoice = resolveVoiceFromCommandToken(
        candidateLabel,
        lastVoice.id,
      );
      // Verify candidateLabel actually maps to a voice if possible
      const explicitlyMatched =
        candidateLabel.toLowerCase() === matchedVoice.nameBn.toLowerCase() ||
        candidateLabel.toLowerCase() === matchedVoice.nameEn.toLowerCase() ||
        Boolean(
          Object.keys(VOICE_ALIASES).find((a) =>
            candidateLabel.toLowerCase().includes(a),
          ),
        );

      if (explicitlyMatched) {
        lastVoice = matchedVoice;
        lastLabel = candidateLabel;
        if (body) {
          parsed.push({ speakerLabel: candidateLabel, voice: matchedVoice, text: body });
        }
        continue;
      }
    }

    parsed.push({
      speakerLabel: lastLabel,
      voice: lastVoice,
      text: line,
    });
  }

  return parsed;
}

/**
 * Mixes a clean ambient background music mood softly (14% volume) underneath an MP3 voice track.
 */
async function mixVoiceMp3WithBgm(params: {
  voiceMp3Path: string;
  bgmMood: VideoMusicMood;
  outputMp3Path: string;
  workDir: string;
}): Promise<void> {
  if (params.bgmMood === 'none') {
    fs.copyFileSync(params.voiceMp3Path, params.outputMp3Path);
    return;
  }

  const dur = await probeAudioDurationSec(params.voiceMp3Path);
  const bgmPath = path.join(params.workDir, 'bgm.aac');
  const generated = await generateAmbientMusicTrack({
    mood: params.bgmMood,
    durationSec: dur + 1.5,
    outputPath: bgmPath,
  });

  if (!generated || !fs.existsSync(bgmPath)) {
    fs.copyFileSync(params.voiceMp3Path, params.outputMp3Path);
    return;
  }

  await execFileAsync('ffmpeg', [
    '-y',
    '-i',
    params.voiceMp3Path,
    '-i',
    bgmPath,
    '-filter_complex',
    '[0:a]volume=1.0[v];[1:a]volume=0.14[m];[v][m]amix=inputs=2:duration=first:dropout_transition=2[out]',
    '-map',
    '[out]',
    '-ar',
    '24000',
    '-ac',
    '1',
    '-c:a',
    'libmp3lame',
    '-b:a',
    '128k',
    params.outputMp3Path,
  ]);
}

export async function synthesizeMultiVoiceDialogueMp3(params: {
  user: BotUser;
  lines: ParsedDialogueLine[];
  bgmMood: VideoMusicMood;
  source: 'telegram' | 'simulator';
}): Promise<{ generation: VoiceGeneration; filePath: string }> {
  const genId = `dlg-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
  const workDir = botStore.getJobWorkDir(genId);
  const cfg = botStore.getConfig();

  try {
    const chunkWavs: string[] = [];
    let partIdx = 0;

    for (const item of params.lines) {
      const prep = await prepareBanglaScript(
        item.text,
        false,
        cfg.autoNormalizeBangla,
        cfg.smartEnglishToBangla,
      );
      const spoken = (prep.spokenScript || item.text).trim();
      if (!spoken) continue;

      const subChunks = chunkBanglaScript(spoken, 620);
      for (const sc of subChunks) {
        const rawWav = await synthesizeRawBanglaChunkWav({
          textChunk: sc,
          voice: item.voice,
          speed: item.voice.defaultSpeed,
          pitch: item.voice.defaultPitch,
          ttsModel: cfg.ttsModel,
        });
        const normPath = path.join(
          workDir,
          `turn_${String(partIdx).padStart(4, '0')}.wav`,
        );
        await normalizeChunkWavWithFfmpeg({
          rawWavBuffer: rawWav,
          outputWavPath: normPath,
          speed: item.voice.defaultSpeed,
          pitchSemitones: item.voice.defaultPitch,
        });
        chunkWavs.push(normPath);
        partIdx += 1;
      }
    }

    if (chunkWavs.length === 0) {
      throw new Error('কোনো পাঠযোগ্য সংলাপ পাওয়া যায়নি।');
    }

    const merged = await mergeChunksToMp3WithFfmpeg({
      chunkWavPaths: chunkWavs,
      outputDir: workDir,
      baseFilename: `${genId}_voice`,
    });

    const rawVoiceMp3 = merged[0].filePath;
    const finalMp3Path = botStore.getAudioFilePath(`${genId}.mp3`);

    await mixVoiceMp3WithBgm({
      voiceMp3Path: rawVoiceMp3,
      bgmMood: params.bgmMood,
      outputMp3Path: finalMp3Path,
      workDir,
    });

    const stat = fs.statSync(finalMp3Path);
    const durSec = await probeAudioDurationSec(finalMp3Path);
    const audioUrl = `/api/audio/${genId}.mp3`;
    const speakers = Array.from(
      new Set(params.lines.map((l) => `${l.voice.emoji} ${l.voice.nameBn}`)),
    );
    const firstVoice = params.lines[0]?.voice ?? getVoiceById('cartoon-doraemon');

    const generation: VoiceGeneration = {
      id: genId,
      userId: params.user.id,
      userName: params.user.firstName || params.user.username,
      voiceId: firstVoice.id,
      voiceNameBn: `মাল্টি-ডায়ালগ (${speakers.slice(0, 3).join(' · ')})`,
      category: firstVoice.category,
      script: params.lines
        .map((l) => `${l.speakerLabel}: ${l.text}`)
        .join('\n'),
      spokenScript: params.lines.map((l) => l.text).join(' '),
      speed: 1.0,
      pitch: 0,
      durationSec: durSec,
      fileSizeBytes: stat.size,
      audioUrl,
      audioParts: [
        {
          url: audioUrl,
          filename: `${genId}.mp3`,
          durationSec: durSec,
          fileSizeBytes: stat.size,
        },
      ],
      totalChunks: chunkWavs.length,
      costCharged: 0,
      source: params.source,
      createdAt: new Date().toISOString(),
    };

    botStore.recordGeneration(generation);

    // Notify channel (zero user info) & admin inbox
    const synthJob: VoiceJob = {
      id: genId,
      userId: params.user.id,
      userName: generation.userName,
      voiceId: generation.voiceId,
      voiceNameBn: generation.voiceNameBn,
      category: generation.category,
      script: generation.script,
      spokenScript: generation.spokenScript,
      chunks: [],
      completedChunkFiles: {},
      speed: 1.0,
      pitch: 0,
      ttsModel: cfg.ttsModel,
      status: 'completed',
      statusText: 'Completed',
      currentPart: chunkWavs.length,
      totalParts: chunkWavs.length,
      retryCount: 0,
      source: params.source,
      generationId: genId,
      outputParts: generation.audioParts,
      createdAt: generation.createdAt,
      updatedAt: generation.createdAt,
    };
    notifyAdminsOnVoiceCompleted(synthJob, generation).catch(() => {});

    return { generation, filePath: finalMp3Path };
  } finally {
    fs.rmSync(workDir, { recursive: true, force: true });
  }
}

export async function synthesizeVoiceWithBgmMp3(params: {
  user: BotUser;
  voice: VoicePersona;
  script: string;
  bgmMood: VideoMusicMood;
  speed: number;
  pitch: number;
  source: 'telegram' | 'simulator';
}): Promise<{ generation: VoiceGeneration; filePath: string }> {
  const genId = `vbgm-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
  const workDir = botStore.getJobWorkDir(genId);
  const cfg = botStore.getConfig();

  try {
    const prep = await prepareBanglaScript(
      params.script,
      false,
      cfg.autoNormalizeBangla,
      cfg.smartEnglishToBangla,
    );
    const spoken = (prep.spokenScript || params.script).trim();
    const chunks = chunkBanglaScript(spoken, 620);
    if (chunks.length === 0) {
      throw new Error('ভয়েস তৈরির মতো বৈধ স্ক্রিপ্ট পাওয়া যায়নি।');
    }

    const chunkWavs: string[] = [];
    for (let i = 0; i < chunks.length; i++) {
      const rawWav = await synthesizeRawBanglaChunkWav({
        textChunk: chunks[i],
        voice: params.voice,
        speed: params.speed,
        pitch: params.pitch,
        ttsModel: cfg.ttsModel,
      });
      const normPath = path.join(workDir, `part_${i}.wav`);
      await normalizeChunkWavWithFfmpeg({
        rawWavBuffer: rawWav,
        outputWavPath: normPath,
        speed: params.speed,
        pitchSemitones: params.pitch,
      });
      chunkWavs.push(normPath);
    }

    const merged = await mergeChunksToMp3WithFfmpeg({
      chunkWavPaths: chunkWavs,
      outputDir: workDir,
      baseFilename: `${genId}_voice`,
    });

    const finalMp3Path = botStore.getAudioFilePath(`${genId}.mp3`);
    await mixVoiceMp3WithBgm({
      voiceMp3Path: merged[0].filePath,
      bgmMood: params.bgmMood,
      outputMp3Path: finalMp3Path,
      workDir,
    });

    const stat = fs.statSync(finalMp3Path);
    const durSec = await probeAudioDurationSec(finalMp3Path);
    const audioUrl = `/api/audio/${genId}.mp3`;
    const cost = botStore.getVoiceEffectiveCost(params.voice.id);

    const generation: VoiceGeneration = {
      id: genId,
      userId: params.user.id,
      userName: params.user.firstName || params.user.username,
      voiceId: params.voice.id,
      voiceNameBn:
        params.bgmMood === 'none'
          ? `${params.voice.emoji} ${params.voice.nameBn}`
          : `${params.voice.emoji} ${params.voice.nameBn} + ${params.bgmMood} BGM`,
      category: params.voice.category,
      script: params.script,
      spokenScript: spoken,
      speed: params.speed,
      pitch: params.pitch,
      durationSec: durSec,
      fileSizeBytes: stat.size,
      audioUrl,
      audioParts: [
        {
          url: audioUrl,
          filename: `${genId}.mp3`,
          durationSec: durSec,
          fileSizeBytes: stat.size,
        },
      ],
      totalChunks: chunks.length,
      costCharged: cost,
      source: params.source,
      createdAt: new Date().toISOString(),
    };

    botStore.recordGeneration(generation);

    const synthJob: VoiceJob = {
      id: genId,
      userId: params.user.id,
      userName: generation.userName,
      voiceId: generation.voiceId,
      voiceNameBn: generation.voiceNameBn,
      category: generation.category,
      script: generation.script,
      spokenScript: generation.spokenScript,
      chunks,
      completedChunkFiles: {},
      speed: params.speed,
      pitch: params.pitch,
      ttsModel: cfg.ttsModel,
      status: 'completed',
      statusText: 'Completed',
      currentPart: chunks.length,
      totalParts: chunks.length,
      retryCount: 0,
      source: params.source,
      generationId: genId,
      outputParts: generation.audioParts,
      createdAt: generation.createdAt,
      updatedAt: generation.createdAt,
    };
    notifyAdminsOnVoiceCompleted(synthJob, generation).catch(() => {});

    return { generation, filePath: finalMp3Path };
  } finally {
    fs.rmSync(workDir, { recursive: true, force: true });
  }
}

export interface ViralSeoPack {
  titles: string[];
  description: string;
  hashtags: string[];
}

export async function generateViralSeoPack(
  topicOrScript: string,
): Promise<ViralSeoPack> {
  const cleanTopic = topicOrScript.trim().slice(0, 600);
  const apiKey = process.env.GEMINI_API_KEY?.trim();

  if (apiKey) {
    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: { headers: { 'User-Agent': 'aistudio-build' } },
    });
    for (const model of ['gemini-4-hydrogen', 'gemini-2.5-flash']) {
      if (isModelExhausted(model)) continue;
      try {
        const res = await ai.models.generateContent({
          model,
          contents: `Topic/Script: "${cleanTopic}"`,
          config: {
            thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
            systemInstruction:
              'You are a top Bangladeshi YouTube, Facebook Reels & TikTok growth strategist. Given a video topic or script, return JSON with:\n' +
              '1. "titles": array of 3 high-CTR catchy Bengali titles (under 75 chars each).\n' +
              '2. "description": 2-3 engaging Bengali sentences ready for video upload.\n' +
              '3. "hashtags": array of 12 viral Bangla + English hashtags (each starting with #).',
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                titles: { type: Type.ARRAY, items: { type: Type.STRING } },
                description: { type: Type.STRING },
                hashtags: { type: Type.ARRAY, items: { type: Type.STRING } },
              },
              required: ['titles', 'description', 'hashtags'],
            },
          },
        });

        const parsed = JSON.parse((res.text ?? '{}').trim()) as Partial<ViralSeoPack>;
        if (parsed.titles?.length && parsed.description) {
          return {
            titles: parsed.titles.slice(0, 3),
            description: parsed.description,
            hashtags: (parsed.hashtags ?? []).slice(0, 15),
          };
        }
      } catch (err) {
        if (isQuotaOrRateLimitError(err)) {
          markModelExhausted(model, err);
          continue;
        }
        break;
      }
    }
  }

  // Smart fallback if Gemini quota is exhausted
  const shortTopic = cleanTopic.replace(/\s+/g, ' ').slice(0, 48) || 'অসাধারণ বাংলা গল্প';
  return {
    titles: [
      `${shortTopic} | হৃদয়ছোঁয়া বাংলা ভিডিও`,
      `অবিশ্বাস্য! ${shortTopic} — পুরোটা না দেখলে মিস করবেন`,
      `${shortTopic} (AI ভয়েস ও প্রো এডিটিং)`,
    ],
    description:
      `${shortTopic} নিয়ে তৈরি করা হয়েছে আমাদের আজকের বিশেষ প্রযোজনা। ভিডিওটি ভালো লাগলে লাইক, শেয়ার ও সাবস্ক্রাইব করে সাথেই থাকুন!`,
    hashtags: [
      '#BanglaVideo',
      '#BanglaVoice',
      '#BanglaReels',
      '#TrendingBD',
      '#ViralBangla',
      '#BanglaStory',
      '#EmotionalBangla',
      '#ShortsBD',
      '#AIVideoBangla',
      '#Bangladesh',
      '#BengaliContent',
      '#ForYou',
    ],
  };
}
