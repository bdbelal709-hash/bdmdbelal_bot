import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';
import {
  isModelExhausted,
  isQuotaOrRateLimitError,
  markModelExhausted,
} from './gemini.ts';
import type {
  VideoMusicMood,
  VideoScene,
  VideoTemplateId,
  VideoTemplateInfo,
} from './types.ts';
import { chunkBanglaScript } from './voices.ts';

function getAiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey) return null;
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

async function generateJsonWithTextModelFallback(
  ai: GoogleGenAI,
  request: {
    contents: Parameters<GoogleGenAI['models']['generateContent']>[0]['contents'];
    config: Parameters<GoogleGenAI['models']['generateContent']>[0]['config'];
  },
) {
  const models = ['gemini-4-hydrogen', 'gemini-2.5-flash'];
  let lastErr: unknown = null;
  for (const model of models) {
    if (isModelExhausted(model)) continue;
    try {
      return await ai.models.generateContent({
        model,
        contents: request.contents,
        config: request.config,
      });
    } catch (err) {
      lastErr = err;
      if (isQuotaOrRateLimitError(err)) {
        markModelExhausted(model, err);
        continue;
      }
      throw err;
    }
  }
  throw lastErr ?? new Error('No LLM model available');
}

export const VIDEO_TEMPLATES: VideoTemplateInfo[] = [
  {
    id: 'cinematic_doc',
    nameBn: 'সিনেম্যাটিক ডকুমেন্টারি',
    nameEn: 'Cinematic Documentary',
    taglineBn: 'গভীর রঙ, স্মুথ জুম ও এপিক স্টোরিটেলিং লেআউট',
    badgeText: 'FILM',
    accentHex: '#0f766e',
    secondaryHex: '#f59e0b',
    bgDarkHex: '#0b1320',
    subtitleFont: 'Noto Sans Bengali',
    ffmpegColorFilter: 'eq=contrast=1.10:saturation=1.12:brightness=-0.02',
  },
  {
    id: 'viral_reels',
    nameBn: 'ভাইরাল রিলস / শর্টস',
    nameEn: 'Viral Reels & Shorts',
    taglineBn: 'হাই-কনট্রাস্ট গোল্ড ক্যাপশন, দ্রুতগতির সিন ও পপ লুক',
    badgeText: 'REELS',
    accentHex: '#0d9488',
    secondaryHex: '#fbbf24',
    bgDarkHex: '#111827',
    subtitleFont: 'Noto Sans Bengali',
    ffmpegColorFilter: 'eq=contrast=1.14:saturation=1.22:brightness=0.01',
  },
  {
    id: 'tech_explainer',
    nameBn: 'টেক ও এআই এক্সপ্লেইনার',
    nameEn: 'Tech & AI Explainer',
    taglineBn: 'সাইবার-টিল গ্রিড, ক্রিস্প গ্রাফিক্স ও মডার্ন ক্যাপশন',
    badgeText: 'TECH',
    accentHex: '#0284c7',
    secondaryHex: '#2dd4bf',
    bgDarkHex: '#091526',
    subtitleFont: 'Noto Sans Bengali',
    ffmpegColorFilter: 'eq=contrast=1.08:saturation=1.15:gamma=1.02',
  },
  {
    id: 'news_fact',
    nameBn: 'নিউজ ও ইনফো ব্রিফিং',
    nameEn: 'News & Fact Briefing',
    taglineBn: 'ব্রেকিং লোয়ার-থার্ড ব্যান্ড ও প্রফেশনাল ব্রডকাস্ট টোন',
    badgeText: 'NEWS',
    accentHex: '#be123c',
    secondaryHex: '#38bdf8',
    bgDarkHex: '#0f172a',
    subtitleFont: 'Noto Sans Bengali',
    ffmpegColorFilter: 'eq=contrast=1.06:saturation=1.04',
  },
  {
    id: 'emotional_story',
    nameBn: 'ইমোশনাল ও ইসলামিক / মোটিভেশন',
    nameEn: 'Emotional & Motivational',
    taglineBn: 'উষ্ণ সোনালি আভা, নরম ট্রানজিশন ও সেরিফ ক্যালিগ্রাফি',
    badgeText: 'STORY',
    accentHex: '#b45309',
    secondaryHex: '#fde68a',
    bgDarkHex: '#181310',
    subtitleFont: 'Noto Serif Bengali',
    ffmpegColorFilter: 'eq=contrast=1.05:saturation=0.96:brightness=0.01',
  },
];

export function getVideoTemplate(id?: string): VideoTemplateInfo {
  return (
    VIDEO_TEMPLATES.find((t) => t.id === id) ?? VIDEO_TEMPLATES[0]
  );
}

/**
 * Mode 1: Prompt -> Complete Natural Bangla Script + Title + Music Mood
 */
export async function generateBanglaVideoScriptFromPrompt(params: {
  prompt: string;
  templateId?: VideoTemplateId;
  durationHintSec?: number;
}): Promise<{
  title: string;
  banglaScript: string;
  musicMood: VideoMusicMood;
  sceneCountEstimate: number;
}> {
  const ai = getAiClient();
  const tpl = getVideoTemplate(params.templateId);
  const targetSec = params.durationHintSec && params.durationHintSec > 0
    ? params.durationHintSec
    : 45;
  const approxWords = Math.max(40, Math.round((targetSec / 60) * 135));

  if (!ai) {
    return {
      title: params.prompt.slice(0, 50) || 'বাংলা AI ভিডিও',
      banglaScript: params.prompt,
      musicMood: 'cinematic',
      sceneCountEstimate: 4,
    };
  }

  try {
    const response = await generateJsonWithTextModelFallback(ai, {
      contents:
        `User Video Prompt: "${params.prompt.trim()}"\n` +
        `Selected Visual Template: ${tpl.nameEn} (${tpl.nameBn})\n` +
        `Target Spoken Length: ~${approxWords} words (approx ${targetSec} seconds).`,
      config: {
        thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
        systemInstruction:
          'You are an award-winning Bangladeshi scriptwriter & AI film director. Write a gripping, natural, spoken Bangladeshi Bangla video narration script based on the user prompt.\n\nRULES:\n1. banglaScript MUST be 100% fluent Bengali script with ZERO English/Latin letters (render brand/tech names phonetically in Bangla, e.g., চ্যাটজিপিটি, গুগল, এআই).\n2. Start with a strong 1-sentence hook that captures viewer attention immediately.\n3. Flow smoothly sentence by sentence using natural Bangla punctuation (। and ,) for AI voice synthesis.\n4. Return a short catchy Bangla title and the best matching background music mood from: cinematic, emotional, upbeat, tech, suspense.',
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            banglaScript: { type: Type.STRING },
            musicMood: { type: Type.STRING },
            sceneCountEstimate: { type: Type.NUMBER },
          },
          required: ['title', 'banglaScript', 'musicMood', 'sceneCountEstimate'],
        },
      },
    });

    const parsed = JSON.parse((response.text ?? '{}').trim()) as {
      title?: string;
      banglaScript?: string;
      musicMood?: string;
      sceneCountEstimate?: number;
    };

    const allowedMoods: VideoMusicMood[] = [
      'none',
      'cinematic',
      'emotional',
      'upbeat',
      'tech',
      'suspense',
    ];
    const rawMood = (parsed.musicMood ?? 'cinematic').toLowerCase() as VideoMusicMood;

    return {
      title: parsed.title?.trim() || params.prompt.slice(0, 48),
      banglaScript: parsed.banglaScript?.trim() || params.prompt.trim(),
      musicMood: allowedMoods.includes(rawMood) ? rawMood : 'cinematic',
      sceneCountEstimate: Math.max(2, Math.round(parsed.sceneCountEstimate ?? 4)),
    };
  } catch {
    return {
      title: params.prompt.slice(0, 48) || 'বাংলা AI ভিডিও',
      banglaScript: params.prompt.trim(),
      musicMood: 'cinematic',
      sceneCountEstimate: 4,
    };
  }
}

function heuristicSceneFallback(segmentText: string, startIndex: number): VideoScene[] {
  const sentences = segmentText
    .split(/(?<=[।.!?])\s+/)
    .map((s) => s.trim())
    .filter(Boolean);

  const grouped: string[] = [];
  let buf = '';
  for (const s of sentences) {
    if ((buf + ' ' + s).trim().length <= 160) {
      buf = (buf + ' ' + s).trim();
    } else {
      if (buf) grouped.push(buf);
      buf = s;
    }
  }
  if (buf) grouped.push(buf);
  if (grouped.length === 0 && segmentText.trim()) {
    grouped.push(segmentText.trim());
  }

  const motions: VideoScene['motion'][] = [
    'zoom_in',
    'pan_right',
    'zoom_out',
    'pan_left',
  ];

  return grouped.map((txt, idx) => {
    const keywords = inferKeywordsFromBangla(txt);
    return {
      index: startIndex + idx,
      narrationBangla: txt,
      subtitleText: txt,
      visualPrompt: `Cinematic atmospheric visual depicting: ${keywords}, dramatic lighting, ultra-detailed editorial artwork, no text`,
      searchKeywords: keywords,
      emotion: 'dramatic',
      motion: motions[(startIndex + idx) % motions.length],
      transition: idx === 0 ? 'cut' : 'fade',
    };
  });
}

function inferKeywordsFromBangla(text: string): string {
  const lower = text.toLowerCase();
  if (/যুদ্ধ|সৈন্য|লড়াই|বিস্ফোরণ|আগুন|war|battle|army/.test(lower)) {
    return 'epic battle smoke dramatic sky';
  }
  if (/সমুদ্র|সাগর|নদী|পানি|বৃষ্টি|ঢেউ|ocean|sea|river|water/.test(lower)) {
    return 'deep ocean waves cinematic sea';
  }
  if (/প্রযুক্তি|এআই|রোবট|কম্পিউটার|ইন্টারনেট|বিজ্ঞান|কোড|tech|ai|digital/.test(lower)) {
    return 'futuristic technology circuit neural network';
  }
  if (/টাকা|অর্থ|ব্যবসা|বাজার|ব্যাংক|money|finance|business/.test(lower)) {
    return 'modern city skyline business finance';
  }
  if (/প্রকৃতি|পাহাড়|বন|গাছ|সূর্য|আকাশ|nature|mountain|forest|sky/.test(lower)) {
    return 'golden sunrise mountain forest nature';
  }
  if (/কষ্ট|হৃদয়|ভালোবাসা|পরিবার|মা|বাবা|স্বপ্ন|sad|love|dream|hope/.test(lower)) {
    return 'emotional golden hour silhouette hope';
  }
  return 'cinematic storytelling landscape dramatic atmosphere';
}

/**
 * Unlimited-Script Smart Scene Director:
 * Processes ANY script length in ~2200-char batches so zero lines are dropped.
 */
export async function planUnlimitedScenesFromScript(params: {
  script: string;
  title?: string;
  templateId?: VideoTemplateId;
}): Promise<VideoScene[]> {
  const fullScript = params.script.trim();
  if (!fullScript) return [];

  const batches =
    fullScript.length > 2200 ? chunkBanglaScript(fullScript, 2200) : [fullScript];

  const ai = getAiClient();
  const tpl = getVideoTemplate(params.templateId);
  const allScenes: VideoScene[] = [];

  for (let bIdx = 0; bIdx < batches.length; bIdx++) {
    const batchText = batches[bIdx];
    if (!ai) {
      allScenes.push(...heuristicSceneFallback(batchText, allScenes.length));
      continue;
    }

    try {
      const response = await generateJsonWithTextModelFallback(ai, {
        contents:
          `Video Title: ${params.title || 'Bangla Video'}\n` +
          `Template Style: ${tpl.nameEn}\n` +
          `Script Part ${bIdx + 1}/${batches.length}:\n"""\n${batchText}\n"""`,
        config: {
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
          systemInstruction:
            'You are an AI Video Scene Director. Break the provided Bangla script segment into consecutive visual scenes.\n\nCRITICAL RULES:\n1. Concatenate ALL narrationBangla fields in order MUST cover 100% of the script segment—DO NOT omit or summarize away any sentence!\n2. Keep each scene around 1–2 sentences (approx 4–10 seconds spoken) for dynamic visual pacing.\n3. For each scene, understand the true semantic meaning:\n   - War/conflict -> dramatic battle/fire visuals\n   - Ocean/water -> ocean/waves visuals\n   - Tech/AI -> futuristic technology/network visuals\n   - People/history/city -> relevant environment visuals\n   - Emotional -> warm moody emotional imagery\n4. visualPrompt: detailed English prompt for generating a clean cinematic frame with NO embedded text or watermarks.\n5. searchKeywords: 2–4 clean English stock-footage search keywords (e.g. "ocean waves sunset", "futuristic city neon", "programmer coding dark").\n6. emotion: one of dramatic, calm, happy, tense, informative, sad.\n7. motion: one of zoom_in, zoom_out, pan_left, pan_right, pulse.',
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              scenes: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    narrationBangla: { type: Type.STRING },
                    subtitleText: { type: Type.STRING },
                    visualPrompt: { type: Type.STRING },
                    searchKeywords: { type: Type.STRING },
                    emotion: { type: Type.STRING },
                    motion: { type: Type.STRING },
                  },
                  required: [
                    'narrationBangla',
                    'subtitleText',
                    'visualPrompt',
                    'searchKeywords',
                    'emotion',
                    'motion',
                  ],
                },
              },
            },
            required: ['scenes'],
          },
        },
      });

      const parsed = JSON.parse((response.text ?? '{}').trim()) as {
        scenes?: Array<{
          narrationBangla?: string;
          subtitleText?: string;
          visualPrompt?: string;
          searchKeywords?: string;
          emotion?: string;
          motion?: string;
        }>;
      };

      const rawScenes = parsed.scenes ?? [];
      if (rawScenes.length === 0) {
        allScenes.push(...heuristicSceneFallback(batchText, allScenes.length));
        continue;
      }

      const validEmotions: VideoScene['emotion'][] = [
        'dramatic',
        'calm',
        'happy',
        'tense',
        'informative',
        'sad',
      ];
      const validMotions: VideoScene['motion'][] = [
        'zoom_in',
        'zoom_out',
        'pan_left',
        'pan_right',
        'pulse',
      ];

      for (const s of rawScenes) {
        const narration = s.narrationBangla?.trim();
        if (!narration) continue;
        const emo = validEmotions.includes(s.emotion as VideoScene['emotion'])
          ? (s.emotion as VideoScene['emotion'])
          : 'dramatic';
        const mot = validMotions.includes(s.motion as VideoScene['motion'])
          ? (s.motion as VideoScene['motion'])
          : 'zoom_in';
        allScenes.push({
          index: allScenes.length,
          narrationBangla: narration,
          subtitleText: s.subtitleText?.trim() || narration,
          visualPrompt:
            s.visualPrompt?.trim() ||
            `Cinematic scene representing ${s.searchKeywords || 'story'}, atmospheric lighting, no text`,
          searchKeywords:
            s.searchKeywords?.trim() || inferKeywordsFromBangla(narration),
          emotion: emo,
          motion: mot,
          transition: allScenes.length === 0 ? 'cut' : 'fade',
        });
      }
    } catch {
      allScenes.push(...heuristicSceneFallback(batchText, allScenes.length));
    }
  }

  return allScenes;
}

/**
 * Mode 3: Voice File -> Multimodal Audio Understanding + Timestamped Scene Plan
 */
export async function transcribeAndPlanScenesFromAudio(params: {
  audioBuffer: Buffer;
  mimeType: string;
  totalDurationSec: number;
  templateId?: VideoTemplateId;
}): Promise<{
  title: string;
  transcriptBangla: string;
  musicMood: VideoMusicMood;
  scenes: VideoScene[];
}> {
  const ai = getAiClient();
  const tpl = getVideoTemplate(params.templateId);
  const totalSec = Math.max(2, params.totalDurationSec);

  if (ai && params.audioBuffer.length <= 18 * 1024 * 1024) {
    try {
      const response = await generateJsonWithTextModelFallback(ai, {
        contents: [
          {
            role: 'user',
            parts: [
              {
                inlineData: {
                  mimeType: params.mimeType || 'audio/mpeg',
                  data: params.audioBuffer.toString('base64'),
                },
              },
              {
                text: `Listen carefully to the full ${totalSec.toFixed(1)} second audio track. Transcribe what is spoken into natural Bangla script (transcriptBangla), and split the entire ${totalSec.toFixed(1)}s duration seamlessly into sequential visual scenes matching the meaning & mood of each spoken moment for template style "${tpl.nameEn}".`,
              },
            ],
          },
        ],
        config: {
          thinkingConfig: { thinkingLevel: ThinkingLevel.LOW },
          systemInstruction:
            'Analyze the uploaded voice audio carefully. Provide a short Bangla title, full Bangla transcription/caption (transcriptBangla), recommended musicMood (none/cinematic/emotional/upbeat/tech/suspense), and consecutive VideoScenes with accurate startSec and endSec timestamps covering from 0 to the total audio duration.',
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              transcriptBangla: { type: Type.STRING },
              musicMood: { type: Type.STRING },
              scenes: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    startSec: { type: Type.NUMBER },
                    endSec: { type: Type.NUMBER },
                    subtitleText: { type: Type.STRING },
                    visualPrompt: { type: Type.STRING },
                    searchKeywords: { type: Type.STRING },
                    emotion: { type: Type.STRING },
                    motion: { type: Type.STRING },
                  },
                  required: [
                    'startSec',
                    'endSec',
                    'subtitleText',
                    'visualPrompt',
                    'searchKeywords',
                    'emotion',
                    'motion',
                  ],
                },
              },
            },
            required: ['title', 'transcriptBangla', 'musicMood', 'scenes'],
          },
        },
      });

      const parsed = JSON.parse((response.text ?? '{}').trim()) as {
        title?: string;
        transcriptBangla?: string;
        musicMood?: string;
        scenes?: Array<{
          startSec?: number;
          endSec?: number;
          subtitleText?: string;
          visualPrompt?: string;
          searchKeywords?: string;
          emotion?: string;
          motion?: string;
        }>;
      };

      const rawScenes = parsed.scenes ?? [];
      if (rawScenes.length > 0) {
        const scenes: VideoScene[] = rawScenes.map((s, idx) => {
          const start =
            idx === 0
              ? 0
              : Math.max(0, Math.min(totalSec - 0.5, Number(s.startSec ?? 0)));
          const end =
            idx === rawScenes.length - 1
              ? totalSec
              : Math.max(start + 1, Math.min(totalSec, Number(s.endSec ?? start + 4)));
          const sub = s.subtitleText?.trim() || 'ভয়েস ন্যারেশন';
          return {
            index: idx,
            narrationBangla: sub,
            subtitleText: sub,
            visualPrompt:
              s.visualPrompt?.trim() ||
              `Cinematic visual matching ${s.searchKeywords || 'story'}`,
            searchKeywords:
              s.searchKeywords?.trim() || inferKeywordsFromBangla(sub),
            emotion: (['dramatic', 'calm', 'happy', 'tense', 'informative', 'sad'].includes(
              s.emotion ?? '',
            )
              ? s.emotion
              : 'dramatic') as VideoScene['emotion'],
            motion: (['zoom_in', 'zoom_out', 'pan_left', 'pan_right', 'pulse'].includes(
              s.motion ?? '',
            )
              ? s.motion
              : 'zoom_in') as VideoScene['motion'],
            transition: idx === 0 ? 'cut' : 'fade',
            startSec: start,
            endSec: end,
            durationSec: Math.max(1, end - start),
          };
        });

        // Guarantee contiguous timeline without gaps
        for (let i = 0; i < scenes.length; i++) {
          const prevEnd = i === 0 ? 0 : (scenes[i - 1].endSec ?? 0);
          scenes[i].startSec = prevEnd;
          if (i === scenes.length - 1) {
            scenes[i].endSec = totalSec;
          } else if ((scenes[i].endSec ?? 0) <= prevEnd) {
            scenes[i].endSec = Math.min(totalSec, prevEnd + Math.max(2, totalSec / scenes.length));
          }
          scenes[i].durationSec = Math.max(
            0.5,
            (scenes[i].endSec ?? totalSec) - (scenes[i].startSec ?? 0),
          );
        }

        return {
          title: parsed.title?.trim() || 'ভয়েস টু প্রফেশনাল ভিডিও',
          transcriptBangla:
            parsed.transcriptBangla?.trim() ||
            scenes.map((s) => s.subtitleText).join(' '),
          musicMood: (['none', 'cinematic', 'emotional', 'upbeat', 'tech', 'suspense'].includes(
            (parsed.musicMood ?? '').toLowerCase(),
          )
            ? (parsed.musicMood ?? '').toLowerCase()
            : 'cinematic') as VideoMusicMood,
          scenes,
        };
      }
    } catch (err) {
      console.warn('Multimodal audio transcription fallback used:', err);
    }
  }

  // Fallback balanced timeline scenes if audio is too large or API fails
  const count = Math.max(2, Math.min(12, Math.ceil(totalSec / 6)));
  const perScene = totalSec / count;
  const scenes: VideoScene[] = Array.from({ length: count }).map((_, idx) => {
    const startSec = Math.round(idx * perScene * 100) / 100;
    const endSec =
      idx === count - 1
        ? totalSec
        : Math.round((idx + 1) * perScene * 100) / 100;
    return {
      index: idx,
      narrationBangla: '',
      subtitleText: '',
      visualPrompt: `Cinematic atmospheric scene part ${idx + 1}`,
      searchKeywords: 'cinematic storytelling landscape',
      emotion: 'dramatic',
      motion: idx % 2 === 0 ? 'zoom_in' : 'zoom_out',
      transition: idx === 0 ? 'cut' : 'fade',
      startSec,
      endSec,
      durationSec: Math.max(1, endSec - startSec),
    };
  });

  return {
    title: 'ভয়েস টু AI ভিডিও',
    transcriptBangla: '',
    musicMood: 'cinematic',
    scenes,
  };
}
