import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import {
  mergeChunksToMp3WithFfmpeg,
  normalizeChunkWavWithFfmpeg,
} from './audio.ts';
import { synthesizeRawBanglaChunkWav } from './gemini.ts';
import { botStore } from './store.ts';
import type { VoicePersona } from './types.ts';
import { getVoiceById } from './voices.ts';

export interface VoiceDemoResult {
  voice: VoicePersona;
  filePath: string;
  filename: string;
  url: string;
  durationSec: number;
  fileSizeBytes: number;
}

const inFlightDemos = new Map<string, Promise<VoiceDemoResult>>();

/**
 * Generates (and caches) a dedicated voice demo MP3 for any VoicePersona
 * speaking its custom "ডেভলপার বেলাল হোসেন" sample Bangla script.
 */
export async function getOrGenerateVoiceDemoMp3(
  voiceId: string,
): Promise<VoiceDemoResult> {
  const voice = getVoiceById(voiceId);
  const existing = inFlightDemos.get(voice.id);
  if (existing) return existing;

  const task = (async (): Promise<VoiceDemoResult> => {
    const demosDir = path.join(botStore.getAudioDir(), 'demos');
    fs.mkdirSync(demosDir, { recursive: true });

    const filename = `demo-${voice.id}.mp3`;
    const filePath = path.join(demosDir, filename);
    const metaPath = path.join(demosDir, `demo-${voice.id}.meta.json`);
    const sig = crypto
      .createHash('sha1')
      .update(`${voice.id}|${voice.sampleBangla}|${voice.defaultSpeed}|${voice.defaultPitch}`)
      .digest('hex');

    if (fs.existsSync(filePath) && fs.existsSync(metaPath)) {
      try {
        const meta = JSON.parse(fs.readFileSync(metaPath, 'utf-8')) as {
          sig?: string;
          durationSec?: number;
          fileSizeBytes?: number;
        };
        if (meta.sig === sig && fs.statSync(filePath).size > 256) {
          return {
            voice,
            filePath,
            filename,
            url: `/api/voices/${voice.id}/demo.mp3`,
            durationSec: meta.durationSec ?? 6,
            fileSizeBytes: meta.fileSizeBytes ?? fs.statSync(filePath).size,
          };
        }
      } catch {
        // Rebuild demo cleanly below
      }
    }

    const workDir = path.join(demosDir, `tmp-${voice.id}-${Date.now()}`);
    fs.mkdirSync(workDir, { recursive: true });

    try {
      const cfg = botStore.getConfig();
      const rawWav = await synthesizeRawBanglaChunkWav({
        textChunk: voice.sampleBangla,
        voice,
        speed: voice.defaultSpeed,
        pitch: voice.defaultPitch,
        ttsModel: cfg.ttsModel,
      });

      const normWav = path.join(workDir, 'norm.wav');
      await normalizeChunkWavWithFfmpeg({
        rawWavBuffer: rawWav,
        outputWavPath: normWav,
        speed: voice.defaultSpeed,
        pitchSemitones: voice.defaultPitch,
      });

      const merged = await mergeChunksToMp3WithFfmpeg({
        chunkWavPaths: [normWav],
        outputDir: demosDir,
        baseFilename: `demo-${voice.id}`,
      });

      const out = merged[0];
      fs.writeFileSync(
        metaPath,
        JSON.stringify({
          sig,
          durationSec: out.durationSec,
          fileSizeBytes: out.fileSizeBytes,
        }),
        'utf-8',
      );

      return {
        voice,
        filePath: out.filePath,
        filename: out.filename,
        url: `/api/voices/${voice.id}/demo.mp3`,
        durationSec: out.durationSec,
        fileSizeBytes: out.fileSizeBytes,
      };
    } finally {
      fs.rmSync(workDir, { recursive: true, force: true });
    }
  })();

  inFlightDemos.set(voice.id, task);
  try {
    return await task;
  } finally {
    inFlightDemos.delete(voice.id);
  }
}
