import fs from 'node:fs';
import path from 'node:path';
import {
  normalizeTelegramChannelTarget,
  sendTestChannelNotification,
} from './adminNotify.ts';
import { buildBotSourcePackageZip } from './botExport.ts';
import {
  type DetectedScriptLanguage,
  prepareBanglaScript,
} from './gemini.ts';
import { type JobLifecycleListener, voiceJobQueue } from './jobs.ts';
import { botStore } from './store.ts';
import {
  runAssistantChat,
  runCodingAssistant,
  runWebResearch,
} from './aiAssistant.ts';
import {
  enhanceAudioWithNoiseRemoval,
  synthesizeMultilingualSpeechMp3,
  transcribeAudioFile,
  translateAudioToTargetLanguage,
} from './audioStudio.ts';
import {
  generateViralSeoPack,
  parseMultiVoiceDialogue,
  resolveMusicMoodFromToken,
  resolveVoiceFromCommandToken,
  synthesizeMultiVoiceDialogueMp3,
  synthesizeVoiceWithBgmMp3,
} from './creatorTools.ts';
import {
  analyzeUploadedDocument,
  extractLocalTextFromDocument,
  generateStructuredDocument,
} from './documentAssistant.ts';
import {
  enhanceAndRestorePhoto,
  generateAiImage,
  generateGraphicDesignPng,
  redesignFromReferenceImage,
  removeSolidBackgroundLocal,
  upscalePhoto2x,
} from './imageStudio.ts';
import type {
  AudioPartOutput,
  BotConfig,
  BotMessagePayload,
  BotUser,
  InlineButton,
  UserSavedPreset,
  VideoAspectRatio,
  VideoDraftContext,
  VideoMusicMood,
  VideoProjectJob,
  VideoResolution,
  VideoTemplateId,
  VoiceCategory,
  VoiceGeneration,
  VoiceJob,
} from './types.ts';
import {
  VIDEO_TEMPLATES,
  generateBanglaVideoScriptFromPrompt,
  getVideoTemplate,
} from './videoDirector.ts';
import {
  type VideoJobLifecycleListener,
  videoJobQueue,
} from './videoJobs.ts';
import { probeMediaInfo } from './videoRenderer.ts';
import { getOrGenerateVoiceDemoMp3 } from './voiceDemo.ts';
import {
  VOICE_CATALOG,
  chunkBanglaScript,
  getVoiceById,
  getVoicesByCategory,
} from './voices.ts';

interface TelegramApiUser {
  id: number;
  username?: string;
  first_name?: string;
}

interface TelegramDocument {
  file_id: string;
  file_name?: string;
  mime_type?: string;
  file_size?: number;
}

interface TelegramVideoOrAudio {
  file_id: string;
  file_name?: string;
  mime_type?: string;
  file_size?: number;
  duration?: number;
}

interface TelegramChatRef {
  id: number;
  title?: string;
  username?: string;
  type?: string;
}

interface TelegramPhotoSize {
  file_id: string;
  width: number;
  height: number;
  file_size?: number;
}

interface TelegramUpdate {
  update_id: number;
  message?: {
    message_id: number;
    from?: TelegramApiUser;
    chat: { id: number };
    text?: string;
    photo?: TelegramPhotoSize[];
    document?: TelegramDocument;
    video?: TelegramVideoOrAudio;
    voice?: TelegramVideoOrAudio;
    audio?: TelegramVideoOrAudio;
    caption?: string;
    forward_from_chat?: TelegramChatRef;
    forward_origin?: {
      type?: string;
      chat?: TelegramChatRef;
    };
  };
  channel_post?: {
    message_id: number;
    chat: TelegramChatRef;
    text?: string;
  };
  my_chat_member?: {
    chat: TelegramChatRef;
    from: TelegramApiUser;
    new_chat_member?: {
      status?: string;
    };
  };
  callback_query?: {
    id: string;
    from: TelegramApiUser;
    message?: { chat: { id: number }; message_id: number };
    data?: string;
  };
}

function makeMsgId(): string {
  return `msg-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}

function nowTimeLabel(): string {
  return new Date().toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
  });
}

function formatPitchLabel(pitch: number): string {
  if (pitch <= -2) return 'গম্ভীর (-2)';
  if (pitch === -1) return 'হালকা গম্ভীর (-1)';
  if (pitch === 0) return 'স্বাভাবিক (0)';
  if (pitch === 1) return 'হালকা উজ্জ্বল (+1)';
  return 'তীক্ষ্ণ (+2)';
}

function formatDurationHuman(sec: number): string {
  const s = Math.round(sec);
  if (s < 60) return `${s}s`;
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const rem = s % 60;
  if (h > 0) return `${h}h ${m}m ${rem}s`;
  return `${m}m ${rem}s`;
}

function formatClockMMSS(sec: number): string {
  const s = Math.max(0, Math.floor(sec));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const rem = s % 60;
  const mm = String(m).padStart(2, '0');
  const ss = String(rem).padStart(2, '0');
  if (h > 0) {
    return `${String(h).padStart(2, '0')}:${mm}:${ss}`;
  }
  return `${mm}:${ss}`;
}

function formatProgressBar(pct: number): string {
  const clamped = Math.max(0, Math.min(100, Math.round(pct)));
  const filled = Math.round((clamped / 100) * 10);
  return `${'█'.repeat(Math.min(10, filled))}${'░'.repeat(Math.max(0, 10 - filled))}`;
}

function formatEtaLine(elapsedSec?: number, remainingSec?: number): string {
  const el = formatClockMMSS(elapsedSec ?? 0);
  if (typeof remainingSec === 'number' && remainingSec > 0) {
    return `⏱️ লাইভ টাইমার: ${el} · আনুমানিক বাকি: ~${formatClockMMSS(remainingSec)}`;
  }
  return `⏱️ লাইভ টাইমার: ${el}`;
}

function formatVoiceCategoryLabel(category: VoiceCategory): string {
  if (category === 'male') return 'Male';
  if (category === 'female') return 'Female';
  return 'Cartoon';
}

function isEn(user?: BotUser): boolean {
  return user?.language === 'en';
}

function mainMenuButtons(isAdmin: boolean, lang: 'bn' | 'en' = 'bn'): InlineButton[][] {
  const en = lang === 'en';
  const rows: InlineButton[][] = [
    [
      { text: en ? '💬 AI Chat (ChatGPT)' : '💬 AI চ্যাট (ChatGPT)', callback_data: 'menu:chat' },
      { text: en ? '🌐 Web Research' : '🌐 ওয়েব রিসার্চ', callback_data: 'menu:research' },
    ],
    [
      { text: en ? '🎨 AI Image Studio' : '🎨 AI ইমেজ ও ডিজাইন', callback_data: 'menu:image' },
      { text: en ? '🎬 AI Video Studio' : '🎬 AI ভিডিও স্টুডিও', callback_data: 'menu:video' },
    ],
    [
      { text: en ? '🎙️ Voice & Audio' : '🎙️ ভয়েস ও অডিও স্টুডিও', callback_data: 'menu:voice_studio' },
      { text: en ? '📄 Documents AI' : '📄 ডকুমেন্ট অ্যাসিস্ট্যান্ট', callback_data: 'menu:docs' },
    ],
    [
      { text: en ? '💻 Coding Assistant' : '💻 কোডিং অ্যাসিস্ট্যান্ট', callback_data: 'menu:coding' },
      { text: en ? '🧠 Memory & Tasks' : '🧠 মেমোরি ও পূর্বের কাজ', callback_data: 'menu:memory' },
    ],
    [
      { text: en ? '🚀 Multi-Studio Hub' : '🚀 মাল্টি-স্টুডিও হাব', callback_data: 'menu:cmd_hub' },
      { text: en ? '🔊 Voice Demos' : '🔊 ভয়েস ডেমো শুনুন', callback_data: 'menu:demos' },
    ],
    [
      { text: en ? '⚙️ Settings & Language' : '⚙️ সেটিংস ও ভাষা (BN/EN)', callback_data: 'menu:settings' },
      { text: en ? '💳 Wallet' : '💳 ওয়ালেট', callback_data: 'menu:wallet' },
      { text: en ? '👤 Profile' : '👤 প্রোফাইল', callback_data: 'menu:profile' },
    ],
  ];
  if (isAdmin) {
    rows.push([
      { text: en ? '📁 Bot Source ZIP' : '📁 ফাইল (Unified Bot ZIP)', callback_data: 'adm:bot_files' },
      { text: en ? '🛡️ Admin Panel' : '🛡️ Admin Dashboard', callback_data: 'adm:home' },
    ]);
  }
  return rows;
}

function categoryMenuButtons(): InlineButton[][] {
  return [
    [{ text: '👨 Male Voice (ছেলেদের ও ইমোশনাল ভাইরাল কণ্ঠস্বর)', callback_data: 'cat:male' }],
    [{ text: '👩 Female Voice (মেয়েদের ও ইমোশনাল কণ্ঠস্বর)', callback_data: 'cat:female' }],
    [{ text: '🎭 Cartoon Voice (অগি · টম-জেরি · ডোরেমন · নোবিতা · শিনচ্যান)', callback_data: 'cat:cartoon' }],
    [{ text: '🔊 সব ভয়েসের ডেমো শুনুন (বেলাল হোসেন)', callback_data: 'menu:demos' }],
    [{ text: '🏠 মেইন মেনু', callback_data: 'menu:main' }],
  ];
}

function voiceListButtons(category: VoiceCategory, selectedId: string): InlineButton[][] {
  const voices = getVoicesByCategory(category);
  const rows: InlineButton[][] = voices.map((v) => {
    const cost = botStore.getVoiceEffectiveCost(v.id);
    const priceTag = cost > 0 ? ` — ৳${cost}` : ' — ফ্রি';
    return [
      {
        text: `${v.id === selectedId ? '✅ ' : ''}${v.emoji} ${v.nameBn} (${v.roleBn})${priceTag}`,
        callback_data: `voice:${v.id}`,
      },
    ];
  });
  rows.push([
    { text: '🔊 এই ক্যাটাগরির ডেমো শুনুন', callback_data: `demos:cat:${category}` },
  ]);
  rows.push([
    { text: '⚙️ স্পিড ও পিচ', callback_data: 'menu:settings' },
    { text: '🔄 ক্যাটাগরি বদলান', callback_data: 'menu:create' },
  ]);
  return rows;
}

function buildVoiceDemosPayload(category: VoiceCategory): {
  text: string;
  buttons: InlineButton[][];
} {
  const voices = getVoicesByCategory(category);
  const catLabel =
    category === 'male'
      ? '👨 Male Voice ডেমো'
      : category === 'female'
        ? '👩 Female Voice ডেমো'
        : '🎭 Cartoon Voice ডেমো';

  const voiceListText = voices
    .map((v) => `${v.emoji} **${v.nameBn}** — ${v.roleBn}`)
    .join('\n');

  const buttons: InlineButton[][] = [
    [
      {
        text: `${category === 'male' ? '✅ ' : ''}👨 Male`,
        callback_data: 'demos:cat:male',
      },
      {
        text: `${category === 'female' ? '✅ ' : ''}👩 Female`,
        callback_data: 'demos:cat:female',
      },
      {
        text: `${category === 'cartoon' ? '✅ ' : ''}🎭 Cartoon`,
        callback_data: 'demos:cat:cartoon',
      },
    ],
    ...voices.map((v) => [
      {
        text: `🔊 ${v.emoji} ${v.nameBn} — ${v.roleBn} (ডেমো শুনুন)`,
        callback_data: `demo:${v.id}`,
      },
    ]),
    [
      { text: '🎙️ ভয়েস তৈরি করুন', callback_data: `cat:${category}` },
      { text: '🏠 মেইন মেনু', callback_data: 'menu:main' },
    ],
  ];

  const text =
    `🔊 **ভয়েস ডেমো সেন্টার (${catLabel})**\n\n` +
    `যেকোনো ভয়েসে ট্যাপ করলে সরাসরি অডিও ডেমো শুনতে পারবেন—প্রতিটি ডেমোতে কণ্ঠশিল্পী **“ডেভলপার বেলাল হোসেন”** ও বটের পরিচিতি সুন্দরভাবে শোনাবে:\n\n` +
    `${voiceListText}`;

  return { text, buttons };
}

function speedPitchButtons(user: BotUser): InlineButton[][] {
  const speeds = [0.75, 0.85, 1.0, 1.15, 1.25];
  const pitches = [
    { label: 'গম্ভীর (-2)', val: -2 },
    { label: 'স্বাভাবিক (0)', val: 0 },
    { label: 'তীক্ষ্ণ (+2)', val: 2 },
  ];

  return [
    speeds.map((s) => ({
      text: `${Math.abs(user.speed - s) < 0.01 ? '✅ ' : ''}${s}x`,
      callback_data: `speed:${s}`,
    })),
    pitches.map((p) => ({
      text: `${user.pitch === p.val ? '✅ ' : ''}${p.label}`,
      callback_data: `pitch:${p.val}`,
    })),
    [
      { text: '✍️ স্ক্রিপ্ট লিখুন', callback_data: 'menu:prompt_script' },
      { text: '🏠 মেইন মেনু', callback_data: 'menu:main' },
    ],
  ];
}

function postAudioButtons(generationId: string): InlineButton[][] {
  return [
    [
      { text: '🔄 পুনরায় জেনারেট', callback_data: `regen:${generationId}` },
      { text: '🎚️ স্পিড ও পিচ', callback_data: 'menu:settings' },
    ],
    [
      { text: '🎬 AI ভিডিও স্টুডিও', callback_data: 'menu:video' },
      { text: '👤 প্রোফাইল ও ফাইলস', callback_data: 'menu:profile' },
    ],
    [{ text: '🏠 মেইন মেনু', callback_data: 'menu:main' }],
  ];
}

function defaultVideoDraft(user: BotUser, mode: VideoDraftContext['mode']): VideoDraftContext {
  return {
    mode,
    templateId: 'cinematic_doc',
    aspectRatio: mode === 'edit_video' ? '9:16' : '16:9',
    resolution: '1080p',
    videoSpeed: mode === 'edit_video' ? 0 : 1,
    voiceSpeed: user.speed || 1.0,
    voicePitch: user.pitch || 0,
    voiceId: user.selectedVoiceId,
    musicMood: 'cinematic',
    originalAudioMode: 'mute',
    includeSubtitles: true,
    includeIntroOutro: mode !== 'edit_video',
  };
}

function buildVideoConfigCardMessage(user: BotUser): {
  text: string;
  buttons: InlineButton[][];
} {
  const draft = user.pendingContext?.videoDraft ?? defaultVideoDraft(user, 'prompt');
  const tpl = getVideoTemplate(draft.templateId);
  const voice = getVoiceById(draft.voiceId ?? user.selectedVoiceId);
  const cfg = botStore.getConfig();
  const cost = Math.max(0, cfg.videoGenerationCost ?? 0);

  const modeTitle =
    draft.mode === 'prompt'
      ? 'প্রম্পট → AI ভিডিও'
      : draft.mode === 'script'
        ? 'আনলিমিটেড স্ক্রিপ্ট → AI ভিডিও'
        : draft.mode === 'voice'
          ? 'ভয়েস ফাইল → AI ভিডিও'
          : draft.mode === 'image_to_video'
            ? 'ছবি → AI ভিডিও (Image-to-Video)'
            : 'নিজস্ব ভিডিও এডিট (Smart Video Editor)';

  const vSpeedLabel =
    !draft.videoSpeed || draft.videoSpeed <= 0
      ? 'Auto-Sync (ভয়েসের সাথে মিল)'
      : `${draft.videoSpeed}x`;

  const origAudioLabel =
    draft.originalAudioMode === 'keep'
      ? 'Keep Original'
      : draft.originalAudioMode === 'duck'
        ? 'Duck 20% + Voiceover'
        : 'Mute + New Voiceover';

  const summarySource =
    draft.mode === 'edit_video'
      ? `🎞️ ভিডিও: **${draft.uploadedVideoName || 'Uploaded Video'}** (${draft.uploadedVideoDurationSec ?? '?'}s)\n` +
        (draft.script
          ? `📝 ভয়েস স্ক্রিপ্ট: ${draft.script.slice(0, 140)}${draft.script.length > 140 ? '...' : ''}\n`
          : draft.uploadedAudioName
            ? `🎵 ভয়েস ফাইল: ${draft.uploadedAudioName}\n`
            : `🔇 শুধু ভিডিও/স্পিড/মিউজিক এডিট\n`)
      : draft.mode === 'voice'
        ? `🎤 আপলোডেড ভয়েস: **${draft.uploadedAudioName || 'Voice File'}** (${draft.uploadedAudioDurationSec ?? '?'}s)\n`
        : `📝 বাংলা স্ক্রিপ্ট (${(draft.script || '').length} অক্ষর):\n“${(draft.script || draft.prompt || '').slice(0, 160)}${(draft.script || '').length > 160 ? '...' : ''}”\n`;

  const text =
    `🎬 **AI প্রফেশনাল ভিডিও সেটিংস কনফিগারেশন**\n\n` +
    `• মোড: **${modeTitle}**\n` +
    `• শিরোনাম: **${draft.title || 'বাংলা AI ভিডিও'}**\n` +
    `${summarySource}\n` +
    `🎨 **টেমপ্লেট:** ${tpl.nameBn}\n` +
    `📐 **ফরম্যাট ও কোয়ালিটি:** ${draft.aspectRatio ?? '16:9'} · **${(draft.resolution ?? '1080p').toUpperCase()}**\n` +
    (draft.mode === 'edit_video'
      ? `⏩ **ভিডিও স্পিড:** ${vSpeedLabel} | 🔊 **মূল অডিও:** ${origAudioLabel}\n`
      : '') +
    `🎙️ **ভয়েস ও স্পিড:** ${voice.nameBn} · **${draft.voiceSpeed ?? 1}x**\n` +
    `🎵 **মিউজিক:** ${draft.musicMood ?? 'cinematic'} | 💬 **সাবটাইটেল:** ${draft.includeSubtitles !== false ? 'ON ✅' : 'OFF'}\n` +
    (draft.watermarkText ? `🏷️ **ওয়াটারমার্ক:** ${draft.watermarkText}\n` : '') +
    `💰 **চার্জ:** **${cost > 0 ? `৳${cost}` : 'ফ্রি (৳0)'}**\n\n` +
    `নিচের বাটন থেকে পরিবর্তন করুন অথবা **“🚀 ভিডিও তৈরি শুরু করুন”** চাপুন:`;

  const buttons: InlineButton[][] = [
    [{ text: '🎨 ইউনিক টেমপ্লেট বদলান', callback_data: 'vid:tpl_menu' }],
    [
      { text: `${draft.aspectRatio === '16:9' ? '✅ ' : ''}16:9`, callback_data: 'vid:ar:16:9' },
      { text: `${draft.aspectRatio === '9:16' ? '✅ ' : ''}9:16 Reels`, callback_data: 'vid:ar:9:16' },
      { text: `${draft.aspectRatio === '1:1' ? '✅ ' : ''}1:1 Square`, callback_data: 'vid:ar:1:1' },
    ],
    [
      { text: `${draft.resolution === '720p' ? '✅ ' : ''}720p`, callback_data: 'vid:res:720p' },
      { text: `${draft.resolution === '1080p' ? '✅ ' : ''}1080p HD`, callback_data: 'vid:res:1080p' },
      { text: `${draft.resolution === '4k' ? '✅ ' : ''}4K UHD`, callback_data: 'vid:res:4k' },
    ],
  ];

  if (draft.mode === 'edit_video') {
    buttons.push([
      { text: `${!draft.videoSpeed ? '✅ ' : ''}Auto-Sync`, callback_data: 'vid:vspd:0' },
      { text: `${draft.videoSpeed === 0.75 ? '✅ ' : ''}0.75x`, callback_data: 'vid:vspd:0.75' },
      { text: `${draft.videoSpeed === 1 ? '✅ ' : ''}1x`, callback_data: 'vid:vspd:1' },
      { text: `${draft.videoSpeed === 1.5 ? '✅ ' : ''}1.5x`, callback_data: 'vid:vspd:1.5' },
      { text: `${draft.videoSpeed === 2 ? '✅ ' : ''}2x`, callback_data: 'vid:vspd:2' },
    ]);
    buttons.push([
      { text: '📝 ভয়েস স্ক্রিপ্ট যোগ/এডিট', callback_data: 'vid:edit_script' },
      { text: `🔊 মূল সাউন্ড: ${draft.originalAudioMode === 'mute' ? 'Mute' : draft.originalAudioMode === 'duck' ? 'Duck' : 'Keep'}`, callback_data: 'vid:orig_cycle' },
    ]);
  }

  buttons.push([
    { text: `🎙️ ভয়েস স্পিড: ${draft.voiceSpeed ?? 1}x`, callback_data: 'vid:aspd_cycle' },
    { text: `🎵 মিউজিক: ${draft.musicMood ?? 'cinematic'}`, callback_data: 'vid:bgm_cycle' },
  ]);
  buttons.push([
    { text: `💬 সাবটাইটেল: ${draft.includeSubtitles !== false ? 'ON' : 'OFF'}`, callback_data: 'vid:sub_toggle' },
    { text: '🏷️ ওয়াটারমার্ক', callback_data: 'vid:wm' },
  ]);
  buttons.push([
    { text: '🚀 ভিডিও তৈরি শুরু করুন (Render MP4)', callback_data: 'vid:render' },
  ]);
  buttons.push([{ text: '❌ বাতিল করুন', callback_data: 'menu:main' }]);

  return { text, buttons };
}

// ---------------------------------------------------------------------------
// Admin Panel Views for Telegram
// ---------------------------------------------------------------------------

function buildAdminDashboardMessage(): { text: string; buttons: InlineButton[][] } {
  const stats = botStore.getDashboardStats();
  const cfg = botStore.getConfig();
  const activePayCount = (cfg.paymentAccounts ?? []).filter((a) => a.enabled).length;
  const customVoicePrices = Object.keys(cfg.voiceCosts ?? {}).length;
  const enabledMap = cfg.enabledFeatures ?? {
    chat: true,
    image: true,
    video: true,
    voice: true,
    documents: true,
    coding: true,
    research: true,
    memory: true,
  };
  const enabledCount = Object.values(enabledMap).filter(Boolean).length;
  const usage = stats.featureUsage;
  const text =
    `🛡️ **BanglaVoice All-in-One Admin Dashboard**\n\n` +
    `• Total Users: **${stats.totalUsers}** (Active: ${stats.activeUsers} | Banned: ${stats.bannedUsers})\n` +
    `• Free: **${stats.freeUsers}** | Premium: **${stats.premiumUsers}**\n` +
    `• Voices: **${stats.totalVoicesGenerated}** | Videos: **${stats.totalVideosGenerated}** | Today: **${stats.todayGenerations}**\n` +
    `• AI Usage — Chat: **${usage.chat}** · Img: **${usage.image}** · Doc: **${usage.documents}** · Code: **${usage.coding}** · Web: **${usage.research}**\n` +
    `• Enabled AI Modules: **${enabledCount}/8** | Error Logs: **${stats.errorCount}**\n` +
    `• Pending Payments: **${stats.pendingPayments}** | Active Jobs: **${stats.activeJobs}**\n` +
    `• Active Payment Numbers: **${activePayCount}** | Per-Voice Prices: **${customVoicePrices}**\n` +
    `• Total User Balance: **৳${stats.totalBalance.toFixed(2)}**\n` +
    `• Voice Cost: **৳${cfg.voiceGenerationCost}** | Video Cost: **৳${cfg.videoGenerationCost}** | TTS: \`${cfg.ttsModel}\``;

  const buttons: InlineButton[][] = [
    [
      { text: '👥 User Management', callback_data: 'adm:users:0' },
      { text: '🔍 Search User (TG ID)', callback_data: 'adm:search' },
    ],
    [
      { text: '🧩 AI Features (On/Off)', callback_data: 'adm:features' },
      { text: `🚨 Error Logs (${stats.errorCount})`, callback_data: 'adm:errors' },
    ],
    [
      { text: '💰 Balance Management', callback_data: 'adm:balance' },
      {
        text: `💳 Payment Requests (${stats.pendingPayments})`,
        callback_data: 'adm:payments',
      },
    ],
    [
      { text: '📲 Payment Numbers', callback_data: 'adm:pay_nums' },
      { text: '💲 Per-Voice Charges', callback_data: 'adm:voice_costs' },
    ],
    [
      { text: '📜 Transaction History', callback_data: 'adm:tx' },
      { text: '📊 Daily Usage Stats', callback_data: 'adm:stats' },
    ],
    [
      { text: '🎙️ Voice Gen Settings', callback_data: 'adm:voice_cfg' },
      { text: '👑 Free & Premium Plans', callback_data: 'adm:plans' },
    ],
    [
      { text: '🚫 Ban / Unban Users', callback_data: 'adm:ban_list' },
      { text: '⚙️ System Settings', callback_data: 'adm:sys' },
    ],
    [{ text: '📁 বটের সমস্ত ফাইল (Source ZIP Export)', callback_data: 'adm:bot_files' }],
    [
      { text: '🔄 Refresh Dashboard', callback_data: 'adm:home' },
      { text: '🏠 Exit Admin', callback_data: 'menu:main' },
    ],
  ];

  return { text, buttons };
}

function buildAdminUserProfileMessage(target: BotUser): {
  text: string;
  buttons: InlineButton[][];
} {
  const dailyLimit = botStore.getUserEffectiveDailyLimit(target);
  const charLimit = botStore.getUserMaxChars(target);
  const exp = target.premiumExpiresAt
    ? new Date(target.premiumExpiresAt).toLocaleDateString()
    : 'N/A';

  const text =
    `👤 **User Profile Details**\n\n` +
    `• Name: **${target.firstName}** (@${target.username})\n` +
    `• Telegram ID: **${target.telegramId}**\n` +
    `• Role: **${target.role.toUpperCase()}**\n` +
    `• Plan: **${target.tier === 'premium' ? '👑 Premium' : 'Free'}**` +
    (target.tier === 'premium' ? ` (Expires: ${exp})` : '') +
    `\n` +
    `• Status: **${target.status === 'banned' ? '⛔ BANNED' : '✅ ACTIVE'}**\n` +
    `• Balance: **৳${target.balance.toFixed(2)}**\n` +
    `• Daily Usage: **${target.dailyCount} / ${dailyLimit}**\n` +
    `• Char Limit: **${charLimit === 0 ? 'Unlimited' : charLimit}**\n` +
    `• Total Voices: **${target.totalCount}**`;

  const buttons: InlineButton[][] = [
    [
      {
        text: '📜 Voice History',
        callback_data: `adm:u_hist:${target.id}`,
      },
      {
        text: '💰 Check / Edit Balance',
        callback_data: `adm:u_bal_menu:${target.id}`,
      },
    ],
    [
      {
        text:
          target.status === 'banned'
            ? '✅ Unban User'
            : '🚫 Ban User',
        callback_data: `adm:u_ban:${target.id}`,
      },
      {
        text:
          target.tier === 'premium'
            ? '⬇️ Deactivate Premium'
            : '👑 Activate Premium',
        callback_data: `adm:u_prem:${target.id}`,
      },
    ],
    [
      {
        text: '🎚️ Set Individual Voice Limit',
        callback_data: `adm:u_limit:${target.id}`,
      },
    ],
    [
      { text: '◀️ Back to Users', callback_data: 'adm:users:0' },
      { text: '🛡️ Admin Home', callback_data: 'adm:home' },
    ],
  ];

  return { text, buttons };
}

function buildPlanSettingsMessage(): { text: string; buttons: InlineButton[][] } {
  const cfg = botStore.getConfig();
  const text =
    `👑 **Free & Premium Plan Settings**\n\n` +
    `• Free Daily Limit: **${cfg.freeDailyLimit}**\n` +
    `• Premium Daily Limit: **${cfg.premiumDailyLimit}**\n` +
    `• Free Character Limit: **${cfg.maxScriptCharsFree === 0 ? 'Unlimited (0)' : cfg.maxScriptCharsFree}**\n` +
    `• Premium Character Limit: **${cfg.maxScriptCharsPremium === 0 ? 'Unlimited (0)' : cfg.maxScriptCharsPremium}**\n` +
    `• Voice Generation Cost: **৳${cfg.voiceGenerationCost}**\n` +
    `• Premium Duration: **${cfg.premiumMembershipDays} Days**\n\n` +
    `যেকোনো সেটিং পরিবর্তন করতে নিচের বাটনে ট্যাপ করুন:`;

  const buttons: InlineButton[][] = [
    [
      { text: 'Free Daily Limit', callback_data: 'adm:cfg_edit:freeDailyLimit' },
      {
        text: 'Premium Daily Limit',
        callback_data: 'adm:cfg_edit:premiumDailyLimit',
      },
    ],
    [
      {
        text: 'Free Char Limit',
        callback_data: 'adm:cfg_edit:maxScriptCharsFree',
      },
      {
        text: 'Premium Char Limit',
        callback_data: 'adm:cfg_edit:maxScriptCharsPremium',
      },
    ],
    [
      {
        text: 'Voice Cost (৳)',
        callback_data: 'adm:cfg_edit:voiceGenerationCost',
      },
      {
        text: 'Video Cost (৳)',
        callback_data: 'adm:cfg_edit:videoGenerationCost',
      },
    ],
    [
      {
        text: 'Premium Days',
        callback_data: 'adm:cfg_edit:premiumMembershipDays',
      },
    ],
    [{ text: '🛡️ Admin Dashboard', callback_data: 'adm:home' }],
  ];
  return { text, buttons };
}

const CONFIG_KEY_LABELS: Record<string, string> = {
  freeDailyLimit: 'Free User Daily Limit (সংখ্যা লিখুন, যেমন 10)',
  premiumDailyLimit: 'Premium User Daily Limit (সংখ্যা লিখুন, যেমন 200)',
  maxScriptCharsFree:
    'Free Character Limit (0 লিখলে Unlimited / কোনো সীমা থাকবে না)',
  maxScriptCharsPremium:
    'Premium Character Limit (0 লিখলে Unlimited / কোনো সীমা থাকবে না)',
  voiceGenerationCost:
    'Voice Generation Cost (৳ সংখ্যা লিখুন, ফ্রি রাখতে 0 লিখুন)',
  videoGenerationCost:
    'AI Video Generation Cost (৳ সংখ্যা লিখুন, ফ্রি রাখতে 0 লিখুন)',
  premiumMembershipDays: 'Premium Membership Duration (দিন সংখ্যা লিখুন, যেমন 30)',
  notificationChannelId:
    'Notification Channel (@channel_username অথবা -100... লিখুন; বন্ধ করতে none লিখুন। বটকে ওই চ্যানেলে Admin হিসেবে রাখুন)',
};

export interface BotActionOutput {
  messages: BotMessagePayload[];
  user: BotUser;
  queuedJob?: VoiceJob;
  queuedVideoJob?: VideoProjectJob;
  pendingAdminNotifications?: Array<{
    text: string;
    buttons: InlineButton[][];
  }>;
  pendingUserNotification?: {
    telegramId: string;
    text: string;
  };
  pendingBroadcast?: {
    text: string;
    excludeTelegramId?: string;
  };
}

const UNIFIED_TELEGRAM_COMMANDS = [
  {
    command: 'start',
    description: 'ChatGPT + All-in-One AI Assistant মেনু',
  },
  {
    command: 'chat',
    description: 'AI চ্যাট অ্যাসিস্ট্যান্ট (ChatGPT মোড)',
  },
  {
    command: 'image',
    description: 'AI ইমেজ, লোগো, ব্যানার, থাম্বনেইল ও ফটো এডিট',
  },
  {
    command: 'video',
    description: 'AI ভিডিও ও Image-to-Video স্টুডিও',
  },
  {
    command: 'voice',
    description: 'বাংলা ও ইংরেজি ভয়েস, STT, অনুবাদ ও Noise Removal',
  },
  {
    command: 'docs',
    description: 'PDF/Word/Excel/PPT পড়া ও তৈরি করা',
  },
  {
    command: 'code',
    description: 'AI কোডিং, ডিবাগিং ও প্রজেক্ট জেনারেটর',
  },
  {
    command: 'research',
    description: 'লাইভ ওয়েব সার্চ ও URL রিসার্চ',
  },
  {
    command: 'memory',
    description: 'ব্যক্তিগত মেমোরি, পূর্বের কাজ ও চ্যাট রিসেট',
  },
  {
    command: 'hub',
    description: 'AI মাল্টি-স্টুডিও হাব (কমান্ডে এ-টু-জেড কাজ)',
  },
  {
    command: 'profile',
    description: 'আমার প্রোফাইল, ব্যালেন্স ও সমস্ত ফাইল',
  },
  {
    command: 'files',
    description: 'বটের সমস্ত সোর্স ও ডিপ্লয়মেন্ট ফাইল (.ZIP)',
  },
];

function buildCommandHubGuideMessage(user: BotUser, isAdmin: boolean): string {
  const presetVoice = user.savedPreset?.voiceId
    ? getVoiceById(user.savedPreset.voiceId).nameBn
    : 'সেট করা নেই';
  const presetInfo = user.savedPreset
    ? `${presetVoice} · ${user.savedPreset.aspectRatio ?? '9:16'} · ${(user.savedPreset.resolution ?? '1080p').toUpperCase()} · ${user.savedPreset.musicMood ?? 'cinematic'}`
    : 'সেট করা নেই (/preset লিখে সেট করুন)';

  return (
    `🚀 **AI মাল্টি-স্টুডিও হাব — সম্পূর্ণ কমান্ড মোড**\n\n` +
    `এখানে কোনো বাটন চাপতে হবে না — নিচের নম্বর (` +
    `1` +
    `–` +
    `${isAdmin ? '8' : '7'}` +
    `) অথবা কমান্ড টাইপ করে ধাপে ধাপে **A to Z** সব কাজ করতে পারবেন:\n\n` +
    `1️⃣ \`1\` বা \`/videocmd\` — **AI ভিডিও + ভাইরাল SEO** (টপিক → ফরম্যাট → ভয়েস/BGM → ওয়াটারমার্ক/সাবটাইটেল → রেন্ডার)\n` +
    `2️⃣ \`2\` বা \`/dialogue\` — **মাল্টি-ভয়েস কার্টুন/গল্প ডায়ালগ MP3** (ডোরেমন + নোবিতা + অগি + আরিফ)\n` +
    `3️⃣ \`3\` বা \`/voicebgm\` — **ভয়েস + ব্যাকগ্রাউন্ড মিউজিক MP3** (ইমোশনাল/সিনেম্যাটিক সুরসহ ভয়েস)\n` +
    `4️⃣ \`4\` বা \`/seo <টপিক>\` — **ভাইরাল SEO জেনারেটর** (৩টি টাইটেল + ডেসক্রিপশন + হ্যাশট্যাগ)\n` +
    `5️⃣ \`5\` বা \`/preset\` — **আমার প্রিসেট সেভ** (বর্তমান: ${presetInfo})\n` +
    `6️⃣ \`6\` বা \`/ref\` — **রেফারেল লিংক ও বোনাস** (মোট রেফার: ${user.referralCount ?? 0}জন)\n` +
    `7️⃣ \`7\` বা \`/voices\` — **সব ভয়েস কমান্ড তালিকা** (১৬টি ভয়েসের নাম ও ইমোজি)\n` +
    (isAdmin
      ? `8️⃣ \`8\` বা \`/broadcast <মেসেজ>\` — **অ্যাডমিন ব্রডকাস্ট** (সব ইউজারকে মেসেজ পাঠান)\n`
      : '') +
    `\n🔙 যেকোনো সময় \`back\` (হাবে ফিরতে) অথবা \`0\` / \`/exit\` (মেইন মেনুতে ফিরতে) লিখুন।\n` +
    `👉 শুরু করতে এখন একটি নম্বর বা কমান্ড লিখুন:`
  );
}

function buildVoicesCommandReference(): string {
  const male = getVoicesByCategory('male')
    .map((v) => `• ${v.emoji} **${v.nameBn}** (${v.roleBn}) — লিখুন: \`${v.nameEn.split(' ')[0]}\``)
    .join('\n');
  const female = getVoicesByCategory('female')
    .map((v) => `• ${v.emoji} **${v.nameBn}** (${v.roleBn}) — লিখুন: \`${v.nameEn.split(' ')[0]}\``)
    .join('\n');
  const cartoon = getVoicesByCategory('cartoon')
    .map((v) => `• ${v.emoji} **${v.nameBn}** (${v.roleBn}) — লিখুন: \`${v.nameEn.split(' ')[0]}\``)
    .join('\n');

  return (
    `🎙️ **কমান্ড মোডের সব ভয়েস নামের তালিকা**\n` +
    `(বাংলা বা ইংরেজি যেকোনো প্রথম নাম লিখলেই ভয়েস সিলেক্ট হয়ে যাবে)\n\n` +
    `👨 **Male Voices:**\n${male}\n\n` +
    `👩 **Female Voices:**\n${female}\n\n` +
    `🎭 **Cartoon Voices:**\n${cartoon}\n\n` +
    `🎵 **BGM মুডসমূহ:** \`cinematic\`, \`emotional\`, \`upbeat\`, \`tech\`, \`suspense\`, \`none\`\n\n` +
    `👉 ফিরে যেতে \`back\` অথবা নতুন কমান্ড (\`1\`-\`7\`) লিখুন।`
  );
}

function parseCommandFormatLine(
  input: string,
  fallback: { aspectRatio: VideoAspectRatio; resolution: VideoResolution },
): { aspectRatio: VideoAspectRatio; resolution: VideoResolution } {
  const lower = input.toLowerCase();
  let aspectRatio: VideoAspectRatio = fallback.aspectRatio;
  if (/(?:9\s*:\s*16|reels|tiktok|shorts|vertical)/i.test(lower)) aspectRatio = '9:16';
  else if (/(?:1\s*:\s*1|square|instagram|fb)/i.test(lower)) aspectRatio = '1:1';
  else if (/(?:16\s*:\s*9|youtube|landscape|wide)/i.test(lower)) aspectRatio = '16:9';

  let resolution: VideoResolution = fallback.resolution;
  if (/(?:4k|2160|uhd)/i.test(lower)) resolution = '4k';
  else if (/(?:720|hd\b)/i.test(lower) && !/1080/i.test(lower)) resolution = '720p';
  else if (/1080|fhd/i.test(lower)) resolution = '1080p';

  return { aspectRatio, resolution };
}

function parseVoiceAndBgmFromLine(
  input: string,
  fallbackVoiceId: string,
  fallbackMood: VideoMusicMood,
): { voiceId: string; musicMood: VideoMusicMood } {
  const tokens = input.trim().split(/[\s,|]+/).filter(Boolean);
  let matchedVoice = getVoiceById(fallbackVoiceId);
  let matchedMood: VideoMusicMood = fallbackMood;
  let foundVoice = false;

  for (const tok of tokens) {
    if (
      /^(?:cinematic|emotional|emotion|sad|upbeat|funny|cartoon|tech|suspense|horror|none|off|no|ইমোশনাল|সিনেম্যাটিক|ফানি|কার্টুন|টেক|সাসপেন্স|নাই|বন্ধ)$/i.test(
        tok,
      )
    ) {
      matchedMood = resolveMusicMoodFromToken(tok);
      continue;
    }
    if (!foundVoice) {
      const v = resolveVoiceFromCommandToken(tok, '__NONE__');
      if (v.id !== '__NONE__' && VOICE_CATALOG.some((c) => c.id === v.id)) {
        matchedVoice = v;
        foundVoice = true;
      }
    }
  }

  if (!foundVoice && tokens.length > 0) {
    const whole = resolveVoiceFromCommandToken(input, fallbackVoiceId);
    matchedVoice = whole;
  }

  return { voiceId: matchedVoice.id, musicMood: matchedMood };
}

function parsePresetCommand(
  input: string,
  current?: UserSavedPreset,
): UserSavedPreset {
  const tokens = input.trim().split(/\s+/).filter(Boolean);
  const next: UserSavedPreset = {
    aspectRatio: current?.aspectRatio ?? '9:16',
    resolution: current?.resolution ?? '1080p',
    musicMood: current?.musicMood ?? 'cinematic',
    voiceId: current?.voiceId,
    watermarkText: current?.watermarkText,
    speed: current?.speed ?? 1.0,
    pitch: current?.pitch ?? 0,
  };

  const fmt = parseCommandFormatLine(input, {
    aspectRatio: next.aspectRatio ?? '9:16',
    resolution: next.resolution ?? '1080p',
  });
  next.aspectRatio = fmt.aspectRatio;
  next.resolution = fmt.resolution;

  for (const tok of tokens) {
    if (tok.startsWith('@') && tok.length > 1) {
      next.watermarkText = tok.slice(0, 32);
      continue;
    }
    if (/^wm:/i.test(tok)) {
      const val = tok.slice(3).trim();
      next.watermarkText = val.toLowerCase() === 'none' ? undefined : val.slice(0, 32);
      continue;
    }
    if (/^(?:0?\.\d+|1(?:\.\d+)?)x$/i.test(tok)) {
      const spd = Number.parseFloat(tok.replace(/x/i, ''));
      if (!Number.isNaN(spd)) {
        next.speed = Math.min(1.5, Math.max(0.6, Number(spd.toFixed(2))));
      }
      continue;
    }
    if (
      /^(?:cinematic|emotional|emotion|sad|upbeat|funny|cartoon|tech|suspense|horror|none|ইমোশনাল|সিনেম্যাটিক|ফানি|কার্টুন|টেক|সাসপেন্স|নাই)$/i.test(
        tok,
      )
    ) {
      next.musicMood = resolveMusicMoodFromToken(tok);
      continue;
    }
    if (!/^(?:9:16|16:9|1:1|720p|1080p|4k|reels|shorts|square|youtube)$/i.test(tok)) {
      const candidate = resolveVoiceFromCommandToken(tok, '__NONE__');
      if (candidate.id !== '__NONE__' && VOICE_CATALOG.some((c) => c.id === candidate.id)) {
        next.voiceId = candidate.id;
      }
    }
  }

  return next;
}

function buildUnifiedProfilePayload(
  user: BotUser,
  tab: 'overview' | 'audio' | 'video' = 'overview',
  page = 0,
): { text: string; buttons: InlineButton[][] } {
  const limit = botStore.getUserEffectiveDailyLimit(user);
  const maxChars = botStore.getUserMaxChars(user);
  const voice = getVoiceById(user.selectedVoiceId);
  const exp = user.premiumExpiresAt
    ? new Date(user.premiumExpiresAt).toLocaleDateString()
    : '—';

  const audioFiles = botStore.listGenerations(user.id, 50);
  const videoFiles = botStore
    .listVideoJobs(user.id, 50)
    .filter((v) => v.status === 'completed' && Boolean(v.outputFilename));

  const header =
    `👤 **আমার প্রোফাইল ও সমস্ত ফাইল (Unified Hub)**\n\n` +
    `• নাম: **${user.firstName}** (@${user.username})\n` +
    `• Telegram ID: \`${user.telegramId}\`\n` +
    `• প্ল্যান: **${user.tier === 'premium' ? '👑 Premium' : 'Free'}**` +
    (user.tier === 'premium' ? ` (মেয়াদ: ${exp})` : '') +
    ` | ব্যালেন্স: **৳${user.balance.toFixed(2)}**\n` +
    `• আজকের ব্যবহার: **${user.dailyCount} / ${limit}** | সীমা: **${maxChars === 0 ? 'Unlimited' : `${maxChars} অক্ষর`}**\n` +
    `• কণ্ঠস্বর: **${voice.nameBn}** · ${user.speed}x · ${formatPitchLabel(user.pitch)}\n` +
    `• সংরক্ষিত ফাইল: **🎧 ${audioFiles.length}টি অডিও** · **🎬 ${videoFiles.length}টি ভিডিও**\n`;

  const buttons: InlineButton[][] = [
    [
      {
        text: `${tab === 'overview' ? '✅ ' : ''}👤 সারসংক্ষেপ`,
        callback_data: 'profile:tab:overview:0',
      },
      {
        text: `${tab === 'audio' ? '✅ ' : ''}🎧 অডিও (${audioFiles.length})`,
        callback_data: 'profile:tab:audio:0',
      },
      {
        text: `${tab === 'video' ? '✅ ' : ''}🎬 ভিডিও (${videoFiles.length})`,
        callback_data: 'profile:tab:video:0',
      },
    ],
  ];

  if (tab === 'audio') {
    const pageSize = 5;
    const slice = audioFiles.slice(page * pageSize, (page + 1) * pageSize);
    if (slice.length === 0) {
      buttons.push([
        { text: '🎙️ প্রথম ভয়েস তৈরি করুন', callback_data: 'menu:create' },
        { text: '🏠 মেইন মেনু', callback_data: 'menu:main' },
      ]);
      return {
        text: `${header}\n🎧 **আমার অডিও ফাইলসমূহ**\nএখনো কোনো ভয়েস অডিও ফাইল তৈরি করা হয়নি।`,
        buttons,
      };
    }

    const lines = slice
      .map((g, idx) => {
        const num = page * pageSize + idx + 1;
        return `${num}. 🎧 **${g.voiceNameBn}** (${formatDurationHuman(g.durationSec)})\n   “${g.script.slice(0, 55)}${g.script.length > 55 ? '...' : ''}”`;
      })
      .join('\n\n');

    for (let idx = 0; idx < slice.length; idx++) {
      const g = slice[idx];
      const num = page * pageSize + idx + 1;
      buttons.push([
        {
          text: `📥 অডিও #${num} (${formatDurationHuman(g.durationSec)})`,
          callback_data: `file:audio:${g.id}`,
        },
        {
          text: `🔄 পুনরায়`,
          callback_data: `regen:${g.id}`,
        },
      ]);
    }

    const nav: InlineButton[] = [];
    if (page > 0) {
      nav.push({ text: '⬅️ পূর্বের', callback_data: `profile:tab:audio:${page - 1}` });
    }
    if ((page + 1) * pageSize < audioFiles.length) {
      nav.push({ text: 'পরবর্তী ➡️', callback_data: `profile:tab:audio:${page + 1}` });
    }
    if (nav.length > 0) buttons.push(nav);

    buttons.push([
      { text: '📦 সব ফাইল একসাথে পাঠান', callback_data: 'file:all' },
      { text: '🏠 মেইন মেনু', callback_data: 'menu:main' },
    ]);

    return {
      text: `${header}\n🎧 **আমার অডিও ফাইলসমূহ (পৃষ্ঠা ${page + 1})**\n\n${lines}`,
      buttons,
    };
  }

  if (tab === 'video') {
    const pageSize = 5;
    const slice = videoFiles.slice(page * pageSize, (page + 1) * pageSize);
    if (slice.length === 0) {
      buttons.push([
        { text: '🎬 প্রথম AI ভিডিও তৈরি করুন', callback_data: 'menu:video' },
        { text: '🏠 মেইন মেনু', callback_data: 'menu:main' },
      ]);
      return {
        text: `${header}\n🎬 **আমার ভিডিও ফাইলসমূহ**\nএখনো কোনো ভিডিও ফাইল তৈরি করা হয়নি।`,
        buttons,
      };
    }

    const lines = slice
      .map((v, idx) => {
        const num = page * pageSize + idx + 1;
        const dur = v.durationSec ? formatDurationHuman(v.durationSec) : '—';
        return `${num}. 🎬 **${v.title}** (${v.aspectRatio} · ${v.resolution.toUpperCase()} · ${dur})`;
      })
      .join('\n\n');

    for (let idx = 0; idx < slice.length; idx++) {
      const v = slice[idx];
      const num = page * pageSize + idx + 1;
      const shortTitle = v.title.slice(0, 18);
      buttons.push([
        {
          text: `📥 ভিডিও #${num}: ${shortTitle}${v.title.length > 18 ? '...' : ''}`,
          callback_data: `file:video:${v.id}`,
        },
      ]);
    }

    const nav: InlineButton[] = [];
    if (page > 0) {
      nav.push({ text: '⬅️ পূর্বের', callback_data: `profile:tab:video:${page - 1}` });
    }
    if ((page + 1) * pageSize < videoFiles.length) {
      nav.push({ text: 'পরবর্তী ➡️', callback_data: `profile:tab:video:${page + 1}` });
    }
    if (nav.length > 0) buttons.push(nav);

    buttons.push([
      { text: '📦 সব ফাইল একসাথে পাঠান', callback_data: 'file:all' },
      { text: '🏠 মেইন মেনু', callback_data: 'menu:main' },
    ]);

    return {
      text: `${header}\n🎬 **আমার ভিডিও ফাইলসমূহ (পৃষ্ঠা ${page + 1})**\n\n${lines}`,
      buttons,
    };
  }

  // Overview tab: combined Audio + Video recent files right inside ONE unified profile
  const recentAudio = audioFiles.slice(0, 3);
  const recentVideo = videoFiles.slice(0, 3);

  let filesSection = '';
  if (recentAudio.length === 0 && recentVideo.length === 0) {
    filesSection = '\n📂 **আমার ফাইলসমূহ:** এখনো কোনো অডিও বা ভিডিও তৈরি হয়নি।';
  } else {
    if (recentVideo.length > 0) {
      filesSection +=
        `\n🎬 **সাম্প্রতিক ভিডিও ফাইল:**\n` +
        recentVideo
          .map(
            (v, i) =>
              `  ${i + 1}. ${v.title.slice(0, 36)} (${v.resolution.toUpperCase()}, ${v.durationSec ? formatDurationHuman(v.durationSec) : '—'})`,
          )
          .join('\n');
    }
    if (recentAudio.length > 0) {
      filesSection +=
        `\n\n🎧 **সাম্প্রতিক অডিও ফাইল:**\n` +
        recentAudio
          .map(
            (g, i) =>
              `  ${i + 1}. ${g.voiceNameBn.split(' ')[0]} (${formatDurationHuman(g.durationSec)}) — “${g.script.slice(0, 32)}${g.script.length > 32 ? '...' : ''}”`,
          )
          .join('\n');
    }
  }

  for (let i = 0; i < recentVideo.length; i++) {
    const v = recentVideo[i];
    buttons.push([
      {
        text: `📥 🎬 ভিডিও #${i + 1}: ${v.title.slice(0, 22)}${v.title.length > 22 ? '...' : ''}`,
        callback_data: `file:video:${v.id}`,
      },
    ]);
  }
  for (let i = 0; i < recentAudio.length; i++) {
    const g = recentAudio[i];
    buttons.push([
      {
        text: `📥 🎧 অডিও #${i + 1}: ${g.voiceNameBn.split(' ')[0]} (${formatDurationHuman(g.durationSec)})`,
        callback_data: `file:audio:${g.id}`,
      },
    ]);
  }

  if (audioFiles.length > 0 || videoFiles.length > 0) {
    buttons.push([
      { text: '📦 সব ফাইল একসাথে পাঠান', callback_data: 'file:all' },
    ]);
  }

  buttons.push([
    { text: '💳 ব্যালেন্স ও রিচার্জ', callback_data: 'menu:wallet' },
    { text: '⚙️ স্পিড ও পিচ', callback_data: 'menu:settings' },
  ]);
  buttons.push([
    { text: '🎙️ নতুন ভয়েস', callback_data: 'menu:create' },
    { text: '🎬 নতুন ভিডিও', callback_data: 'menu:video' },
  ]);
  buttons.push([{ text: '🏠 মেইন মেনু', callback_data: 'menu:main' }]);

  return {
    text: `${header}${filesSection}`,
    buttons,
  };
}

export async function processBotInteraction(params: {
  user: BotUser;
  text?: string;
  callbackData?: string;
  source: 'telegram' | 'simulator';
  telegramChatId?: number;
  enqueueListenerFactory?: (jobId: string) => JobLifecycleListener;
  videoListenerFactory?: (jobId: string) => VideoJobLifecycleListener;
}): Promise<BotActionOutput> {
  let user = params.user;
  const text = params.text?.trim() ?? '';
  const cb = params.callbackData?.trim() ?? '';
  const messages: BotMessagePayload[] = [];
  const pendingAdminNotifications: Array<{
    text: string;
    buttons: InlineButton[][];
  }> = [];
  let pendingUserNotification:
    | { telegramId: string; text: string }
    | undefined;

  if (user.status === 'banned' && !botStore.isAdmin(user)) {
    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text: '⛔ আপনার অ্যাকাউন্টটি অ্যাডমিন কর্তৃক নিষিদ্ধ (Banned) করা হয়েছে। আপনি এই বট ব্যবহার করতে পারবেন না।',
      timestamp: nowTimeLabel(),
    });
    return { messages, user };
  }

  // -------------------------------------------------------------------------
  // 1. Handle /admin Authorization & Entry
  // -------------------------------------------------------------------------
  if (text === '/admin' || text.startsWith('/admin ')) {
    const arg = text.slice('/admin'.length).trim();
    const cfg = botStore.getConfig();

    const noAdminsYet = cfg.adminTelegramIds.length === 0;
    const validClaimCode = arg && arg === cfg.adminClaimCode;

    if (!botStore.isAdmin(user)) {
      if (noAdminsYet || validClaimCode) {
        user = botStore.authorizeTelegramAdmin(user.id) ?? user;
      } else {
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text:
            '🔒 আপনি অ্যাডমিন হিসেবে অনুমোদিত নন।\n' +
            'অ্যাডমিন অ্যাক্সেস নিতে `/admin <ClaimCode>` পাঠান অথবা Web Admin Panel থেকে আপনার Telegram ID যুক্ত করুন।',
          timestamp: nowTimeLabel(),
        });
        return { messages, user };
      }
    }

    user = botStore.updateUser(user.id, { step: 'idle', pendingContext: undefined }) ?? user;
    const dash = buildAdminDashboardMessage();
    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text: dash.text,
      timestamp: nowTimeLabel(),
      buttons: dash.buttons,
    });
    return { messages, user };
  }

  // Direct one-line Admin slash command: /setpay bKash 017XXXXXXXX Personal
  if (
    text === '/setpay' ||
    text.startsWith('/setpay ') ||
    text === '/addpay' ||
    text.startsWith('/addpay ')
  ) {
    if (!botStore.isAdmin(user)) {
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          '🔒 এই কমান্ডটি শুধুমাত্র অ্যাডমিনের জন্য।\n' +
          'প্রথমে `/admin ADMIN2026` পাঠিয়ে অ্যাডমিন অ্যাক্সেস নিন।',
        timestamp: nowTimeLabel(),
      });
      return { messages, user };
    }

    const rawArgs = text
      .replace(/^\/(setpay|addpay)/i, '')
      .trim();
    const parts = rawArgs.split(/\s+/).filter(Boolean);
    if (parts.length < 2) {
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          '⚠️ সঠিক ফরম্যাটে কমান্ডটি পাঠান:\n' +
          '`/setpay bKash 017XXXXXXXX Personal`\n' +
          'অথবা\n' +
          '`/setpay Nagad 018XXXXXXXX Agent`',
        timestamp: nowTimeLabel(),
      });
      return { messages, user };
    }

    const method = parts[0];
    const accountNumber = parts[1];
    const accountType = parts.slice(2).join(' ') || 'Personal (Send Money)';
    const cfg = botStore.getConfig();
    const nextAccounts = [
      ...(cfg.paymentAccounts ?? []),
      {
        id: `payacc-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
        method,
        accountNumber,
        accountType,
        enabled: true,
      },
    ];
    botStore.updateConfig({ paymentAccounts: nextAccounts });
    user =
      botStore.updateUser(user.id, {
        step: 'idle',
        pendingContext: undefined,
      }) ?? user;

    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text:
        `✅ পেমেন্ট নম্বর সফলভাবে যুক্ত হয়েছে!\n\n` +
        `• মাধ্যম: **${method}**\n` +
        `• নম্বর: \`${accountNumber}\`\n` +
        `• ধরন: **${accountType}**`,
      timestamp: nowTimeLabel(),
      buttons: [
        [{ text: '📲 Payment Numbers দেখুন', callback_data: 'adm:pay_nums' }],
        [{ text: '🛡️ Admin Dashboard', callback_data: 'adm:home' }],
      ],
    });
    return { messages, user };
  }

  if (text === '/setpaynote' || text.startsWith('/setpaynote ')) {
    if (!botStore.isAdmin(user)) {
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: '🔒 এই কমান্ডটি শুধুমাত্র অ্যাডমিনের জন্য।',
        timestamp: nowTimeLabel(),
      });
      return { messages, user };
    }
    const note = text.slice('/setpaynote'.length).trim();
    if (!note) {
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: '⚠️ নির্দেশনা লিখুন, যেমন:\n`/setpaynote ১. বিকাশে Send Money করুন ২. TrxID দিন`',
        timestamp: nowTimeLabel(),
      });
      return { messages, user };
    }
    botStore.updateConfig({ paymentInstructions: note });
    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text: `✅ ইউজার পেমেন্ট নির্দেশনা আপডেট হয়েছে:\n\n${note}`,
      timestamp: nowTimeLabel(),
    });
    return { messages, user };
  }

  // -------------------------------------------------------------------------
  // 2. Standard User Commands & Main Menu (+ Referral /start ref_<id>)
  // -------------------------------------------------------------------------
  if (
    text === '/start' ||
    text.startsWith('/start ') ||
    text === '/menu' ||
    cb === 'menu:main'
  ) {
    let referralWelcomeNote = '';
    if (text.startsWith('/start ')) {
      const startPayload = text.slice('/start '.length).trim();
      const refMatch = startPayload.match(/^ref_(\d+)$/i);
      if (refMatch) {
        const refTgId = refMatch[1];
        if (refTgId !== user.telegramId && !user.referredBy) {
          const referrer = botStore.findUserByTelegramIdOrUsername(refTgId);
          if (referrer && referrer.id !== user.id) {
            const bonus = Math.max(0, botStore.getConfig().referralBonusBdt ?? 20);
            user =
              botStore.updateUser(user.id, { referredBy: referrer.telegramId }) ??
              user;
            botStore.updateUser(referrer.id, {
              referralCount: (referrer.referralCount ?? 0) + 1,
            });
            if (bonus > 0) {
              botStore.adjustBalance({
                userId: referrer.id,
                amountDelta: bonus,
                type: 'referral_bonus',
                description: `Referral bonus from @${user.username || user.telegramId}`,
              });
            }
            pendingUserNotification = {
              telegramId: referrer.telegramId,
              text:
                `🎁 অভিনন্দন! আপনার রেফারেল লিংক থেকে নতুন ইউজার (${user.firstName}) যুক্ত হয়েছেন।\n` +
                (bonus > 0
                  ? `আপনার অ্যাকাউন্টে ৳${bonus} রেফারেল বোনাস যোগ করা হয়েছে!`
                  : 'আপনার রেফারেল সংখ্যা +১ বেড়েছে!'),
            };
            referralWelcomeNote = `\n🎁 আপনি **${referrer.firstName}**-এর রেফারেলে যুক্ত হয়েছেন!\n`;
          }
        }
      }
    }

    user =
      botStore.updateUser(user.id, {
        step: 'assistant_chat',
        pendingContext: undefined,
      }) ?? user;
    const currentVoice = getVoiceById(user.selectedVoiceId);
    const limit = botStore.getUserEffectiveDailyLimit(user);
    const isAdmin = botStore.isAdmin(user);
    const lang = user.language === 'en' ? 'en' : 'bn';
    const welcomeText =
      lang === 'en'
        ? `🤖 **Welcome to BanglaVoice ChatGPT & All-in-One AI Assistant, ${user.firstName}!**\n` +
          `${referralWelcomeNote}\n` +
          `💬 **ChatGPT Mode is ACTIVE!** Just type any question, code, math, analysis, or upload any Photo, PDF, Word, Excel, Voice, or Video directly.\n\n` +
          `• Voice Engine: **${currentVoice.nameEn}** · Speed: **${user.speed}x**\n` +
          `• Wallet: **৳${user.balance.toFixed(2)}** · Plan: **${user.tier === 'premium' ? 'Premium' : 'Free'}** (${user.dailyCount}/${limit})\n` +
          `• Saved Memories: **${(user.memories ?? []).length}** | History turns: **${(user.chatHistory ?? []).length}**\n\n` +
          `Choose a specialized AI studio below or start chatting right now:`
        : `🤖 **BanglaVoice All-in-One AI Assistant (ChatGPT Mode)-এ স্বাগতম, ${user.firstName}!**\n` +
          `${referralWelcomeNote}\n` +
          `💬 **ChatGPT মোড এখন চালু আছে!** বাংলা, ইংরেজি বা যেকোনো ভাষায় সরাসরি প্রশ্ন করুন, কোড লিখুন, ছবি/PDF/Word/Excel/ভয়েস/ভিডিও পাঠান—বট আপনার কথোপকথন ও মেমোরি মনে রেখে উত্তর দেবে।\n\n` +
          `• ভয়েস পার্সোনা: **${currentVoice.nameBn}** · স্পিড: **${user.speed}x**\n` +
          `• ব্যালেন্স: **৳${user.balance.toFixed(2)}** | প্ল্যান: **${user.tier === 'premium' ? 'Premium' : 'Free'}** (${user.dailyCount}/${limit})\n` +
          `• সংরক্ষিত মেমোরি: **${(user.memories ?? []).length}টি** | চ্যাট কনটেক্সট: **${(user.chatHistory ?? []).length} মেসেজ**\n\n` +
          `নিচের মেনু থেকে যেকোনো AI স্টুডিও বেছে নিন অথবা সরাসরি প্রশ্ন লিখুন:`;

    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text: welcomeText,
      timestamp: nowTimeLabel(),
      buttons: mainMenuButtons(isAdmin, lang),
    });
    return { messages, user, pendingUserNotification };
  }

  // Global Cancel / Language Toggle / Retry Actions
  if (cb === 'act:cancel' || /^\/cancel$/i.test(text)) {
    user =
      botStore.updateUser(user.id, {
        step: 'assistant_chat',
        pendingContext: undefined,
      }) ?? user;
    const lang = user.language === 'en' ? 'en' : 'bn';
    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text:
        lang === 'en'
          ? '⏹️ Current action cancelled. Returned to **ChatGPT AI Chat** mode.'
          : '⏹️ বর্তমান কাজ বাতিল করা হয়েছে। আপনি এখন আবার **AI চ্যাট (ChatGPT)** মোডে আছেন।',
      timestamp: nowTimeLabel(),
      buttons: mainMenuButtons(botStore.isAdmin(user), lang),
    });
    return { messages, user };
  }

  if (cb === 'lang:bn' || cb === 'lang:en') {
    const nextLang = cb === 'lang:en' ? 'en' : 'bn';
    user = botStore.updateUser(user.id, { language: nextLang }) ?? user;
    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text:
        nextLang === 'en'
          ? '✅ Interface & AI default response language set to **English**.'
          : '✅ বটের ইন্টারফেস ও AI উত্তর দেওয়ার ভাষা **বাংলা (Bangla)** সেট করা হয়েছে।',
      timestamp: nowTimeLabel(),
      buttons: mainMenuButtons(botStore.isAdmin(user), nextLang),
    });
    return { messages, user };
  }

  if (cb === 'act:retry') {
    const lastAction = user.pendingContext?.lastRetryAction;
    if (!lastAction) {
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: isEn(user)
          ? '⚠️ Nothing to retry right now. Send a new prompt!'
          : '⚠️ পুনরায় চেষ্টা করার মতো পূর্বের কোনো কাজ পাওয়া যায়নি। নতুন প্রম্পট পাঠান।',
        timestamp: nowTimeLabel(),
        buttons: mainMenuButtons(botStore.isAdmin(user), isEn(user) ? 'en' : 'bn'),
      });
      return { messages, user };
    }
    try {
      if (lastAction.kind === 'chat') {
        const res = await runAssistantChat({ user, message: lastAction.prompt });
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text:
            res.replyText +
            (res.sources.length > 0
              ? `\n\n🔗 **উৎস:**\n${res.sources.map((s, i) => `${i + 1}. ${s.title} — ${s.url}`).join('\n')}`
              : ''),
          timestamp: nowTimeLabel(),
          buttons: [
            [
              { text: '🔄 Retry', callback_data: 'act:retry' },
              { text: '🧹 নতুন চ্যাট', callback_data: 'chat:clear' },
              { text: '🏠 মেনু', callback_data: 'menu:main' },
            ],
          ],
        });
      } else if (lastAction.kind === 'image') {
        const ratio = (lastAction.extra as '1:1' | '16:9' | '9:16' | '4:3') || '1:1';
        const img = await generateAiImage({
          user,
          prompt: lastAction.prompt,
          aspectRatio: ratio,
        });
        user =
          botStore.updateUser(user.id, {
            lastUpload: {
              type: 'photo',
              filePath: img.filePath,
              filename: img.filename,
              mimeType: 'image/png',
              uploadedAt: new Date().toISOString(),
            },
          }) ?? user;
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `${img.caption}\n⚙️ Engine: ${img.engineLabel}`,
          timestamp: nowTimeLabel(),
          photo: { url: img.url, filePath: img.filePath, caption: img.caption },
          buttons: [
            [
              { text: '🔄 আরেকটি তৈরি (Retry)', callback_data: 'act:retry' },
              { text: '📐 2x Upscale', callback_data: 'img:quick_upscale' },
            ],
            [
              { text: '🎬 Image → Video', callback_data: 'img:quick_i2v' },
              { text: '🏠 মেইন মেনু', callback_data: 'menu:main' },
            ],
          ],
        });
      } else if (lastAction.kind === 'research') {
        const res = await runWebResearch({
          user,
          queryOrUrl: lastAction.prompt,
          deepReport: lastAction.extra === 'deep',
        });
        const srcBlock =
          res.sources.length > 0
            ? `\n\n🔗 **Verified Sources:**\n${res.sources.map((s, i) => `${i + 1}. ${s.title}\n   ${s.url}`).join('\n')}`
            : '';
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `🌐 **Web Research Report**\n\n${res.reportText}${srcBlock}`,
          timestamp: nowTimeLabel(),
          buttons: [
            [
              { text: '🔄 Retry', callback_data: 'act:retry' },
              { text: '🏠 মেইন মেনু', callback_data: 'menu:main' },
            ],
          ],
        });
      } else if (lastAction.kind === 'coding') {
        const mode = (lastAction.extra as 'write' | 'debug' | 'project') || 'write';
        const res = await runCodingAssistant({
          user,
          prompt: lastAction.prompt,
          mode,
        });
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: res.explanationAndCode.slice(0, 3800),
          timestamp: nowTimeLabel(),
          document: res.generatedFile,
          buttons: [
            [
              { text: '🔄 Retry', callback_data: 'act:retry' },
              { text: '🏠 মেইন মেনু', callback_data: 'menu:main' },
            ],
          ],
        });
      }
    } catch (err) {
      botStore.logError(`retry:${lastAction.kind}`, err, user.id);
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: `❌ Retry ব্যর্থ হয়েছে: ${err instanceof Error ? err.message : 'Error'}`,
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '🏠 মেইন মেনু', callback_data: 'menu:main' }]],
      });
    }
    return { messages, user };
  }

  // -------------------------------------------------------------------------
  // 2B. Complete All-in-One AI Assistant Modules (Chat, Image, Voice, Docs, Coding, Research, Memory)
  // -------------------------------------------------------------------------
  const checkFeatureDisabled = (mod: Parameters<typeof botStore.isFeatureEnabled>[0]): boolean => {
    if (botStore.isFeatureEnabled(mod)) return false;
    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text: isEn(user)
        ? `🔒 The **${mod.toUpperCase()}** module is currently disabled by Admin.`
        : `🔒 অ্যাডমিন কর্তৃক **${mod.toUpperCase()}** ফিচারটি সাময়িকভাবে বন্ধ রাখা হয়েছে।`,
      timestamp: nowTimeLabel(),
      buttons: [[{ text: '🏠 মেইন মেনু', callback_data: 'menu:main' }]],
    });
    return true;
  };

  // --- Module 1: AI Chat Assistant (/chat, /ask) ---
  if (cb === 'menu:chat' || /^\/chat$/i.test(text)) {
    if (checkFeatureDisabled('chat')) return { messages, user };
    user =
      botStore.updateUser(user.id, {
        step: 'assistant_chat',
        pendingContext: undefined,
      }) ?? user;
    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text: isEn(user)
        ? `💬 **AI Chat Assistant (ChatGPT Mode)**\n\n` +
          `Ask anything—reasoning, analysis, math, writing, translation, coding, or upload an Image / PDF / Audio.\n` +
          `• Saved memories: **${(user.memories ?? []).length}** | Active history turns: **${(user.chatHistory ?? []).length}**\n` +
          `• Tip: Say *"Remember my business name is ..."* anytime to save long-term memory!`
        : `💬 **AI চ্যাট অ্যাসিস্ট্যান্ট (ChatGPT মোড)**\n\n` +
          `যেকোনো প্রশ্ন, বিশ্লেষণ, গণিত, লেখালেখি, অনুবাদ বা প্রোগ্রামিং নিয়ে সরাসরি কথা বলুন।\n` +
          `• কথোপকথন ও দীর্ঘ-মেয়াদী মেমোরি মনে রাখা হচ্ছে (**${(user.memories ?? []).length}টি মেমোরি** · **${(user.chatHistory ?? []).length} চ্যাট টার্ন**)।\n` +
          `• ছবি বা ফাইল আপলোড করেও প্রশ্ন করতে পারবেন!`,
      timestamp: nowTimeLabel(),
      buttons: [
        [
          { text: '🌐 Web Search সহ প্রশ্ন', callback_data: 'menu:research' },
          { text: '🧠 আমার মেমোরি', callback_data: 'menu:memory' },
        ],
        [
          { text: '🧹 চ্যাট রিসেট (/clear)', callback_data: 'chat:clear' },
          { text: '🎙️ ভয়েস তৈরি করুন', callback_data: 'menu:create' },
        ],
        [{ text: '🏠 মেইন মেনু', callback_data: 'menu:main' }],
      ],
    });
    return { messages, user };
  }

  if (text.startsWith('/ask ')) {
    if (checkFeatureDisabled('chat')) return { messages, user };
    const q = text.slice('/ask '.length).trim();
    if (q) {
      try {
        user =
          botStore.updateUser(user.id, {
            step: 'assistant_chat',
            pendingContext: { lastRetryAction: { kind: 'chat', prompt: q } },
          }) ?? user;
        const res = await runAssistantChat({ user, message: q });
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text:
            res.replyText +
            (res.rememberedNote ? `\n\n🧠 মেমোরিতে সেভ হয়েছে: _${res.rememberedNote}_` : '') +
            (res.sources.length > 0
              ? `\n\n🔗 **উৎস:**\n${res.sources.map((s, i) => `${i + 1}. ${s.title} — ${s.url}`).join('\n')}`
              : ''),
          timestamp: nowTimeLabel(),
          buttons: [
            [
              { text: '🔄 Retry', callback_data: 'act:retry' },
              { text: '🔊 ভয়েসে শুনুন', callback_data: 'chat:tts_last' },
            ],
            [
              { text: '🧹 নতুন চ্যাট', callback_data: 'chat:clear' },
              { text: '🏠 মেইন মেনু', callback_data: 'menu:main' },
            ],
          ],
        });
      } catch (err) {
        botStore.logError('chat', err, user.id);
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `❌ উত্তর তৈরি করা যায়নি: ${err instanceof Error ? err.message : 'Error'}`,
          timestamp: nowTimeLabel(),
          buttons: [[{ text: '🔄 Retry', callback_data: 'act:retry' }]],
        });
      }
      return { messages, user };
    }
  }

  if (cb === 'chat:clear' || /^\/clear$/i.test(text)) {
    user = botStore.clearChatHistory(user.id) ?? user;
    user = botStore.updateUser(user.id, { step: 'assistant_chat' }) ?? user;
    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text: isEn(user)
        ? '🧹 Current conversation history cleared! (Your long-term Memories are still safely kept.) Start a fresh topic anytime.'
        : '🧹 বর্তমান চ্যাট হিস্টোরি পরিষ্কার করা হয়েছে! (আপনার সংরক্ষিত দীর্ঘ-মেয়াদী মেমোরি সুরক্ষিত আছে।) নতুন বিষয় লিখুন:',
      timestamp: nowTimeLabel(),
      buttons: [
        [
          { text: '🧠 মেমোরি দেখুন', callback_data: 'menu:memory' },
          { text: '🏠 মেইন মেনু', callback_data: 'menu:main' },
        ],
      ],
    });
    return { messages, user };
  }

  if (cb === 'chat:tts_last') {
    const lastAssistant = [...(user.chatHistory ?? [])]
      .reverse()
      .find((t) => t.role === 'assistant');
    if (!lastAssistant?.text) {
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: '⚠️ ভয়েস করার জন্য কোনো পূর্বের AI উত্তর পাওয়া যায়নি।',
        timestamp: nowTimeLabel(),
      });
      return { messages, user };
    }
    return await showBanglaPreviewForScript({
      user,
      rawScript: lastAssistant.text.slice(0, 3500),
    });
  }

  // --- Module 2: AI Image & Design Studio (/image, img:*) ---
  if (cb === 'menu:image' || /^\/image$/i.test(text) || text.startsWith('/image ')) {
    if (checkFeatureDisabled('image')) return { messages, user };
    const inlinePrompt = text.startsWith('/image ') ? text.slice('/image '.length).trim() : '';
    if (inlinePrompt) {
      try {
        user =
          botStore.updateUser(user.id, {
            pendingContext: { lastRetryAction: { kind: 'image', prompt: inlinePrompt, extra: '1:1' } },
          }) ?? user;
        const img = await generateAiImage({
          user,
          prompt: inlinePrompt,
          aspectRatio: '1:1',
        });
        user =
          botStore.updateUser(user.id, {
            lastUpload: {
              type: 'photo',
              filePath: img.filePath,
              filename: img.filename,
              mimeType: 'image/png',
              uploadedAt: new Date().toISOString(),
            },
          }) ?? user;
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `${img.caption}\n⚙️ Engine: ${img.engineLabel}`,
          timestamp: nowTimeLabel(),
          photo: { url: img.url, filePath: img.filePath, caption: img.caption },
          buttons: [
            [
              { text: '🔄 Retry', callback_data: 'act:retry' },
              { text: '📐 2x HD Upscale', callback_data: 'img:quick_upscale' },
            ],
            [
              { text: '✨ Enhance', callback_data: 'img:quick_enhance' },
              { text: '🎬 Image → Video', callback_data: 'img:quick_i2v' },
            ],
            [{ text: '🏠 মেইন মেনু', callback_data: 'menu:main' }],
          ],
        });
      } catch (err) {
        botStore.logError('image', err, user.id);
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `❌ ছবি তৈরি করা যায়নি: ${err instanceof Error ? err.message : 'Error'}`,
          timestamp: nowTimeLabel(),
          buttons: [
            [{ text: '🖌️ Vector Logo/Poster বানান (Gemini SVG)', callback_data: 'img:design:poster' }],
            [{ text: '🏠 মেইন মেনু', callback_data: 'menu:main' }],
          ],
        });
      }
      return { messages, user };
    }

    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text:
        `🎨 **AI Image & Graphic Design Studio**\n\n` +
        `এক জায়গায় ছবি তৈরি, ডিজাইন এবং ফটো প্রসেসিং:\n` +
        `• **Text-to-Image (Free Flux AI):** Square (1:1), YouTube (16:9), Reels (9:16)\n` +
        `• **Professional Graphic Design (বাংলা + English সাপোর্ট):** Logo, Banner, Poster, YouTube Thumbnail\n` +
        `• **Photo Tools:** Reference Redesign, Enhance & Restore, 2x HD Upscale, Solid BG Removal`,
      timestamp: nowTimeLabel(),
      buttons: [
        [
          { text: '🖼️ ছবি তৈরি (1:1)', callback_data: 'img:t2i:1:1' },
          { text: '📺 16:9', callback_data: 'img:t2i:16:9' },
          { text: '📱 9:16', callback_data: 'img:t2i:9:16' },
        ],
        [
          { text: '🏷️ Logo ডিজাইন', callback_data: 'img:design:logo' },
          { text: '🖼️ Banner ডিজাইন', callback_data: 'img:design:banner' },
        ],
        [
          { text: '📰 Poster ডিজাইন', callback_data: 'img:design:poster' },
          { text: '▶️ YouTube Thumbnail', callback_data: 'img:design:thumbnail' },
        ],
        [
          { text: '🎭 Reference → নতুন ডিজাইন', callback_data: 'img:ref' },
          { text: '✨ Photo Enhance', callback_data: 'img:enhance' },
        ],
        [
          { text: '📐 2x HD Upscale', callback_data: 'img:upscale' },
          { text: '✂️ Studio BG Remove', callback_data: 'img:bg' },
        ],
        [
          { text: 'ℹ️ Object Removal তথ্য', callback_data: 'img:obj_info' },
          { text: '🏠 মেইন মেনু', callback_data: 'menu:main' },
        ],
      ],
    });
    return { messages, user };
  }

  if (cb.startsWith('img:')) {
    if (checkFeatureDisabled('image')) return { messages, user };

    if (cb.startsWith('img:t2i:')) {
      const ratio = (cb.slice('img:t2i:'.length) as '1:1' | '16:9' | '9:16' | '4:3') || '1:1';
      user =
        botStore.updateUser(user.id, {
          step: 'img_t2i',
          pendingContext: { imageAspectRatio: ratio },
        }) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `🎨 **Text-to-Image (${ratio})**\n\n` +
          `আপনি কেমন ছবি তৈরি করতে চান তা বাংলা বা ইংরেজিতে বিস্তারিত লিখে পাঠান:\n` +
          `উদাহরণ: _“রাতের ঢাকা শহরের ভবিষ্যৎমুখী নিয়ন দৃশ্য, বৃষ্টিভেজা রাস্তা, সিনেমাটিক আলো”_`,
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '❌ বাতিল', callback_data: 'act:cancel' }]],
      });
      return { messages, user };
    }

    if (cb.startsWith('img:design:')) {
      const kind = cb.slice('img:design:'.length) as 'logo' | 'banner' | 'poster' | 'thumbnail';
      user =
        botStore.updateUser(user.id, {
          step: 'img_design_prompt',
          pendingContext: { imageDesignKind: kind },
        }) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `🖌️ **প্রফেশনাল ${kind.toUpperCase()} ডিজাইন (বাংলা + English Text Support)**\n\n` +
          `ডিজাইনের নাম, মূল লেখা (Text), রঙ ও থিম লিখে পাঠান:\n` +
          `উদাহরণ: _“ব্র্যান্ড নাম: টেক বাংলা, আধুনিক নীল ও সোনালী থিম, মিনিমাল প্রিমিয়াম স্টাইল”_`,
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '❌ বাতিল', callback_data: 'act:cancel' }]],
      });
      return { messages, user };
    }

    if (cb === 'img:ref') {
      user = botStore.updateUser(user.id, { step: 'img_ref_prompt' }) ?? user;
      const hasPhoto = user.lastUpload?.type === 'photo' && fs.existsSync(user.lastUpload.filePath);
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: hasPhoto
          ? `🎭 **Reference Image → নতুন ডিজাইন**\nআপনার পূর্বের ছবিটি সংরক্ষিত আছে! নতুন ছবি আপলোড করুন অথবা এই ছবিতে কী পরিবর্তন/নতুন ডিজাইন চান তা লিখে পাঠান:`
          : `🎭 **Reference Image → নতুন ডিজাইন**\nপ্রথমে আপনার রেফারেন্স ছবি (Photo) আপলোড করুন (ছবির Caption-এ কী ধরনের নতুন ডিজাইন চান তা লিখতে পারেন):`,
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '❌ বাতিল', callback_data: 'act:cancel' }]],
      });
      return { messages, user };
    }

    if (cb === 'img:enhance' || cb === 'img:upscale' || cb === 'img:bg') {
      const stepMap = {
        'img:enhance': 'img_enhance_wait',
        'img:upscale': 'img_upscale_wait',
        'img:bg': 'img_bg_wait',
      } as const;
      const nextStep = stepMap[cb];
      user = botStore.updateUser(user.id, { step: nextStep }) ?? user;
      const hasPhoto = user.lastUpload?.type === 'photo' && fs.existsSync(user.lastUpload.filePath);
      const btns: InlineButton[][] = [];
      if (hasPhoto) {
        const quickCb =
          cb === 'img:enhance'
            ? 'img:quick_enhance'
            : cb === 'img:upscale'
              ? 'img:quick_upscale'
              : 'img:quick_bg';
        btns.push([{ text: '✅ সর্বশেষ ছবিতেই এটি করুন', callback_data: quickCb }]);
      }
      btns.push([{ text: '❌ বাতিল', callback_data: 'act:cancel' }]);
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          cb === 'img:enhance'
            ? '✨ ছবি Enhance & Restore করার জন্য আপনার **Photo** পাঠান:'
            : cb === 'img:upscale'
              ? '📐 **2x HD Upscale** করার জন্য আপনার **Photo** পাঠান:'
              : '✂️ **Studio Background Remove** করার জন্য আপনার **Photo** পাঠান (সলিড বা পরিষ্কার ব্যাকগ্রাউন্ডের জন্য সবচেয়ে কার্যকর):',
        timestamp: nowTimeLabel(),
        buttons: btns,
      });
      return { messages, user };
    }

    if (cb === 'img:quick_enhance' || cb === 'img:quick_upscale' || cb === 'img:quick_bg') {
      const up = user.lastUpload;
      if (!up || up.type !== 'photo' || !fs.existsSync(up.filePath)) {
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: '⚠️ কোনো ছবি পাওয়া যায়নি। প্রথমে একটি ছবি পাঠান।',
          timestamp: nowTimeLabel(),
        });
        return { messages, user };
      }
      try {
        const out =
          cb === 'img:quick_enhance'
            ? await enhanceAndRestorePhoto({ user, inputPath: up.filePath })
            : cb === 'img:quick_upscale'
              ? await upscalePhoto2x({ user, inputPath: up.filePath })
              : await removeSolidBackgroundLocal({ user, inputPath: up.filePath });

        user =
          botStore.updateUser(user.id, {
            step: 'assistant_chat',
            lastUpload: {
              type: 'photo',
              filePath: out.filePath,
              filename: out.filename,
              mimeType: 'image/png',
              uploadedAt: new Date().toISOString(),
            },
          }) ?? user;

        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `${out.caption}\n⚙️ ${out.engineLabel}`,
          timestamp: nowTimeLabel(),
          photo: { url: out.url, filePath: out.filePath, caption: out.caption },
          buttons: [
            [
              { text: '📐 2x Upscale', callback_data: 'img:quick_upscale' },
              { text: '🎬 Image → Video', callback_data: 'img:quick_i2v' },
            ],
            [{ text: '🎨 ইমেজ স্টুডিও', callback_data: 'menu:image' }],
          ],
        });
      } catch (err) {
        botStore.logError('image:process', err, user.id);
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `❌ প্রসেস করা যায়নি: ${err instanceof Error ? err.message : 'Error'}`,
          timestamp: nowTimeLabel(),
        });
      }
      return { messages, user };
    }

    if (cb === 'img:quick_i2v') {
      const up = user.lastUpload;
      if (!up || up.type !== 'photo' || !fs.existsSync(up.filePath)) {
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: '⚠️ প্রথমে একটি ছবি পাঠান বা তৈরি করুন।',
          timestamp: nowTimeLabel(),
        });
        return { messages, user };
      }
      const draft: VideoDraftContext = {
        ...defaultVideoDraft(user, 'image_to_video'),
        uploadedImagePath: up.filePath,
        title: 'ছবি থেকে AI ভিডিও',
      };
      user =
        botStore.updateUser(user.id, {
          step: 'awaiting_video_i2v_prompt',
          pendingContext: { videoDraft: draft },
        }) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `🖼️➡️🎬 **ছবিটি যুক্ত হয়েছে! এখন ভিডিওর বর্ণনা/ভয়েস লিখুন:**\n\n` +
          `এই ছবি দিয়ে কী বিষয়ে ভিডিও বানাতে চান তা সংক্ষেপে লিখুন (AI বাংলা ভয়েসওভার ও সাবটাইটেলসহ মোশন ভিডিও তৈরি করবে)।`,
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '❌ বাতিল', callback_data: 'act:cancel' }]],
      });
      return { messages, user };
    }

    if (cb === 'img:obj_info') {
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `ℹ️ **Object Removal / Generative Image Editing সম্পর্কে স্বচ্ছ তথ্য:**\n\n` +
          `• জটিল ছবি থেকে নির্দিষ্ট কোনো বস্তু মুছে AI দিয়ে ব্যাকগ্রাউন্ড পূরণ (Semantic Generative Inpainting) ও Gemini Imagen 4 মডেলের জন্য **Paid Gemini API Key** প্রয়োজন, যা বর্তমানে সক্রিয় নেই।\n` +
          `• **বর্তমানে সম্পূর্ণ ফ্রিতে যা ব্যবহার করতে পারবেন:**\n` +
          `  ✅ Text-to-Image (Flux Free Engine)\n` +
          `  ✅ Logo / Banner / Poster / Thumbnail (Gemini SVG + Noto Bangla HD)\n` +
          `  ✅ Reference Image → নতুন ডিজাইন\n` +
          `  ✅ Photo Enhance & Restore, 2x HD Upscale এবং Solid-Background Studio Removal`,
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '🎨 Image Studio-তে ফিরুন', callback_data: 'menu:image' }]],
      });
      return { messages, user };
    }
  }

  // --- Module 4: Unified Voice & Audio Studio (STT, Translate, Noise Removal, EN TTS, Bangla Voices) ---
  if (cb === 'menu:voice_studio') {
    if (checkFeatureDisabled('voice')) return { messages, user };
    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text:
        `🎙️ **AI Voice & Audio Studio**\n\n` +
        `• **বাংলা AI ভয়েস:** ১৬টি Male, Female ও Cartoon কণ্ঠ (Unlimited Duration)\n` +
        `• **English Voice (TTS):** প্রাকৃতিক Male/Female ইংরেজি কণ্ঠ\n` +
        `• **Speech-to-Text (STT):** ভয়েস মেসেজ/অডিও থেকে বাংলা-ইংরেজি লেখা বের করা\n` +
        `• **Audio Translation:** বাংলা অডিও → English MP3 অথবা English অডিও → বাংলা MP3\n` +
        `• **Noise Removal & Enhance:** নয়েজ কমিয়ে স্টুডিও-মানের অডিও`,
      timestamp: nowTimeLabel(),
      buttons: [
        [
          { text: '🎙️ বাংলা ভয়েস তৈরি (১৬ কণ্ঠ)', callback_data: 'menu:create' },
          { text: '🔊 ভয়েস ডেমো', callback_data: 'menu:demos' },
        ],
        [
          { text: '🇬🇧 English Voice (TTS)', callback_data: 'vstudio:tts_en' },
          { text: '📝 অডিও → লেখা (STT)', callback_data: 'vstudio:stt' },
        ],
        [
          { text: '🌍 অডিও অনুবাদ (BN↔EN)', callback_data: 'vstudio:translate:menu' },
          { text: '✨ Noise Removal', callback_data: 'vstudio:enhance' },
        ],
        [
          { text: '📄 লং স্ক্রিপ্ট মোড', callback_data: 'menu:longscript' },
          { text: '🔐 Voice Cloning তথ্য', callback_data: 'vstudio:clone_info' },
        ],
        [{ text: '🏠 মেইন মেনু', callback_data: 'menu:main' }],
      ],
    });
    return { messages, user };
  }

  if (cb.startsWith('vstudio:')) {
    if (checkFeatureDisabled('voice')) return { messages, user };
    if (cb === 'vstudio:stt') {
      user = botStore.updateUser(user.id, { step: 'voice_stt_wait' }) ?? user;
      const hasAudio = user.lastUpload?.type === 'audio' && fs.existsSync(user.lastUpload.filePath);
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: '📝 **Speech-to-Text (STT):** সরাসরি টেলিগ্রামে Voice Record করুন অথবা MP3/WAV/OGG ফাইল পাঠান:',
        timestamp: nowTimeLabel(),
        buttons: [
          ...(hasAudio ? [[{ text: '✅ সর্বশেষ অডিও ট্রান্সক্রাইব করুন', callback_data: 'vstudio:do_stt' }]] : []),
          [{ text: '❌ বাতিল', callback_data: 'act:cancel' }],
        ],
      });
      return { messages, user };
    }
    if (cb === 'vstudio:do_stt') {
      const up = user.lastUpload;
      if (!up || up.type !== 'audio' || !fs.existsSync(up.filePath)) {
        messages.push({ id: makeMsgId(), sender: 'bot', text: '⚠️ আগে একটি অডিও বা ভয়েস পাঠান।', timestamp: nowTimeLabel() });
        return { messages, user };
      }
      try {
        const res = await transcribeAudioFile({ user, filePath: up.filePath, mimeType: up.mimeType });
        user = botStore.updateUser(user.id, { step: 'assistant_chat' }) ?? user;
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `📝 **অডিও থেকে প্রাপ্ত লেখা (Transcript):**\n\n${res.transcript}`,
          timestamp: nowTimeLabel(),
          buttons: [
            [
              { text: '🌍 English-এ অনুবাদ', callback_data: 'vstudio:do_tr:en' },
              { text: '🇧🇩 বাংলায় অনুবাদ', callback_data: 'vstudio:do_tr:bn' },
            ],
            [{ text: '🏠 মেইন মেনু', callback_data: 'menu:main' }],
          ],
        });
      } catch (err) {
        messages.push({ id: makeMsgId(), sender: 'bot', text: `❌ STT ব্যর্থ হয়েছে: ${err instanceof Error ? err.message : 'Error'}`, timestamp: nowTimeLabel() });
      }
      return { messages, user };
    }
    if (cb === 'vstudio:enhance') {
      user = botStore.updateUser(user.id, { step: 'voice_enhance_wait' }) ?? user;
      const hasAudio = user.lastUpload?.type === 'audio' && fs.existsSync(user.lastUpload.filePath);
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: '✨ **Audio Noise Removal & Studio Enhancement:** আপনার Voice বা Audio ফাইল পাঠান:',
        timestamp: nowTimeLabel(),
        buttons: [
          ...(hasAudio ? [[{ text: '✅ সর্বশেষ অডিও Enhance করুন', callback_data: 'vstudio:do_enhance' }]] : []),
          [{ text: '❌ বাতিল', callback_data: 'act:cancel' }],
        ],
      });
      return { messages, user };
    }
    if (cb === 'vstudio:do_enhance') {
      const up = user.lastUpload;
      if (!up || up.type !== 'audio' || !fs.existsSync(up.filePath)) {
        messages.push({ id: makeMsgId(), sender: 'bot', text: '⚠️ আগে একটি অডিও বা ভয়েস পাঠান।', timestamp: nowTimeLabel() });
        return { messages, user };
      }
      try {
        const enh = await enhanceAudioWithNoiseRemoval({ user, inputPath: up.filePath });
        user = botStore.updateUser(user.id, { step: 'assistant_chat' }) ?? user;
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `✅ **Audio Enhanced & Noise Reduced!** (${enh.durationSec}s)`,
          timestamp: nowTimeLabel(),
          audio: {
            generationId: `enh-${Date.now()}`,
            url: enh.url,
            filePath: enh.filePath,
            title: 'Studio Enhanced Audio',
            performer: 'BanglaVoice Audio Studio',
            durationSec: enh.durationSec,
            fileSizeBytes: enh.fileSizeBytes,
          },
          buttons: [[{ text: '🏠 মেইন মেনু', callback_data: 'menu:main' }]],
        });
      } catch (err) {
        messages.push({ id: makeMsgId(), sender: 'bot', text: `❌ অডিও এনহ্যান্স ব্যর্থ: ${err instanceof Error ? err.message : 'Error'}`, timestamp: nowTimeLabel() });
      }
      return { messages, user };
    }
    if (cb === 'vstudio:translate:menu') {
      const hasAudio = user.lastUpload?.type === 'audio' && fs.existsSync(user.lastUpload.filePath);
      user = botStore.updateUser(user.id, { step: 'voice_translate_wait' }) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: '🌍 **Audio Translation (Voice → Voice):**\nঅডিও ফাইল বা Voice Message পাঠান, অথবা সর্বশেষ আপলোড করা অডিও অনুবাদ করুন:',
        timestamp: nowTimeLabel(),
        buttons: [
          ...(hasAudio
            ? [
                [
                  { text: '🇧🇩 → 🇬🇧 English MP3 বানান', callback_data: 'vstudio:do_tr:en' },
                  { text: '🇬🇧 → 🇧🇩 বাংলা MP3 বানান', callback_data: 'vstudio:do_tr:bn' },
                ],
              ]
            : []),
          [{ text: '❌ বাতিল', callback_data: 'act:cancel' }],
        ],
      });
      return { messages, user };
    }
    if (cb.startsWith('vstudio:do_tr:')) {
      const targetLang = cb.endsWith(':en') ? 'en' : 'bn';
      const up = user.lastUpload;
      if (!up || up.type !== 'audio' || !fs.existsSync(up.filePath)) {
        messages.push({ id: makeMsgId(), sender: 'bot', text: '⚠️ আগে একটি অডিও বা ভয়েস পাঠান।', timestamp: nowTimeLabel() });
        return { messages, user };
      }
      try {
        const res = await translateAudioToTargetLanguage({
          user,
          inputPath: up.filePath,
          mimeType: up.mimeType,
          targetLang,
        });
        user = botStore.updateUser(user.id, { step: 'assistant_chat' }) ?? user;
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text:
            `🌍 **Audio Translation (${targetLang.toUpperCase()}) সম্পন্ন!**\n\n` +
            `• মূল কথা: _${res.originalText.slice(0, 300)}_\n` +
            `• অনুবাদ: **${res.translatedText.slice(0, 400)}**`,
          timestamp: nowTimeLabel(),
          audio: {
            generationId: `tr-${Date.now()}`,
            url: res.audio.url,
            filePath: res.audio.filePath,
            title: `Translated (${targetLang.toUpperCase()})`,
            performer: 'BanglaVoice Studio',
            durationSec: res.audio.durationSec,
            fileSizeBytes: res.audio.fileSizeBytes,
          },
          buttons: [[{ text: '🏠 মেইন মেনু', callback_data: 'menu:main' }]],
        });
      } catch (err) {
        messages.push({ id: makeMsgId(), sender: 'bot', text: `❌ অনুবাদ ব্যর্থ: ${err instanceof Error ? err.message : 'Error'}`, timestamp: nowTimeLabel() });
      }
      return { messages, user };
    }
    if (cb === 'vstudio:tts_en') {
      user =
        botStore.updateUser(user.id, {
          step: 'voice_translate_wait',
          pendingContext: { configKey: 'tts_en' },
        }) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: '🇬🇧 **English AI Voice (TTS):** ইংরেজি টেক্সট লিখে পাঠান (যেকোনো বাংলা লিখলে তা ইংরেজিতে অনুবাদ হয়ে ইংরেজি ভয়েস হবে না—সরাসরি ইংরেজি পাঠান):',
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '❌ বাতিল', callback_data: 'act:cancel' }]],
      });
      return { messages, user };
    }
    if (cb === 'vstudio:clone_info') {
      const hasEleven = Boolean(botStore.getConfig().elevenLabsApiKey || process.env.ELEVENLABS_API_KEY);
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: hasEleven
          ? '🔐 Voice Cloning কনফিগারেশন সক্রিয় আছে।'
          : `🔐 **Voice Cloning (অনুমোদিত কণ্ঠ) সম্পর্কে স্বচ্ছ তথ্য:**\n\n` +
            `জিরো-শট কাস্টম Voice Cloning-এর জন্য আলাদা থার্ড-পার্টি পেইড ক্লোনিং API (যেমন ElevenLabs API Key) প্রয়োজন হয়। বর্তমানে এটি কনফিগার করা নেই—তাই মিথ্যা/নকল ক্লোনিং দেখানো হবে না।\n\n` +
            `✅ আপনি ১৬টি স্টুডিও বাংলা পার্সোনা, English Neural Voice, STT, Audio Translation এবং FFmpeg Noise Removal সবকিছুই এখনই বিনামূল্যে ব্যবহার করতে পারবেন।`,
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '🎙️ Voice Studio-তে ফিরুন', callback_data: 'menu:voice_studio' }]],
      });
      return { messages, user };
    }
  }

  // --- Module 5: AI Document Assistant (/docs, doc:*) ---
  if (cb === 'menu:docs' || /^\/docs$/i.test(text)) {
    if (checkFeatureDisabled('documents')) return { messages, user };
    const upDoc = user.lastUpload?.type === 'document' && fs.existsSync(user.lastUpload.filePath)
      ? user.lastUpload
      : undefined;
    const activeDocBtns: InlineButton[][] = upDoc
      ? [
          [
            { text: '📋 সারসংক্ষেপ (Summarize)', callback_data: 'doc:action:summary' },
            { text: '❓ ফাইল থেকে প্রশ্ন (Q&A)', callback_data: 'doc:action:qa' },
          ],
          [
            { text: '🇧🇩 বাংলায় অনুবাদ', callback_data: 'doc:action:tr_bn' },
            { text: '🇬🇧 Translate EN', callback_data: 'doc:action:tr_en' },
          ],
        ]
      : [];

    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text:
        `📄 **AI Document Assistant**\n\n` +
        (upDoc
          ? `📎 বর্তমান সংযুক্ত ফাইল: **${upDoc.filename}**\n\n`
          : `যেকোনো **PDF, Word (.docx), Excel (.xlsx/.csv) বা Text** ফাইল এখানে পাঠান — AI ফাইল পড়বে, সারসংক্ষেপ করবে, অনুবাদ করবে এবং আপনার সব প্রশ্নের উত্তর দেবে।\n\n`) +
        `**নতুন ডকুমেন্ট তৈরি করুন (Real Downloadable Files):**\n` +
        `• 📝 Word (.docx) | 📊 Excel (.xlsx) | 📽️ PowerPoint (.pptx) | 📑 PDF (.pdf)`,
      timestamp: nowTimeLabel(),
      buttons: [
        ...activeDocBtns,
        [{ text: '📂 বিশ্লেষণের জন্য ফাইল আপলোড', callback_data: 'doc:read' }],
        [
          { text: '📝 Word (.docx)', callback_data: 'doc:create:docx' },
          { text: '📊 Excel (.xlsx)', callback_data: 'doc:create:xlsx' },
        ],
        [
          { text: '📽️ PowerPoint (.pptx)', callback_data: 'doc:create:pptx' },
          { text: '📑 PDF রিপোর্ট', callback_data: 'doc:create:pdf' },
        ],
        [{ text: '🏠 মেইন মেনু', callback_data: 'menu:main' }],
      ],
    });
    return { messages, user };
  }

  if (cb.startsWith('doc:')) {
    if (checkFeatureDisabled('documents')) return { messages, user };
    if (cb === 'doc:read') {
      user = botStore.updateUser(user.id, { step: 'doc_wait_file' }) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: '📂 আপনার **PDF, Word (.docx), Excel (.xlsx), CSV বা Text** ফাইলটি আপলোড করুন (Caption-এ আপনার প্রশ্ন বা কাজের নির্দেশ লিখতে পারেন):',
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '❌ বাতিল', callback_data: 'act:cancel' }]],
      });
      return { messages, user };
    }
    if (cb.startsWith('doc:create:')) {
      const fmt = cb.slice('doc:create:'.length) as 'pdf' | 'docx' | 'xlsx' | 'pptx';
      user =
        botStore.updateUser(user.id, {
          step: 'doc_create_prompt',
          pendingContext: { docCreateFormat: fmt },
        }) ?? user;
      const examples: Record<string, string> = {
        docx: '“ডিজিটাল মার্কেটিং এজেন্সির জন্য একটি পূর্ণাঙ্গ প্রজেক্ট প্রপোজাল ও বাজেট প্ল্যান”',
        xlsx: '“একটি মাসিক ই-কমার্স সেলস ও খরচের শিট (তারিখ, পণ্য, পরিমাণ, লাভসহ)”',
        pptx: '“কৃত্রিম বুদ্ধিমত্তা ও ভবিষ্যতের কর্মসংস্থান বিষয়ে ৬ স্লাইডের প্রেজেন্টেশন”',
        pdf: '“অনলাইন বিজনেস শুরুর ৩০ দিনের রোডম্যাপ রিপোর্ট”',
      };
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `📄 **নতুন ${fmt.toUpperCase()} ফাইল তৈরি**\n\n` +
          `আপনি কোন বিষয় বা তথ্যের ওপর **.${fmt}** ডকুমেন্ট তৈরি করতে চান তা বিস্তারিত লিখুন:\n` +
          `উদাহরণ: _${examples[fmt]}_`,
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '❌ বাতিল', callback_data: 'act:cancel' }]],
      });
      return { messages, user };
    }
    if (cb === 'doc:action:qa') {
      user = botStore.updateUser(user.id, { step: 'doc_qa' }) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: `❓ **${user.lastUpload?.filename || 'ডকুমেন্ট'}** সম্পর্কে আপনার প্রশ্নটি লিখে পাঠান:`,
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '❌ বাতিল', callback_data: 'act:cancel' }]],
      });
      return { messages, user };
    }
    if (cb.startsWith('doc:action:')) {
      const up = user.lastUpload;
      if (!up || up.type !== 'document' || !fs.existsSync(up.filePath)) {
        messages.push({ id: makeMsgId(), sender: 'bot', text: '⚠️ আগে একটি ডকুমেন্ট ফাইল আপলোড করুন।', timestamp: nowTimeLabel() });
        return { messages, user };
      }
      const act = cb.slice('doc:action:'.length);
      const taskPrompt =
        act === 'summary'
          ? 'Summarize this entire document thoroughly with structured headings and key bullet points.'
          : act === 'tr_bn'
            ? 'Translate the key content and full text of this document cleanly into natural Bengali (Bangla).'
            : 'Translate the key content and full text of this document cleanly into natural English.';
      try {
        const answer = await analyzeUploadedDocument({
          user,
          filePath: up.filePath,
          filename: up.filename,
          taskPrompt,
        });
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `📄 **${up.filename}**\n\n${answer.slice(0, 3800)}`,
          timestamp: nowTimeLabel(),
          buttons: [
            [
              { text: '❓ আরও প্রশ্ন করুন', callback_data: 'doc:action:qa' },
              { text: '📄 Document Menu', callback_data: 'menu:docs' },
            ],
          ],
        });
      } catch (err) {
        messages.push({ id: makeMsgId(), sender: 'bot', text: `❌ বিশ্লেষণ ব্যর্থ: ${err instanceof Error ? err.message : 'Error'}`, timestamp: nowTimeLabel() });
      }
      return { messages, user };
    }
  }

  // --- Module 6: AI Coding Assistant (/code, code:*) ---
  if (cb === 'menu:coding' || /^\/code$/i.test(text) || text.startsWith('/code ')) {
    if (checkFeatureDisabled('coding')) return { messages, user };
    const inlineCode = text.startsWith('/code ') ? text.slice('/code '.length).trim() : '';
    if (inlineCode) {
      try {
        user =
          botStore.updateUser(user.id, {
            step: 'code_chat',
            pendingContext: { lastRetryAction: { kind: 'coding', prompt: inlineCode, extra: 'write' } },
          }) ?? user;
        const out = await runCodingAssistant({ user, prompt: inlineCode, mode: 'write' });
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: out.explanationAndCode.slice(0, 3800),
          timestamp: nowTimeLabel(),
          document: out.generatedFile,
          buttons: [
            [
              { text: '🔄 Retry', callback_data: 'act:retry' },
              { text: '💻 Coding Menu', callback_data: 'menu:coding' },
            ],
          ],
        });
      } catch (err) {
        messages.push({ id: makeMsgId(), sender: 'bot', text: `❌ কোড তৈরি ব্যর্থ: ${err instanceof Error ? err.message : 'Error'}`, timestamp: nowTimeLabel() });
      }
      return { messages, user };
    }

    user = botStore.updateUser(user.id, { step: 'code_chat' }) ?? user;
    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text:
        `💻 **AI Coding & Project Assistant**\n\n` +
        `Python, JavaScript/TypeScript, HTML/CSS, React, Website ও Telegram Bot কোড লিখুন, ডিবাগ করুন অথবা সরাসরি ডাউনলোডযোগ্য প্রজেক্ট ZIP তৈরি করুন:`,
      timestamp: nowTimeLabel(),
      buttons: [
        [
          { text: '✍️ Code Write & Explain', callback_data: 'code:mode:write' },
          { text: '🐞 Debug & Optimize', callback_data: 'code:mode:debug' },
        ],
        [
          { text: '📦 Full Project (.ZIP)', callback_data: 'code:mode:project' },
          { text: '🏠 মেইন মেনু', callback_data: 'menu:main' },
        ],
      ],
    });
    return { messages, user };
  }

  if (cb.startsWith('code:mode:')) {
    if (checkFeatureDisabled('coding')) return { messages, user };
    const m = cb.slice('code:mode:'.length) as 'write' | 'debug' | 'project';
    const nextStep = m === 'debug' ? 'code_debug' : m === 'project' ? 'code_project' : 'code_chat';
    user = botStore.updateUser(user.id, { step: nextStep }) ?? user;
    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text:
        m === 'debug'
          ? '🐞 আপনার সমস্যাযুক্ত কোড ও এরর মেসেজটি পেস্ট করুন — আমি root cause খুঁজে ফিক্স করে দেব:'
          : m === 'project'
            ? '📦 আপনি কোন প্রজেক্ট (যেমন: Portfolio Website, Python Telegram Bot, To-Do App) বানাতে চান তা লিখুন — আমি সম্পূর্ণ কোড ও `.ZIP` ফাইল তৈরি করে দেব:'
            : '✍️ আপনার প্রয়োজনীয় প্রোগ্রামিং কাজের বিবরণ লিখুন (Python, JS, HTML, CSS, Telegram Bot ইত্যাদি):',
      timestamp: nowTimeLabel(),
      buttons: [[{ text: '❌ বাতিল', callback_data: 'act:cancel' }]],
    });
    return { messages, user };
  }

  // --- Module 7: AI Web Research (/research, /search, res:*) ---
  if (
    cb === 'menu:research' ||
    /^\/(research|search)$/i.test(text) ||
    text.startsWith('/research ') ||
    text.startsWith('/search ')
  ) {
    if (checkFeatureDisabled('research')) return { messages, user };
    const inlineQ = text.startsWith('/research ')
      ? text.slice('/research '.length).trim()
      : text.startsWith('/search ')
        ? text.slice('/search '.length).trim()
        : '';
    if (inlineQ) {
      try {
        user =
          botStore.updateUser(user.id, {
            pendingContext: { lastRetryAction: { kind: 'research', prompt: inlineQ, extra: 'std' } },
          }) ?? user;
        const res = await runWebResearch({ user, queryOrUrl: inlineQ });
        const srcBlock =
          res.sources.length > 0
            ? `\n\n🔗 **Verified Sources:**\n${res.sources.map((s, i) => `${i + 1}. ${s.title}\n   ${s.url}`).join('\n')}`
            : '';
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `🌐 **Web Research & Live Search**\n\n${res.reportText.slice(0, 3200)}${srcBlock}`,
          timestamp: nowTimeLabel(),
          buttons: [
            [
              { text: '🔄 Retry', callback_data: 'act:retry' },
              { text: '🏠 মেইন মেনু', callback_data: 'menu:main' },
            ],
          ],
        });
      } catch (err) {
        messages.push({ id: makeMsgId(), sender: 'bot', text: `❌ রিসার্চ ব্যর্থ: ${err instanceof Error ? err.message : 'Error'}`, timestamp: nowTimeLabel() });
      }
      return { messages, user };
    }

    user = botStore.updateUser(user.id, { step: 'research_query' }) ?? user;
    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text:
        `🌐 **AI Web Research & URL Analyzer**\n\n` +
        `সর্বশেষ খবর, তথ্য, তুলনামূলক বিশ্লেষণ বা যেকোনো ওয়েবসাইট URL (\`https://...\`) বিশ্লেষণ করতে আপনার প্রশ্ন বা লিংক পাঠান:`,
      timestamp: nowTimeLabel(),
      buttons: [
        [
          { text: '🔍 লাইভ সার্চ', callback_data: 'res:mode:search' },
          { text: '🌍 URL বিশ্লেষণ', callback_data: 'res:mode:url' },
        ],
        [
          { text: '📊 Deep Research Report', callback_data: 'res:mode:deep' },
          { text: '🏠 মেইন মেনু', callback_data: 'menu:main' },
        ],
      ],
    });
    return { messages, user };
  }

  if (cb.startsWith('res:mode:')) {
    if (checkFeatureDisabled('research')) return { messages, user };
    const mode = cb.slice('res:mode:'.length);
    user =
      botStore.updateUser(user.id, {
        step: mode === 'url' ? 'research_url' : 'research_query',
        pendingContext: { configKey: mode === 'deep' ? 'deep' : 'std' },
      }) ?? user;
    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text:
        mode === 'url'
          ? '🌍 যে ওয়েবপেজ বা আর্টিকেলটি বিশ্লেষণ করতে চান তার **URL (https://...)** ও প্রশ্ন লিখুন:'
          : mode === 'deep'
            ? '📊 গভীর তুলনামূলক রিসার্চের বিষয়টি লিখুন (AI একাধিক সোর্স যাচাই করে রিপোর্ট দেবে):'
            : '🔍 ইন্টারনেট থেকে যেকোনো সর্বশেষ তথ্য খুঁজতে প্রশ্ন লিখুন:',
      timestamp: nowTimeLabel(),
      buttons: [[{ text: '❌ বাতিল', callback_data: 'act:cancel' }]],
    });
    return { messages, user };
  }

  // --- Module 8: Memory & Personalization (/memory, /remember, mem:*) ---
  if (
    cb === 'menu:memory' ||
    /^\/memory$/i.test(text) ||
    text.startsWith('/remember ')
  ) {
    if (checkFeatureDisabled('memory')) return { messages, user };
    if (text.startsWith('/remember ')) {
      const val = text.slice('/remember '.length).trim();
      if (val) {
        user = botStore.upsertUserMemory(user.id, 'Note', val) ?? user;
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `🧠 **মেমোরিতে সংরক্ষিত হয়েছে!**\n“${val}”\n\nএখন থেকে সব AI চ্যাটে বট এটি মনে রাখবে।`,
          timestamp: nowTimeLabel(),
          buttons: [[{ text: '🧠 সব মেমোরি দেখুন', callback_data: 'menu:memory' }]],
        });
        return { messages, user };
      }
    }

    const mems = user.memories ?? [];
    const memLines =
      mems.length > 0
        ? mems.map((m, i) => `${i + 1}. **${m.key}:** ${m.value}`).join('\n')
        : '_এখনো কোনো ব্যক্তিগত মেমোরি সেভ করা হয়নি।_';
    const lastTask = user.lastActiveTask
      ? `\n📌 **সর্বশেষ অসমাপ্ত/সাম্প্রতিক কাজ (${user.lastActiveTask.module.toUpperCase()}):**\n${user.lastActiveTask.summary}\n`
      : '';

    const delRows: InlineButton[][] = mems.slice(0, 6).map((m, idx) => [
      {
        text: `🗑️ মুছুন #${idx + 1}: ${m.value.slice(0, 22)}${m.value.length > 22 ? '...' : ''}`,
        callback_data: `mem:del:${m.id}`,
      },
    ]);

    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text:
        `🧠 **ব্যক্তিগত মেমোরি ও কাজের ধারাবাহিকতা**\n\n` +
        `**সংরক্ষিত মেমোরিসমূহ (${mems.length}):**\n${memLines}\n` +
        `${lastTask}\n` +
        `• চলমান চ্যাট কনটেক্সট: **${(user.chatHistory ?? []).length} মেসেজ**`,
      timestamp: nowTimeLabel(),
      buttons: [
        ...(user.lastActiveTask
          ? [[{ text: '▶️ সর্বশেষ কাজ চালিয়ে যান (Resume)', callback_data: 'mem:continue' }]]
          : []),
        [
          { text: '➕ নতুন মেমোরি যোগ', callback_data: 'mem:add' },
          { text: '🧹 চ্যাট রিসেট', callback_data: 'chat:clear' },
        ],
        ...delRows,
        ...(mems.length > 0
          ? [[{ text: '🗑️ সব মেমোরি মুছুন', callback_data: 'mem:clear' }]]
          : []),
        [{ text: '🏠 মেইন মেনু', callback_data: 'menu:main' }],
      ],
    });
    return { messages, user };
  }

  if (cb.startsWith('mem:')) {
    if (cb === 'mem:add') {
      user = botStore.updateUser(user.id, { step: 'memory_add' }) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: '➕ আপনি কী মনে রাখতে চান তা লিখুন (যেমন: `আমার ব্যবসার নাম স্টার টেক এবং আমি বাংলায় উত্তর পছন্দ করি`):',
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '❌ বাতিল', callback_data: 'act:cancel' }]],
      });
      return { messages, user };
    }
    if (cb.startsWith('mem:del:')) {
      const id = cb.slice('mem:del:'.length);
      botStore.deleteUserMemory(user.id, id);
      user = botStore.getUserById(user.id) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: '🗑️ মেমোরিটি মুছে ফেলা হয়েছে।',
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '🧠 মেমোরিতে ফিরুন', callback_data: 'menu:memory' }]],
      });
      return { messages, user };
    }
    if (cb === 'mem:clear') {
      user = botStore.clearUserMemories(user.id) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: '🗑️ আপনার সব সংরক্ষিত মেমোরি মুছে ফেলা হয়েছে।',
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '🏠 মেইন মেনু', callback_data: 'menu:main' }]],
      });
      return { messages, user };
    }
    if (cb === 'mem:continue') {
      const task = user.lastActiveTask;
      user = botStore.updateUser(user.id, { step: 'assistant_chat' }) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: task
          ? `▶️ **পূর্বের কাজ পুনরায় চালু হয়েছে (${task.module.toUpperCase()})!**\n\n• কাজ: **${task.summary}**\n• সর্বশেষ অংশ: _${(task.contextText || '').slice(0, 220)}_\n\nএবার পরবর্তী নির্দেশ লিখুন (বট পূর্বের কনটেক্সট ধরে কাজ করবে):`
          : '💬 আপনার পূর্বের কথোপকথন সক্রিয় আছে — পরবর্তী বার্তা পাঠান:',
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '🏠 মেইন মেনু', callback_data: 'menu:main' }]],
      });
      return { messages, user };
    }
  }

  // -------------------------------------------------------------------------
  // 2A. AI Multi-Studio Command Hub Entry & Direct Slash Commands
  // -------------------------------------------------------------------------
  if (
    cb === 'menu:cmd_hub' ||
    /^\/(hub|studio|cmd)$/i.test(text) ||
    (user.step.startsWith('cmd_') &&
      user.step !== 'cmd_hub_menu' &&
      /^(?:back|হাব|hub)$/i.test(text))
  ) {
    user =
      botStore.updateUser(user.id, {
        step: 'cmd_hub_menu',
        pendingContext: undefined,
      }) ?? user;
    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text: buildCommandHubGuideMessage(user, botStore.isAdmin(user)),
      timestamp: nowTimeLabel(),
    });
    return { messages, user };
  }

  if (
    /^\/exit$/i.test(text) ||
    (user.step.startsWith('cmd_') &&
      (/^\/?cancel$/i.test(text) ||
        /^exit$/i.test(text) ||
        (user.step === 'cmd_hub_menu' && text === '0')))
  ) {
    user =
      botStore.updateUser(user.id, {
        step: 'awaiting_category',
        pendingContext: undefined,
      }) ?? user;
    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text: '🏠 কমান্ড হাব থেকে মেইন মেনুতে ফিরে এসেছেন। নিচের যেকোনো অপশন বেছে নিন:',
      timestamp: nowTimeLabel(),
      buttons: mainMenuButtons(botStore.isAdmin(user)),
    });
    return { messages, user };
  }

  // Direct slash commands & numbered shortcuts from cmd_hub_menu
  const lowerCmd = text.toLowerCase();
  const inHubMenu = user.step === 'cmd_hub_menu';

  if (
    (inHubMenu && text === '1') ||
    lowerCmd === '/videocmd' ||
    lowerCmd.startsWith('/videocmd ')
  ) {
    const inlinePrompt = lowerCmd.startsWith('/videocmd ')
      ? text.slice('/videocmd '.length).trim()
      : '';
    const preset = user.savedPreset;
    const baseDraft: VideoDraftContext = {
      ...defaultVideoDraft(user, 'prompt'),
      aspectRatio: preset?.aspectRatio ?? '9:16',
      resolution: preset?.resolution ?? '1080p',
      voiceId: preset?.voiceId ?? user.selectedVoiceId,
      musicMood: preset?.musicMood ?? 'cinematic',
      watermarkText: preset?.watermarkText,
    };

    if (inlinePrompt) {
      baseDraft.prompt = inlinePrompt;
      baseDraft.title = inlinePrompt.slice(0, 48);
      user =
        botStore.updateUser(user.id, {
          step: 'cmd_vid_format',
          pendingContext: { videoDraft: baseDraft },
        }) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `🎬 **ধাপ ২/৫ — ভিডিও ফরম্যাট ও কোয়ালিটি**\n` +
          `প্রম্পট সেট হয়েছে: “${inlinePrompt.slice(0, 100)}”\n\n` +
          `ফরম্যাট ও রেজোলিউশন লিখুন (যেমন: \`9:16 1080p\`, \`16:9 720p\`, \`1:1 1080p\`, \`16:9 4k\`),\n` +
          `অথবা \`skip\` লিখুন (ডিফল্ট: **${baseDraft.aspectRatio} ${baseDraft.resolution?.toUpperCase()}**)।`,
        timestamp: nowTimeLabel(),
      });
      return { messages, user };
    }

    user =
      botStore.updateUser(user.id, {
        step: 'cmd_vid_prompt',
        pendingContext: { videoDraft: baseDraft },
      }) ?? user;
    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text:
        `🎬 **ধাপ ১/৫ — AI ভিডিও টপিক/প্রম্পট**\n\n` +
        `আপনি কোন বিষয়ের ওপর ভিডিও বানাতে চান তা লিখে পাঠান।\n` +
        `উদাহরণ: \`কৃত্রিম বুদ্ধিমত্তা কীভাবে আমাদের ভবিষ্যৎ বদলে দিচ্ছে\`\n\n` +
        `(ফিরে যেতে \`back\` লিখুন)`,
      timestamp: nowTimeLabel(),
    });
    return { messages, user };
  }

  if ((inHubMenu && text === '2') || lowerCmd === '/dialogue') {
    user =
      botStore.updateUser(user.id, {
        step: 'cmd_dlg_bgm',
        pendingContext: { dialogueBgmMood: 'upbeat' },
      }) ?? user;
    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text:
        `🎭 **মাল্টি-ভয়েস ডায়ালগ — ধাপ ১/৩ (ব্যাকগ্রাউন্ড মিউজিক)**\n\n` +
        `সংলাপের পেছনে কোন মিউজিক মুড চান তা লিখুন:\n` +
        `• \`upbeat\` (কার্টুন / মজার)\n` +
        `• \`emotional\` (আবেগঘন / কষ্টের)\n` +
        `• \`cinematic\` (গল্প / ডকুমেন্টারি)\n` +
        `• \`suspense\` (রহস্য / ভয়)\n` +
        `• \`none\` (মিউজিক ছাড়া)\n\n` +
        `যেকোনো একটি নাম লিখে পাঠান (অথবা \`skip\` লিখুন):`,
      timestamp: nowTimeLabel(),
    });
    return { messages, user };
  }

  if ((inHubMenu && text === '3') || lowerCmd === '/voicebgm') {
    user =
      botStore.updateUser(user.id, {
        step: 'cmd_vbgm_voice',
        pendingContext: {
          voiceBgmVoiceId: user.savedPreset?.voiceId ?? user.selectedVoiceId,
          voiceBgmMood: user.savedPreset?.musicMood ?? 'emotional',
        },
      }) ?? user;
    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text:
        `🎵 **ভয়েস + ব্যাকগ্রাউন্ড মিউজিক MP3 — ধাপ ১/৩**\n\n` +
        `কোন ভয়েস এবং কোন মিউজিক মুড চান তা একসাথে লিখে পাঠান।\n` +
        `উদাহরণ:\n` +
        `• \`আরিয়ান emotional\`\n` +
        `• \`মেহেক emotional\`\n` +
        `• \`আরিফ cinematic\`\n` +
        `• \`অগি upbeat\`\n` +
        `• \`ডোরেমন upbeat\`\n\n` +
        `(সব ভয়েস দেখতে \`/voices\` লিখুন)`,
      timestamp: nowTimeLabel(),
    });
    return { messages, user };
  }

  if ((inHubMenu && text === '4') || lowerCmd === '/seo' || lowerCmd.startsWith('/seo ')) {
    const inlineTopic = lowerCmd.startsWith('/seo ')
      ? text.slice('/seo '.length).trim()
      : '';
    if (inlineTopic) {
      const pack = await generateViralSeoPack(inlineTopic);
      user =
        botStore.updateUser(user.id, {
          step: 'cmd_hub_menu',
          pendingContext: undefined,
        }) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `🔍 **ভাইরাল SEO প্যাক প্রস্তুত!**\n\n` +
          `📌 **৩টি হাই-CTR টাইটেল:**\n` +
          pack.titles.map((t, i) => `${i + 1}. ${t}`).join('\n') +
          `\n\n📝 **ভিডিও ডেসক্রিপশন:**\n${pack.description}\n\n` +
          `🏷️ **ভাইরাল হ্যাশট্যাগ:**\n${pack.hashtags.join(' ')}\n\n` +
          `👉 পরবর্তী কাজের জন্য \`1\`-\`7\` অথবা \`/hub\` লিখুন।`,
        timestamp: nowTimeLabel(),
      });
      return { messages, user };
    }

    user =
      botStore.updateUser(user.id, {
        step: 'cmd_seo_topic',
        pendingContext: undefined,
      }) ?? user;
    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text:
        `🔍 **ভাইরাল SEO জেনারেটর**\n\n` +
        `আপনার ভিডিওর টপিক বা স্ক্রিপ্ট লিখে পাঠান — আমি সাথে সাথে ৩টি আকর্ষণীয় বাংলা টাইটেল, ডেসক্রিপশন ও ভাইরাল হ্যাশট্যাগ তৈরি করে দেব:`,
      timestamp: nowTimeLabel(),
    });
    return { messages, user };
  }

  if (
    (inHubMenu && text === '5') ||
    lowerCmd === '/preset' ||
    lowerCmd.startsWith('/preset ')
  ) {
    const inlineArgs = lowerCmd.startsWith('/preset ')
      ? text.slice('/preset '.length).trim()
      : '';
    if (inlineArgs) {
      const saved = parsePresetCommand(inlineArgs, user.savedPreset);
      user =
        botStore.updateUser(user.id, {
          step: 'cmd_hub_menu',
          savedPreset: saved,
          pendingContext: undefined,
        }) ?? user;
      const vName = saved.voiceId
        ? getVoiceById(saved.voiceId).nameBn
        : getVoiceById(user.selectedVoiceId).nameBn;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `💾 **আপনার ক্রিয়েটর প্রিসেট সেভ হয়েছে!**\n\n` +
          `• ভয়েস: **${vName}**\n` +
          `• ফরম্যাট: **${saved.aspectRatio} · ${(saved.resolution ?? '1080p').toUpperCase()}**\n` +
          `• BGM মুড: **${saved.musicMood}**\n` +
          `• স্পিড: **${saved.speed ?? 1.0}x**\n` +
          (saved.watermarkText ? `• ওয়াটারমার্ক: **${saved.watermarkText}**\n` : '') +
          `\nএখন থেকে \`/videocmd\`-এ \`preset\` বা \`skip\` লিখলেই এগুলো অটো-অ্যাপ্লাই হবে!\n👉 পরের কমান্ড (\`1\`-\`7\` বা \`/hub\`) লিখুন।`,
        timestamp: nowTimeLabel(),
      });
      return { messages, user };
    }

    const cur = user.savedPreset;
    const curVoice = cur?.voiceId
      ? getVoiceById(cur.voiceId).nameBn
      : getVoiceById(user.selectedVoiceId).nameBn;
    user =
      botStore.updateUser(user.id, {
        step: 'cmd_preset_input',
        pendingContext: undefined,
      }) ?? user;
    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text:
        `💾 **আমার ডিফল্ট প্রিসেট সেটআপ**\n\n` +
        `বর্তমান প্রিসেট: ${cur ? `${curVoice} · ${cur.aspectRatio} · ${cur.resolution?.toUpperCase()} · ${cur.musicMood}${cur.watermarkText ? ` · ${cur.watermarkText}` : ''}` : 'এখনো সেট করা হয়নি'}\n\n` +
        `নতুন প্রিসেট সেট করতে এক লাইনে আপনার পছন্দের ভয়েস, ফরম্যাট, রেজোলিউশন, BGM ও ওয়াটারমার্ক লিখুন:\n` +
        `উদাহরণ: \`আরিয়ান 9:16 1080p emotional @MyChannel\`\n` +
        `অথবা \`back\` লিখুন।`,
      timestamp: nowTimeLabel(),
    });
    return { messages, user };
  }

  if ((inHubMenu && text === '6') || lowerCmd === '/ref') {
    const cfg = botStore.getConfig();
    const botUsername = cfg.telegramBotUsername || 'controller67755382bot';
    const refLink = `https://t.me/${botUsername}?start=ref_${user.telegramId}`;
    const bonus = cfg.referralBonusBdt ?? 20;
    user =
      botStore.updateUser(user.id, {
        step: 'cmd_hub_menu',
        pendingContext: undefined,
      }) ?? user;
    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text:
        `🎁 **রেফারেল ও বোনাস প্রোগ্রাম**\n\n` +
        `• আপনার রেফারেল লিংক:\n\`${refLink}\`\n\n` +
        `• মোট সফল রেফার: **${user.referralCount ?? 0} জন**\n` +
        `• প্রতি রেফার বোনাস: **৳${bonus}**\n` +
        `• বর্তমান ব্যালেন্স: **৳${user.balance.toFixed(2)}**\n\n` +
        `আপনার বন্ধুরা এই লিংকে \`/start\` চাপলেই আপনার অ্যাকাউন্টে অটো **৳${bonus}** যোগ হয়ে যাবে!\n👉 পরের কমান্ড (\`1\`-\`7\` বা \`/hub\`) লিখুন।`,
      timestamp: nowTimeLabel(),
    });
    return { messages, user };
  }

  if ((inHubMenu && text === '7') || lowerCmd === '/voices') {
    user =
      botStore.updateUser(user.id, {
        step: 'cmd_hub_menu',
        pendingContext: undefined,
      }) ?? user;
    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text: buildVoicesCommandReference(),
      timestamp: nowTimeLabel(),
    });
    return { messages, user };
  }

  if (
    (inHubMenu && text === '8') ||
    lowerCmd === '/broadcast' ||
    lowerCmd.startsWith('/broadcast ')
  ) {
    if (!botStore.isAdmin(user)) {
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: '🔒 ব্রডকাস্ট কমান্ডটি শুধুমাত্র অ্যাডমিনের জন্য।',
        timestamp: nowTimeLabel(),
      });
      return { messages, user };
    }

    const activeTgCount = botStore
      .listUsers()
      .filter((u) => u.status === 'active' && !u.telegramId.startsWith('sim_')).length;
    const inlineMsg = lowerCmd.startsWith('/broadcast ')
      ? text.slice('/broadcast '.length).trim()
      : '';

    if (inlineMsg) {
      user =
        botStore.updateUser(user.id, {
          step: 'cmd_broadcast_confirm',
          pendingContext: { broadcastDraftText: inlineMsg },
        }) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `📣 **ব্রডকাস্ট প্রিভিউ (সক্রিয় টেলিগ্রাম ইউজার: ${activeTgCount} জন)**\n\n` +
          `${inlineMsg}\n\n` +
          `পাঠাতে \`send\` লিখুন, অথবা বাতিল করতে \`cancel\` / \`back\` লিখুন।`,
        timestamp: nowTimeLabel(),
      });
      return { messages, user };
    }

    user =
      botStore.updateUser(user.id, {
        step: 'cmd_broadcast_msg',
        pendingContext: undefined,
      }) ?? user;
    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text:
        `📣 **অ্যাডমিন ব্রডকাস্ট (টার্গেট: ${activeTgCount} জন সক্রিয় ইউজার)**\n\n` +
        `সব ইউজারকে পাঠানোর জন্য আপনার ঘোষণা বা মেসেজটি লিখে পাঠান (বা \`back\` লিখুন):`,
      timestamp: nowTimeLabel(),
    });
    return { messages, user };
  }

  if (
    cb === 'adm:bot_files' ||
    cb === 'adm:send_bot_zip' ||
    text === '/files' ||
    text === '/botfiles'
  ) {
    if (!botStore.isAdmin(user)) {
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          '🔒 **ফাইল অপশনটি শুধুমাত্র অ্যাডমিনের জন্য সংরক্ষিত।**\n\n' +
          'আপনার নিজের তৈরি করা অডিও ও ভিডিও ফাইল দেখতে `/profile` ব্যবহার করুন।',
        timestamp: nowTimeLabel(),
        buttons: [
          [{ text: '👤 আমার প্রোফাইল (/profile)', callback_data: 'menu:profile' }],
          [{ text: '🏠 মেইন মেনু', callback_data: 'menu:main' }],
        ],
      });
      return { messages, user };
    }

    if (cb === 'adm:send_bot_zip') {
      try {
        const archive = await buildBotSourcePackageZip();
        const sizeKb = Math.max(1, Math.round(archive.fileSizeBytes / 1024));
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text:
            `📦 **BanglaVoice Bot — একত্রিত সম্পূর্ণ সোর্স প্যাকেজ (${archive.filename})**\n` +
            `• মোট ফাইল: ${archive.fileCount}টি | সাইজ: ${sizeKb} KB\n` +
            `• সব ফাইল ও আপডেট একত্রিত ফোল্ডারে: \`BanglaVoice-Bot/\`\n` +
            `• ভেতরে আছে: server/, src/, Dockerfile, render.yaml, package.json, .env.example ও DEPLOY_GUIDE.txt\n\n` +
            `এখন থেকে সব আপডেট এই একটিমাত্র ZIP ফাইলেই সংরক্ষিত থাকবে। যেকোনো VPS, Render বা কম্পিউটারে আনজিপ করে সরাসরি চালাতে পারবেন।`,
          timestamp: nowTimeLabel(),
          document: {
            url: '/api/admin/export-bot-zip',
            filePath: archive.zipPath,
            filename: archive.filename,
            fileSizeBytes: archive.fileSizeBytes,
          },
          buttons: [
            [{ text: '🔄 সর্বশেষ আপডেটসহ ZIP রিফ্রেশ করুন', callback_data: 'adm:send_bot_zip' }],
            [{ text: '🏠 মেইন মেনু', callback_data: 'menu:main' }],
          ],
        });
      } catch (err) {
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `❌ বট ফাইল প্যাকেজ তৈরি করা যায়নি: ${err instanceof Error ? err.message : 'Error'}`,
          timestamp: nowTimeLabel(),
          buttons: [[{ text: '🏠 মেইন মেনু', callback_data: 'menu:main' }]],
        });
      }
      return { messages, user };
    }

    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text:
        `📁 **বটের সমস্ত ফাইল — একত্রিত সিঙ্গেল প্যাকেজ (Unified ZIP)**\n\n` +
        `আপনার বটের সমস্ত সোর্স কোড, আপডেট ও ডিপ্লয়মেন্ট কনফিগারেশন আলাদা আলাদা না রেখে **একটিমাত্র একত্রিত ZIP ফাইলে (\`BanglaVoice-Bot-All-Files.zip\`)** সংরক্ষণ করা হয়েছে:\n\n` +
        `• সম্পূর্ণ ব্যাকএন্ড (\`server/\`, \`server.ts\`) — টেলিগ্রাম বট, ভয়েস ডেমো ইঞ্জিন, AI ভিডিও জেনারেটর, স্মার্ট এডিটর, পেমেন্ট ও অ্যাডমিন প্যানেল\n` +
        `• সম্পূর্ণ ওয়েব ড্যাশবোর্ড (\`src/\`, \`index.html\`, \`vite.config.ts\`)\n` +
        `• ডিপ্লয়মেন্ট কনফিগ (\`Dockerfile\`, \`render.yaml\`, \`.env.example\`, \`DEPLOY_GUIDE.txt\`)\n` +
        `• সব ফাইল আর্কাইভের ভেতরে \`BanglaVoice-Bot/\` একক ফোল্ডারের আন্ডারে সাজানো আছে।\n\n` +
        `নিচের বাটনে ট্যাপ করলে এখনই একত্রিত \`.ZIP\` ফাইলটি আপনার ইনবক্সে চলে আসবে:`,
      timestamp: nowTimeLabel(),
      buttons: [
        [{ text: '📦 একত্রিত সব ফাইল (.ZIP) এখনই পাঠান', callback_data: 'adm:send_bot_zip' }],
        [
          { text: '🛡️ Admin Dashboard', callback_data: 'adm:home' },
          { text: '🏠 মেইন মেনু', callback_data: 'menu:main' },
        ],
      ],
    });
    return { messages, user };
  }

  if (cb === 'menu:video' || text === '/video') {
    if (!botStore.isFeatureEnabled('video')) {
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: '🔒 অ্যাডমিন কর্তৃক Video Studio সাময়িকভাবে বন্ধ রাখা হয়েছে।',
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '🏠 মেইন মেনু', callback_data: 'menu:main' }]],
      });
      return { messages, user };
    }
    user =
      botStore.updateUser(user.id, {
        step: 'idle',
        pendingContext: undefined,
      }) ?? user;
    const cfg = botStore.getConfig();
    const cost = Math.max(0, cfg.videoGenerationCost ?? 0);
    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text:
        `🎬 **AI Automatic Professional Video Studio**\n\n` +
        `আপনি কিভাবে প্রফেশনাল ভিডিও তৈরি বা এডিট করতে চান?\n\n` +
        `১. **প্রম্পট → AI ভিডিও:** শুধু একটি আইডিয়া বা প্রম্পট দিন, AI স্ক্রিপ্ট, ভয়েস ও দৃশ্য তৈরি করে সম্পূর্ণ ভিডিও বানাবে।\n` +
        `২. **ছবি → AI ভিডিও (Image-to-Video):** আপনার যেকোনো ছবি পাঠান, AI সিনেমাটিক মোশন, ভয়েসওভার ও সাবটাইটেলসহ ভিডিও বানাবে।\n` +
        `৩. **স্ক্রিপ্ট → ভিডিও:** আপনার যেকোনো দৈর্ঘ্যের স্ক্রিপ্ট দিন (Unlimited), AI প্রতিটি লাইনের অর্থ বুঝে দৃশ্য ও বাংলা সাবটাইটেল যুক্ত করবে।\n` +
        `৪. **ভয়েস/অডিও → ভিডিও:** আপনার ভয়েস ফাইল পাঠান, AI ভয়েস শুনে সময়ের সাথে নিখুঁতভাবে দৃশ্য সাজিয়ে দেবে।\n` +
        `৫. **নিজস্ব ভিডিও এডিট:** আপনার ভিডিও পাঠান—বট ভিডিও স্পিড, ভয়েস স্পিড, বাংলা ভয়েসওভার, ব্যাকগ্রাউন্ড মিউজিক, কালার ও ইউনিক টেমপ্লেট সেট করে এডিট করে দেবে।\n\n` +
        `• ভিডিও তৈরি চার্জ: **${cost > 0 ? `৳${cost}` : 'ফ্রি (৳0)'}**`,
      timestamp: nowTimeLabel(),
      buttons: [
        [{ text: '✨ প্রম্পট থেকে AI ভিডিও', callback_data: 'vid:mode:prompt' }],
        [{ text: '🖼️ ছবি থেকে AI ভিডিও (Image → Video)', callback_data: 'vid:mode:image_to_video' }],
        [{ text: '📜 স্ক্রিপ্ট থেকে AI ভিডিও', callback_data: 'vid:mode:script' }],
        [{ text: '🎤 ভয়েস/অডিও থেকে ভিডিও', callback_data: 'vid:mode:voice' }],
        [{ text: '✂️ নিজস্ব ভিডিও এডিট (Smart Editor)', callback_data: 'vid:mode:edit_video' }],
        [{ text: '🏠 মেইন মেনু', callback_data: 'menu:main' }],
      ],
    });
    return { messages, user };
  }

  if (cb.startsWith('vid:')) {
    if (cb === 'vid:mode:image_to_video') {
      const draft = defaultVideoDraft(user, 'image_to_video');
      user =
        botStore.updateUser(user.id, {
          step: 'awaiting_video_i2v_photo',
          pendingContext: { videoDraft: draft },
        }) ?? user;
      const hasPhoto = user.lastUpload?.type === 'photo' && fs.existsSync(user.lastUpload.filePath);
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `🖼️➡️🎬 **ছবি → AI ভিডিও (Image-to-Video) — ধাপ ১**\n\n` +
          `ভিডিও বানানোর জন্য আপনার **Photo** আপলোড করুন (চাইলে ছবির Caption-এ ভিডিওর বিষয় লিখতে পারেন)।`,
        timestamp: nowTimeLabel(),
        buttons: [
          ...(hasPhoto ? [[{ text: '✅ সর্বশেষ ছবি ব্যবহার করুন', callback_data: 'img:quick_i2v' }]] : []),
          [{ text: '❌ বাতিল করুন', callback_data: 'menu:video' }],
        ],
      });
      return { messages, user };
    }
    if (cb === 'vid:mode:prompt') {
      const draft = defaultVideoDraft(user, 'prompt');
      user =
        botStore.updateUser(user.id, {
          step: 'awaiting_video_prompt',
          pendingContext: { videoDraft: draft },
        }) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `✨ **ধাপ ১: ভিডিও প্রম্পট লিখুন**\n\n` +
          `আপনি কী বিষয়ের ওপর ভিডিও বানাতে চান তা সংক্ষেপে বাংলা বা ইংরেজিতে লিখুন।\n` +
          `উদাহরণ: _"কৃত্রিম বুদ্ধিমত্তা কিভাবে আগামী ৫ বছরে মানুষের কাজ বদলে দেবে সে বিষয়ে একটি উত্তেজনাপূর্ণ ডকুমেন্টারি ভিডিও তৈরি করো"_`,
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '❌ বাতিল করুন', callback_data: 'menu:video' }]],
      });
      return { messages, user };
    }

    if (cb === 'vid:mode:script') {
      const draft = defaultVideoDraft(user, 'script');
      user =
        botStore.updateUser(user.id, {
          step: 'awaiting_video_script',
          pendingContext: { videoDraft: draft },
        }) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `📜 **ধাপ ১: সম্পূর্ণ ভিডিও স্ক্রিপ্ট পাঠান**\n\n` +
          `আপনার বাংলা, ইংরেজি বা মিশ্রিত স্ক্রিপ্ট লিখে পাঠান (অথবা \`.txt\` ফাইল আপলোড করুন)।\n` +
          `যেকোনো দৈর্ঘ্যের স্ক্রিপ্টের প্রতিটি অংশ মিলিয়ে AI সম্পূর্ণ ভিডিও তৈরি করবে।`,
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '❌ বাতিল করুন', callback_data: 'menu:video' }]],
      });
      return { messages, user };
    }

    if (cb === 'vid:mode:voice') {
      const draft = defaultVideoDraft(user, 'voice');
      user =
        botStore.updateUser(user.id, {
          step: 'awaiting_video_voice',
          pendingContext: { videoDraft: draft },
        }) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `🎤 **ধাপ ১: ভয়েস মেসেজ বা অডিও ফাইল পাঠান**\n\n` +
          `টেলিগ্রামে সরাসরি Voice Record করে পাঠান অথবা যেকোনো MP3 / WAV / M4A অডিও ফাইল আপলোড করুন।\n` +
          `AI আপনার ভয়েস শুনে প্রতিটি অংশের সাথে মিল রেখে দৃশ্য ও সাবটাইটেল তৈরি করবে।`,
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '❌ বাতিল করুন', callback_data: 'menu:video' }]],
      });
      return { messages, user };
    }

    if (cb === 'vid:mode:edit_video') {
      const draft = defaultVideoDraft(user, 'edit_video');
      user =
        botStore.updateUser(user.id, {
          step: 'awaiting_video_upload',
          pendingContext: { videoDraft: draft },
        }) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `✂️ **Smart Video Editor — ধাপ ১: আপনার ভিডিও পাঠান**\n\n` +
          `এডিট করার জন্য আপনার MP4 / MOV ভিডিও ফাইলটি এখানে আপলোড করুন।\n` +
          `ভিডিও পাওয়ার পর আমি আপনার কাছ থেকে ভিডিওর স্পিড, ভয়েস/স্ক্রিপ্ট, ভয়েস স্পিড, ব্যাকগ্রাউন্ড মিউজিক ও ইউনিক টেমপ্লেট জানতে চাইব।`,
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '❌ বাতিল করুন', callback_data: 'menu:video' }]],
      });
      return { messages, user };
    }

    const draft = user.pendingContext?.videoDraft;
    if (!draft) {
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: '⚠️ ভিডিও ড্রাফট পাওয়া যায়নি। নতুন করে AI ভিডিও স্টুডিও শুরু করুন।',
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '🎬 AI ভিডিও স্টুডিও', callback_data: 'menu:video' }]],
      });
      return { messages, user };
    }

    const updateDraft = (patch: Partial<VideoDraftContext>) => {
      const nextDraft: VideoDraftContext = { ...draft, ...patch };
      user =
        botStore.updateUser(user.id, {
          pendingContext: { ...user.pendingContext, videoDraft: nextDraft },
        }) ?? user;
      return nextDraft;
    };

    if (cb === 'vid:tpl_menu') {
      const btns: InlineButton[][] = VIDEO_TEMPLATES.map((t) => [
        {
          text: `${draft.templateId === t.id ? '✅ ' : '🎨 '}${t.nameBn} (${t.badgeText})`,
          callback_data: `vid:tpl:${t.id}`,
        },
      ]);
      btns.push([{ text: '◀️ ফিরে যান', callback_data: 'vid:back_cfg' }]);
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: `🎨 **ইউনিক প্রিমিয়াম টেমপ্লেট নির্বাচন করুন:**`,
        timestamp: nowTimeLabel(),
        buttons: btns,
      });
      return { messages, user };
    }

    if (cb.startsWith('vid:tpl:')) {
      const tplId = cb.slice('vid:tpl:'.length) as VideoTemplateId;
      updateDraft({ templateId: tplId });
    } else if (cb.startsWith('vid:ar:')) {
      updateDraft({ aspectRatio: cb.slice('vid:ar:'.length) as VideoAspectRatio });
    } else if (cb.startsWith('vid:res:')) {
      updateDraft({ resolution: cb.slice('vid:res:'.length) as VideoResolution });
    } else if (cb.startsWith('vid:vspd:')) {
      const val = Number.parseFloat(cb.slice('vid:vspd:'.length));
      if (!Number.isNaN(val)) updateDraft({ videoSpeed: val });
    } else if (cb === 'vid:aspd_cycle') {
      const order = [0.85, 1.0, 1.15, 1.25];
      const cur = draft.voiceSpeed ?? 1.0;
      const idx = order.findIndex((s) => Math.abs(s - cur) < 0.05);
      updateDraft({ voiceSpeed: order[(idx + 1) % order.length] });
    } else if (cb === 'vid:bgm_cycle') {
      const moods: VideoMusicMood[] = [
        'cinematic',
        'emotional',
        'upbeat',
        'tech',
        'suspense',
        'none',
      ];
      const cur = draft.musicMood ?? 'cinematic';
      const idx = moods.indexOf(cur);
      updateDraft({ musicMood: moods[(idx + 1) % moods.length] });
    } else if (cb === 'vid:orig_cycle') {
      const modes: Array<'mute' | 'duck' | 'keep'> = ['mute', 'duck', 'keep'];
      const cur = draft.originalAudioMode ?? 'mute';
      const idx = modes.indexOf(cur);
      updateDraft({ originalAudioMode: modes[(idx + 1) % modes.length] });
    } else if (cb === 'vid:sub_toggle') {
      updateDraft({ includeSubtitles: draft.includeSubtitles === false });
    } else if (cb === 'vid:edit_script') {
      user =
        botStore.updateUser(user.id, {
          step: 'awaiting_video_edit_script',
        }) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `📝 **এডিটেড ভিডিওর জন্য স্ক্রিপ্ট / প্রম্পট / ভয়েস দিন**\n\n` +
          `আপনার ভিডিওর সাথে মিলিয়ে নতুন বাংলা ভয়েসওভার দিতে এখানে স্ক্রিপ্ট বা প্রম্পট লিখুন (অথবা সরাসরি নতুন ভয়েস/অডিও ফাইল পাঠান):`,
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '◀️ ফিরে যান', callback_data: 'vid:back_cfg' }]],
      });
      return { messages, user };
    } else if (cb === 'vid:wm') {
      user =
        botStore.updateUser(user.id, {
          step: 'awaiting_video_watermark',
        }) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: `🏷️ ভিডিওর কোণায় বসানোর জন্য আপনার **চ্যানেল বা ব্র্যান্ডের নাম (Watermark)** লিখে পাঠান (মুছে ফেলতে \`none\` লিখুন):`,
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '◀️ ফিরে যান', callback_data: 'vid:back_cfg' }]],
      });
      return { messages, user };
    } else if (cb === 'vid:render') {
      const currentDraft = user.pendingContext?.videoDraft ?? draft;
      user =
        botStore.updateUser(user.id, {
          step: 'idle',
          pendingContext: undefined,
        }) ?? user;

      const enqueued = await videoJobQueue.enqueueVideoJob({
        user,
        mode: currentDraft.mode,
        title: currentDraft.title,
        prompt: currentDraft.prompt,
        script: currentDraft.script,
        templateId: currentDraft.templateId,
        aspectRatio: currentDraft.aspectRatio,
        resolution: currentDraft.resolution,
        videoSpeed: currentDraft.videoSpeed,
        voiceId: currentDraft.voiceId ?? user.selectedVoiceId,
        voiceSpeed: currentDraft.voiceSpeed ?? user.speed,
        voicePitch: currentDraft.voicePitch ?? user.pitch,
        musicMood: currentDraft.musicMood,
        originalAudioMode: currentDraft.originalAudioMode,
        includeSubtitles: currentDraft.includeSubtitles,
        includeIntroOutro: currentDraft.includeIntroOutro,
        watermarkText: currentDraft.watermarkText,
        uploadedVideoPath: currentDraft.uploadedVideoPath,
        uploadedImagePath: currentDraft.uploadedImagePath,
        uploadedAudioPath: currentDraft.uploadedAudioPath,
        source: params.source,
        telegramChatId: params.telegramChatId,
      });

      if (!enqueued.ok || !enqueued.job) {
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `⚠️ ${enqueued.error ?? 'ভিডিও তৈরি শুরু করা যায়নি।'}`,
          timestamp: nowTimeLabel(),
          buttons: [
            [{ text: '➕ ব্যালেন্স রিচার্জ', callback_data: 'pay:start' }],
            [{ text: '🎬 AI ভিডিও স্টুডিও', callback_data: 'menu:video' }],
          ],
        });
        return { messages, user };
      }

      const vJob = enqueued.job;
      if (params.videoListenerFactory) {
        videoJobQueue.registerListener(
          vJob.id,
          params.videoListenerFactory(vJob.id),
        );
      }

      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        videoJobId: vJob.id,
        text:
          `🎬 **AI ভিডিও অটো-প্রসেসিং শুরু হয়েছে!**\n\n` +
          `• প্রজেক্ট: **${vJob.title}**\n` +
          `• ফরম্যাট: **${vJob.aspectRatio} (${vJob.resolution.toUpperCase()})**\n` +
          `• টেমপ্লেট: **${getVideoTemplate(vJob.templateId).nameBn}**\n` +
          `• অগ্রগতি: [${formatProgressBar(vJob.progressPct)}] **${vJob.progressPct}%** — ${vJob.statusText}\n` +
          `• ⏱️ লাইভ টাইমার: **00:00** · আনুমানিক বাকি: ~${formatClockMMSS(vJob.estimatedRemainingSec ?? 25)}`,
        timestamp: nowTimeLabel(),
      });
      return { messages, user, queuedVideoJob: vJob };
    }

    const cfgCard = buildVideoConfigCardMessage(user);
    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text: cfgCard.text,
      timestamp: nowTimeLabel(),
      buttons: cfgCard.buttons,
    });
    return { messages, user };
  }

  if (
    cb === 'menu:demos' ||
    cb.startsWith('demos:cat:') ||
    text === '/demos' ||
    text === '/demo'
  ) {
    const requestedCat = cb.startsWith('demos:cat:')
      ? (cb.slice('demos:cat:'.length) as VoiceCategory)
      : user.selectedCategory || 'male';
    const validCat: VoiceCategory =
      requestedCat === 'female' || requestedCat === 'cartoon'
        ? requestedCat
        : 'male';
    const demoMenu = buildVoiceDemosPayload(validCat);
    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text: demoMenu.text,
      timestamp: nowTimeLabel(),
      buttons: demoMenu.buttons,
    });
    return { messages, user };
  }

  if (cb.startsWith('demo:')) {
    const voiceId = cb.slice('demo:'.length);
    try {
      const demo = await getOrGenerateVoiceDemoMp3(voiceId);
      const v = demo.voice;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `🔊 ${v.emoji} **${v.nameBn} (${v.roleBn}) — ভয়েস ডেমো**\n\n` +
          `“${v.sampleBangla}”\n\n` +
          `👨‍💻 **ডেভলপার বেলাল হোসেন** · স্পিড: ${v.defaultSpeed}x`,
        timestamp: nowTimeLabel(),
        audio: {
          generationId: `demo-${v.id}`,
          url: demo.url,
          filePath: demo.filePath,
          title: `${v.emoji} ${v.nameBn} Demo — ডেভলপার বেলাল হোসেন`,
          performer: 'Developer Belal Hossain · BanglaVoice Bot',
          durationSec: demo.durationSec,
          fileSizeBytes: demo.fileSizeBytes,
        },
        buttons: [
          [
            {
              text: `✍️ ${v.emoji} ${v.nameBn} দিয়ে স্ক্রিপ্ট লিখুন`,
              callback_data: `voice:${v.id}`,
            },
          ],
          [
            {
              text: '🔊 অন্য ভয়েস ডেমো শুনুন',
              callback_data: `demos:cat:${v.category}`,
            },
            { text: '🏠 মেইন মেনু', callback_data: 'menu:main' },
          ],
        ],
      });
    } catch (err) {
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: `❌ ভয়েস ডেমো তৈরি করা যায়নি: ${err instanceof Error ? err.message : 'Error'}`,
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '🔊 ডেমো মেনুতে ফিরুন', callback_data: 'menu:demos' }]],
      });
    }
    return { messages, user };
  }

  if (cb === 'menu:create' || text === '/voice') {
    user = botStore.updateUser(user.id, { step: 'awaiting_category' }) ?? user;
    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text: `🎭 **Voice Category নির্বাচন করুন**\n\nআপনি কোন ধরনের কণ্ঠস্বর দিয়ে বাংলা ভয়েস তৈরি করতে চান?`,
      timestamp: nowTimeLabel(),
      buttons: categoryMenuButtons(),
    });
    return { messages, user };
  }

  if (cb === 'cat:male' || cb === 'cat:female' || cb === 'cat:cartoon') {
    const category: VoiceCategory =
      cb === 'cat:male' ? 'male' : cb === 'cat:female' ? 'female' : 'cartoon';
    const voices = getVoicesByCategory(category);
    const defaultVoice =
      voices.find((v) => v.id === user.selectedVoiceId) ?? voices[0];
    user =
      botStore.updateUser(user.id, {
        selectedCategory: category,
        selectedVoiceId: defaultVoice.id,
        step: 'awaiting_voice',
      }) ?? user;

    const catHeader =
      category === 'male'
        ? `👨 **Male Voice (ছেলেদের ও ইমোশনাল কণ্ঠস্বর)**\n\nসংবাদ, গল্প, ইমোশনাল, ইমোশনাল ভাইরাল ও প্রোমো ভয়েস থেকে পছন্দেরটি বেছে নিন:`
        : category === 'female'
          ? `👩 **Female Voice (মেয়েদের ও ইমোশনাল কণ্ঠস্বর)**\n\nমিষ্টি, সংবাদ ও ইমোশনাল ভাইরাল নারী কণ্ঠস্বরগুলোর মধ্য থেকে পছন্দেরটি বেছে নিন:`
          : `🎭 **Cartoon Voice (ইউনিক কার্টুন কণ্ঠস্বর)**\n\nঅগি, টম অ্যান্ড জেরি, ডোরেমন, নোবিতা ও শিনচ্যান স্টাইলের মজার কার্টুন কণ্ঠস্বর বেছে নিন:`;

    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text: catHeader,
      timestamp: nowTimeLabel(),
      buttons: voiceListButtons(category, user.selectedVoiceId),
    });
    return { messages, user };
  }

  if (cb.startsWith('voice:')) {
    const voiceId = cb.slice('voice:'.length);
    const voice = getVoiceById(voiceId);
    user =
      botStore.updateUser(user.id, {
        selectedCategory: voice.category,
        selectedVoiceId: voice.id,
        step: 'awaiting_script',
      }) ?? user;

    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text:
        `✅ ${voice.emoji} **${voice.nameBn} (${voice.roleBn})** নির্বাচিত হয়েছে!\n` +
        `${voice.descriptionBn}\n\n` +
        `⚙️ স্পিড: **${user.speed}x** | পিচ: **${formatPitchLabel(user.pitch)}**\n\n` +
        `✍️ **এবার আপনার বাংলা, ইংরেজি বা মিশ্রিত Script লিখে পাঠান (অথবা .txt ফাইল আপলোড করুন)।**\n` +
        `ইংরেজি স্ক্রিপ্ট স্বয়ংক্রিয়ভাবে স্বাভাবিক বাংলায় রূপান্তরিত হবে এবং ভয়েস তৈরির আগে আপনি প্রিভিউ দেখে এডিট করতে পারবেন।`,
      timestamp: nowTimeLabel(),
      buttons: [
        [
          { text: `🔊 ${voice.emoji} ডেমো শুনুন`, callback_data: `demo:${voice.id}` },
          { text: '📄 লং স্ক্রিপ্ট মোড', callback_data: 'menu:longscript' },
        ],
        [
          { text: '⚙️ স্পিড ও পিচ', callback_data: 'menu:settings' },
          { text: '🔄 অন্য ভয়েস', callback_data: `cat:${voice.category}` },
        ],
      ],
    });
    return { messages, user };
  }

  if (cb === 'menu:longscript' || text === '/longscript') {
    user =
      botStore.updateUser(user.id, {
        step: 'collecting_long_script',
        pendingContext: { longScriptParts: [] },
      }) ?? user;

    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text:
        `📄 **Unlimited Duration লং স্ক্রিপ্ট মোড চালু হয়েছে**\n\n` +
        `টেলিগ্রামে একটি মেসেজে ৪,০৯৬ অক্ষরের বেশি লেখা যায় না। তাই বড় অডিও (৫ মিনিট, ২০ মিনিট, ৩০ মিনিট বা ১ ঘণ্টা+) তৈরি করতে:\n\n` +
        `১. আপনার বাংলা, ইংরেজি বা মিশ্রিত স্ক্রিপ্ট একাধিক মেসেজে পরপর পাঠান (সবগুলো স্বয়ংক্রিয়ভাবে যুক্ত হবে), **অথবা**\n` +
        `২. সরাসরি একটি সম্পূর্ণ **\`.txt\` ফাইল** পাঠান।\n\n` +
        `সব অংশ পাঠানো শেষ হলে নিচের **“👁️ বাংলা প্রিভিউ দেখুন”** বাটনে চাপ দিন।`,
      timestamp: nowTimeLabel(),
      buttons: [
        [{ text: '👁️ বাংলা প্রিভিউ দেখুন', callback_data: 'long:submit' }],
        [{ text: '❌ বাতিল করুন', callback_data: 'menu:main' }],
      ],
    });
    return { messages, user };
  }

  if (cb === 'long:submit') {
    const parts = user.pendingContext?.longScriptParts ?? [];
    const combined = parts.join('\n\n').trim();

    if (!combined) {
      user =
        botStore.updateUser(user.id, {
          step: 'awaiting_script',
          pendingContext: undefined,
        }) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: '⚠️ কোনো স্ক্রিপ্ট পাওয়া যায়নি। অনুগ্রহ করে প্রথমে বাংলা বা ইংরেজি স্ক্রিপ্ট পাঠান।',
        timestamp: nowTimeLabel(),
        buttons: mainMenuButtons(botStore.isAdmin(user)),
      });
      return { messages, user };
    }

    return await showBanglaPreviewForScript({
      user,
      rawScript: combined,
    });
  }

  if (cb === 'preview:confirm') {
    const previewBangla = user.pendingContext?.previewBanglaScript?.trim();
    const previewRaw = user.pendingContext?.previewRawScript?.trim() || previewBangla;
    if (!previewBangla) {
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: '⚠️ কোনো প্রিভিউ স্ক্রিপ্ট পাওয়া যায়নি। অনুগ্রহ করে নতুন করে আপনার স্ক্রিপ্ট পাঠান।',
        timestamp: nowTimeLabel(),
        buttons: mainMenuButtons(botStore.isAdmin(user)),
      });
      return { messages, user };
    }

    user =
      botStore.updateUser(user.id, {
        step: 'awaiting_script',
        pendingContext: undefined,
      }) ?? user;

    return await enqueueFromBot({
      user,
      script: previewBangla,
      originalScript: previewRaw,
      preConvertedBangla: true,
      source: params.source,
      telegramChatId: params.telegramChatId,
      enqueueListenerFactory: params.enqueueListenerFactory,
    });
  }

  if (cb === 'preview:edit') {
    const previewBangla = user.pendingContext?.previewBanglaScript?.trim();
    if (!previewBangla) {
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: '⚠️ এডিট করার মতো কোনো প্রিভিউ পাওয়া যায়নি। নতুন স্ক্রিপ্ট পাঠান।',
        timestamp: nowTimeLabel(),
        buttons: mainMenuButtons(botStore.isAdmin(user)),
      });
      return { messages, user };
    }

    user =
      botStore.updateUser(user.id, {
        step: 'awaiting_preview_edit',
      }) ?? user;

    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text:
        `✏️ **বাংলা স্ক্রিপ্ট এডিট মোড**\n\n` +
        `উপরের বাংলা প্রিভিউটি কপি করে আপনার প্রয়োজনমতো সংশোধন করে এখানে পাঠান (অথবা সংশোধিত \`.txt\` ফাইল আপলোড করুন)।`,
      timestamp: nowTimeLabel(),
      buttons: [
        [{ text: '✅ আগের প্রিভিউ দিয়েই ভয়েস তৈরি করুন', callback_data: 'preview:confirm' }],
        [{ text: '❌ বাতিল করুন', callback_data: 'menu:main' }],
      ],
    });
    return { messages, user };
  }

  if (cb === 'preview:reconvert') {
    const raw = user.pendingContext?.previewRawScript?.trim();
    if (!raw) {
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: '⚠️ মূল স্ক্রিপ্ট পাওয়া যায়নি। অনুগ্রহ করে আবার স্ক্রিপ্ট পাঠান।',
        timestamp: nowTimeLabel(),
        buttons: mainMenuButtons(botStore.isAdmin(user)),
      });
      return { messages, user };
    }

    return await showBanglaPreviewForScript({
      user,
      rawScript: raw,
    });
  }

  if (cb === 'menu:settings' || text === '/settings') {
    const lang = user.language === 'en' ? 'en' : 'bn';
    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text:
        `⚙️ **Settings: Speed, Pitch & Language (ভাষা)**\n\n` +
        `• স্পিড: **${user.speed}x** | পিচ: **${formatPitchLabel(user.pitch)}**\n` +
        `• ভাষা (Language): **${lang === 'en' ? '🇺🇸 English' : '🇧🇩 বাংলা (Bangla)'}**\n\n` +
        `নিচের বাটন থেকে সেটিংস পরিবর্তন করুন:`,
      timestamp: nowTimeLabel(),
      buttons: [
        [
          { text: `${lang === 'bn' ? '✅ ' : ''}🇧🇩 বাংলা`, callback_data: 'lang:bn' },
          { text: `${lang === 'en' ? '✅ ' : ''}🇺🇸 English`, callback_data: 'lang:en' },
        ],
        ...speedPitchButtons(user),
      ],
    });
    return { messages, user };
  }

  if (cb.startsWith('speed:')) {
    const speedVal = Number(cb.slice('speed:'.length));
    if (!Number.isNaN(speedVal)) {
      user = botStore.updateUser(user.id, { speed: speedVal }) ?? user;
    }
    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text: `🎚️ ভয়েস স্পিড **${user.speed}x** সেট করা হয়েছে।`,
      timestamp: nowTimeLabel(),
      buttons: speedPitchButtons(user),
    });
    return { messages, user };
  }

  if (cb.startsWith('pitch:')) {
    const pitchVal = Number(cb.slice('pitch:'.length));
    if (!Number.isNaN(pitchVal)) {
      user = botStore.updateUser(user.id, { pitch: pitchVal }) ?? user;
    }
    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text: `🎛️ ভয়েস পিচ **${formatPitchLabel(user.pitch)}** সেট করা হয়েছে।`,
      timestamp: nowTimeLabel(),
      buttons: speedPitchButtons(user),
    });
    return { messages, user };
  }

  if (cb === 'menu:prompt_script') {
    const voice = getVoiceById(user.selectedVoiceId);
    user = botStore.updateUser(user.id, { step: 'awaiting_script' }) ?? user;
    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text: `✍️ বর্তমান ভয়েস **${voice.nameBn}** (${user.speed}x, ${formatPitchLabel(user.pitch)}) দিয়ে ভয়েস তৈরি করতে আপনার **বাংলা, ইংরেজি বা মিশ্রিত Script** পাঠান:`,
      timestamp: nowTimeLabel(),
    });
    return { messages, user };
  }

  // -------------------------------------------------------------------------
  // 3. User Wallet, Balance & Confirmed Payment Requests
  // -------------------------------------------------------------------------
  if (cb === 'menu:wallet' || text === '/balance') {
    const cfg = botStore.getConfig();
    const activeAccounts = (cfg.paymentAccounts ?? []).filter(
      (a) => a.enabled && a.accountNumber.trim(),
    );
    const payNumLines =
      activeAccounts.length > 0
        ? activeAccounts
            .map(
              (a) =>
                `• **${a.method}** (${a.accountType}): \`${a.accountNumber}\`${a.note ? ` — ${a.note}` : ''}`,
            )
            .join('\n')
        : '• এখনো কোনো পেমেন্ট নম্বর সেট করা হয়নি।';

    const txs = botStore.listTransactions(user.id, 5);
    const txLines =
      txs.length > 0
        ? txs
            .map(
              (t) =>
                `• ${t.amount >= 0 ? '+' : ''}৳${t.amount} — ${t.description}`,
            )
            .join('\n')
        : 'এখনো কোনো লেনদেন নেই।';

    const voiceCost = botStore.getVoiceEffectiveCost(user.selectedVoiceId);
    const voice = getVoiceById(user.selectedVoiceId);

    const guideText = cfg.paymentInstructions?.trim()
      ? `\n\n📖 **কিভাবে পেমেন্ট ও TrxID জমা দেবেন:**\n${cfg.paymentInstructions.trim()}`
      : '';

    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text:
        `💳 **ব্যালেন্স ও পেমেন্ট ওয়ালেট**\n\n` +
        `• বর্তমান ব্যালেন্স: **৳${user.balance.toFixed(2)}**\n` +
        `• নির্বাচিত ভয়েস (${voice.nameBn}) চার্জ: **${voiceCost > 0 ? `৳${voiceCost}` : 'ফ্রি (৳0)'}**\n\n` +
        `**পেমেন্ট নম্বরসমূহ:**\n${payNumLines}` +
        guideText +
        `\n\n**সাম্প্রতিক লেনদেন:**\n${txLines}`,
      timestamp: nowTimeLabel(),
      buttons: [
        [{ text: '➕ ব্যালেন্স রিচার্জ (Payment Request)', callback_data: 'pay:start' }],
        [{ text: '🏠 মেইন মেনু', callback_data: 'menu:main' }],
      ],
    });
    return { messages, user };
  }

  if (cb === 'pay:start') {
    const cfg = botStore.getConfig();
    const activeAccounts = (cfg.paymentAccounts ?? []).filter(
      (a) => a.enabled && a.accountNumber.trim(),
    );

    if (activeAccounts.length === 0) {
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `⚠️ **কোনো পেমেন্ট নম্বর পাওয়া যায়নি**\n\n` +
          `অ্যাডমিন এখনো কোনো bKash / Nagad / Rocket পেমেন্ট নম্বর যুক্ত করেননি। অনুগ্রহ করে অ্যাডমিনের সাথে যোগাযোগ করুন।`,
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '◀️ ওয়ালেট মেনু', callback_data: 'menu:wallet' }]],
      });
      return { messages, user };
    }

    user =
      botStore.updateUser(user.id, {
        step: 'awaiting_payment_method',
        pendingContext: {},
      }) ?? user;

    const methodBtns: InlineButton[][] = activeAccounts.map((acc) => [
      {
        text: `📲 ${acc.method} (${acc.accountType}) — ${acc.accountNumber}`,
        callback_data: `pay:acct:${acc.id}`,
      },
    ]);
    methodBtns.push([{ text: '❌ বাতিল', callback_data: 'menu:wallet' }]);

    const guide = cfg.paymentInstructions?.trim()
      ? `\n\n📖 **নির্দেশনা:**\n${cfg.paymentInstructions.trim()}`
      : '';

    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text:
        `💰 **ব্যালেন্স রিচার্জ — ধাপ ১/৪: পেমেন্ট মাধ্যম নির্বাচন**\n\n` +
        `নিচের অ্যাডমিন অনুমোদিত পেমেন্ট নম্বরগুলোর মধ্য থেকে যেটি ব্যবহার করে টাকা পাঠাবেন তা সিলেক্ট করুন:` +
        guide,
      timestamp: nowTimeLabel(),
      buttons: methodBtns,
    });
    return { messages, user };
  }

  if (cb.startsWith('pay:acct:')) {
    const accId = cb.slice('pay:acct:'.length);
    const cfg = botStore.getConfig();
    const acc = (cfg.paymentAccounts ?? []).find((a) => a.id === accId && a.enabled);
    if (!acc) {
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: '⚠️ নির্বাচিত পেমেন্ট নম্বরটি বর্তমানে সক্রিয় নেই। আবার চেষ্টা করুন।',
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '🔄 পুনরায় চেষ্টা', callback_data: 'pay:start' }]],
      });
      return { messages, user };
    }

    user =
      botStore.updateUser(user.id, {
        step: 'awaiting_payment_amount',
        pendingContext: {
          paymentMethod: acc.method,
          paymentAccountNumber: acc.accountNumber,
        },
      }) ?? user;

    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text:
        `📲 **ধাপ ২/৪: পেমেন্ট নম্বর ও পরিমাণ**\n\n` +
        `• মাধ্যম: **${acc.method}** (${acc.accountType})\n` +
        `• প্রাপক নম্বর: \`${acc.accountNumber}\`\n` +
        (acc.note ? `• নির্দেশনা: ${acc.note}\n` : '') +
        `\nউপরোক্ত নম্বরে টাকা পাঠানোর পর আপনি কত টাকা (৳) রিচার্জ করছেন তা সংখ্যায় লিখে পাঠান (যেমন: \`100\` বা \`500\`):`,
      timestamp: nowTimeLabel(),
      buttons: [[{ text: '❌ বাতিল', callback_data: 'menu:wallet' }]],
    });
    return { messages, user };
  }

  if (cb === 'pay:confirm') {
    const ctx = user.pendingContext;
    if (
      !ctx?.paymentAmount ||
      !ctx?.paymentRef ||
      !ctx?.paymentMethod
    ) {
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: '⚠️ পেমেন্ট তথ্য অসম্পূর্ণ। অনুগ্রহ করে নতুন করে পেমেন্ট রিকোয়েস্ট শুরু করুন।',
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '➕ নতুন রিকোয়েস্ট', callback_data: 'pay:start' }]],
      });
      return { messages, user };
    }

    try {
      const result = botStore.submitPaymentRequestAndAutoVerify({
        user,
        amount: ctx.paymentAmount,
        method: ctx.paymentMethod,
        accountNumber: ctx.paymentAccountNumber,
        referenceNote: ctx.paymentRef,
      });

      const payment = result.payment;
      user =
        botStore.updateUser(user.id, {
          step: 'idle',
          pendingContext: undefined,
        }) ?? user;

      if (result.autoApproved) {
        pendingAdminNotifications.push({
          text:
            `⚡ **অটো-ভেরিফাইড পেমেন্ট (SMS Match)**\n\n` +
            `• ID: \`${payment.id}\`\n` +
            `• User: ${payment.userName} (${payment.telegramId})\n` +
            `• Amount: **+৳${payment.amount}**\n` +
            `• TrxID / Ref: \`${payment.referenceNote}\``,
          buttons: [[{ text: '🛡️ Admin Dashboard', callback_data: 'adm:home' }]],
        });

        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text:
            `⚡ **পেমেন্ট স্বয়ংক্রিয়ভাবে ভেরিফাই ও ব্যালেন্স যুক্ত হয়েছে!**\n\n` +
            `• Request ID: \`${payment.id}\`\n` +
            `• মাধ্যম: **${payment.method}**${payment.accountNumber ? ` (${payment.accountNumber})` : ''}\n` +
            `• যুক্তকৃত ব্যালেন্স: **+৳${payment.amount}**\n` +
            `• নতুন ব্যালেন্স: **৳${user.balance.toFixed(2)}**\n` +
            `• TrxID: \`${payment.trxId ?? payment.referenceNote}\``,
          timestamp: nowTimeLabel(),
          buttons: [
            [{ text: '🎙️ এখনই ভয়েস তৈরি করুন', callback_data: 'menu:create' }],
            [{ text: '🏠 মেইন মেনু', callback_data: 'menu:main' }],
          ],
        });
        return { messages, user, pendingAdminNotifications };
      }

      pendingAdminNotifications.push({
        text:
          `🔔 **নতুন Confirmed Payment Request এসেছে!**\n\n` +
          `• ID: \`${payment.id}\`\n` +
          `• User: ${payment.userName} (ID: ${payment.telegramId})\n` +
          `• Method: **${payment.method}**${payment.accountNumber ? ` (\`${payment.accountNumber}\`)` : ''}\n` +
          `• Amount: **৳${payment.amount}**\n` +
          `• Sender / TrxID: ${payment.referenceNote}`,
        buttons: [
          [
            {
              text: `✅ Approve (৳${payment.amount})`,
              callback_data: `adm:pay_ok:${payment.id}`,
            },
            { text: '❌ Reject', callback_data: `adm:pay_no:${payment.id}` },
          ],
        ],
      });

      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `✅ **আপনার পেমেন্ট রিকোয়েস্ট সফলভাবে কনফার্ম ও জমা হয়েছে!**\n\n` +
          `• Request ID: \`${payment.id}\`\n` +
          `• মাধ্যম: **${payment.method}**${payment.accountNumber ? ` (${payment.accountNumber})` : ''}\n` +
          `• পরিমাণ: **৳${payment.amount}**\n` +
          `• TrxID / রেফারেন্স: \`${payment.referenceNote}\`\n\n` +
          `পেমেন্ট SMS মিললে সাথে সাথেই অটো-ভেরিফাই হবে, অথবা অ্যাডমিন যাচাই করে Approve করলে ব্যালেন্স যুক্ত হয়ে যাবে।`,
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '🏠 মেইন মেনু', callback_data: 'menu:main' }]],
      });
      return { messages, user, pendingAdminNotifications };
    } catch (err) {
      user =
        botStore.updateUser(user.id, {
          step: 'idle',
          pendingContext: undefined,
        }) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: `⚠️ ${err instanceof Error ? err.message : 'পেমেন্ট রিকোয়েস্ট গ্রহণ করা যায়নি।'}`,
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '➕ নতুন রিকোয়েস্ট', callback_data: 'pay:start' }]],
      });
      return { messages, user };
    }
  }

  if (
    cb === 'menu:profile' ||
    cb === 'menu:account' ||
    cb === 'menu:history' ||
    cb.startsWith('profile:tab:') ||
    text === '/profile' ||
    text === '/account' ||
    text === '/history' ||
    text === '/myfiles'
  ) {
    let tab: 'overview' | 'audio' | 'video' = 'overview';
    let page = 0;
    if (cb.startsWith('profile:tab:')) {
      const [, , tabPart, pagePart] = cb.split(':');
      if (tabPart === 'audio' || tabPart === 'video' || tabPart === 'overview') {
        tab = tabPart;
      }
      page = Number.parseInt(pagePart ?? '0', 10) || 0;
    } else if (cb === 'menu:history' || text === '/history') {
      tab = 'audio';
    }

    const unified = buildUnifiedProfilePayload(user, tab, page);
    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text: unified.text,
      timestamp: nowTimeLabel(),
      buttons: unified.buttons,
    });
    return { messages, user };
  }

  if (cb.startsWith('file:audio:')) {
    const genId = cb.slice('file:audio:'.length);
    const gen = botStore.getGenerationById(genId);
    if (!gen || (gen.userId !== user.id && !botStore.isAdmin(user))) {
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: '⚠️ দুঃখিত, এই অডিও ফাইলটি খুঁজে পাওয়া যায়নি।',
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '👤 প্রোফাইলে ফিরুন', callback_data: 'menu:profile' }]],
      });
      return { messages, user };
    }
    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text: `🎧 ${gen.voiceNameBn} (${formatDurationHuman(gen.durationSec)})`,
      timestamp: nowTimeLabel(),
      audio: {
        generationId: gen.id,
        url: gen.audioUrl,
        title: `Bangla Voice - ${gen.voiceNameBn}`,
        performer: 'BanglaVoice AI Bot',
        durationSec: gen.durationSec,
        fileSizeBytes: gen.fileSizeBytes,
      },
      buttons: postAudioButtons(gen.id),
    });
    return { messages, user };
  }

  if (cb.startsWith('file:video:')) {
    const vjobId = cb.slice('file:video:'.length);
    const vjob = botStore.getVideoJobById(vjobId);
    if (
      !vjob ||
      !vjob.outputVideoUrl ||
      (vjob.userId !== user.id && !botStore.isAdmin(user))
    ) {
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: '⚠️ দুঃখিত, এই ভিডিও ফাইলটি খুঁজে পাওয়া যায়নি।',
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '👤 প্রোফাইলে ফিরুন', callback_data: 'menu:profile' }]],
      });
      return { messages, user };
    }
    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text: `🎬 ${vjob.title} (${vjob.aspectRatio} · ${vjob.resolution.toUpperCase()} · ${vjob.durationSec ? formatDurationHuman(vjob.durationSec) : ''})`,
      timestamp: nowTimeLabel(),
      video: {
        jobId: vjob.id,
        url: vjob.outputVideoUrl,
        title: vjob.title,
        durationSec: vjob.durationSec ?? 0,
        fileSizeBytes: vjob.fileSizeBytes ?? 0,
      },
      buttons: [
        [
          { text: '👤 প্রোফাইল ও ফাইলস', callback_data: 'menu:profile' },
          { text: '🏠 মেইন মেনু', callback_data: 'menu:main' },
        ],
      ],
    });
    return { messages, user };
  }

  if (cb === 'file:all') {
    const audios = botStore.listGenerations(user.id, 4);
    const videos = botStore
      .listVideoJobs(user.id, 4)
      .filter((v) => v.status === 'completed' && Boolean(v.outputVideoUrl));

    if (audios.length === 0 && videos.length === 0) {
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: '📂 আপনার প্রোফাইলে এখনো কোনো অডিও বা ভিডিও ফাইল সংরক্ষিত নেই।',
        timestamp: nowTimeLabel(),
        buttons: [
          [
            { text: '🎙️ ভয়েস তৈরি করুন', callback_data: 'menu:create' },
            { text: '🎬 ভিডিও তৈরি করুন', callback_data: 'menu:video' },
          ],
        ],
      });
      return { messages, user };
    }

    for (const v of videos) {
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: `🎬 ${v.title} (${v.aspectRatio} · ${v.resolution.toUpperCase()})`,
        timestamp: nowTimeLabel(),
        video: {
          jobId: v.id,
          url: v.outputVideoUrl!,
          title: v.title,
          durationSec: v.durationSec ?? 0,
          fileSizeBytes: v.fileSizeBytes ?? 0,
        },
      });
    }
    for (const g of audios) {
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: `🎧 ${g.voiceNameBn} (${formatDurationHuman(g.durationSec)})`,
        timestamp: nowTimeLabel(),
        audio: {
          generationId: g.id,
          url: g.audioUrl,
          title: `Bangla Voice - ${g.voiceNameBn}`,
          performer: 'BanglaVoice AI Bot',
          durationSec: g.durationSec,
          fileSizeBytes: g.fileSizeBytes,
        },
      });
    }
    messages.push({
      id: makeMsgId(),
      sender: 'bot',
      text: `✅ আপনার সর্বশেষ ${videos.length}টি ভিডিও এবং ${audios.length}টি অডিও ফাইল পাঠানো হয়েছে।`,
      timestamp: nowTimeLabel(),
      buttons: [
        [{ text: '👤 প্রোফাইলে ফিরুন', callback_data: 'menu:profile' }],
        [{ text: '🏠 মেইন মেনু', callback_data: 'menu:main' }],
      ],
    });
    return { messages, user };
  }

  if (cb.startsWith('regen:')) {
    const prevId = cb.slice('regen:'.length);
    const prevGen = botStore.getGenerationById(prevId);
    if (!prevGen) {
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: 'দুঃখিত, পূর্বের স্ক্রিপ্টটি খুঁজে পাওয়া যায়নি। অনুগ্রহ করে নতুন বাংলা স্ক্রিপ্ট পাঠান।',
        timestamp: nowTimeLabel(),
        buttons: mainMenuButtons(botStore.isAdmin(user)),
      });
      return { messages, user };
    }

    return await enqueueFromBot({
      user,
      script: prevGen.spokenScript || prevGen.script,
      originalScript: prevGen.script,
      preConvertedBangla: !/[A-Za-z]/.test(prevGen.spokenScript || ''),
      source: params.source,
      telegramChatId: params.telegramChatId,
      enqueueListenerFactory: params.enqueueListenerFactory,
    });
  }

  // -------------------------------------------------------------------------
  // 4. Admin Callback Actions (Requires Admin Authorization)
  // -------------------------------------------------------------------------
  if (cb.startsWith('adm:')) {
    if (!botStore.isAdmin(user)) {
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: '🔒 শুধুমাত্র অনুমোদিত অ্যাডমিন এই প্যানেল ব্যবহার করতে পারবেন।',
        timestamp: nowTimeLabel(),
      });
      return { messages, user };
    }

    if (cb === 'adm:home') {
      user =
        botStore.updateUser(user.id, {
          step: 'idle',
          pendingContext: undefined,
        }) ?? user;
      const dash = buildAdminDashboardMessage();
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: dash.text,
        timestamp: nowTimeLabel(),
        buttons: dash.buttons,
      });
      return { messages, user };
    }

    if (cb === 'adm:features' || cb.startsWith('adm:ftoggle:')) {
      const cfg = botStore.getConfig();
      const map = { ...(cfg.enabledFeatures ?? {}) };
      if (cb.startsWith('adm:ftoggle:')) {
        const mod = cb.slice('adm:ftoggle:'.length) as keyof typeof map;
        map[mod] = !botStore.isFeatureEnabled(mod);
        botStore.updateConfig({ enabledFeatures: map });
      }
      const stats = botStore.getDashboardStats();
      const mods: Array<{ id: keyof typeof map; label: string }> = [
        { id: 'chat', label: '💬 AI Chat' },
        { id: 'image', label: '🎨 Image Studio' },
        { id: 'video', label: '🎬 Video Studio' },
        { id: 'voice', label: '🎙️ Voice Studio' },
        { id: 'documents', label: '📄 Documents AI' },
        { id: 'coding', label: '💻 Coding AI' },
        { id: 'research', label: '🌐 Web Research' },
        { id: 'memory', label: '🧠 Memory' },
      ];
      const summary = mods
        .map(
          (m) =>
            `• ${m.label}: **${botStore.isFeatureEnabled(m.id) ? 'ON ✅' : 'OFF ❌'}** (ব্যবহার: ${stats.featureUsage[m.id] ?? 0})`,
        )
        .join('\n');
      const btns: InlineButton[][] = [];
      for (let i = 0; i < mods.length; i += 2) {
        btns.push(
          mods.slice(i, i + 2).map((m) => ({
            text: `${botStore.isFeatureEnabled(m.id) ? '✅' : '❌'} ${m.label}`,
            callback_data: `adm:ftoggle:${m.id}`,
          })),
        );
      }
      btns.push([{ text: '🛡️ Admin Home', callback_data: 'adm:home' }]);
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: `🧩 **AI Feature Enable / Disable Control**\n\n${summary}\n\nযেকোনো ফিচার চালু/বন্ধ করতে ট্যাপ করুন:`,
        timestamp: nowTimeLabel(),
        buttons: btns,
      });
      return { messages, user };
    }

    if (cb === 'adm:errors' || cb === 'adm:errors:clear') {
      if (cb === 'adm:errors:clear') {
        botStore.clearErrorLogs();
      }
      const logs = botStore.getErrorLogs(12);
      const lines =
        logs.length > 0
          ? logs
              .map(
                (l, i) =>
                  `${i + 1}. **[${l.module}]** ${l.message.slice(0, 120)} (${new Date(l.createdAt).toLocaleTimeString()})`,
              )
              .join('\n')
          : '✅ কোনো এরর লগ নেই — সিস্টেম সম্পূর্ণ সুস্থ!';
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: `🚨 **System Error Logs (${logs.length})**\n\n${lines}`,
        timestamp: nowTimeLabel(),
        buttons: [
          ...(logs.length > 0 ? [[{ text: '🗑️ সব Error Log মুছুন', callback_data: 'adm:errors:clear' }]] : []),
          [{ text: '🛡️ Admin Home', callback_data: 'adm:home' }],
        ],
      });
      return { messages, user };
    }

    if (cb.startsWith('adm:users:') || cb === 'adm:ban_list' || cb === 'adm:balance') {
      const allUsers = botStore.listUsers();
      const page = cb.startsWith('adm:users:')
        ? Number(cb.slice('adm:users:'.length)) || 0
        : 0;
      const pageSize = 6;
      const slice = allUsers.slice(page * pageSize, (page + 1) * pageSize);

      const headerTitle =
        cb === 'adm:ban_list'
          ? '🚫 **Ban / Unban User Selection**'
          : cb === 'adm:balance'
            ? '💰 **Balance Management — Select User**'
            : `👥 **User Management (${allUsers.length} Users)**`;

      const summary = slice
        .map(
          (u) =>
            `• ${u.firstName} (@${u.username}) · ID: ${u.telegramId} · ${u.tier.toUpperCase()} · ৳${u.balance.toFixed(0)} · ${u.status === 'banned' ? '⛔' : '✅'}`,
        )
        .join('\n');

      const btns: InlineButton[][] = slice.map((u) => [
        {
          text: `${u.status === 'banned' ? '⛔ ' : ''}${u.firstName} (${u.telegramId}) — ৳${u.balance.toFixed(0)}`,
          callback_data:
            cb === 'adm:balance'
              ? `adm:u_bal_menu:${u.id}`
              : `adm:user:${u.id}`,
        },
      ]);

      const navRow: InlineButton[] = [];
      if (page > 0) {
        navRow.push({ text: '⬅️ Prev', callback_data: `adm:users:${page - 1}` });
      }
      if ((page + 1) * pageSize < allUsers.length) {
        navRow.push({ text: 'Next ➡️', callback_data: `adm:users:${page + 1}` });
      }
      if (navRow.length > 0) btns.push(navRow);
      btns.push([
        { text: '🔍 Search by Telegram ID', callback_data: 'adm:search' },
        { text: '🛡️ Admin Home', callback_data: 'adm:home' },
      ]);

      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: `${headerTitle}\n\n${summary || 'কোনো ব্যবহারকারী নেই।'}`,
        timestamp: nowTimeLabel(),
        buttons: btns,
      });
      return { messages, user };
    }

    if (cb === 'adm:search') {
      user =
        botStore.updateUser(user.id, {
          step: 'admin_search_user',
          pendingContext: undefined,
        }) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: '🔍 ব্যবহারকারীর **Telegram ID** অথবা **Username** লিখে পাঠান:',
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '❌ Cancel', callback_data: 'adm:home' }]],
      });
      return { messages, user };
    }

    if (cb.startsWith('adm:user:')) {
      const targetId = cb.slice('adm:user:'.length);
      const target = botStore.getUserById(targetId);
      if (!target) {
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: '⚠️ User পাওয়া যায়নি।',
          timestamp: nowTimeLabel(),
          buttons: [[{ text: '🛡️ Admin Home', callback_data: 'adm:home' }]],
        });
        return { messages, user };
      }
      const profile = buildAdminUserProfileMessage(target);
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: profile.text,
        timestamp: nowTimeLabel(),
        buttons: profile.buttons,
      });
      return { messages, user };
    }

    if (cb.startsWith('adm:u_hist:')) {
      const targetId = cb.slice('adm:u_hist:'.length);
      const target = botStore.getUserById(targetId);
      const gens = botStore.listGenerations(targetId, 8);
      const lines =
        gens.length > 0
          ? gens
              .map(
                (g, i) =>
                  `${i + 1}. **${g.voiceNameBn}** (${formatDurationHuman(g.durationSec)})\n   “${g.script.slice(0, 70)}...”`,
              )
              .join('\n\n')
          : 'এই ব্যবহারকারীর কোনো ভয়েস হিস্টোরি নেই।';
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: `📜 **${target?.firstName ?? targetId} — Voice History**\n\n${lines}`,
        timestamp: nowTimeLabel(),
        buttons: [
          [{ text: '◀️ Back to Profile', callback_data: `adm:user:${targetId}` }],
        ],
      });
      return { messages, user };
    }

    if (cb.startsWith('adm:u_ban:')) {
      const targetId = cb.slice('adm:u_ban:'.length);
      const target = botStore.getUserById(targetId);
      if (target) {
        const updated =
          botStore.updateUser(target.id, {
            status: target.status === 'banned' ? 'active' : 'banned',
          }) ?? target;
        const profile = buildAdminUserProfileMessage(updated);
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `${updated.status === 'banned' ? '⛔ User Banned!' : '✅ User Unbanned!'}\n\n${profile.text}`,
          timestamp: nowTimeLabel(),
          buttons: profile.buttons,
        });
      }
      return { messages, user };
    }

    if (cb.startsWith('adm:u_prem:')) {
      const targetId = cb.slice('adm:u_prem:'.length);
      const target = botStore.getUserById(targetId);
      if (target) {
        const updated =
          target.tier === 'premium'
            ? botStore.deactivatePremium(target.id)
            : botStore.activatePremium(target.id);
        const profile = buildAdminUserProfileMessage(updated ?? target);
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `${updated?.tier === 'premium' ? '👑 Premium Activated!' : '⬇️ Switched to Free Plan.'}\n\n${profile.text}`,
          timestamp: nowTimeLabel(),
          buttons: profile.buttons,
        });
      }
      return { messages, user };
    }

    if (cb.startsWith('adm:u_limit:')) {
      const targetId = cb.slice('adm:u_limit:'.length);
      user =
        botStore.updateUser(user.id, {
          step: 'admin_set_user_limit',
          pendingContext: { targetUserId: targetId },
        }) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: '🎚️ এই ইউজারের জন্য নতুন **Daily Voice Limit** সংখ্যা লিখুন (ডিফল্টে ফেরাতে `default` লিখুন):',
        timestamp: nowTimeLabel(),
        buttons: [
          [{ text: '❌ Cancel', callback_data: `adm:user:${targetId}` }],
        ],
      });
      return { messages, user };
    }

    if (cb.startsWith('adm:u_bal_menu:')) {
      const targetId = cb.slice('adm:u_bal_menu:'.length);
      const target = botStore.getUserById(targetId);
      if (!target) return { messages, user };
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `💰 **Balance Control — ${target.firstName}**\n` +
          `বর্তমান ব্যালেন্স: **৳${target.balance.toFixed(2)}**\n\n` +
          `দ্রুত বাটন ব্যবহার করুন অথবা কাস্টম পরিমাণ দিন:`,
        timestamp: nowTimeLabel(),
        buttons: [
          [
            { text: '+৳50', callback_data: `adm:u_bal_do:${target.id}:50` },
            { text: '+৳100', callback_data: `adm:u_bal_do:${target.id}:100` },
            { text: '+৳500', callback_data: `adm:u_bal_do:${target.id}:500` },
          ],
          [
            { text: '-৳50', callback_data: `adm:u_bal_do:${target.id}:-50` },
            { text: '-৳100', callback_data: `adm:u_bal_do:${target.id}:-100` },
          ],
          [
            {
              text: '✍️ Custom Add / Deduct',
              callback_data: `adm:u_bal_custom:${target.id}`,
            },
          ],
          [{ text: '◀️ Back to Profile', callback_data: `adm:user:${target.id}` }],
        ],
      });
      return { messages, user };
    }

    if (cb.startsWith('adm:u_bal_do:')) {
      const rest = cb.slice('adm:u_bal_do:'.length);
      const lastColon = rest.lastIndexOf(':');
      const targetId = rest.slice(0, lastColon);
      const delta = Number(rest.slice(lastColon + 1));
      if (!Number.isNaN(delta)) {
        const res = botStore.adjustBalance({
          userId: targetId,
          amountDelta: delta,
          type: delta >= 0 ? 'admin_add' : 'admin_deduct',
          description: `অ্যাডমিন ${delta >= 0 ? 'Add' : 'Deduct'} (Telegram /admin)`,
        });
        const profile = buildAdminUserProfileMessage(res.user);
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `✅ ব্যালেন্স আপডেট হয়েছে (${delta >= 0 ? '+' : ''}৳${delta})।\n\n${profile.text}`,
          timestamp: nowTimeLabel(),
          buttons: profile.buttons,
        });
      }
      return { messages, user };
    }

    if (cb.startsWith('adm:u_bal_custom:')) {
      const targetId = cb.slice('adm:u_bal_custom:'.length);
      user =
        botStore.updateUser(user.id, {
          step: 'admin_adjust_balance',
          pendingContext: { targetUserId: targetId },
        }) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: '💰 যোগ করতে `+200` বা `200`, এবং বিয়োগ করতে `-50` লিখে পাঠান:',
        timestamp: nowTimeLabel(),
        buttons: [
          [{ text: '❌ Cancel', callback_data: `adm:u_bal_menu:${targetId}` }],
        ],
      });
      return { messages, user };
    }

    if (cb === 'adm:payments') {
      const pending = botStore.listPaymentRequests('pending');
      if (pending.length === 0) {
        const recent = botStore.listPaymentRequests().slice(0, 5);
        const recentTxt =
          recent.length > 0
            ? recent
                .map(
                  (p) =>
                    `• ${p.id} · ${p.userName} · ৳${p.amount} · ${p.status.toUpperCase()}`,
                )
                .join('\n')
            : 'কোনো পেমেন্ট রিকোয়েস্ট নেই।';
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `💳 **Payment Management**\n\nকোনো পেন্ডিং পেমেন্ট নেই।\n\n**সাম্প্রতিক পেমেন্ট:**\n${recentTxt}`,
          timestamp: nowTimeLabel(),
          buttons: [[{ text: '🛡️ Admin Home', callback_data: 'adm:home' }]],
        });
        return { messages, user };
      }

      const txt = pending
        .map(
          (p) =>
            `• **${p.id}** — ${p.userName} (ID: ${p.telegramId})\n  Amount: **৳${p.amount}** | Ref: ${p.referenceNote}`,
        )
        .join('\n\n');

      const btns: InlineButton[][] = [];
      for (const p of pending.slice(0, 5)) {
        btns.push([
          {
            text: `✅ Approve ${p.id} (৳${p.amount})`,
            callback_data: `adm:pay_ok:${p.id}`,
          },
          {
            text: `❌ Reject ${p.id}`,
            callback_data: `adm:pay_no:${p.id}`,
          },
        ]);
      }
      btns.push([{ text: '🛡️ Admin Home', callback_data: 'adm:home' }]);

      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: `💳 **Pending Payment Requests (${pending.length})**\n\n${txt}`,
        timestamp: nowTimeLabel(),
        buttons: btns,
      });
      return { messages, user };
    }

    if (cb.startsWith('adm:pay_ok:') || cb.startsWith('adm:pay_no:')) {
      const isApprove = cb.startsWith('adm:pay_ok:');
      const payId = cb.slice(isApprove ? 'adm:pay_ok:'.length : 'adm:pay_no:'.length);
      try {
        const result = botStore.reviewPaymentRequest({
          paymentId: payId,
          decision: isApprove ? 'approved' : 'rejected',
          reviewedBy: user.firstName,
        });
        pendingUserNotification = {
          telegramId: result.payment.telegramId,
          text: isApprove
            ? `✅ আপনার পেমেন্ট রিকোয়েস্ট (${result.payment.id}) অনুমোদিত হয়েছে! আপনার ব্যালেন্সে +৳${result.payment.amount} যুক্ত হয়েছে। বর্তমান ব্যালেন্স: ৳${result.user?.balance.toFixed(2)}`
            : `❌ দুঃখিত, আপনার পেমেন্ট রিকোয়েস্ট (${result.payment.id}) বাতিল করা হয়েছে। সঠিক তথ্যসহ আবার চেষ্টা করুন।`,
        };
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: isApprove
            ? `✅ Payment **${payId}** Approved! ৳${result.payment.amount} ব্যালেন্সে যোগ হয়েছে।`
            : `❌ Payment **${payId}** Rejected.`,
          timestamp: nowTimeLabel(),
          buttons: [
            [{ text: '💳 Back to Payments', callback_data: 'adm:payments' }],
            [{ text: '🛡️ Admin Home', callback_data: 'adm:home' }],
          ],
        });
      } catch (err) {
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `⚠️ ${err instanceof Error ? err.message : 'Payment review error'}`,
          timestamp: nowTimeLabel(),
          buttons: [[{ text: '🛡️ Admin Home', callback_data: 'adm:home' }]],
        });
      }
      return { messages, user, pendingUserNotification };
    }

    if (cb === 'adm:tx') {
      const txs = botStore.listTransactions(undefined, 10);
      const lines =
        txs.length > 0
          ? txs
              .map(
                (t) =>
                  `• ${t.userName}: **${t.amount >= 0 ? '+' : ''}৳${t.amount}** (Bal: ৳${t.balanceAfter}) · ${t.description}`,
              )
              .join('\n')
          : 'এখনো কোনো ট্রানজেকশন রেকর্ড হয়নি।';
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: `📜 **Transaction History (সর্বশেষ ১০টি)**\n\n${lines}`,
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '🛡️ Admin Home', callback_data: 'adm:home' }]],
      });
      return { messages, user };
    }

    if (cb === 'adm:stats') {
      const stats = botStore.getDashboardStats();
      const lines = stats.dailySeries
        .map(
          (d) =>
            `• ${d.date}: **${d.generations}** ভয়েস · ${d.characters.toLocaleString()} অক্ষর · ${d.activeUsers} ইউজার`,
        )
        .join('\n');
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: `📊 **Daily Usage Statistics (গত ৭ দিন)**\n\n${lines}`,
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '🛡️ Admin Home', callback_data: 'adm:home' }]],
      });
      return { messages, user };
    }

    if (cb === 'adm:plans') {
      const planMsg = buildPlanSettingsMessage();
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: planMsg.text,
        timestamp: nowTimeLabel(),
        buttons: planMsg.buttons,
      });
      return { messages, user };
    }

    if (cb.startsWith('adm:cfg_edit:')) {
      const key = cb.slice('adm:cfg_edit:'.length);
      user =
        botStore.updateUser(user.id, {
          step: 'admin_edit_config',
          pendingContext: { configKey: key },
        }) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: `⚙️ **${CONFIG_KEY_LABELS[key] ?? key}**\n\nনতুন মান লিখে পাঠান:`,
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '❌ Cancel', callback_data: 'adm:plans' }]],
      });
      return { messages, user };
    }

    if (cb === 'adm:voice_cfg' || cb === 'adm:sys') {
      const cfg = botStore.getConfig();
      const activeJobs = botStore.listIncompleteJobs().length;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `⚙️ **Voice Generation & System Settings**\n\n` +
          `• TTS Model: \`${cfg.ttsModel}\`\n` +
          `• Smart English → Bangla: **${cfg.smartEnglishToBangla ? 'ON ✅' : 'OFF'}**\n` +
          `• Strict Bangla-Only: **${cfg.strictBanglaOnly ? 'ON ✅' : 'OFF'}**\n` +
          `• Auto Bangla Normalize: **${cfg.autoNormalizeBangla ? 'ON ✅' : 'OFF'}**\n` +
          `• Notification Channel: **${cfg.notificationChannelId || 'Admin DM Only (Not Set)'}**\n` +
          `• Background Jobs Running: **${activeJobs}**\n` +
          `• Admin Claim Code: \`${cfg.adminClaimCode}\``,
        timestamp: nowTimeLabel(),
        buttons: [
          [
            {
              text: `🔄 Switch TTS Model`,
              callback_data: 'adm:toggle:ttsModel',
            },
            {
              text: `Smart EN→BN: ${cfg.smartEnglishToBangla ? 'ON' : 'OFF'}`,
              callback_data: 'adm:toggle:smartEnglishToBangla',
            },
          ],
          [
            {
              text: `Bangla-Only: ${cfg.strictBanglaOnly ? 'ON' : 'OFF'}`,
              callback_data: 'adm:toggle:strictBanglaOnly',
            },
            {
              text: `Normalize: ${cfg.autoNormalizeBangla ? 'ON' : 'OFF'}`,
              callback_data: 'adm:toggle:autoNormalizeBangla',
            },
          ],
          [
            {
              text: `📢 Notification Channel (${cfg.notificationChannelId || 'Set'})`,
              callback_data: 'adm:cfg_edit:notificationChannelId',
            },
          ],
          [{ text: '🛡️ Admin Home', callback_data: 'adm:home' }],
        ],
      });
      return { messages, user };
    }

    if (cb === 'adm:pay_nums') {
      const cfg = botStore.getConfig();
      const accounts = cfg.paymentAccounts ?? [];
      const listTxt =
        accounts.length > 0
          ? accounts
              .map(
                (a, idx) =>
                  `${idx + 1}. **${a.method}** (${a.accountType}) — \`${a.accountNumber}\` [${a.enabled ? '✅ সক্রিয়' : '⏸️ বন্ধ'}]${a.note ? `\n   _${a.note}_` : ''}`,
              )
              .join('\n')
          : 'এখনো কোনো পেমেন্ট নম্বর যোগ করা হয়নি।';

      const btns: InlineButton[][] = accounts.map((a) => [
        {
          text: `${a.enabled ? '⏸️ বন্ধ করুন' : '✅ চালু করুন'}: ${a.method} (${a.accountNumber})`,
          callback_data: `adm:pay_tog:${a.id}`,
        },
        {
          text: '🗑️ মুছুন',
          callback_data: `adm:pay_del:${a.id}`,
        },
      ]);

      btns.push([
        { text: '➕ bKash যোগ', callback_data: 'adm:pay_add:bKash' },
        { text: '➕ Nagad যোগ', callback_data: 'adm:pay_add:Nagad' },
      ]);
      btns.push([
        { text: '➕ Rocket যোগ', callback_data: 'adm:pay_add:Rocket' },
        { text: '➕ Upay / Bank', callback_data: 'adm:pay_add:Custom' },
      ]);
      btns.push([{ text: '🛡️ Admin Home', callback_data: 'adm:home' }]);

      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: `📲 **Admin Payment Numbers**\n\n${listTxt}`,
        timestamp: nowTimeLabel(),
        buttons: btns,
      });
      return { messages, user };
    }

    if (cb.startsWith('adm:pay_add:')) {
      const methodLabel = cb.slice('adm:pay_add:'.length);
      user =
        botStore.updateUser(user.id, {
          step: 'admin_edit_payment_number',
          pendingContext: { paymentMethodLabel: methodLabel },
        }) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `➕ **নতুন ${methodLabel} পেমেন্ট নম্বর যোগ করুন**\n\n` +
          `আপনার নম্বর ও ধরন লিখে পাঠান:\n` +
          `উদাহরণ: \`017XXXXXXXX | Personal (Send Money)\`\n` +
          `অথবা শুধু নম্বর লিখুন: \`017XXXXXXXX\``,
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '❌ Cancel', callback_data: 'adm:pay_nums' }]],
      });
      return { messages, user };
    }

    if (cb.startsWith('adm:pay_tog:')) {
      const id = cb.slice('adm:pay_tog:'.length);
      const cfg = botStore.getConfig();
      const updated = (cfg.paymentAccounts ?? []).map((a) =>
        a.id === id ? { ...a, enabled: !a.enabled } : a,
      );
      botStore.updateConfig({ paymentAccounts: updated });
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: '✅ পেমেন্ট নম্বরের অবস্থা আপডেট হয়েছে।',
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '📲 Payment Numbers দেখুন', callback_data: 'adm:pay_nums' }]],
      });
      return { messages, user };
    }

    if (cb.startsWith('adm:pay_del:')) {
      const id = cb.slice('adm:pay_del:'.length);
      const cfg = botStore.getConfig();
      const updated = (cfg.paymentAccounts ?? []).filter((a) => a.id !== id);
      botStore.updateConfig({ paymentAccounts: updated });
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: '🗑️ পেমেন্ট নম্বরটি মুছে ফেলা হয়েছে।',
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '📲 Payment Numbers দেখুন', callback_data: 'adm:pay_nums' }]],
      });
      return { messages, user };
    }

    if (cb === 'adm:voice_costs') {
      const cfg = botStore.getConfig();
      const lines = VOICE_CATALOG.map((v) => {
        const hasCustom = typeof cfg.voiceCosts?.[v.id] === 'number';
        const effective = botStore.getVoiceEffectiveCost(v.id);
        return `• **${v.nameBn}** (${formatVoiceCategoryLabel(v.category)}): **${effective > 0 ? `৳${effective}` : 'ফ্রি (৳0)'}**${hasCustom ? ' [Custom]' : ' [Default]'}`;
      }).join('\n');

      const btns: InlineButton[][] = [];
      for (let i = 0; i < VOICE_CATALOG.length; i += 2) {
        const pair = VOICE_CATALOG.slice(i, i + 2).map((v) => ({
          text: `${v.nameBn} (৳${botStore.getVoiceEffectiveCost(v.id)})`,
          callback_data: `adm:vcost:${v.id}`,
        }));
        btns.push(pair);
      }
      btns.push([
        { text: `Default Cost (৳${cfg.voiceGenerationCost})`, callback_data: 'adm:cfg_edit:voiceGenerationCost' },
        { text: '🛡️ Admin Home', callback_data: 'adm:home' },
      ]);

      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `💲 **ভয়েস অনুযায়ী আলাদা চার্জ (Per-Voice Charges)**\n\n` +
          `• ডিফল্ট গ্লোবাল চার্জ: **৳${cfg.voiceGenerationCost}**\n\n${lines}\n\n` +
          `যেকোনো ভয়েসের আলাদা চার্জ বসাতে নিচের বাটনে ট্যাপ করুন:`,
        timestamp: nowTimeLabel(),
        buttons: btns,
      });
      return { messages, user };
    }

    if (cb.startsWith('adm:vcost:')) {
      const voiceId = cb.slice('adm:vcost:'.length);
      const voice = getVoiceById(voiceId);
      const cur = botStore.getVoiceEffectiveCost(voiceId);
      user =
        botStore.updateUser(user.id, {
          step: 'admin_edit_voice_cost',
          pendingContext: { voiceCostEditId: voiceId },
        }) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `💲 **${voice.nameBn} (${voice.roleBn}) — চার্জ নির্ধারণ**\n` +
          `বর্তমান চার্জ: **৳${cur}**\n\n` +
          `নতুন টাকার পরিমাণ লিখুন (যেমন \`10\`, ফ্রি করতে \`0\`, বা ডিফল্টে ফেরাতে \`default\` লিখুন):`,
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '❌ Cancel', callback_data: 'adm:voice_costs' }]],
      });
      return { messages, user };
    }

    if (cb.startsWith('adm:toggle:')) {
      const field = cb.slice('adm:toggle:'.length);
      const cfg = botStore.getConfig();
      const patch: Partial<BotConfig> = {};
      if (field === 'smartEnglishToBangla') {
        patch.smartEnglishToBangla = !cfg.smartEnglishToBangla;
      } else if (field === 'strictBanglaOnly') {
        patch.strictBanglaOnly = !cfg.strictBanglaOnly;
      } else if (field === 'autoNormalizeBangla') {
        patch.autoNormalizeBangla = !cfg.autoNormalizeBangla;
      } else if (field === 'ttsModel') {
        patch.ttsModel =
          cfg.ttsModel === 'gemini-3.8-flash-lite-tts'
            ? 'gemini-3.8-flash-tts'
            : 'gemini-3.8-flash-lite-tts';
      }
      botStore.updateConfig(patch);
      const nextCfg = botStore.getConfig();
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `✅ সেটিংস আপডেট হয়েছে!\n\n` +
          `• TTS Model: \`${nextCfg.ttsModel}\`\n` +
          `• Smart English → Bangla: **${nextCfg.smartEnglishToBangla ? 'ON' : 'OFF'}**\n` +
          `• Strict Bangla-Only: **${nextCfg.strictBanglaOnly ? 'ON' : 'OFF'}**\n` +
          `• Auto Normalize: **${nextCfg.autoNormalizeBangla ? 'ON' : 'OFF'}**`,
        timestamp: nowTimeLabel(),
        buttons: [
          [{ text: '⚙️ Back to System Settings', callback_data: 'adm:sys' }],
          [{ text: '🛡️ Admin Home', callback_data: 'adm:home' }],
        ],
      });
      return { messages, user };
    }
  }

  // -------------------------------------------------------------------------
  // 5. Handle Multi-Step Text Prompts (Payments, Long Script, Admin Inputs)
  // -------------------------------------------------------------------------
  if (text) {
    if (user.step === 'collecting_long_script') {
      const existingParts = user.pendingContext?.longScriptParts ?? [];
      const nextParts = [...existingParts, text];
      const totalChars = nextParts.join('\n\n').length;
      user =
        botStore.updateUser(user.id, {
          pendingContext: { longScriptParts: nextParts },
        }) ?? user;

      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `📝 অংশ #${nextParts.length} যুক্ত হয়েছে (মোট ${totalChars.toLocaleString()} অক্ষর)।\n` +
          `আরও অংশ পাঠাতে পারেন অথবা বাংলা প্রিভিউ দেখতে **“👁️ বাংলা প্রিভিউ দেখুন”** বাটনে চাপ দিন।`,
        timestamp: nowTimeLabel(),
        buttons: [
          [{ text: '👁️ বাংলা প্রিভিউ দেখুন', callback_data: 'long:submit' }],
          [{ text: '❌ বাতিল করুন', callback_data: 'menu:main' }],
        ],
      });
      return { messages, user };
    }

    if (user.step === 'awaiting_preview_edit') {
      return await showBanglaPreviewForScript({
        user,
        rawScript: user.pendingContext?.previewRawScript || text,
        editedBanglaCandidate: text,
      });
    }

    if (user.step === 'awaiting_payment_amount') {
      const amount = Number.parseFloat(text.replace(/[^\d.]/g, ''));
      if (Number.isNaN(amount) || amount <= 0) {
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: '⚠️ সঠিক টাকার পরিমাণ লিখুন (যেমন: 100 বা 500)।',
          timestamp: nowTimeLabel(),
        });
        return { messages, user };
      }
      const prevCtx = user.pendingContext ?? {};
      user =
        botStore.updateUser(user.id, {
          step: 'awaiting_payment_ref',
          pendingContext: {
            ...prevCtx,
            paymentAmount: amount,
          },
        }) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `💳 **ধাপ ৩/৪: Transaction ID (TrxID) ও সেন্ডার নম্বর**\n\n` +
          `• মাধ্যম: **${prevCtx.paymentMethod ?? 'Manual Transfer'}**` +
          (prevCtx.paymentAccountNumber ? ` (\`${prevCtx.paymentAccountNumber}\`)` : '') +
          `\n• পরিমাণ: **৳${amount}**\n\n` +
          `📌 **TrxID কোথায় পাবেন:** টাকা পাঠানোর পর bKash/Nagad SMS বা অ্যাপের Transaction History-তে \`8N7A6B5C\` এর মতো একটি **TrxID** কোড থাকে।\n` +
          `এবার আপনার যে নম্বর থেকে টাকা পাঠিয়েছেন এবং সেই **TrxID** লিখে পাঠান (যেমন: \`01711223344 TrxID 9X82AB12\`):`,
        timestamp: nowTimeLabel(),
        buttons: [[{ text: '❌ বাতিল', callback_data: 'menu:wallet' }]],
      });
      return { messages, user };
    }

    if (user.step === 'awaiting_payment_ref') {
      const prevCtx = user.pendingContext ?? {};
      const amount = prevCtx.paymentAmount ?? 100;
      const method = prevCtx.paymentMethod ?? 'Manual Transfer';
      const accNum = prevCtx.paymentAccountNumber;

      user =
        botStore.updateUser(user.id, {
          step: 'awaiting_payment_confirm',
          pendingContext: {
            ...prevCtx,
            paymentMethod: method,
            paymentAccountNumber: accNum,
            paymentAmount: amount,
            paymentRef: text,
          },
        }) ?? user;

      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `🔍 **ধাপ ৪/৪: পেমেন্ট কনফার্মেশন (Review & Confirm)**\n\n` +
          `রিকোয়েস্ট পাঠানোর আগে তথ্যগুলো যাচাই করে নিন:\n` +
          `• পেমেন্ট মাধ্যম: **${method}**\n` +
          (accNum ? `• প্রাপক নম্বর: \`${accNum}\`\n` : '') +
          `• টাকার পরিমাণ: **৳${amount}**\n` +
          `• Sender / TrxID: \`${text}\`\n\n` +
          `সব তথ্য সঠিক থাকলে নিচের **“✅ কনফার্ম ও রিকোয়েস্ট পাঠান”** বাটনে ক্লিক করুন:`,
        timestamp: nowTimeLabel(),
        buttons: [
          [{ text: '✅ কনফার্ম ও রিকোয়েস্ট পাঠান', callback_data: 'pay:confirm' }],
          [{ text: '🔄 পরিবর্তন করুন', callback_data: 'pay:start' }],
          [{ text: '❌ বাতিল করুন', callback_data: 'menu:wallet' }],
        ],
      });
      return { messages, user };
    }

    if (user.step === 'admin_search_user' && botStore.isAdmin(user)) {
      const found = botStore.findUserByTelegramIdOrUsername(text);
      user =
        botStore.updateUser(user.id, {
          step: 'idle',
          pendingContext: undefined,
        }) ?? user;
      if (!found) {
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `⚠️ "${text}" দিয়ে কোনো ইউজার পাওয়া যায়নি।`,
          timestamp: nowTimeLabel(),
          buttons: [[{ text: '🛡️ Admin Home', callback_data: 'adm:home' }]],
        });
        return { messages, user };
      }
      const profile = buildAdminUserProfileMessage(found);
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: profile.text,
        timestamp: nowTimeLabel(),
        buttons: profile.buttons,
      });
      return { messages, user };
    }

    if (user.step === 'admin_set_user_limit' && botStore.isAdmin(user)) {
      const targetId = user.pendingContext?.targetUserId;
      user =
        botStore.updateUser(user.id, {
          step: 'idle',
          pendingContext: undefined,
        }) ?? user;
      if (!targetId) return { messages, user };

      const nextLimit =
        text.toLowerCase() === 'default' ? null : Number.parseInt(text, 10);
      if (nextLimit !== null && (Number.isNaN(nextLimit) || nextLimit < 0)) {
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: '⚠️ সঠিক সংখ্যা দিন অথবা `default` লিখুন।',
          timestamp: nowTimeLabel(),
        });
        return { messages, user };
      }
      const updated = botStore.updateUser(targetId, {
        customDailyLimit: nextLimit,
      });
      if (updated) {
        const profile = buildAdminUserProfileMessage(updated);
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `✅ ইউজারের দৈনিক ভয়েস লিমিট আপডেট হয়েছে।\n\n${profile.text}`,
          timestamp: nowTimeLabel(),
          buttons: profile.buttons,
        });
      }
      return { messages, user };
    }

    if (user.step === 'admin_adjust_balance' && botStore.isAdmin(user)) {
      const targetId = user.pendingContext?.targetUserId;
      user =
        botStore.updateUser(user.id, {
          step: 'idle',
          pendingContext: undefined,
        }) ?? user;
      const delta = Number.parseFloat(text);
      if (!targetId || Number.isNaN(delta) || delta === 0) {
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: '⚠️ সঠিক টাকার পরিমাণ দিন (যেমন `+200` বা `-50`)।',
          timestamp: nowTimeLabel(),
        });
        return { messages, user };
      }
      const res = botStore.adjustBalance({
        userId: targetId,
        amountDelta: delta,
        type: delta >= 0 ? 'admin_add' : 'admin_deduct',
        description: `অ্যাডমিন কাস্টম সমন্বয় (${delta >= 0 ? '+' : ''}৳${delta})`,
      });
      const profile = buildAdminUserProfileMessage(res.user);
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: `✅ ব্যালেন্স আপডেট হয়েছে।\n\n${profile.text}`,
        timestamp: nowTimeLabel(),
        buttons: profile.buttons,
      });
      return { messages, user };
    }

    if (user.step === 'admin_edit_config' && botStore.isAdmin(user)) {
      const key = user.pendingContext?.configKey;
      user =
        botStore.updateUser(user.id, {
          step: 'idle',
          pendingContext: undefined,
        }) ?? user;
      if (key === 'notificationChannelId') {
        const normalized = normalizeTelegramChannelTarget(text);
        botStore.updateConfig({ notificationChannelId: normalized });
        if (!normalized) {
          messages.push({
            id: makeMsgId(),
            sender: 'bot',
            text: '✅ Notification Channel মুছে ফেলা হয়েছে। এখন থেকে অ্যালার্ট শুধু Admin DM-এ আসবে।',
            timestamp: nowTimeLabel(),
            buttons: [[{ text: '⚙️ System Settings', callback_data: 'adm:sys' }]],
          });
          return { messages, user };
        }
        const testRes = await sendTestChannelNotification(normalized);
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: testRes.ok
            ? `✅ Notification Channel সেট ও টেস্ট সফল হয়েছে: **${testRes.channelId}**\nএখন থেকে সব অডিও ও ভিডিও জেনারেশন অ্যালার্ট সরাসরি ওই চ্যানেলে যাবে!`
            : `⚠️ চ্যানেলটি (\`${normalized}\`) সেভ হয়েছে, কিন্তু টেস্ট মেসেজ যায়নি:\n${testRes.error}\n\n👉 অনুগ্রহ করে **@${botStore.getConfig().telegramBotUsername || 'এই বট'}**-কে ওই চ্যানেলে **Administrator** হিসেবে যুক্ত করুন।`,
          timestamp: nowTimeLabel(),
          buttons: [[{ text: '⚙️ System Settings', callback_data: 'adm:sys' }]],
        });
        return { messages, user };
      }

      const val = Number.parseFloat(text);
      if (!key || Number.isNaN(val) || val < 0) {
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: '⚠️ সঠিক ধনাত্মক সংখ্যা প্রদান করুন।',
          timestamp: nowTimeLabel(),
        });
        return { messages, user };
      }
      botStore.updateConfig({ [key]: val } as Partial<BotConfig>);
      const planMsg = buildPlanSettingsMessage();
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: `✅ সেটিংস আপডেট হয়েছে!\n\n${planMsg.text}`,
        timestamp: nowTimeLabel(),
        buttons: planMsg.buttons,
      });
      return { messages, user };
    }

    if (user.step === 'admin_edit_payment_number' && botStore.isAdmin(user)) {
      const methodLabel = user.pendingContext?.paymentMethodLabel || 'Payment';
      const [rawNum, rawType] = text.split('|').map((s) => s.trim());
      if (!rawNum) {
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: '⚠️ সঠিক পেমেন্ট নম্বর লিখুন (যেমন: `017XXXXXXXX | Personal`)।',
          timestamp: nowTimeLabel(),
        });
        return { messages, user };
      }

      const cfg = botStore.getConfig();
      const nextAccounts = [
        ...(cfg.paymentAccounts ?? []),
        {
          id: `payacc-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
          method: methodLabel,
          accountNumber: rawNum,
          accountType: rawType || 'Personal (Send Money)',
          enabled: true,
        },
      ];
      botStore.updateConfig({ paymentAccounts: nextAccounts });
      user =
        botStore.updateUser(user.id, {
          step: 'idle',
          pendingContext: undefined,
        }) ?? user;

      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: `✅ নতুন **${methodLabel}** পেমেন্ট নম্বর (\`${rawNum}\`) যুক্ত করা হয়েছে!`,
        timestamp: nowTimeLabel(),
        buttons: [
          [{ text: '📲 Payment Numbers দেখুন', callback_data: 'adm:pay_nums' }],
          [{ text: '🛡️ Admin Home', callback_data: 'adm:home' }],
        ],
      });
      return { messages, user };
    }

    if (user.step === 'admin_edit_voice_cost' && botStore.isAdmin(user)) {
      const voiceId = user.pendingContext?.voiceCostEditId;
      user =
        botStore.updateUser(user.id, {
          step: 'idle',
          pendingContext: undefined,
        }) ?? user;
      if (!voiceId) return { messages, user };

      const cfg = botStore.getConfig();
      const nextCosts = { ...(cfg.voiceCosts ?? {}) };
      if (text.toLowerCase() === 'default') {
        delete nextCosts[voiceId];
      } else {
        const val = Number.parseFloat(text.replace(/[^\d.]/g, ''));
        if (Number.isNaN(val) || val < 0) {
          messages.push({
            id: makeMsgId(),
            sender: 'bot',
            text: '⚠️ সঠিক টাকার পরিমাণ দিন (যেমন `10` বা `0`), অথবা `default` লিখুন।',
            timestamp: nowTimeLabel(),
            buttons: [[{ text: '💲 Back to Voice Charges', callback_data: 'adm:voice_costs' }]],
          });
          return { messages, user };
        }
        nextCosts[voiceId] = val;
      }

      botStore.updateConfig({ voiceCosts: nextCosts });
      const voice = getVoiceById(voiceId);
      const eff = botStore.getVoiceEffectiveCost(voiceId);
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: `✅ **${voice.nameBn}** ভয়েসের চার্জ এখন **${eff > 0 ? `৳${eff}` : 'ফ্রি (৳0)'}** সেট করা হয়েছে।`,
        timestamp: nowTimeLabel(),
        buttons: [
          [{ text: '💲 সব ভয়েসের চার্জ দেখুন', callback_data: 'adm:voice_costs' }],
          [{ text: '🛡️ Admin Home', callback_data: 'adm:home' }],
        ],
      });
      return { messages, user };
    }

    if (user.step === 'awaiting_video_prompt') {
      const draft = user.pendingContext?.videoDraft ?? defaultVideoDraft(user, 'prompt');
      const gen = await generateBanglaVideoScriptFromPrompt({
        prompt: text,
        templateId: draft.templateId,
      });
      const nextDraft: VideoDraftContext = {
        ...draft,
        prompt: text,
        title: gen.title,
        script: gen.banglaScript,
        musicMood: gen.musicMood,
      };
      user =
        botStore.updateUser(user.id, {
          step: 'idle',
          pendingContext: { ...user.pendingContext, videoDraft: nextDraft },
        }) ?? user;
      const cfgCard = buildVideoConfigCardMessage(user);
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: `✅ AI আপনার প্রম্পট থেকে বাংলা ভিডিও স্ক্রিপ্ট প্রস্তুত করেছে!\n\n${cfgCard.text}`,
        timestamp: nowTimeLabel(),
        buttons: cfgCard.buttons,
      });
      return { messages, user };
    }

    if (user.step === 'awaiting_video_script') {
      const draft = user.pendingContext?.videoDraft ?? defaultVideoDraft(user, 'script');
      const nextDraft: VideoDraftContext = {
        ...draft,
        script: text,
        title: text.slice(0, 44),
      };
      user =
        botStore.updateUser(user.id, {
          step: 'idle',
          pendingContext: { ...user.pendingContext, videoDraft: nextDraft },
        }) ?? user;
      const cfgCard = buildVideoConfigCardMessage(user);
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: cfgCard.text,
        timestamp: nowTimeLabel(),
        buttons: cfgCard.buttons,
      });
      return { messages, user };
    }

    if (user.step === 'awaiting_video_edit_script') {
      const draft = user.pendingContext?.videoDraft ?? defaultVideoDraft(user, 'edit_video');
      const nextDraft: VideoDraftContext = {
        ...draft,
        script: text,
        title: draft.title || text.slice(0, 44),
      };
      user =
        botStore.updateUser(user.id, {
          step: 'idle',
          pendingContext: { ...user.pendingContext, videoDraft: nextDraft },
        }) ?? user;
      const cfgCard = buildVideoConfigCardMessage(user);
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: `✅ ভিডিও এডিটিং-এর জন্য নতুন বাংলা ভয়েস স্ক্রিপ্ট যুক্ত হয়েছে!\n\n${cfgCard.text}`,
        timestamp: nowTimeLabel(),
        buttons: cfgCard.buttons,
      });
      return { messages, user };
    }

    if (user.step === 'awaiting_video_watermark') {
      const draft = user.pendingContext?.videoDraft;
      if (draft) {
        const nextDraft: VideoDraftContext = {
          ...draft,
          watermarkText: text.toLowerCase() === 'none' ? undefined : text.slice(0, 32),
        };
        user =
          botStore.updateUser(user.id, {
            step: 'idle',
            pendingContext: { ...user.pendingContext, videoDraft: nextDraft },
          }) ?? user;
        const cfgCard = buildVideoConfigCardMessage(user);
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: cfgCard.text,
          timestamp: nowTimeLabel(),
          buttons: cfgCard.buttons,
        });
        return { messages, user };
      }
    }

    // -----------------------------------------------------------------------
    // Command Hub Step-by-Step A-to-Z Flows (No Button Grids)
    // -----------------------------------------------------------------------
    if (user.step === 'cmd_hub_menu') {
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `⚠️ সঠিক কমান্ড নম্বর (\`1\`–\`${botStore.isAdmin(user) ? '8' : '7'}\`) অথবা কমান্ড (\`/videocmd\`, \`/dialogue\`, \`/voicebgm\`, \`/seo\`, \`/preset\`, \`/ref\`, \`/voices\`) লিখুন।\n` +
          `মেইন মেনুতে ফিরতে \`0\` বা \`/exit\` লিখুন।`,
        timestamp: nowTimeLabel(),
      });
      return { messages, user };
    }

    if (user.step === 'cmd_vid_prompt') {
      const prevDraft = user.pendingContext?.videoDraft ?? defaultVideoDraft(user, 'prompt');
      const nextDraft: VideoDraftContext = {
        ...prevDraft,
        prompt: text,
        title: text.slice(0, 48),
      };
      user =
        botStore.updateUser(user.id, {
          step: 'cmd_vid_format',
          pendingContext: { ...user.pendingContext, videoDraft: nextDraft },
        }) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `🎬 **ধাপ ২/৫ — ভিডিও ফরম্যাট ও কোয়ালিটি**\n` +
          `টপিক: “${text.slice(0, 80)}”\n\n` +
          `লিখুন: \`9:16 1080p\` (Reels/Shorts), \`16:9 1080p\` (YouTube), \`1:1 720p\`, বা \`16:9 4k\`।\n` +
          `অথবা ডিফল্ট/প্রিসেট রাখতে \`skip\` লিখুন (বর্তমান: **${nextDraft.aspectRatio} ${(nextDraft.resolution ?? '1080p').toUpperCase()}**)।`,
        timestamp: nowTimeLabel(),
      });
      return { messages, user };
    }

    if (user.step === 'cmd_vid_format') {
      const prevDraft = user.pendingContext?.videoDraft ?? defaultVideoDraft(user, 'prompt');
      let nextDraft = { ...prevDraft };
      if (/^preset$/i.test(text) && user.savedPreset) {
        nextDraft = {
          ...nextDraft,
          aspectRatio: user.savedPreset.aspectRatio ?? nextDraft.aspectRatio,
          resolution: user.savedPreset.resolution ?? nextDraft.resolution,
          voiceId: user.savedPreset.voiceId ?? nextDraft.voiceId,
          musicMood: user.savedPreset.musicMood ?? nextDraft.musicMood,
          watermarkText: user.savedPreset.watermarkText ?? nextDraft.watermarkText,
        };
      } else if (!/^skip$/i.test(text)) {
        const parsed = parseCommandFormatLine(text, {
          aspectRatio: prevDraft.aspectRatio ?? '9:16',
          resolution: prevDraft.resolution ?? '1080p',
        });
        nextDraft.aspectRatio = parsed.aspectRatio;
        nextDraft.resolution = parsed.resolution;
      }

      user =
        botStore.updateUser(user.id, {
          step: 'cmd_vid_voice_bgm',
          pendingContext: { ...user.pendingContext, videoDraft: nextDraft },
        }) ?? user;
      const curVoice = getVoiceById(nextDraft.voiceId ?? user.selectedVoiceId);
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `🎙️ **ধাপ ৩/৫ — ভয়েস ও ব্যাকগ্রাউন্ড মিউজিক**\n` +
          `ফরম্যাট সেট: **${nextDraft.aspectRatio} ${(nextDraft.resolution ?? '1080p').toUpperCase()}**\n\n` +
          `এক লাইনে ভয়েস ও মিউজিক মুড লিখুন (যেমন: \`আরিয়ান emotional\`, \`মেহেক emotional\`, \`আরিফ cinematic\`, \`অগি upbeat\`, \`ডোরেমন upbeat\`)\n` +
          `অথবা \`skip\` লিখুন (বর্তমান: **${curVoice.nameBn} + ${nextDraft.musicMood}**)।`,
        timestamp: nowTimeLabel(),
      });
      return { messages, user };
    }

    if (user.step === 'cmd_vid_voice_bgm') {
      const prevDraft = user.pendingContext?.videoDraft ?? defaultVideoDraft(user, 'prompt');
      const nextDraft = { ...prevDraft };
      if (!/^skip$/i.test(text)) {
        const parsed = parseVoiceAndBgmFromLine(
          text,
          prevDraft.voiceId ?? user.selectedVoiceId,
          prevDraft.musicMood ?? 'cinematic',
        );
        nextDraft.voiceId = parsed.voiceId;
        nextDraft.musicMood = parsed.musicMood;
      }
      user =
        botStore.updateUser(user.id, {
          step: 'cmd_vid_extra',
          pendingContext: { ...user.pendingContext, videoDraft: nextDraft },
        }) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `🏷️ **ধাপ ৪/৫ — ওয়াটারমার্ক ও সাবটাইটেল**\n\n` +
          `আপনার চ্যানেলের নাম/ওয়াটারমার্ক ও সাবটাইটেল অপশন লিখুন:\n` +
          `• উদাহরণ: \`@BelalStudio sub:on\` অথবা \`MyChannel sub:off\`\n` +
          `• ওয়াটারমার্ক ছাড়া রাখতে লিখুন: \`none\` বা \`skip\``,
        timestamp: nowTimeLabel(),
      });
      return { messages, user };
    }

    if (user.step === 'cmd_vid_extra') {
      const prevDraft = user.pendingContext?.videoDraft ?? defaultVideoDraft(user, 'prompt');
      const nextDraft = { ...prevDraft };
      if (!/^(?:skip|none)$/i.test(text)) {
        let cleaned = text;
        if (/sub\s*:\s*off/i.test(cleaned)) {
          nextDraft.includeSubtitles = false;
          cleaned = cleaned.replace(/sub\s*:\s*off/gi, '').trim();
        } else if (/sub\s*:\s*on/i.test(cleaned)) {
          nextDraft.includeSubtitles = true;
          cleaned = cleaned.replace(/sub\s*:\s*on/gi, '').trim();
        }
        if (cleaned) {
          nextDraft.watermarkText = cleaned.slice(0, 32);
        }
      } else if (/^none$/i.test(text)) {
        nextDraft.watermarkText = undefined;
      }

      user =
        botStore.updateUser(user.id, {
          step: 'cmd_vid_confirm',
          pendingContext: { ...user.pendingContext, videoDraft: nextDraft },
        }) ?? user;

      const v = getVoiceById(nextDraft.voiceId ?? user.selectedVoiceId);
      const cost = Math.max(0, botStore.getConfig().videoGenerationCost ?? 0);
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `✅ **ধাপ ৫/৫ — ফাইনাল রিভিউ (কমান্ডে নিশ্চিত করুন)**\n\n` +
          `• প্রম্পট: ${nextDraft.prompt || nextDraft.title}\n` +
          `• ফরম্যাট: **${nextDraft.aspectRatio} (${(nextDraft.resolution ?? '1080p').toUpperCase()})**\n` +
          `• ভয়েস: **${v.emoji} ${v.nameBn}**\n` +
          `• BGM মিউজিক: **${nextDraft.musicMood}**\n` +
          `• সাবটাইটেল: **${nextDraft.includeSubtitles !== false ? 'ON' : 'OFF'}**\n` +
          `• ওয়াটারমার্ক: **${nextDraft.watermarkText || 'নাই'}**\n` +
          `• চার্জ: **${cost > 0 ? `৳${cost}` : 'ফ্রি'}**\n\n` +
          `👉 ভিডিও + ভাইরাল SEO প্যাক তৈরি শুরু করতে লিখুন: \`start\`\n` +
          `(অথবা বাতিল করতে \`back\` / \`cancel\` লিখুন)`,
        timestamp: nowTimeLabel(),
      });
      return { messages, user };
    }

    if (user.step === 'cmd_vid_confirm') {
      if (!/^(?:start|go|confirm|run|render|শুরু)$/i.test(text)) {
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: '⚠️ ভিডিও তৈরি শুরু করতে `start` লিখুন, অথবা ফিরে যেতে `back` / `cancel` লিখুন।',
          timestamp: nowTimeLabel(),
        });
        return { messages, user };
      }

      const draft = user.pendingContext?.videoDraft ?? defaultVideoDraft(user, 'prompt');
      const promptInput = draft.prompt || draft.title || 'বাংলা AI ভিডিও';
      const gen = await generateBanglaVideoScriptFromPrompt({
        prompt: promptInput,
        templateId: draft.templateId,
      });

      const seoPack = await generateViralSeoPack(promptInput);

      const enqueued = await videoJobQueue.enqueueVideoJob({
        user,
        mode: 'prompt',
        title: gen.title || draft.title || promptInput.slice(0, 48),
        prompt: promptInput,
        script: gen.banglaScript,
        templateId: draft.templateId ?? 'viral_reels',
        aspectRatio: draft.aspectRatio ?? '9:16',
        resolution: draft.resolution ?? '1080p',
        videoSpeed: 1,
        voiceId: draft.voiceId ?? user.selectedVoiceId,
        voiceSpeed: user.speed || 1.0,
        voicePitch: user.pitch || 0,
        musicMood: draft.musicMood ?? gen.musicMood,
        originalAudioMode: 'mute',
        includeSubtitles: draft.includeSubtitles !== false,
        includeIntroOutro: true,
        watermarkText: draft.watermarkText,
        source: params.source,
        telegramChatId: params.telegramChatId,
      });

      user =
        botStore.updateUser(user.id, {
          step: 'cmd_hub_menu',
          pendingContext: undefined,
        }) ?? user;

      if (!enqueued.ok || !enqueued.job) {
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `⚠️ ${enqueued.error ?? 'ভিডিও তৈরি শুরু করা যায়নি।'}`,
          timestamp: nowTimeLabel(),
        });
        return { messages, user };
      }

      const vJob = enqueued.job;
      if (params.videoListenerFactory) {
        videoJobQueue.registerListener(
          vJob.id,
          params.videoListenerFactory(vJob.id),
        );
      }

      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        videoJobId: vJob.id,
        text:
          `🎬 **AI ভিডিও অটো-প্রসেসিং শুরু হয়েছে!**\n\n` +
          `• প্রজেক্ট: **${vJob.title}**\n` +
          `• ফরম্যাট: **${vJob.aspectRatio} (${vJob.resolution.toUpperCase()})**\n` +
          `• অগ্রগতি: [${formatProgressBar(vJob.progressPct)}] **${vJob.progressPct}%** — ${vJob.statusText}\n` +
          `• ⏱️ লাইভ টাইমার: **00:00** · আনুমানিক বাকি: ~${formatClockMMSS(vJob.estimatedRemainingSec ?? 25)}`,
        timestamp: nowTimeLabel(),
      });

      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `🔍 **আপনার এই ভিডিওর জন্য রেডি ভাইরাল SEO প্যাক:**\n\n` +
          `📌 **৩টি টাইটেল:**\n` +
          seoPack.titles.map((t, i) => `${i + 1}. ${t}`).join('\n') +
          `\n\n📝 **ডেসক্রিপশন:**\n${seoPack.description}\n\n` +
          `🏷️ **হ্যাশট্যাগ:**\n${seoPack.hashtags.join(' ')}\n\n` +
          `👉 পরবর্তী কমান্ডের জন্য \`1\`–\`7\` বা \`/hub\` লিখুন।`,
        timestamp: nowTimeLabel(),
      });

      return { messages, user, queuedVideoJob: vJob };
    }

    if (user.step === 'cmd_dlg_bgm') {
      const mood: VideoMusicMood = /^skip$/i.test(text)
        ? 'upbeat'
        : resolveMusicMoodFromToken(text);
      user =
        botStore.updateUser(user.id, {
          step: 'cmd_dlg_script',
          pendingContext: { ...user.pendingContext, dialogueBgmMood: mood },
        }) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `🎭 **মাল্টি-ভয়েস ডায়ালগ — ধাপ ২/৩ (সংলাপ লিখুন)**\n` +
          `মিউজিক মুড: **${mood}**\n\n` +
          `প্রতি লাইনে \`চরিত্রের নাম: সংলাপ\` ফরম্যাটে স্ক্রিপ্ট লিখে পাঠান।\n` +
          `উদাহরণ:\n` +
          `\`ডোরেমন: হ্যালো নোবিতা! আজকে স্কুলের পড়া করেছ?\n` +
          `নোবিতা: না ডোরেমন, আজকে একটু খেলা করি!\n` +
          `অগি: আরে তোমরা কী করছো?\``,
        timestamp: nowTimeLabel(),
      });
      return { messages, user };
    }

    if (user.step === 'cmd_dlg_script') {
      const parsedLines = parseMultiVoiceDialogue(text, user.selectedVoiceId);
      if (parsedLines.length === 0) {
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: '⚠️ কোনো বৈধ সংলাপ পাওয়া যায়নি। উদাহরণ অনুযায়ী `নাম: কথা` লিখে পাঠান।',
          timestamp: nowTimeLabel(),
        });
        return { messages, user };
      }

      user =
        botStore.updateUser(user.id, {
          step: 'cmd_dlg_confirm',
          pendingContext: { ...user.pendingContext, dialogueRawScript: text },
        }) ?? user;

      const breakdown = parsedLines
        .slice(0, 6)
        .map(
          (l, idx) =>
            `${idx + 1}. ${l.voice.emoji} **${l.voice.nameBn}** (${l.speakerLabel}): “${l.text.slice(0, 45)}${l.text.length > 45 ? '...' : ''}”`,
        )
        .join('\n');

      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `✅ **মাল্টি-ভয়েস ডায়ালগ — ধাপ ৩/৩ (কনফার্ম করুন)**\n\n` +
          `• মোট সংলাপ: **${parsedLines.length}টি** | BGM: **${user.pendingContext?.dialogueBgmMood ?? 'upbeat'}**\n` +
          `${breakdown}\n\n` +
          `👉 সব কণ্ঠস্বর একসাথে মিক্স করে MP3 তৈরি করতে \`go\` বা \`start\` লিখুন (বা \`back\` লিখুন):`,
        timestamp: nowTimeLabel(),
      });
      return { messages, user };
    }

    if (user.step === 'cmd_dlg_confirm') {
      if (!/^(?:go|start|confirm|run|শুরু)$/i.test(text)) {
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: '⚠️ ডায়ালগ MP3 তৈরি করতে `go` বা `start` লিখুন, অথবা বাতিল করতে `back` লিখুন।',
          timestamp: nowTimeLabel(),
        });
        return { messages, user };
      }

      const raw = user.pendingContext?.dialogueRawScript ?? '';
      const mood = user.pendingContext?.dialogueBgmMood ?? 'upbeat';
      const parsedLines = parseMultiVoiceDialogue(raw, user.selectedVoiceId);
      if (parsedLines.length === 0) {
        user = botStore.updateUser(user.id, { step: 'cmd_dlg_script' }) ?? user;
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: '⚠️ সংলাপ পাওয়া যায়নি, আবার লিখুন।',
          timestamp: nowTimeLabel(),
        });
        return { messages, user };
      }

      try {
        const { generation, filePath } = await synthesizeMultiVoiceDialogueMp3({
          user,
          lines: parsedLines,
          bgmMood: mood,
          source: params.source,
        });
        user =
          botStore.updateUser(user.id, {
            step: 'cmd_hub_menu',
            pendingContext: undefined,
          }) ?? user;

        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text:
            `🎭 **মাল্টি-ভয়েস ডায়ালগ MP3 প্রস্তুত!**\n` +
            `• কণ্ঠস্বর: ${generation.voiceNameBn}\n` +
            `• BGM মুড: **${mood}** | দৈর্ঘ্য: **${formatDurationHuman(generation.durationSec)}**\n\n` +
            `👉 নতুন কাজের জন্য \`1\`–\`7\` অথবা \`/hub\` লিখুন।`,
          timestamp: nowTimeLabel(),
          audio: {
            generationId: generation.id,
            url: generation.audioUrl,
            filePath,
            title: generation.voiceNameBn,
            performer: 'BanglaVoice Multi-Dialogue',
            durationSec: generation.durationSec,
            fileSizeBytes: generation.fileSizeBytes,
          },
        });
      } catch (err) {
        user =
          botStore.updateUser(user.id, {
            step: 'cmd_hub_menu',
            pendingContext: undefined,
          }) ?? user;
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `❌ ডায়ালগ তৈরি ব্যর্থ হয়েছে: ${err instanceof Error ? err.message : 'Error'}`,
          timestamp: nowTimeLabel(),
        });
      }
      return { messages, user };
    }

    if (user.step === 'cmd_vbgm_voice') {
      const parsed = parseVoiceAndBgmFromLine(
        text,
        user.selectedVoiceId,
        'emotional',
      );
      const voice = getVoiceById(parsed.voiceId);
      user =
        botStore.updateUser(user.id, {
          step: 'cmd_vbgm_speed',
          pendingContext: {
            ...user.pendingContext,
            voiceBgmVoiceId: parsed.voiceId,
            voiceBgmMood: parsed.musicMood,
          },
        }) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `🎚️ **ভয়েস + BGM — ধাপ ২/৩ (স্পিড ও পিচ)**\n` +
          `সিলেক্ট হয়েছে: **${voice.emoji} ${voice.nameBn}** + **${parsed.musicMood} BGM**\n\n` +
          `স্পিড ও পিচ লিখুন (যেমন: \`1.0 0\` বা \`0.9 -1\` বা \`1.1 +1\`),\n` +
          `অথবা স্বাভাবিক রাখতে \`skip\` লিখুন:`,
        timestamp: nowTimeLabel(),
      });
      return { messages, user };
    }

    if (user.step === 'cmd_vbgm_speed') {
      let speed = user.speed || 1.0;
      let pitch = user.pitch || 0;
      if (!/^skip$/i.test(text)) {
        const nums = text.match(/-?\d+(?:\.\d+)?/g) ?? [];
        if (nums[0]) {
          const s = Number.parseFloat(nums[0]);
          if (!Number.isNaN(s)) speed = Math.min(1.5, Math.max(0.6, Number(s.toFixed(2))));
        }
        if (nums[1]) {
          const p = Number.parseInt(nums[1], 10);
          if (!Number.isNaN(p)) pitch = Math.min(4, Math.max(-4, p));
        }
      }

      user =
        botStore.updateUser(user.id, {
          step: 'cmd_vbgm_script',
          pendingContext: {
            ...user.pendingContext,
            voiceBgmSpeed: speed,
            voiceBgmPitch: pitch,
          },
        }) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `✍️ **ভয়েস + BGM — ধাপ ৩/৩ (স্ক্রিপ্ট লিখুন)**\n` +
          `স্পিড: **${speed}x** | পিচ: **${pitch}**\n\n` +
          `এখন আপনার বাংলা/ইংরেজি স্ক্রিপ্ট লিখে পাঠান — সাথে সাথে ব্যাকগ্রাউন্ড মিউজিকসহ MP3 তৈরি হয়ে যাবে:`,
        timestamp: nowTimeLabel(),
      });
      return { messages, user };
    }

    if (user.step === 'cmd_vbgm_script') {
      const voiceId = user.pendingContext?.voiceBgmVoiceId ?? user.selectedVoiceId;
      const voice = getVoiceById(voiceId);
      const eligibility = botStore.canUserGenerate(user, voice.id);
      if (!eligibility.ok) {
        user =
          botStore.updateUser(user.id, {
            step: 'cmd_hub_menu',
            pendingContext: undefined,
          }) ?? user;
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `⚠️ ${eligibility.reason}`,
          timestamp: nowTimeLabel(),
        });
        return { messages, user };
      }

      const bgmMood = user.pendingContext?.voiceBgmMood ?? 'emotional';
      const speed = user.pendingContext?.voiceBgmSpeed ?? user.speed ?? 1.0;
      const pitch = user.pendingContext?.voiceBgmPitch ?? user.pitch ?? 0;

      try {
        const { generation, filePath } = await synthesizeVoiceWithBgmMp3({
          user,
          voice,
          script: text,
          bgmMood,
          speed,
          pitch,
          source: params.source,
        });
        user =
          botStore.updateUser(user.id, {
            step: 'cmd_hub_menu',
            pendingContext: undefined,
          }) ?? user;

        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text:
            `🎵 **ভয়েস + BGM MP3 প্রস্তুত!**\n` +
            `• কণ্ঠস্বর: **${voice.emoji} ${voice.nameBn}**\n` +
            `• মিউজিক: **${bgmMood}** | দৈর্ঘ্য: **${formatDurationHuman(generation.durationSec)}**\n\n` +
            `👉 নতুন কাজের জন্য \`1\`–\`7\` অথবা \`/hub\` লিখুন।`,
          timestamp: nowTimeLabel(),
          audio: {
            generationId: generation.id,
            url: generation.audioUrl,
            filePath,
            title: `${voice.nameBn} (${bgmMood} BGM)`,
            performer: 'BanglaVoice Studio',
            durationSec: generation.durationSec,
            fileSizeBytes: generation.fileSizeBytes,
          },
        });
      } catch (err) {
        user =
          botStore.updateUser(user.id, {
            step: 'cmd_hub_menu',
            pendingContext: undefined,
          }) ?? user;
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `❌ ভয়েস+BGM তৈরি ব্যর্থ হয়েছে: ${err instanceof Error ? err.message : 'Error'}`,
          timestamp: nowTimeLabel(),
        });
      }
      return { messages, user };
    }

    if (user.step === 'cmd_seo_topic') {
      const pack = await generateViralSeoPack(text);
      user =
        botStore.updateUser(user.id, {
          step: 'cmd_hub_menu',
          pendingContext: undefined,
        }) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `🔍 **ভাইরাল SEO প্যাক প্রস্তুত!**\n\n` +
          `📌 **৩টি হাই-CTR টাইটেল:**\n` +
          pack.titles.map((t, i) => `${i + 1}. ${t}`).join('\n') +
          `\n\n📝 **ভিডিও ডেসক্রিপশন:**\n${pack.description}\n\n` +
          `🏷️ **ভাইরাল হ্যাশট্যাগ:**\n${pack.hashtags.join(' ')}\n\n` +
          `👉 পরবর্তী কাজের জন্য \`1\`–\`7\` অথবা \`/hub\` লিখুন।`,
        timestamp: nowTimeLabel(),
      });
      return { messages, user };
    }

    if (user.step === 'cmd_preset_input') {
      const saved = parsePresetCommand(text, user.savedPreset);
      user =
        botStore.updateUser(user.id, {
          step: 'cmd_hub_menu',
          savedPreset: saved,
          pendingContext: undefined,
        }) ?? user;
      const vName = saved.voiceId
        ? getVoiceById(saved.voiceId).nameBn
        : getVoiceById(user.selectedVoiceId).nameBn;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `💾 **প্রিসেট সফলভাবে সেভ হয়েছে!**\n\n` +
          `• ভয়েস: **${vName}**\n` +
          `• ফরম্যাট: **${saved.aspectRatio} · ${(saved.resolution ?? '1080p').toUpperCase()}**\n` +
          `• BGM মুড: **${saved.musicMood}**\n` +
          `• স্পিড: **${saved.speed ?? 1.0}x**\n` +
          (saved.watermarkText ? `• ওয়াটারমার্ক: **${saved.watermarkText}**\n` : '') +
          `\n👉 পরবর্তী কাজের জন্য \`1\`–\`7\` অথবা \`/hub\` লিখুন।`,
        timestamp: nowTimeLabel(),
      });
      return { messages, user };
    }

    if (user.step === 'cmd_broadcast_msg') {
      if (!botStore.isAdmin(user)) {
        user = botStore.updateUser(user.id, { step: 'cmd_hub_menu' }) ?? user;
        return { messages, user };
      }
      const activeTgCount = botStore
        .listUsers()
        .filter((u) => u.status === 'active' && !u.telegramId.startsWith('sim_')).length;
      user =
        botStore.updateUser(user.id, {
          step: 'cmd_broadcast_confirm',
          pendingContext: { broadcastDraftText: text },
        }) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `📣 **ব্রডকাস্ট প্রিভিউ (টার্গেট: ${activeTgCount} জন সক্রিয় ইউজার)**\n\n` +
          `${text}\n\n` +
          `👉 পাঠাতে \`send\` লিখুন, অথবা বাতিল করতে \`back\` / \`cancel\` লিখুন:`,
        timestamp: nowTimeLabel(),
      });
      return { messages, user };
    }

    if (user.step === 'cmd_broadcast_confirm') {
      if (!botStore.isAdmin(user)) {
        user = botStore.updateUser(user.id, { step: 'cmd_hub_menu' }) ?? user;
        return { messages, user };
      }
      if (!/^(?:send|confirm|go|পাঠান)$/i.test(text)) {
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: '⚠️ ব্রডকাস্ট পাঠাতে `send` লিখুন, অথবা বাতিল করতে `back` / `cancel` লিখুন।',
          timestamp: nowTimeLabel(),
        });
        return { messages, user };
      }

      const broadcastText = user.pendingContext?.broadcastDraftText ?? '';
      user =
        botStore.updateUser(user.id, {
          step: 'cmd_hub_menu',
          pendingContext: undefined,
        }) ?? user;

      if (!broadcastText) {
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: '⚠️ ব্রডকাস্ট মেসেজ খালি ছিল।',
          timestamp: nowTimeLabel(),
        });
        return { messages, user };
      }

      const activeTgCount = botStore
        .listUsers()
        .filter(
          (u) =>
            u.status === 'active' &&
            !u.telegramId.startsWith('sim_') &&
            u.telegramId !== user.telegramId,
        ).length;

      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text:
          `🚀 **ব্রডকাস্ট পাঠানো শুরু হয়েছে!** (${activeTgCount} জন সক্রিয় টেলিগ্রাম ইউজারের কাছে)\n` +
          `👉 পরবর্তী কমান্ডের জন্য \`1\`–\`8\` বা \`/hub\` লিখুন।`,
        timestamp: nowTimeLabel(),
      });
      return {
        messages,
        user,
        pendingBroadcast: {
          text: broadcastText,
          excludeTelegramId: user.telegramId,
        },
      };
    }

    // -----------------------------------------------------------------------
    // All-in-One AI Assistant Multi-Step Text Flows & ChatGPT Mode Fallback
    // -----------------------------------------------------------------------
    if (user.step === 'awaiting_video_i2v_prompt') {
      const draft = user.pendingContext?.videoDraft ?? defaultVideoDraft(user, 'image_to_video');
      const gen = await generateBanglaVideoScriptFromPrompt({
        prompt: text,
        templateId: draft.templateId,
      });
      const nextDraft: VideoDraftContext = {
        ...draft,
        mode: 'image_to_video',
        prompt: text,
        title: gen.title,
        script: gen.banglaScript,
        musicMood: gen.musicMood,
      };
      user =
        botStore.updateUser(user.id, {
          step: 'idle',
          pendingContext: { ...user.pendingContext, videoDraft: nextDraft },
        }) ?? user;
      const cfgCard = buildVideoConfigCardMessage(user);
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: `🖼️➡️🎬 আপনার ছবি ও প্রম্পট অনুযায়ী ভিডিও প্রস্তুত! নিচের সেটিংস দেখে Render চাপুন:\n\n${cfgCard.text}`,
        timestamp: nowTimeLabel(),
        buttons: cfgCard.buttons,
      });
      return { messages, user };
    }

    if (user.step === 'img_t2i') {
      const ratio = user.pendingContext?.imageAspectRatio ?? '1:1';
      try {
        user =
          botStore.updateUser(user.id, {
            step: 'assistant_chat',
            pendingContext: { lastRetryAction: { kind: 'image', prompt: text, extra: ratio } },
          }) ?? user;
        const img = await generateAiImage({ user, prompt: text, aspectRatio: ratio });
        user =
          botStore.updateUser(user.id, {
            lastUpload: {
              type: 'photo',
              filePath: img.filePath,
              filename: img.filename,
              mimeType: 'image/png',
              uploadedAt: new Date().toISOString(),
            },
          }) ?? user;
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `${img.caption}\n⚙️ ${img.engineLabel}`,
          timestamp: nowTimeLabel(),
          photo: { url: img.url, filePath: img.filePath, caption: img.caption },
          buttons: [
            [
              { text: '🔄 Retry', callback_data: 'act:retry' },
              { text: '📐 2x HD Upscale', callback_data: 'img:quick_upscale' },
            ],
            [
              { text: '✨ Enhance', callback_data: 'img:quick_enhance' },
              { text: '🎬 Image → Video', callback_data: 'img:quick_i2v' },
            ],
            [{ text: '🎨 Image Studio', callback_data: 'menu:image' }],
          ],
        });
      } catch (err) {
        botStore.logError('image:t2i', err, user.id);
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `❌ ছবি তৈরি করা যায়নি: ${err instanceof Error ? err.message : 'Error'}`,
          timestamp: nowTimeLabel(),
          buttons: [[{ text: '🔄 Retry', callback_data: 'act:retry' }, { text: '🎨 Image Studio', callback_data: 'menu:image' }]],
        });
      }
      return { messages, user };
    }

    if (user.step === 'img_design_prompt') {
      const kind = user.pendingContext?.imageDesignKind ?? 'logo';
      try {
        const img = await generateGraphicDesignPng({ user, designKind: kind, prompt: text });
        user =
          botStore.updateUser(user.id, {
            step: 'assistant_chat',
            lastUpload: {
              type: 'photo',
              filePath: img.filePath,
              filename: img.filename,
              mimeType: 'image/png',
              uploadedAt: new Date().toISOString(),
            },
          }) ?? user;
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `${img.caption}\n⚙️ ${img.engineLabel}`,
          timestamp: nowTimeLabel(),
          photo: { url: img.url, filePath: img.filePath, caption: img.caption },
          buttons: [
            [
              { text: '🖌️ আরেকটি ডিজাইন', callback_data: `img:design:${kind}` },
              { text: '📐 2x Upscale', callback_data: 'img:quick_upscale' },
            ],
            [{ text: '🏠 মেইন মেনু', callback_data: 'menu:main' }],
          ],
        });
      } catch (err) {
        botStore.logError('image:design', err, user.id);
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `❌ ডিজাইন তৈরি ব্যর্থ: ${err instanceof Error ? err.message : 'Error'}`,
          timestamp: nowTimeLabel(),
        });
      }
      return { messages, user };
    }

    if (user.step === 'img_ref_prompt') {
      const up = user.lastUpload;
      if (!up || up.type !== 'photo' || !fs.existsSync(up.filePath)) {
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: '⚠️ প্রথমে একটি Reference Photo আপলোড করুন!',
          timestamp: nowTimeLabel(),
          buttons: [[{ text: '❌ বাতিল', callback_data: 'act:cancel' }]],
        });
        return { messages, user };
      }
      try {
        const img = await redesignFromReferenceImage({
          user,
          referenceImagePath: up.filePath,
          referenceMimeType: up.mimeType,
          instruction: text,
        });
        user =
          botStore.updateUser(user.id, {
            step: 'assistant_chat',
            lastUpload: {
              type: 'photo',
              filePath: img.filePath,
              filename: img.filename,
              mimeType: 'image/png',
              uploadedAt: new Date().toISOString(),
            },
          }) ?? user;
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `🎭 Reference অনুসারে নতুন ডিজাইন প্রস্তুত!\n${img.caption}`,
          timestamp: nowTimeLabel(),
          photo: { url: img.url, filePath: img.filePath, caption: img.caption },
          buttons: [[{ text: '🎨 Image Studio', callback_data: 'menu:image' }]],
        });
      } catch (err) {
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `❌ Reference ডিজাইন ব্যর্থ: ${err instanceof Error ? err.message : 'Error'}`,
          timestamp: nowTimeLabel(),
        });
      }
      return { messages, user };
    }

    if (user.step === 'voice_translate_wait' && user.pendingContext?.configKey === 'tts_en') {
      try {
        const out = await synthesizeMultilingualSpeechMp3({
          text,
          lang: 'en',
          gender: 'female',
        });
        user = botStore.updateUser(user.id, { step: 'assistant_chat', pendingContext: undefined }) ?? user;
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `🇬🇧 **English AI Voice Ready!** (${out.durationSec}s)`,
          timestamp: nowTimeLabel(),
          audio: {
            generationId: `en-${Date.now()}`,
            url: out.url,
            filePath: out.filePath,
            title: 'English Studio Voice',
            performer: 'BanglaVoice AI Studio',
            durationSec: out.durationSec,
            fileSizeBytes: out.fileSizeBytes,
          },
          buttons: [[{ text: '🎙️ Voice Studio', callback_data: 'menu:voice_studio' }]],
        });
      } catch (err) {
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `❌ English TTS ব্যর্থ: ${err instanceof Error ? err.message : 'Error'}`,
          timestamp: nowTimeLabel(),
        });
      }
      return { messages, user };
    }

    if (user.step === 'doc_create_prompt') {
      const fmt = user.pendingContext?.docCreateFormat ?? 'docx';
      try {
        const doc = await generateStructuredDocument({
          user,
          format: fmt,
          topicPrompt: text,
        });
        user =
          botStore.updateUser(user.id, {
            step: 'assistant_chat',
            pendingContext: undefined,
          }) ?? user;
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `✅ **${doc.title} (.${fmt.toUpperCase()}) তৈরি সম্পন্ন!**\n\n${doc.previewSummary}`,
          timestamp: nowTimeLabel(),
          document: {
            url: doc.url,
            filePath: doc.filePath,
            filename: doc.filename,
            mimeType: doc.mimeType,
            fileSizeBytes: doc.fileSizeBytes,
          },
          buttons: [[{ text: '📄 আরেকটি ডকুমেন্ট', callback_data: 'menu:docs' }, { text: '🏠 মেইন মেনু', callback_data: 'menu:main' }]],
        });
      } catch (err) {
        botStore.logError('documents:create', err, user.id);
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `❌ ডকুমেন্ট তৈরি ব্যর্থ: ${err instanceof Error ? err.message : 'Error'}`,
          timestamp: nowTimeLabel(),
        });
      }
      return { messages, user };
    }

    if (user.step === 'doc_qa') {
      const up = user.lastUpload;
      if (!up || up.type !== 'document' || !fs.existsSync(up.filePath)) {
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: '⚠️ কোনো সক্রিয় ডকুমেন্ট পাওয়া যায়নি। প্রথমে একটি PDF/Word/Excel/Text ফাইল পাঠান।',
          timestamp: nowTimeLabel(),
        });
        return { messages, user };
      }
      try {
        const answer = await analyzeUploadedDocument({
          user,
          filePath: up.filePath,
          filename: up.filename,
          taskPrompt: text,
        });
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `📄 **${up.filename} — উত্তর:**\n\n${answer.slice(0, 3800)}`,
          timestamp: nowTimeLabel(),
          buttons: [
            [
              { text: '❓ আরেকটি প্রশ্ন করুন', callback_data: 'doc:action:qa' },
              { text: '📄 Document Menu', callback_data: 'menu:docs' },
            ],
          ],
        });
      } catch (err) {
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `❌ ডকুমেন্ট বিশ্লেষণ ব্যর্থ: ${err instanceof Error ? err.message : 'Error'}`,
          timestamp: nowTimeLabel(),
        });
      }
      return { messages, user };
    }

    if (user.step === 'code_chat' || user.step === 'code_debug' || user.step === 'code_project') {
      const mode =
        user.step === 'code_debug'
          ? 'debug'
          : user.step === 'code_project'
            ? 'project'
            : 'write';
      try {
        user =
          botStore.updateUser(user.id, {
            pendingContext: { lastRetryAction: { kind: 'coding', prompt: text, extra: mode } },
          }) ?? user;
        const out = await runCodingAssistant({ user, prompt: text, mode });
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: out.explanationAndCode.slice(0, 3800),
          timestamp: nowTimeLabel(),
          document: out.generatedFile,
          buttons: [
            [
              { text: '🔄 Retry', callback_data: 'act:retry' },
              { text: '💻 Coding Menu', callback_data: 'menu:coding' },
            ],
            [{ text: '🏠 মেইন মেনু', callback_data: 'menu:main' }],
          ],
        });
      } catch (err) {
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `❌ কোডিং অ্যাসিস্ট্যান্ট এরর: ${err instanceof Error ? err.message : 'Error'}`,
          timestamp: nowTimeLabel(),
          buttons: [[{ text: '🔄 Retry', callback_data: 'act:retry' }]],
        });
      }
      return { messages, user };
    }

    if (user.step === 'research_query' || user.step === 'research_url') {
      const deep = user.pendingContext?.configKey === 'deep';
      try {
        user =
          botStore.updateUser(user.id, {
            step: 'assistant_chat',
            pendingContext: {
              lastRetryAction: { kind: 'research', prompt: text, extra: deep ? 'deep' : 'std' },
            },
          }) ?? user;
        const res = await runWebResearch({ user, queryOrUrl: text, deepReport: deep });
        const srcBlock =
          res.sources.length > 0
            ? `\n\n🔗 **Verified Sources:**\n${res.sources.map((s, i) => `${i + 1}. ${s.title}\n   ${s.url}`).join('\n')}`
            : '';
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `🌐 **Web Research Report**\n\n${res.reportText.slice(0, 3100)}${srcBlock}`,
          timestamp: nowTimeLabel(),
          buttons: [
            [
              { text: '🔄 Retry', callback_data: 'act:retry' },
              { text: '🌐 নতুন রিসার্চ', callback_data: 'menu:research' },
            ],
            [{ text: '🏠 মেইন মেনু', callback_data: 'menu:main' }],
          ],
        });
      } catch (err) {
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `❌ ওয়েব রিসার্চ ব্যর্থ: ${err instanceof Error ? err.message : 'Error'}`,
          timestamp: nowTimeLabel(),
          buttons: [[{ text: '🔄 Retry', callback_data: 'act:retry' }]],
        });
      }
      return { messages, user };
    }

    if (user.step === 'memory_add') {
      user = botStore.upsertUserMemory(user.id, 'Note', text) ?? user;
      user = botStore.updateUser(user.id, { step: 'assistant_chat' }) ?? user;
      messages.push({
        id: makeMsgId(),
        sender: 'bot',
        text: `🧠 **মেমোরি সেভ হয়েছে:**\n“${text}”`,
        timestamp: nowTimeLabel(),
        buttons: [
          [
            { text: '🧠 সব মেমোরি', callback_data: 'menu:memory' },
            { text: '🏠 মেইন মেনু', callback_data: 'menu:main' },
          ],
        ],
      });
      return { messages, user };
    }

    // ChatGPT Natural AI Chat Mode (default conversational experience)
    if (
      (user.step === 'assistant_chat' || user.step === 'idle') &&
      botStore.isFeatureEnabled('chat')
    ) {
      try {
        user =
          botStore.updateUser(user.id, {
            step: 'assistant_chat',
            pendingContext: { lastRetryAction: { kind: 'chat', prompt: text } },
          }) ?? user;
        const res = await runAssistantChat({ user, message: text });
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text:
            res.replyText.slice(0, 3600) +
            (res.rememberedNote ? `\n\n🧠 _মেমোরি সেভ: ${res.rememberedNote}_` : '') +
            (res.sources.length > 0
              ? `\n\n🔗 **উৎস:**\n${res.sources.map((s, i) => `${i + 1}. ${s.title} — ${s.url}`).join('\n')}`
              : ''),
          timestamp: nowTimeLabel(),
          buttons: [
            [
              { text: '🔄 Retry', callback_data: 'act:retry' },
              { text: '🔊 ভয়েস বানান', callback_data: 'chat:tts_last' },
              { text: '🧹 নতুন চ্যাট', callback_data: 'chat:clear' },
            ],
            [
              { text: '🎨 ইমেজ স্টুডিও', callback_data: 'menu:image' },
              { text: '🎙️ বাংলা ভয়েস TTS', callback_data: 'menu:create' },
              { text: '🏠 মেনু', callback_data: 'menu:main' },
            ],
          ],
        });
      } catch (err) {
        botStore.logError('chat', err, user.id);
        messages.push({
          id: makeMsgId(),
          sender: 'bot',
          text: `❌ AI উত্তর তৈরি ব্যর্থ: ${err instanceof Error ? err.message : 'Error'}`,
          timestamp: nowTimeLabel(),
          buttons: [[{ text: '🔄 Retry', callback_data: 'act:retry' }, { text: '🏠 মেনু', callback_data: 'menu:main' }]],
        });
      }
      return { messages, user };
    }

    // Multilingual Script -> Convert to Natural Bangla & Show Editable Preview (Voice TTS Mode)
    return await showBanglaPreviewForScript({
      user,
      rawScript: text,
    });
  }

  return { messages, user };
}

function formatDetectedLangLabel(lang: DetectedScriptLanguage): string {
  if (lang === 'english') return 'ইংরেজি → বাংলায় রূপান্তরিত';
  if (lang === 'mixed') return 'বাংলা + ইংরেজি মিশ্রিত → বাংলায় রূপান্তরিত';
  return 'বাংলা';
}

async function showBanglaPreviewForScript(params: {
  user: BotUser;
  rawScript: string;
  editedBanglaCandidate?: string;
}): Promise<BotActionOutput> {
  let user = params.user;
  const cfg = botStore.getConfig();
  const inputForPrep = (params.editedBanglaCandidate ?? params.rawScript).trim();

  const eligibility = botStore.canUserGenerate(user, user.selectedVoiceId);
  if (!eligibility.ok) {
    return {
      user,
      messages: [
        {
          id: makeMsgId(),
          sender: 'bot',
          text: `⚠️ ${eligibility.reason}`,
          timestamp: nowTimeLabel(),
          buttons: [
            [{ text: '➕ ব্যালেন্স রিচার্জ করুন', callback_data: 'pay:start' }],
            ...mainMenuButtons(botStore.isAdmin(user)),
          ],
        },
      ],
    };
  }

  const maxChars = botStore.getUserMaxChars(user);
  if (maxChars > 0 && inputForPrep.length > maxChars) {
    return {
      user,
      messages: [
        {
          id: makeMsgId(),
          sender: 'bot',
          text: `⚠️ আপনার স্ক্রিপ্টটি ${inputForPrep.length} অক্ষরের, যা আপনার প্ল্যানের সর্বোচ্চ সীমা (${maxChars} অক্ষর) অতিক্রম করেছে।`,
          timestamp: nowTimeLabel(),
          buttons: mainMenuButtons(botStore.isAdmin(user)),
        },
      ],
    };
  }

  const prep = await prepareBanglaScript(
    inputForPrep,
    cfg.strictBanglaOnly,
    params.editedBanglaCandidate ? false : cfg.autoNormalizeBangla,
    cfg.smartEnglishToBangla,
  );

  if (!prep.valid || !prep.spokenScript.trim()) {
    return {
      user,
      messages: [
        {
          id: makeMsgId(),
          sender: 'bot',
          text: `⚠️ ${prep.reason ?? 'অনুগ্রহ করে বাংলা বা ইংরেজিতে একটি বৈধ স্ক্রিপ্ট পাঠান।'}`,
          timestamp: nowTimeLabel(),
          buttons: mainMenuButtons(botStore.isAdmin(user)),
        },
      ],
    };
  }

  const banglaText = prep.spokenScript.trim();
  const chunks = chunkBanglaScript(banglaText, 650);
  const estimatedMinutes = Math.max(
    0.2,
    Math.round((banglaText.length / 800) * 10) / 10,
  );
  const voice = getVoiceById(user.selectedVoiceId);
  const voiceCost = botStore.getVoiceEffectiveCost(voice.id);

  user =
    botStore.updateUser(user.id, {
      step: 'awaiting_preview_confirm',
      pendingContext: {
        previewRawScript: params.rawScript.trim(),
        previewBanglaScript: banglaText,
        previewDetectedLang: prep.detectedLanguage,
      },
    }) ?? user;

  const displayLimit = 2800;
  const previewBody =
    banglaText.length > displayLimit
      ? `${banglaText.slice(0, displayLimit)}\n\n...(মোট ${banglaText.length.toLocaleString()} অক্ষর — সম্পূর্ণ বাংলা স্ক্রিপ্ট থেকে ভয়েস তৈরি হবে)`
      : banglaText;

  return {
    user,
    messages: [
      {
        id: makeMsgId(),
        sender: 'bot',
        text:
          `👁️ **Preview Before Generate (বাংলা স্ক্রিপ্ট প্রিভিউ)**\n\n` +
          `• শনাক্তকৃত ভাষা: **${formatDetectedLangLabel(prep.detectedLanguage)}**\n` +
          `• কণ্ঠস্বর: **${voice.nameBn}** | চার্জ: **${voiceCost > 0 ? `৳${voiceCost}` : 'ফ্রি'}** | স্পিড: **${user.speed}x** | পিচ: **${formatPitchLabel(user.pitch)}**\n` +
          `• বাংলা দৈর্ঘ্য: **${banglaText.length.toLocaleString()} অক্ষর** (${chunks.length} অংশ · ~${estimatedMinutes} মিনিট)\n\n` +
          `**চূড়ান্ত বাংলা স্ক্রিপ্ট:**\n${previewBody}\n\n` +
          `প্রিভিউ ঠিক থাকলে **“✅ ভয়েস জেনারেট করুন”** চাপুন, অথবা পরিবর্তন করতে **“✏️ বাংলা স্ক্রিপ্ট এডিট করুন”** বেছে নিন:`,
        timestamp: nowTimeLabel(),
        buttons: [
          [{ text: '✅ ভয়েস জেনারেট করুন', callback_data: 'preview:confirm' }],
          [
            { text: '✏️ বাংলা স্ক্রিপ্ট এডিট করুন', callback_data: 'preview:edit' },
            { text: '🔄 পুনরায় বাংলা অনুবাদ', callback_data: 'preview:reconvert' },
          ],
          [{ text: '❌ বাতিল করুন', callback_data: 'menu:main' }],
        ],
      },
    ],
  };
}

async function enqueueFromBot(params: {
  user: BotUser;
  script: string;
  originalScript?: string;
  preConvertedBangla?: boolean;
  source: 'telegram' | 'simulator';
  telegramChatId?: number;
  enqueueListenerFactory?: (jobId: string) => JobLifecycleListener;
}): Promise<BotActionOutput> {
  const { user, script, source } = params;
  const result = await voiceJobQueue.enqueueVoiceJob({
    user,
    script,
    originalScript: params.originalScript,
    preConvertedBangla: params.preConvertedBangla,
    source,
    telegramChatId: params.telegramChatId,
  });

  if (!result.ok || !result.job) {
    return {
      user,
      messages: [
        {
          id: makeMsgId(),
          sender: 'bot',
          text: `⚠️ ${result.error ?? 'ভয়েস তৈরি করা সম্ভব হয়নি।'}`,
          timestamp: nowTimeLabel(),
          buttons: [
            [{ text: '➕ ব্যালেন্স রিচার্জ করুন', callback_data: 'pay:start' }],
            [{ text: '🎤 ভয়েস পরিবর্তন করুন', callback_data: 'menu:create' }],
          ],
        },
      ],
    };
  }

  const job = result.job;
  if (params.enqueueListenerFactory) {
    voiceJobQueue.registerListener(
      job.id,
      params.enqueueListenerFactory(job.id),
    );
  }

  const estimatedMinutes = Math.max(
    1,
    Math.round((script.length / 800) * 10) / 10,
  );

  return {
    user,
    queuedJob: job,
    messages: [
      {
        id: makeMsgId(),
        sender: 'bot',
        jobId: job.id,
        text:
          `📥 **ভয়েস অটো-প্রসেসিং শুরু হয়েছে!** (${script.length.toLocaleString()} অক্ষর · ${job.totalParts} অংশ)\n` +
          `🎙️ কণ্ঠস্বর: **${job.voiceNameBn}** | স্পিড: **${job.speed}x**\n` +
          `📊 অগ্রগতি: [${formatProgressBar(job.progressPct ?? 5)}] **${job.progressPct ?? 5}%**\n` +
          `⏱️ লাইভ টাইমার: **00:00** · প্রসেস আনুমানিক: ~${formatClockMMSS(job.estimatedRemainingSec ?? 8)} (অডিও ~${estimatedMinutes} মি.)\n\n` +
          `অবস্থা: **${job.statusText}**`,
        timestamp: nowTimeLabel(),
      },
    ],
  };
}

// ---------------------------------------------------------------------------
// Live Telegram Bot API Connector (Polling + Webhook + Live Status + .txt Upload)
// ---------------------------------------------------------------------------

class TelegramConnector {
  private pollingActive = false;
  private offset = 0;
  private pollAbort: AbortController | null = null;

  private async tgFetch<T = unknown>(
    token: string,
    method: string,
    body?: unknown,
  ): Promise<{ ok: boolean; result?: T; description?: string }> {
    const res = await fetch(`https://api.telegram.org/bot${token}/${method}`, {
      method: body ? 'POST' : 'GET',
      headers: body ? { 'Content-Type': 'application/json' } : undefined,
      body: body ? JSON.stringify(body) : undefined,
    });
    return (await res.json()) as {
      ok: boolean;
      result?: T;
      description?: string;
    };
  }

  async verifyToken(token: string) {
    const data = await this.tgFetch<{
      id: number;
      username: string;
      first_name: string;
    }>(token, 'getMe');
    if (!data.ok || !data.result) {
      throw new Error(data.description || 'Invalid Telegram Bot Token');
    }
    return data.result;
  }

  private async downloadTelegramDocumentText(
    token: string,
    fileId: string,
  ): Promise<string> {
    const fileInfo = await this.tgFetch<{ file_path: string }>(
      token,
      'getFile',
      { file_id: fileId },
    );
    if (!fileInfo.ok || !fileInfo.result?.file_path) {
      throw new Error('ফাইলটি টেলিগ্রাম থেকে ডাউনলোড করা যায়নি।');
    }
    const res = await fetch(
      `https://api.telegram.org/file/bot${token}/${fileInfo.result.file_path}`,
    );
    if (!res.ok) {
      throw new Error('ফাইল পড়তে ব্যর্থ হয়েছে।');
    }
    return await res.text();
  }

  private async downloadTelegramBinaryFile(
    token: string,
    fileId: string,
    fallbackExt: string,
  ): Promise<{ filePath: string; filename: string }> {
    const fileInfo = await this.tgFetch<{ file_path: string }>(
      token,
      'getFile',
      { file_id: fileId },
    );
    if (!fileInfo.ok || !fileInfo.result?.file_path) {
      throw new Error('মিডিয়া ফাইলটি টেলিগ্রাম থেকে ডাউনলোড করা যায়নি (২০MB সীমা)।');
    }
    const res = await fetch(
      `https://api.telegram.org/file/bot${token}/${fileInfo.result.file_path}`,
    );
    if (!res.ok) {
      throw new Error('মিডিয়া ফাইল ডাউনলোড ব্যর্থ হয়েছে।');
    }
    const buf = Buffer.from(await res.arrayBuffer());
    const ext = path.extname(fileInfo.result.file_path) || fallbackExt;
    const safeName = `tg_${Date.now()}_${Math.random().toString(36).slice(2, 6)}${ext}`;
    const destPath = botStore.getUploadFilePath(safeName);
    fs.writeFileSync(destPath, buf);
    return { filePath: destPath, filename: safeName };
  }

  createTelegramVideoJobListener(
    token: string,
    chatId: number,
    statusMessageId: number,
  ): VideoJobLifecycleListener {
    let lastStatusSent = '';
    let lastEditMs = 0;
    let lastChatActionMs = 0;
    let pulseTick = 0;
    const pulseIcons = ['⏳', '⚡', '🔄', '🎬'];

    return {
      onStatus: async (job: VideoProjectJob) => {
        const now = Date.now();
        if (now - lastChatActionMs >= 4500) {
          lastChatActionMs = now;
          this.tgFetch(token, 'sendChatAction', {
            chat_id: chatId,
            action: job.status === 'rendering' ? 'upload_video' : 'typing',
          }).catch(() => {});
        }

        const key = `${job.progressPct}:${job.statusText}:${job.elapsedSec ?? 0}:${job.estimatedRemainingSec ?? 0}`;
        if (key === lastStatusSent) return;
        const stageChanged = !lastStatusSent.includes(`:${job.statusText}:`);
        if (!stageChanged && now - lastEditMs < 2000) return;

        lastStatusSent = key;
        lastEditMs = now;
        pulseTick += 1;
        const pulse = pulseIcons[pulseTick % pulseIcons.length];
        const progressBar = formatProgressBar(job.progressPct);
        const statusMsg =
          `${pulse} LIVE অটো-প্রসেসিং চলছে...\n` +
          `প্রজেক্ট: ${job.title}\n` +
          `অগ্রগতি: [${progressBar}] ${job.progressPct}% (ধাপ ${job.currentStep}/${job.totalSteps})\n` +
          `অবস্থা: ${job.statusText}\n` +
          `${formatEtaLine(job.elapsedSec, job.estimatedRemainingSec)}`;

        await this.tgFetch(token, 'editMessageText', {
          chat_id: chatId,
          message_id: statusMessageId,
          text: statusMsg,
        }).catch(() => {});
      },
      onComplete: async (job: VideoProjectJob) => {
        const durLabel = job.durationSec ? formatDurationHuman(job.durationSec) : '';
        const tookLabel = formatDurationHuman(job.elapsedSec ?? 0);
        await this.tgFetch(token, 'editMessageText', {
          chat_id: chatId,
          message_id: statusMessageId,
          text:
            `✅ AI ভিডিও সম্পন্ন হয়েছে!\n` +
            `প্রজেক্ট: ${job.title}\n` +
            `ফরম্যাট: ${job.aspectRatio} (${job.resolution.toUpperCase()}) · দৈর্ঘ্য: ${durLabel}\n` +
            `⏱️ মোট সময় লেগেছে: ${tookLabel}`,
        }).catch(() => {});

        if (!job.outputFilename) return;
        const filePath = botStore.getVideoFilePath(job.outputFilename);
        if (!fs.existsSync(filePath)) return;
        const stat = fs.statSync(filePath);
        const publicBase =
          process.env.APP_URL?.trim() || `http://localhost:${process.env.PORT || 3000}`;

        if (stat.size <= 48 * 1024 * 1024) {
          const bytes = fs.readFileSync(filePath);
          const form = new FormData();
          form.append('chat_id', String(chatId));
          form.append(
            'caption',
            `🎬 ${job.title}\nফরম্যাট: ${job.aspectRatio} · ${job.resolution.toUpperCase()} · দৈর্ঘ্য: ${durLabel}`,
          );
          form.append('supports_streaming', 'true');
          form.append(
            'reply_markup',
            JSON.stringify({
              inline_keyboard: [
                [{ text: '🎬 নতুন ভিডিও তৈরি', callback_data: 'menu:video' }],
                [{ text: '🏠 মেইন মেনু', callback_data: 'menu:main' }],
              ],
            }),
          );
          form.append(
            'video',
            new Blob([new Uint8Array(bytes)], { type: 'video/mp4' }),
            job.outputFilename,
          );
          await fetch(`https://api.telegram.org/bot${token}/sendVideo`, {
            method: 'POST',
            body: form,
          });
        } else {
          await this.tgFetch(token, 'sendMessage', {
            chat_id: chatId,
            text:
              `📦 আপনার Full HD / 4K ভিডিওটি (${Math.round(stat.size / (1024 * 1024))} MB) তৈরি হয়েছে!\n` +
              `টেলিগ্রাম ৫০MB সীমার চেয়ে বড় হওয়ায় সরাসরি ডাউনলোড লিংক:\n${publicBase}${job.outputVideoUrl}?download=1`,
          });
        }
      },
      onFail: async (_job: VideoProjectJob, errorMessage: string) => {
        await this.tgFetch(token, 'editMessageText', {
          chat_id: chatId,
          message_id: statusMessageId,
          text: `❌ ভিডিও তৈরি ব্যর্থ হয়েছে: ${errorMessage}`,
        }).catch(() => {});
      },
    };
  }

  createTelegramJobListener(
    token: string,
    chatId: number,
    statusMessageId: number,
  ): JobLifecycleListener {
    let lastStatusSent = '';
    let lastEditMs = 0;
    let lastChatActionMs = 0;
    let pulseTick = 0;
    const pulseIcons = ['🎙️', '⚡', '🔄', '🎧'];

    return {
      onStatus: async (job: VoiceJob) => {
        const now = Date.now();
        if (now - lastChatActionMs >= 4500) {
          lastChatActionMs = now;
          this.tgFetch(token, 'sendChatAction', {
            chat_id: chatId,
            action: 'record_voice',
          }).catch(() => {});
        }

        const pct =
          job.progressPct ??
          Math.round((job.currentPart / Math.max(1, job.totalParts)) * 100);
        const key = `${pct}:${job.statusText}:${job.elapsedSec ?? 0}:${job.estimatedRemainingSec ?? 0}`;
        if (key === lastStatusSent) return;
        const stageChanged = !lastStatusSent.includes(`:${job.statusText}:`);
        if (!stageChanged && now - lastEditMs < 1900) return;

        lastStatusSent = key;
        lastEditMs = now;
        pulseTick += 1;
        const pulse = pulseIcons[pulseTick % pulseIcons.length];
        const progressBar = formatProgressBar(pct);
        const statusMsg =
          `${pulse} LIVE ভয়েস অটো-প্রসেসিং চলছে...\n` +
          `কণ্ঠস্বর: ${job.voiceNameBn}\n` +
          `অগ্রগতি: [${progressBar}] ${pct}% (${job.currentPart}/${job.totalParts} পার্ট)\n` +
          `অবস্থা: ${job.statusText}\n` +
          `${formatEtaLine(job.elapsedSec, job.estimatedRemainingSec)}`;

        await this.tgFetch(token, 'editMessageText', {
          chat_id: chatId,
          message_id: statusMessageId,
          text: statusMsg,
        }).catch(() => {});
      },
      onComplete: async (
        job: VoiceJob,
        generation: VoiceGeneration,
        parts: AudioPartOutput[],
      ) => {
        const tookLabel = formatDurationHuman(job.elapsedSec ?? 0);
        await this.tgFetch(token, 'editMessageText', {
          chat_id: chatId,
          message_id: statusMessageId,
          text:
            `✅ ভয়েস তৈরি সম্পন্ন হয়েছে!\n` +
            `কণ্ঠস্বর: ${generation.voiceNameBn}\n` +
            `মোট দৈর্ঘ্য: ${formatDurationHuman(generation.durationSec)} · অংশ: ${parts.length}টি ফাইল\n` +
            `⏱️ মোট সময় লেগেছে: ${tookLabel}`,
        }).catch(() => {});

        for (let idx = 0; idx < parts.length; idx++) {
          const part = parts[idx];
          const filePath = path.join(botStore.getAudioDir(), part.filename);
          if (!fs.existsSync(filePath)) continue;
          const fileBytes = fs.readFileSync(filePath);
          const partSuffix =
            parts.length > 1 ? ` (Part ${idx + 1}/${parts.length})` : '';

          const form = new FormData();
          form.append('chat_id', String(chatId));
          form.append(
            'caption',
            `🎧 বাংলা AI ভয়েস${partSuffix}\nকণ্ঠস্বর: ${generation.voiceNameBn} · স্পিড: ${generation.speed}x · দৈর্ঘ্য: ${formatDurationHuman(part.durationSec)}`,
          );
          form.append('title', `Bangla Voice - ${generation.voiceNameBn}${partSuffix}`);
          form.append('performer', 'BanglaVoice AI Bot');
          if (idx === parts.length - 1) {
            form.append(
              'reply_markup',
              JSON.stringify({
                inline_keyboard: postAudioButtons(generation.id),
              }),
            );
          }
          const blob = new Blob([new Uint8Array(fileBytes)], {
            type: 'audio/mpeg',
          });
          form.append('audio', blob, part.filename);

          await fetch(`https://api.telegram.org/bot${token}/sendAudio`, {
            method: 'POST',
            body: form,
          });
        }
      },
      onFail: async (_job: VoiceJob, errorMessage: string) => {
        await this.tgFetch(token, 'editMessageText', {
          chat_id: chatId,
          message_id: statusMessageId,
          text: `❌ ভয়েস তৈরি ব্যর্থ হয়েছে: ${errorMessage}`,
        }).catch(() => {});
      },
    };
  }

  async sendBotResponseToTelegram(
    token: string,
    chatId: number,
    output: BotActionOutput,
  ) {
    for (const msg of output.messages) {
      const replyMarkup = msg.buttons
        ? { inline_keyboard: msg.buttons }
        : undefined;

      const cleanText = msg.text.replace(/\*\*/g, '').replace(/`/g, '');
      const safeText =
        cleanText.length > 4000 ? `${cleanText.slice(0, 3990)}\n...` : cleanText;

      // Deliver direct Audio MP3 file if attached
      if (msg.audio) {
        const audioFilename = path.basename(msg.audio.url.split('?')[0]);
        const audioPath =
          msg.audio.filePath && fs.existsSync(msg.audio.filePath)
            ? msg.audio.filePath
            : path.join(botStore.getAudioDir(), audioFilename);
        if (fs.existsSync(audioPath)) {
          const bytes = fs.readFileSync(audioPath);
          const form = new FormData();
          form.append('chat_id', String(chatId));
          form.append('caption', safeText.slice(0, 1000));
          form.append('title', msg.audio.title);
          form.append('performer', msg.audio.performer);
          if (replyMarkup) {
            form.append('reply_markup', JSON.stringify(replyMarkup));
          }
          form.append(
            'audio',
            new Blob([new Uint8Array(bytes)], { type: 'audio/mpeg' }),
            path.basename(audioPath) || audioFilename,
          );
          await fetch(`https://api.telegram.org/bot${token}/sendAudio`, {
            method: 'POST',
            body: form,
          });
          continue;
        }
      }

      // Deliver direct Video MP4 file if attached
      if (msg.video) {
        const videoFilename = path.basename(msg.video.url.split('?')[0]);
        const videoPath = botStore.getVideoFilePath(videoFilename);
        if (fs.existsSync(videoPath)) {
          const stat = fs.statSync(videoPath);
          if (stat.size <= 48 * 1024 * 1024) {
            const bytes = fs.readFileSync(videoPath);
            const form = new FormData();
            form.append('chat_id', String(chatId));
            form.append('caption', safeText.slice(0, 1000));
            form.append('supports_streaming', 'true');
            if (replyMarkup) {
              form.append('reply_markup', JSON.stringify(replyMarkup));
            }
            form.append(
              'video',
              new Blob([new Uint8Array(bytes)], { type: 'video/mp4' }),
              videoFilename,
            );
            await fetch(`https://api.telegram.org/bot${token}/sendVideo`, {
              method: 'POST',
              body: form,
            });
            continue;
          }
        }
      }

      // Deliver Photo (AI Image / Design / Enhanced Photo) if attached
      if (msg.photo?.filePath && fs.existsSync(msg.photo.filePath)) {
        const bytes = fs.readFileSync(msg.photo.filePath);
        const form = new FormData();
        form.append('chat_id', String(chatId));
        form.append('caption', (msg.photo.caption || safeText).slice(0, 1000));
        if (replyMarkup) {
          form.append('reply_markup', JSON.stringify(replyMarkup));
        }
        form.append(
          'photo',
          new Blob([new Uint8Array(bytes)], { type: 'image/png' }),
          path.basename(msg.photo.filePath) || 'image.png',
        );
        await fetch(`https://api.telegram.org/bot${token}/sendPhoto`, {
          method: 'POST',
          body: form,
        });
        continue;
      }

      // Deliver Document (.ZIP, .DOCX, .XLSX, .PPTX, .PDF, Code, etc.) if attached
      if (msg.document?.filePath && fs.existsSync(msg.document.filePath)) {
        const bytes = fs.readFileSync(msg.document.filePath);
        const form = new FormData();
        form.append('chat_id', String(chatId));
        form.append('caption', safeText.slice(0, 1000));
        if (replyMarkup) {
          form.append('reply_markup', JSON.stringify(replyMarkup));
        }
        form.append(
          'document',
          new Blob([new Uint8Array(bytes)], {
            type: msg.document.mimeType || 'application/octet-stream',
          }),
          msg.document.filename,
        );
        await fetch(`https://api.telegram.org/bot${token}/sendDocument`, {
          method: 'POST',
          body: form,
        });
        continue;
      }

      const sent = await this.tgFetch<{ message_id: number }>(
        token,
        'sendMessage',
        {
          chat_id: chatId,
          text: safeText,
          reply_markup: replyMarkup,
        },
      );
      if (!sent.ok) {
        console.error('Telegram sendMessage failed:', sent.description || sent);
      }

      if (msg.jobId && sent.ok && sent.result?.message_id) {
        const job = botStore.getJobById(msg.jobId);
        if (job) {
          job.telegramChatId = chatId;
          job.telegramStatusMessageId = sent.result.message_id;
          botStore.upsertJob(job);
        }
        voiceJobQueue.registerListener(
          msg.jobId,
          this.createTelegramJobListener(token, chatId, sent.result.message_id),
        );
      }

      if (msg.videoJobId && sent.ok && sent.result?.message_id) {
        const vJob = botStore.getVideoJobById(msg.videoJobId);
        if (vJob) {
          vJob.telegramChatId = chatId;
          vJob.telegramStatusMessageId = sent.result.message_id;
          botStore.upsertVideoJob(vJob);
        }
        videoJobQueue.registerListener(
          msg.videoJobId,
          this.createTelegramVideoJobListener(token, chatId, sent.result.message_id),
        );
      }
    }

    // Push any admin payment notifications to all configured Telegram admins
    if (output.pendingAdminNotifications) {
      const adminIds = botStore.listAdminTelegramIds();
      for (const notif of output.pendingAdminNotifications) {
        for (const adminTgId of adminIds) {
          await this.tgFetch(token, 'sendMessage', {
            chat_id: adminTgId,
            text: notif.text.replace(/\*\*/g, '').replace(/`/g, ''),
            reply_markup: { inline_keyboard: notif.buttons },
          }).catch(() => {});
        }
      }
    }

    if (
      output.pendingUserNotification &&
      !output.pendingUserNotification.telegramId.startsWith('sim_')
    ) {
      await this.tgFetch(token, 'sendMessage', {
        chat_id: output.pendingUserNotification.telegramId,
        text: output.pendingUserNotification.text,
      }).catch(() => {});
    }

    if (output.pendingBroadcast?.text) {
      const broadcastText = output.pendingBroadcast.text
        .replace(/\*\*/g, '')
        .replace(/`/g, '');
      const targets = botStore
        .listUsers()
        .filter(
          (u) =>
            u.status === 'active' &&
            !u.telegramId.startsWith('sim_') &&
            u.telegramId !== output.pendingBroadcast?.excludeTelegramId,
        );
      let sentCount = 0;
      let failedCount = 0;
      for (const target of targets) {
        const res = await this.tgFetch(token, 'sendMessage', {
          chat_id: target.telegramId,
          text: `📢 ${broadcastText}`,
        }).catch(() => ({ ok: false }));
        if (res && (res as { ok?: boolean }).ok) {
          sentCount += 1;
        } else {
          failedCount += 1;
        }
      }
      await this.tgFetch(token, 'sendMessage', {
        chat_id: chatId,
        text: `✅ ব্রডকাস্ট সম্পন্ন: ${sentCount} জন পেয়েছে, ${failedCount} টি ব্যর্থ হয়েছে।`,
      }).catch(() => {});
    }
  }

  async handleTelegramUpdate(update: TelegramUpdate) {
    const config = botStore.getConfig();
    const token = config.telegramBotToken;
    if (!token) return;

    // 1) Auto-link Private/Public Channel when an Admin adds the bot as Administrator
    if (update.my_chat_member?.chat?.type === 'channel') {
      const mcm = update.my_chat_member;
      const fromUser = botStore.getOrCreateUser({
        telegramId: String(mcm.from.id),
        username: mcm.from.username,
        firstName: mcm.from.first_name,
      });
      const status = mcm.new_chat_member?.status;
      if (
        botStore.isAdmin(fromUser) &&
        (status === 'administrator' || status === 'creator')
      ) {
        const chId = String(mcm.chat.id);
        botStore.updateConfig({ notificationChannelId: chId });
        await this.tgFetch(token, 'sendMessage', {
          chat_id: mcm.from.id,
          text:
            `✅ আপনার চ্যানেল "${mcm.chat.title || chId}" (${chId}) স্বয়ংক্রিয়ভাবে যুক্ত হয়েছে!\n` +
            `এখন থেকে তৈরি হওয়া অডিও/ভিডিও (কোনো ইউজার তথ্য ছাড়া) সরাসরি এই চ্যানেলে যাবে এবং ইউজারের @username সহ কপি আপনার ইনবক্সে আসবে।`,
        }).catch(() => {});
        await this.tgFetch(token, 'sendMessage', {
          chat_id: chId,
          text: '✅ BanglaVoice AI Media Channel সংযুক্ত হয়েছে। নতুন অডিও ও ভিডিও এখানে আপলোড হবে।',
        }).catch(() => {});
      }
      return;
    }

    // 2) Auto-link when /connect or /setchannel is posted inside a Channel
    if (update.channel_post?.chat?.type === 'channel') {
      const postText = (update.channel_post.text ?? '').trim().toLowerCase();
      if (postText === '/connect' || postText === '/setchannel' || !config.notificationChannelId) {
        const chId = String(update.channel_post.chat.id);
        botStore.updateConfig({ notificationChannelId: chId });
        await this.tgFetch(token, 'sendMessage', {
          chat_id: chId,
          text: `✅ চ্যানেল (${chId}) সফলভাবে যুক্ত হয়েছে! এখন থেকে সব অডিও ও ভিডিও এখানে আপলোড হবে।`,
        }).catch(() => {});
        for (const adminId of botStore.listAdminTelegramIds()) {
          if (adminId.startsWith('sim_')) continue;
          await this.tgFetch(token, 'sendMessage', {
            chat_id: adminId,
            text: `✅ চ্যানেল "${update.channel_post.chat.title || chId}" (${chId}) অটো-কানেক্ট হয়েছে!`,
          }).catch(() => {});
        }
      }
      return;
    }

    // 3) Auto-link when an Admin forwards any post from a Channel to the Bot DM
    const fwdChat =
      update.message?.forward_from_chat ??
      update.message?.forward_origin?.chat;
    if (update.message && fwdChat?.type === 'channel') {
      const from = update.message.from;
      const chatId = update.message.chat.id;
      const user = botStore.getOrCreateUser({
        telegramId: String(from?.id ?? chatId),
        username: from?.username,
        firstName: from?.first_name,
      });
      if (botStore.isAdmin(user)) {
        const chId = String(fwdChat.id);
        botStore.updateConfig({ notificationChannelId: chId });
        const testRes = await sendTestChannelNotification(chId);
        await this.tgFetch(token, 'sendMessage', {
          chat_id: chatId,
          text: testRes.ok
            ? `✅ চ্যানেল "${fwdChat.title || chId}" (${chId}) সফলভাবে যুক্ত ও টেস্ট হয়েছে!\nএখন থেকে সব অডিও/ভিডিও চ্যানেলে এবং ইউজারের @username সহ আপনার ইনবক্সে আসবে।`
            : `⚠️ চ্যানেল আইডি (${chId}) পাওয়া গেছে, কিন্তু চ্যানেলে মেসেজ যায়নি: ${testRes.error}\nবটটিকে ওই চ্যানেলে Administrator হিসেবে যুক্ত করুন।`,
        }).catch(() => {});
        return;
      }
    }

    if (update.callback_query) {
      const cq = update.callback_query;
      await this.tgFetch(token, 'answerCallbackQuery', {
        callback_query_id: cq.id,
      }).catch(() => {});

      const chatId = cq.message?.chat.id ?? cq.from.id;
      const user = botStore.getOrCreateUser({
        telegramId: String(cq.from.id),
        username: cq.from.username,
        firstName: cq.from.first_name,
      });

      const output = await processBotInteraction({
        user,
        callbackData: cq.data,
        source: 'telegram',
        telegramChatId: chatId,
      });
      await this.sendBotResponseToTelegram(token, chatId, output);
      return;
    }

    // Handle Telegram Video uploads (for Smart Interactive Video Editor)
    if (update.message?.video) {
      const vid = update.message.video;
      const chatId = update.message.chat.id;
      const from = update.message.from;
      const user = botStore.getOrCreateUser({
        telegramId: String(from?.id ?? chatId),
        username: from?.username,
        firstName: from?.first_name,
      });

      try {
        this.tgFetch(token, 'sendChatAction', {
          chat_id: chatId,
          action: 'upload_video',
        }).catch(() => {});
        const dl = await this.downloadTelegramBinaryFile(token, vid.file_id, '.mp4');
        const info = await probeMediaInfo(dl.filePath);
        const existingDraft =
          user.pendingContext?.videoDraft ?? defaultVideoDraft(user, 'edit_video');
        const nextDraft: VideoDraftContext = {
          ...existingDraft,
          mode: 'edit_video',
          title: update.message.caption?.slice(0, 44) || 'এডিটেড ভিডিও প্রজেক্ট',
          uploadedVideoPath: dl.filePath,
          uploadedVideoName: vid.file_name || dl.filename,
          uploadedVideoDurationSec: info.durationSec,
        };
        const updatedUser =
          botStore.updateUser(user.id, {
            step: 'idle',
            pendingContext: { ...user.pendingContext, videoDraft: nextDraft },
          }) ?? user;
        const cfgCard = buildVideoConfigCardMessage(updatedUser);
        await this.sendBotResponseToTelegram(token, chatId, {
          user: updatedUser,
          messages: [
            {
              id: makeMsgId(),
              sender: 'bot',
              text:
                `✅ আপনার ভিডিওটি (${info.durationSec}s · ${info.width}x${info.height}) রিসিভ হয়েছে!\n` +
                `এবার আপনার প্রয়োজনমতো স্পিড, ভয়েস, মিউজিক ও টেমপ্লেট সেট করুন:\n\n${cfgCard.text}`,
              timestamp: nowTimeLabel(),
              buttons: cfgCard.buttons,
            },
          ],
        });
      } catch (err) {
        await this.tgFetch(token, 'sendMessage', {
          chat_id: chatId,
          text: `❌ ভিডিও ডাউনলোড করা যায়নি: ${err instanceof Error ? err.message : 'Error'}`,
        });
      }
      return;
    }

    // Handle Telegram Photo uploads (ChatGPT Vision, Image-to-Video, Reference Redesign, Enhance, 2x Upscale, Solid BG Remove)
    if (update.message?.photo && update.message.photo.length > 0) {
      const photos = update.message.photo;
      const bestPhoto = photos[photos.length - 1];
      const chatId = update.message.chat.id;
      const from = update.message.from;
      let user = botStore.getOrCreateUser({
        telegramId: String(from?.id ?? chatId),
        username: from?.username,
        firstName: from?.first_name,
      });
      const caption = (update.message.caption ?? '').trim();

      try {
        this.tgFetch(token, 'sendChatAction', { chat_id: chatId, action: 'typing' }).catch(() => {});
        const dl = await this.downloadTelegramBinaryFile(token, bestPhoto.file_id, '.jpg');
        user =
          botStore.updateUser(user.id, {
            lastUpload: {
              type: 'photo',
              filePath: dl.filePath,
              filename: dl.filename,
              mimeType: 'image/jpeg',
              caption,
              uploadedAt: new Date().toISOString(),
            },
          }) ?? user;

        if (user.step === 'awaiting_video_i2v_photo') {
          const prevDraft = user.pendingContext?.videoDraft ?? defaultVideoDraft(user, 'image_to_video');
          const nextDraft: VideoDraftContext = {
            ...prevDraft,
            mode: 'image_to_video',
            uploadedImagePath: dl.filePath,
          };
          if (caption) {
            const gen = await generateBanglaVideoScriptFromPrompt({ prompt: caption, templateId: nextDraft.templateId });
            nextDraft.prompt = caption;
            nextDraft.title = gen.title;
            nextDraft.script = gen.banglaScript;
            nextDraft.musicMood = gen.musicMood;
            const u2 = botStore.updateUser(user.id, {
              step: 'idle',
              pendingContext: { ...user.pendingContext, videoDraft: nextDraft },
            }) ?? user;
            const cfgCard = buildVideoConfigCardMessage(u2);
            await this.sendBotResponseToTelegram(token, chatId, {
              user: u2,
              messages: [{ id: makeMsgId(), sender: 'bot', text: cfgCard.text, timestamp: nowTimeLabel(), buttons: cfgCard.buttons }],
            });
          } else {
            const u2 = botStore.updateUser(user.id, {
              step: 'awaiting_video_i2v_prompt',
              pendingContext: { ...user.pendingContext, videoDraft: nextDraft },
            }) ?? user;
            await this.sendBotResponseToTelegram(token, chatId, {
              user: u2,
              messages: [{
                id: makeMsgId(),
                sender: 'bot',
                text: '🖼️ ছবি যুক্ত হয়েছে! এখন এই ছবি দিয়ে কী বিষয়ে ভিডিও বানাতে চান তা লিখে পাঠান:',
                timestamp: nowTimeLabel(),
                buttons: [[{ text: '❌ বাতিল', callback_data: 'act:cancel' }]],
              }],
            });
          }
          return;
        }

        if (user.step === 'img_enhance_wait' || user.step === 'img_upscale_wait' || user.step === 'img_bg_wait') {
          const act =
            user.step === 'img_enhance_wait'
              ? 'img:quick_enhance'
              : user.step === 'img_upscale_wait'
                ? 'img:quick_upscale'
                : 'img:quick_bg';
          const out = await processBotInteraction({ user, callbackData: act, source: 'telegram', telegramChatId: chatId });
          await this.sendBotResponseToTelegram(token, chatId, out);
          return;
        }

        if (user.step === 'img_ref_prompt') {
          if (caption) {
            const out = await processBotInteraction({ user, text: caption, source: 'telegram', telegramChatId: chatId });
            await this.sendBotResponseToTelegram(token, chatId, out);
          } else {
            await this.sendBotResponseToTelegram(token, chatId, {
              user,
              messages: [{
                id: makeMsgId(),
                sender: 'bot',
                text: '🎭 রেফারেন্স ছবি সেভ হয়েছে! এখন এই ছবির স্টাইল অনুসারে কী ধরনের নতুন ডিজাইন/ছবি চান তা লিখে পাঠান:',
                timestamp: nowTimeLabel(),
                buttons: [[{ text: '❌ বাতিল', callback_data: 'act:cancel' }]],
              }],
            });
          }
          return;
        }

        if (caption) {
          const visionRes = await runAssistantChat({
            user,
            message: caption,
            imagePath: dl.filePath,
            imageMimeType: 'image/jpeg',
          });
          await this.sendBotResponseToTelegram(token, chatId, {
            user,
            messages: [{
              id: makeMsgId(),
              sender: 'bot',
              text: visionRes.replyText.slice(0, 3700),
              timestamp: nowTimeLabel(),
              buttons: [
                [
                  { text: '✨ Enhance', callback_data: 'img:quick_enhance' },
                  { text: '📐 2x Upscale', callback_data: 'img:quick_upscale' },
                ],
                [
                  { text: '🎬 Image → Video', callback_data: 'img:quick_i2v' },
                  { text: '🏠 মেইন মেনু', callback_data: 'menu:main' },
                ],
              ],
            }],
          });
          return;
        }

        const visionAnalyze = await runAssistantChat({
          user,
          message: 'এই ছবিটি সংক্ষেপে বিশ্লেষণ করে কী আছে এবং আমি এর সাথে কী কী করতে পারি তা বলো।',
          imagePath: dl.filePath,
          imageMimeType: 'image/jpeg',
        });
        await this.sendBotResponseToTelegram(token, chatId, {
          user,
          messages: [{
            id: makeMsgId(),
            sender: 'bot',
            text: `🖼️ **ছবি পাওয়া গেছে & AI বিশ্লেষণ:**\n\n${visionAnalyze.replyText.slice(0, 3000)}\n\nনিচের যেকোনো টুল দিয়ে ছবিটি প্রসেস করতে পারেন:`,
            timestamp: nowTimeLabel(),
            buttons: [
              [
                { text: '✨ Enhance & Restore', callback_data: 'img:quick_enhance' },
                { text: '📐 2x HD Upscale', callback_data: 'img:quick_upscale' },
              ],
              [
                { text: '🎭 নতুন ডিজাইন (Ref)', callback_data: 'img:ref' },
                { text: '✂️ Solid BG Remove', callback_data: 'img:quick_bg' },
              ],
              [
                { text: '🎬 Image → AI Video', callback_data: 'img:quick_i2v' },
                { text: '🏠 মেইন মেনু', callback_data: 'menu:main' },
              ],
            ],
          }],
        });
      } catch (err) {
        botStore.logError('telegram:photo', err, user.id);
        await this.tgFetch(token, 'sendMessage', {
          chat_id: chatId,
          text: `❌ ছবি প্রসেস করা যায়নি: ${err instanceof Error ? err.message : 'Error'}`,
        });
      }
      return;
    }

    // Handle Telegram Voice / Audio uploads (STT, Audio Translate, Noise Removal, OR Video Studio Voice-to-Video)
    const msg = update.message;
    const incomingAudio = msg?.voice ?? msg?.audio;
    if (msg && incomingAudio) {
      const chatId = msg.chat.id;
      const from = msg.from;
      let user = botStore.getOrCreateUser({
        telegramId: String(from?.id ?? chatId),
        username: from?.username,
        firstName: from?.first_name,
      });

      try {
        const ext = msg.voice ? '.ogg' : '.mp3';
        const dl = await this.downloadTelegramBinaryFile(
          token,
          incomingAudio.file_id,
          ext,
        );
        const mimeType = incomingAudio.mime_type || (msg.voice ? 'audio/ogg' : 'audio/mpeg');
        user =
          botStore.updateUser(user.id, {
            lastUpload: {
              type: 'audio',
              filePath: dl.filePath,
              filename: incomingAudio.file_name || dl.filename,
              mimeType,
              uploadedAt: new Date().toISOString(),
            },
          }) ?? user;

        if (user.step === 'voice_stt_wait') {
          const out = await processBotInteraction({ user, callbackData: 'vstudio:do_stt', source: 'telegram', telegramChatId: chatId });
          await this.sendBotResponseToTelegram(token, chatId, out);
          return;
        }
        if (user.step === 'voice_enhance_wait') {
          const out = await processBotInteraction({ user, callbackData: 'vstudio:do_enhance', source: 'telegram', telegramChatId: chatId });
          await this.sendBotResponseToTelegram(token, chatId, out);
          return;
        }
        if (user.step === 'voice_translate_wait') {
          const out = await processBotInteraction({
            user,
            callbackData: user.language === 'en' ? 'vstudio:do_tr:en' : 'vstudio:do_tr:bn',
            source: 'telegram',
            telegramChatId: chatId,
          });
          await this.sendBotResponseToTelegram(token, chatId, out);
          return;
        }

        const info = await probeMediaInfo(dl.filePath);
        const curDraft = user.pendingContext?.videoDraft;
        if (user.step === 'awaiting_video_voice' || (curDraft?.mode === 'edit_video' && curDraft.uploadedVideoPath)) {
          const targetMode =
            curDraft?.mode === 'edit_video' && curDraft.uploadedVideoPath
              ? 'edit_video'
              : 'voice';
          const nextDraft: VideoDraftContext = {
            ...(curDraft ?? defaultVideoDraft(user, targetMode)),
            mode: targetMode,
            uploadedAudioPath: dl.filePath,
            uploadedAudioName: incomingAudio.file_name || dl.filename,
            uploadedAudioDurationSec: info.durationSec,
          };
          const updatedUser =
            botStore.updateUser(user.id, {
              step: 'idle',
              pendingContext: { ...user.pendingContext, videoDraft: nextDraft },
            }) ?? user;
          const cfgCard = buildVideoConfigCardMessage(updatedUser);
          await this.sendBotResponseToTelegram(token, chatId, {
            user: updatedUser,
            messages: [
              {
                id: makeMsgId(),
                sender: 'bot',
                text: `🎤 অডিও ট্র্যাক (${info.durationSec}s) ভিডিওতে যুক্ত হয়েছে!\n\n${cfgCard.text}`,
                timestamp: nowTimeLabel(),
                buttons: cfgCard.buttons,
              },
            ],
          });
          return;
        }

        await this.sendBotResponseToTelegram(token, chatId, {
          user,
          messages: [
            {
              id: makeMsgId(),
              sender: 'bot',
              text: `🎤 **অডিও / ভয়েস ফাইল পাওয়া গেছে (${info.durationSec}s)**\nএই ভয়েসটি দিয়ে কী করতে চান তা বেছে নিন:`,
              timestamp: nowTimeLabel(),
              buttons: [
                [
                  { text: '📝 লেখা বের করুন (STT)', callback_data: 'vstudio:do_stt' },
                  { text: '✨ Noise Removal', callback_data: 'vstudio:do_enhance' },
                ],
                [
                  { text: '🇬🇧 English MP3 অনুবাদ', callback_data: 'vstudio:do_tr:en' },
                  { text: '🇧🇩 বাংলা MP3 অনুবাদ', callback_data: 'vstudio:do_tr:bn' },
                ],
                [{ text: '🏠 মেইন মেনু', callback_data: 'menu:main' }],
              ],
            },
          ],
        });
      } catch (err) {
        await this.tgFetch(token, 'sendMessage', {
          chat_id: chatId,
          text: `❌ অডিও প্রসেস করা যায়নি: ${err instanceof Error ? err.message : 'Error'}`,
        });
      }
      return;
    }

    // Handle Document uploads (.pdf, .docx, .xlsx, .csv, .txt, code files)
    if (update.message?.document) {
      const doc = update.message.document;
      const chatId = update.message.chat.id;
      const from = update.message.from;
      let user = botStore.getOrCreateUser({
        telegramId: String(from?.id ?? chatId),
        username: from?.username,
        firstName: from?.first_name,
      });

      const fname = (doc.file_name || 'file.txt').toLowerCase();
      const isTxt = doc.mime_type === 'text/plain' || fname.endsWith('.txt');
      const isSupportedDoc =
        isTxt ||
        /\.(pdf|docx|xlsx|xls|csv|md|json|py|js|ts|tsx|jsx|html|css|sql)$/i.test(fname);

      if (!isSupportedDoc) {
        await this.tgFetch(token, 'sendMessage', {
          chat_id: chatId,
          text: '⚠️ অনুগ্রহ করে PDF, Word (.docx), Excel (.xlsx/.csv), Text (.txt), Code (.py/.js/.html), Photo, Audio বা MP4 ভিডিও পাঠান।',
        });
        return;
      }

      try {
        this.tgFetch(token, 'sendChatAction', { chat_id: chatId, action: 'typing' }).catch(() => {});

        // Preserve original TTS / Video script flow for .txt files in TTS/Video steps
        if (
          isTxt &&
          (user.step === 'awaiting_video_script' ||
            user.step === 'awaiting_video_edit_script' ||
            user.step === 'awaiting_script' ||
            user.step === 'awaiting_preview_edit' ||
            user.step === 'collecting_long_script')
        ) {
          const scriptContent = await this.downloadTelegramDocumentText(token, doc.file_id);
          if (user.step === 'awaiting_video_script' || user.step === 'awaiting_video_edit_script') {
            const output = await processBotInteraction({
              user,
              text: scriptContent,
              source: 'telegram',
              telegramChatId: chatId,
            });
            await this.sendBotResponseToTelegram(token, chatId, output);
            return;
          }
          const output =
            user.step === 'awaiting_preview_edit'
              ? await showBanglaPreviewForScript({
                  user,
                  rawScript: user.pendingContext?.previewRawScript || scriptContent,
                  editedBanglaCandidate: scriptContent,
                })
              : await showBanglaPreviewForScript({ user, rawScript: scriptContent });
          await this.sendBotResponseToTelegram(token, chatId, output);
          return;
        }

        const ext = path.extname(fname) || '.bin';
        const dl = await this.downloadTelegramBinaryFile(token, doc.file_id, ext);
        const extracted = await extractLocalTextFromDocument(dl.filePath);
        user =
          botStore.updateUser(user.id, {
            lastUpload: {
              type: 'document',
              filePath: dl.filePath,
              filename: doc.file_name || dl.filename,
              mimeType: extracted.mimeType,
              extractedText: extracted.extractedText?.slice(0, 6000),
              caption: update.message.caption,
              uploadedAt: new Date().toISOString(),
            },
          }) ?? user;

        const caption = (update.message.caption ?? '').trim();
        if (caption) {
          const answer = await analyzeUploadedDocument({
            user,
            filePath: dl.filePath,
            filename: doc.file_name || dl.filename,
            taskPrompt: caption,
          });
          await this.sendBotResponseToTelegram(token, chatId, {
            user,
            messages: [
              {
                id: makeMsgId(),
                sender: 'bot',
                text: `📄 **${doc.file_name || dl.filename}**\n\n${answer.slice(0, 3800)}`,
                timestamp: nowTimeLabel(),
                buttons: [
                  [
                    { text: '❓ আরেকটি প্রশ্ন', callback_data: 'doc:action:qa' },
                    { text: '📋 সারসংক্ষেপ', callback_data: 'doc:action:summary' },
                  ],
                  [{ text: '🏠 মেইন মেনু', callback_data: 'menu:main' }],
                ],
              },
            ],
          });
          return;
        }

        await this.sendBotResponseToTelegram(token, chatId, {
          user,
          messages: [
            {
              id: makeMsgId(),
              sender: 'bot',
              text:
                `📎 **ফাইল রিসিভ হয়েছে: ${doc.file_name || dl.filename}**\n\n` +
                `আপনি এখন নিচের যেকোনো কাজ এক ক্লিকে করতে পারেন:`,
              timestamp: nowTimeLabel(),
              buttons: [
                [
                  { text: '📋 সারসংক্ষেপ (Summarize)', callback_data: 'doc:action:summary' },
                  { text: '❓ ফাইল থেকে প্রশ্ন (Q&A)', callback_data: 'doc:action:qa' },
                ],
                [
                  { text: '🇧🇩 বাংলায় অনুবাদ', callback_data: 'doc:action:tr_bn' },
                  { text: '🇬🇧 Translate to EN', callback_data: 'doc:action:tr_en' },
                ],
                [{ text: '🏠 মেইন মেনু', callback_data: 'menu:main' }],
              ],
            },
          ],
        });
      } catch (err) {
        botStore.logError('telegram:document', err, user.id);
        await this.tgFetch(token, 'sendMessage', {
          chat_id: chatId,
          text: `❌ ফাইল প্রসেস করা যায়নি: ${err instanceof Error ? err.message : 'Error'}`,
        });
      }
      return;
    }

    if (update.message?.text) {
      const msg = update.message;
      const from = msg.from;
      const chatId = msg.chat.id;
      const user = botStore.getOrCreateUser({
        telegramId: String(from?.id ?? chatId),
        username: from?.username,
        firstName: from?.first_name,
      });

      this.tgFetch(token, 'sendChatAction', {
        chat_id: chatId,
        action: user.step === 'awaiting_script' ? 'record_voice' : 'typing',
      }).catch(() => {});

      const output = await processBotInteraction({
        user,
        text: msg.text,
        source: 'telegram',
        telegramChatId: chatId,
      });
      await this.sendBotResponseToTelegram(token, chatId, output);
    }
  }

  async startPolling() {
    const config = botStore.getConfig();
    if (!config.telegramBotToken) {
      throw new Error('Telegram Bot Token সেট করা নেই।');
    }
    const me = await this.verifyToken(config.telegramBotToken);
    await this.tgFetch(config.telegramBotToken, 'deleteWebhook', {
      drop_pending_updates: false,
    });

    await this.tgFetch(config.telegramBotToken, 'setMyCommands', {
      commands: UNIFIED_TELEGRAM_COMMANDS,
    }).catch(() => {});

    botStore.updateConfig({
      telegramBotUsername: me.username,
      telegramMode: 'polling',
    });

    // Resume any pending Telegram jobs that were interrupted during restart
    voiceJobQueue.resumePendingJobs((job) => {
      if (job.telegramChatId && job.telegramStatusMessageId) {
        return this.createTelegramJobListener(
          config.telegramBotToken,
          job.telegramChatId,
          job.telegramStatusMessageId,
        );
      }
      return undefined;
    });

    if (this.pollingActive) return me;
    this.pollingActive = true;
    void this.pollLoop();
    return me;
  }

  async setWebhook(webhookUrl: string) {
    const config = botStore.getConfig();
    if (!config.telegramBotToken) {
      throw new Error('Telegram Bot Token সেট করা নেই।');
    }
    const cleanUrl = webhookUrl.trim();
    if (!cleanUrl.startsWith('https://')) {
      throw new Error('Telegram Webhook-এর জন্য অবশ্যই HTTPS URL প্রয়োজন।');
    }

    // Stop polling first so webhook & polling do not conflict
    this.pollingActive = false;
    this.pollAbort?.abort();
    this.pollAbort = null;

    const me = await this.verifyToken(config.telegramBotToken);
    const res = await this.tgFetch(config.telegramBotToken, 'setWebhook', {
      url: cleanUrl,
      allowed_updates: [
        'message',
        'callback_query',
        'channel_post',
        'my_chat_member',
      ],
    });
    if (!res.ok) {
      throw new Error(res.description || 'Telegram Webhook সেট করা যায়নি।');
    }

    await this.tgFetch(config.telegramBotToken, 'setMyCommands', {
      commands: UNIFIED_TELEGRAM_COMMANDS,
    }).catch(() => {});

    botStore.updateConfig({
      telegramBotUsername: me.username,
      telegramMode: 'webhook',
    });

    return me;
  }

  stopPolling() {
    this.pollingActive = false;
    this.pollAbort?.abort();
    this.pollAbort = null;
    botStore.updateConfig({ telegramMode: 'stopped' });
  }

  private async pollLoop() {
    while (this.pollingActive) {
      const token = botStore.getConfig().telegramBotToken;
      if (!token) {
        this.pollingActive = false;
        break;
      }

      try {
        this.pollAbort = new AbortController();
        const allowedUpdates = encodeURIComponent(
          JSON.stringify([
            'message',
            'callback_query',
            'channel_post',
            'my_chat_member',
          ]),
        );
        const res = await fetch(
          `https://api.telegram.org/bot${token}/getUpdates?timeout=25&offset=${this.offset}&allowed_updates=${allowedUpdates}`,
          { signal: this.pollAbort.signal },
        );
        const data = (await res.json()) as {
          ok: boolean;
          description?: string;
          result?: TelegramUpdate[];
        };
        if (data.ok && Array.isArray(data.result)) {
          for (const upd of data.result) {
            this.offset = Math.max(this.offset, upd.update_id + 1);
            await this.handleTelegramUpdate(upd).catch((e) => {
              console.error('Telegram update error:', e);
            });
          }
        } else {
          console.error('Telegram getUpdates non-ok response:', data.description || data);
          await new Promise((r) => setTimeout(r, 3000));
        }
      } catch (err) {
        if ((err as Error).name !== 'AbortError') {
          console.error('Telegram pollLoop fetch error:', err);
          await new Promise((r) => setTimeout(r, 3000));
        }
      }
    }
  }
}

export const telegramConnector = new TelegramConnector();
