import { ThinkingLevel, Type } from '@google/genai';
import { Document, HeadingLevel, Packer, Paragraph, TextRun } from 'docx';
import mammoth from 'mammoth';
import fs from 'node:fs';
import path from 'node:path';
import PDFDocument from 'pdfkit';
import PptxGenJS from 'pptxgenjs';
import * as XLSX from 'xlsx';
import { withGeminiRetry } from './aiAssistant.ts';
import { botStore } from './store.ts';
import type { BotUser } from './types.ts';

const BENGALI_PDF_FONT = [
  '/usr/share/fonts/truetype/noto/NotoSansBengali-Regular.ttf',
  '/usr/share/fonts/truetype/noto/NotoSerifBengali-Regular.ttf',
].find((p) => fs.existsSync(p));

/**
 * Extracts readable text from DOCX, XLSX, CSV, TXT, MD, JSON, and Code files.
 * PDFs & Images are passed natively as multimodal inlineData to Gemini!
 */
export async function extractLocalTextFromDocument(
  filePath: string,
): Promise<{ kind: 'pdf' | 'image' | 'text'; extractedText?: string; mimeType: string }> {
  const ext = path.extname(filePath).toLowerCase();

  if (ext === '.pdf') {
    return { kind: 'pdf', mimeType: 'application/pdf' };
  }
  if (/\.(png|jpe?g|webp|gif)$/i.test(ext)) {
    const mime =
      ext === '.png' ? 'image/png' : ext === '.webp' ? 'image/webp' : 'image/jpeg';
    return { kind: 'image', mimeType: mime };
  }

  if (ext === '.docx') {
    const res = await mammoth.extractRawText({ path: filePath });
    return {
      kind: 'text',
      mimeType:
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      extractedText: (res.value || '').trim(),
    };
  }

  if (ext === '.xlsx' || ext === '.xls' || ext === '.csv') {
    const wb = XLSX.readFile(filePath);
    const parts: string[] = [];
    for (const sheetName of wb.SheetNames.slice(0, 6)) {
      const sheet = wb.Sheets[sheetName];
      const csv = XLSX.utils.sheet_to_csv(sheet);
      parts.push(`--- Sheet: ${sheetName} ---\n${csv}`);
    }
    return {
      kind: 'text',
      mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      extractedText: parts.join('\n\n').trim(),
    };
  }

  // Plain text, markdown, JSON, Python, JS, TS, HTML, CSS, etc.
  const raw = fs.readFileSync(filePath, 'utf-8');
  return {
    kind: 'text',
    mimeType: 'text/plain',
    extractedText: raw.slice(0, 45000),
  };
}

/**
 * Reads, summarizes, translates, or answers Q&A on an uploaded document or PDF.
 */
export async function analyzeUploadedDocument(params: {
  user: BotUser;
  filePath: string;
  filename: string;
  taskPrompt: string;
}): Promise<string> {
  const info = await extractLocalTextFromDocument(params.filePath);

  const answer = await withGeminiRetry('documents:read', params.user.id, async (ai, model) => {
    const sys =
      `You are an expert AI Document Analyst. Respond clearly in ` +
      `${params.user.language === 'en' ? 'English' : 'Bengali (Bangla)'} unless the user asks to translate into another language. ` +
      `Base every answer strictly on the provided document.`;

    if (info.kind === 'pdf' || info.kind === 'image') {
      const buf = fs.readFileSync(params.filePath);
      if (buf.length > 18 * 1024 * 1024) {
        throw new Error('ফাইলটি 18MB-এর বেশি হওয়ায় সরাসরি বিশ্লেষণ করা যাচ্ছে না।');
      }
      const res = await ai.models.generateContent({
        model,
        contents: {
          parts: [
            {
              inlineData: {
                mimeType: info.mimeType,
                data: buf.toString('base64'),
              },
            },
            {
              text: `Filename: ${params.filename}\nTask / Question: ${params.taskPrompt}`,
            },
          ],
        },
        config: {
          systemInstruction: sys,
          ...(model === 'gemini-4-hydrogen'
            ? { thinkingConfig: { thinkingLevel: ThinkingLevel.HIGH } }
            : {}),
        },
      });
      return (res.text ?? '').trim();
    }

    const bodyText = (info.extractedText ?? '').trim();
    if (!bodyText) {
      throw new Error('ডকুমেন্টটি থেকে কোনো পাঠযোগ্য টেক্সট পাওয়া যায়নি।');
    }

    const res = await ai.models.generateContent({
      model,
      contents: `Filename: ${params.filename}\n\nDocument Content:\n"""\n${bodyText.slice(0, 32000)}\n"""\n\nTask / Question:\n${params.taskPrompt}`,
      config: {
        systemInstruction: sys,
        ...(model === 'gemini-4-hydrogen'
          ? { thinkingConfig: { thinkingLevel: ThinkingLevel.HIGH } }
          : {}),
      },
    });
    return (res.text ?? '').trim();
  });

  if (!answer) {
    throw new Error('ডকুমেন্ট বিশ্লেষণ করা যায়নি।');
  }

  botStore.incrementFeatureUsage('documents');
  botStore.updateUser(params.user.id, {
    lastActiveTask: {
      module: 'documents',
      summary: `Doc (${params.filename}): ${params.taskPrompt.slice(0, 48)}`,
      contextText: answer.slice(0, 500),
      updatedAt: new Date().toISOString(),
    },
  });

  return answer;
}

export interface GeneratedDocumentOutput {
  filename: string;
  filePath: string;
  url: string;
  mimeType: string;
  fileSizeBytes: number;
  title: string;
  previewSummary: string;
}

/**
 * Generates real downloadable Word (.docx), Excel (.xlsx), PowerPoint (.pptx),
 * or PDF (.pdf) documents structured intelligently by Gemini.
 */
export async function generateStructuredDocument(params: {
  user: BotUser;
  format: 'pdf' | 'docx' | 'xlsx' | 'pptx';
  topicPrompt: string;
}): Promise<GeneratedDocumentOutput> {
  const { user, format, topicPrompt } = params;
  const stamp = `${Date.now()}-${Math.random().toString(36).slice(2, 5)}`;

  if (format === 'xlsx') {
    const spreadsheetData = await withGeminiRetry(
      'documents:xlsx',
      user.id,
      async (ai, model) => {
        const res = await ai.models.generateContent({
          model,
          contents: `Create a clean structured spreadsheet for: "${topicPrompt}"`,
          config: {
            systemInstruction:
              'Return JSON with "title" (sheet title), "headers" (array of column header strings), and "rows" (array of 6-15 rows, each row an array of strings/numbers matching header length).',
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                title: { type: Type.STRING },
                headers: { type: Type.ARRAY, items: { type: Type.STRING } },
                rows: {
                  type: Type.ARRAY,
                  items: { type: Type.ARRAY, items: { type: Type.STRING } },
                },
              },
              required: ['title', 'headers', 'rows'],
            },
          },
        });
        return JSON.parse((res.text ?? '{}').trim()) as {
          title: string;
          headers: string[];
          rows: string[][];
        };
      },
    );

    const wb = XLSX.utils.book_new();
    const aoa = [spreadsheetData.headers, ...(spreadsheetData.rows ?? [])];
    const ws = XLSX.utils.aoa_to_sheet(aoa);
    XLSX.utils.book_append_sheet(
      wb,
      ws,
      (spreadsheetData.title || 'Sheet1').slice(0, 28),
    );
    const filename = `sheet-${stamp}.xlsx`;
    const filePath = botStore.getDocFilePath(filename);
    XLSX.writeFile(wb, filePath);
    const stat = fs.statSync(filePath);
    botStore.incrementFeatureUsage('documents');

    return {
      filename,
      filePath,
      url: `/api/docs/${filename}`,
      mimeType:
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      fileSizeBytes: stat.size,
      title: spreadsheetData.title || 'Excel Spreadsheet',
      previewSummary: `${spreadsheetData.rows?.length ?? 0} সারি ও ${spreadsheetData.headers?.length ?? 0} কলামের এক্সেল শিট তৈরি হয়েছে।`,
    };
  }

  if (format === 'pptx') {
    const deck = await withGeminiRetry(
      'documents:pptx',
      user.id,
      async (ai, model) => {
        const res = await ai.models.generateContent({
          model,
          contents: `Create a professional presentation deck for: "${topicPrompt}"`,
          config: {
            systemInstruction:
              'Return JSON with "deckTitle", "subtitle", and "slides" (array of 5-7 slides, each with "heading" and "bullets": array of 3-5 concise points in the user language).',
            responseMimeType: 'application/json',
            responseSchema: {
              type: Type.OBJECT,
              properties: {
                deckTitle: { type: Type.STRING },
                subtitle: { type: Type.STRING },
                slides: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      heading: { type: Type.STRING },
                      bullets: { type: Type.ARRAY, items: { type: Type.STRING } },
                    },
                    required: ['heading', 'bullets'],
                  },
                },
              },
              required: ['deckTitle', 'subtitle', 'slides'],
            },
          },
        });
        return JSON.parse((res.text ?? '{}').trim()) as {
          deckTitle: string;
          subtitle: string;
          slides: Array<{ heading: string; bullets: string[] }>;
        };
      },
    );

    const pptx = new PptxGenJS();
    pptx.layout = 'LAYOUT_16x9';

    // Title slide
    const titleSlide = pptx.addSlide();
    titleSlide.background = { color: '0F172A' };
    titleSlide.addText(deck.deckTitle || 'AI Presentation', {
      x: 0.8,
      y: 1.8,
      w: 8.4,
      h: 1.2,
      fontSize: 32,
      bold: true,
      color: 'F8FAFC',
    });
    titleSlide.addText(deck.subtitle || '', {
      x: 0.8,
      y: 3.1,
      w: 8.4,
      h: 0.8,
      fontSize: 16,
      color: '5EEAD4',
    });

    for (const s of deck.slides ?? []) {
      const slide = pptx.addSlide();
      slide.background = { color: 'F8FAFC' };
      slide.addShape(pptx.ShapeType.rect, {
        x: 0,
        y: 0,
        w: 10,
        h: 0.9,
        fill: { color: '0F766E' },
      });
      slide.addText(s.heading, {
        x: 0.6,
        y: 0.15,
        w: 8.8,
        h: 0.6,
        fontSize: 22,
        bold: true,
        color: 'FFFFFF',
      });
      slide.addText(
        s.bullets.map((b) => ({ text: b, options: { bullet: true } })),
        {
          x: 0.7,
          y: 1.25,
          w: 8.6,
          h: 3.8,
          fontSize: 16,
          color: '1E293B',
          paraSpaceAfter: 10,
        },
      );
    }

    const filename = `slides-${stamp}.pptx`;
    const filePath = botStore.getDocFilePath(filename);
    await pptx.writeFile({ fileName: filePath });
    const stat = fs.statSync(filePath);
    botStore.incrementFeatureUsage('documents');

    return {
      filename,
      filePath,
      url: `/api/docs/${filename}`,
      mimeType:
        'application/vnd.openxmlformats-officedocument.presentationml.presentation',
      fileSizeBytes: stat.size,
      title: deck.deckTitle || 'PowerPoint Deck',
      previewSummary: `${(deck.slides?.length ?? 0) + 1}টি স্লাইডের প্রফেশনাল PowerPoint (.pptx) তৈরি হয়েছে।`,
    };
  }

  // Word (.docx) or PDF (.pdf)
  const report = await withGeminiRetry(
    `documents:${format}`,
    user.id,
    async (ai, model) => {
      const res = await ai.models.generateContent({
        model,
        contents: `Write a comprehensive, professional structured document on: "${topicPrompt}"`,
        config: {
          systemInstruction:
            'Return JSON with "title", "subtitle", and "sections" (array of 4-7 sections, each with "heading" and "paragraphs": array of paragraphs and optional "bullets": array of bullet strings). Write in the user prompt language (Bengali or English).',
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              subtitle: { type: Type.STRING },
              sections: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    heading: { type: Type.STRING },
                    paragraphs: { type: Type.ARRAY, items: { type: Type.STRING } },
                    bullets: { type: Type.ARRAY, items: { type: Type.STRING } },
                  },
                  required: ['heading', 'paragraphs'],
                },
              },
            },
            required: ['title', 'subtitle', 'sections'],
          },
        },
      });
      return JSON.parse((res.text ?? '{}').trim()) as {
        title: string;
        subtitle: string;
        sections: Array<{
          heading: string;
          paragraphs: string[];
          bullets?: string[];
        }>;
      };
    },
  );

  if (format === 'docx') {
    const children: Paragraph[] = [
      new Paragraph({
        text: report.title || 'AI Document',
        heading: HeadingLevel.TITLE,
      }),
      new Paragraph({
        children: [
          new TextRun({
            text: report.subtitle || '',
            italics: true,
            color: '475569',
          }),
        ],
        spacing: { after: 280 },
      }),
    ];

    for (const sec of report.sections ?? []) {
      children.push(
        new Paragraph({
          text: sec.heading,
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 240, after: 120 },
        }),
      );
      for (const p of sec.paragraphs ?? []) {
        children.push(
          new Paragraph({
            text: p,
            spacing: { after: 140 },
          }),
        );
      }
      for (const b of sec.bullets ?? []) {
        children.push(
          new Paragraph({
            text: b,
            bullet: { level: 0 },
            spacing: { after: 80 },
          }),
        );
      }
    }

    const doc = new Document({
      sections: [{ children }],
    });
    const buf = await Packer.toBuffer(doc);
    const filename = `doc-${stamp}.docx`;
    const filePath = botStore.getDocFilePath(filename);
    fs.writeFileSync(filePath, buf);
    botStore.incrementFeatureUsage('documents');

    return {
      filename,
      filePath,
      url: `/api/docs/${filename}`,
      mimeType:
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      fileSizeBytes: buf.length,
      title: report.title || 'Word Document',
      previewSummary: `${report.sections?.length ?? 0}টি সেকশনসহ Word (.docx) ডকুমেন্ট তৈরি হয়েছে।`,
    };
  }

  // PDF generation via pdfkit
  const filename = `report-${stamp}.pdf`;
  const filePath = botStore.getDocFilePath(filename);
  await new Promise<void>((resolve, reject) => {
    const pdf = new PDFDocument({ margin: 50, size: 'A4' });
    const stream = fs.createWriteStream(filePath);
    pdf.pipe(stream);

    if (BENGALI_PDF_FONT) {
      try {
        pdf.font(BENGALI_PDF_FONT);
      } catch {
        // Fallback to standard Helvetica if font embedding fails
      }
    }

    pdf.fontSize(20).fillColor('#0F172A').text(report.title || 'AI Report');
    if (report.subtitle) {
      pdf.moveDown(0.3).fontSize(11).fillColor('#475569').text(report.subtitle);
    }
    pdf.moveDown(1);

    for (const sec of report.sections ?? []) {
      pdf.fontSize(14).fillColor('#0F766E').text(sec.heading);
      pdf.moveDown(0.3);
      for (const p of sec.paragraphs ?? []) {
        pdf.fontSize(11).fillColor('#1E293B').text(p, { align: 'left' });
        pdf.moveDown(0.35);
      }
      for (const b of sec.bullets ?? []) {
        pdf.fontSize(10.5).fillColor('#334155').text(`• ${b}`, { indent: 14 });
        pdf.moveDown(0.2);
      }
      pdf.moveDown(0.6);
    }

    pdf.end();
    stream.on('finish', () => resolve());
    stream.on('error', reject);
  });

  const stat = fs.statSync(filePath);
  botStore.incrementFeatureUsage('documents');

  return {
    filename,
    filePath,
    url: `/api/docs/${filename}`,
    mimeType: 'application/pdf',
    fileSizeBytes: stat.size,
    title: report.title || 'PDF Report',
    previewSummary: `${report.sections?.length ?? 0}টি সেকশনসহ প্রফেশনাল PDF তৈরি হয়েছে।`,
  };
}
