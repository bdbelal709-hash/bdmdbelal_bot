import { GoogleGenAI } from '@google/genai';
import { execFile } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { promisify } from 'node:util';
import { withGeminiRetry } from './aiAssistant.ts';
import { probeAudioDurationSec } from './audio.ts';
import {
  formatUserFriendlyError,
  isModelExhausted,
  isQuotaOrRateLimitError,
  markModelExhausted,
} from './gemini.ts';
import { botStore } from './store.ts';
import type { BotUser } from './types.ts';
import { chunkBanglaScript } from './voices.ts';

const execFileAsync = promisify(execFile);

function createSttClient(): GoogleGenAI {
  const apiKey = process.env.GEMINI_API_KEY?.trim();
  if (!apiKey) {
    throw new Error('GEMINI_API_KEY কনফিগার করা নেই।');
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

function guessAudioMime(filePath: string, provided?: string): string {
  if (provided && provided.startsWith('audio/')) return provided;
  const ext = path.extname(filePath).toLowerCase();
  if (ext === '.ogg' || ext === '.oga') return 'audio/ogg';
  if (ext === '.wav') return 'audio/wav';
  if (ext === '.m4a' || ext === '.mp4') return 'audio/mp4';
  if (ext === '.webm') return 'audio/webm';
  return 'audio/mp3';
}

/**
 * Speech-to-Text (STT) using gemini-3.5-transcribe.
 */
export async function transcribeAudioFile(params: {
  user: BotUser;
  filePath: string;
  mimeType?: string;
}): Promise<{ transcript: string; detectedSummary?: string }> {
  const buf = fs.readFileSync(params.filePath);
  if (buf.length > 18 * 1024 * 1024) {
    throw new Error('অডিও ফাইলটি 18MB-এর বেশি হওয়ায় সরাসরি ট্রান্সক্রাইব করা যায়নি।');
  }

  const ai = createSttClient();
  const mimeType = guessAudioMime(params.filePath, params.mimeType);
  const candidates = ['gemini-3.5-transcribe', 'gemini-4-hydrogen'];
  let lastErr: unknown;

  for (const model of candidates) {
    if (isModelExhausted(model)) continue;
    try {
      const res = await ai.models.generateContent({
        model,
        contents: {
          parts: [
            {
              inlineData: {
                mimeType,
                data: buf.toString('base64'),
              },
            },
            {
              text: 'Transcribe this audio verbatim in its original spoken language (Bangla, English, or mixed). Output clean, accurate text with proper punctuation.',
            },
          ],
        },
      });
      const text = (res.text ?? '').trim();
      if (text) {
        botStore.incrementFeatureUsage('voice');
        return { transcript: text };
      }
    } catch (err) {
      lastErr = err;
      if (isQuotaOrRateLimitError(err)) {
        markModelExhausted(model, err);
        continue;
      }
    }
  }

  botStore.logError('voice:stt', lastErr, params.user.id);
  throw new Error(formatUserFriendlyError(lastErr));
}

/**
 * Audio Noise Removal & Studio Loudness Enhancement via FFmpeg DSP chain.
 */
export async function enhanceAudioWithNoiseRemoval(params: {
  user: BotUser;
  inputPath: string;
}): Promise<{
  filename: string;
  filePath: string;
  url: string;
  durationSec: number;
  fileSizeBytes: number;
}> {
  const filename = `enh-audio-${Date.now()}.mp3`;
  const outPath = botStore.getAudioFilePath(filename);

  await execFileAsync('ffmpeg', [
    '-y',
    '-i',
    params.inputPath,
    '-af',
    'highpass=f=85,lowpass=f=9000,afftdn=nf=-24:tn=1,acompressor=threshold=-18dB:ratio=3:attack=5:release=60,loudnorm=I=-16:TP=-1.5:LRA=11',
    '-ar',
    '24000',
    '-ac',
    '1',
    '-c:a',
    'libmp3lame',
    '-b:a',
    '128k',
    outPath,
  ]);

  const stat = fs.statSync(outPath);
  const durationSec = await probeAudioDurationSec(outPath);
  botStore.incrementFeatureUsage('voice');

  return {
    filename,
    filePath: outPath,
    url: `/api/audio/${filename}`,
    durationSec,
    fileSizeBytes: stat.size,
  };
}

/**
 * English (plus Bangla) Free Neural / TTS Synthesizer returning MP3 path.
 */
export async function synthesizeMultilingualSpeechMp3(params: {
  text: string;
  lang: 'en' | 'bn';
  gender?: 'male' | 'female';
}): Promise<{
  filename: string;
  filePath: string;
  url: string;
  durationSec: number;
  fileSizeBytes: number;
}> {
  const cleanText = params.text.trim();
  if (!cleanText) throw new Error('অডিও তৈরির জন্য টেক্সট খালি।');

  const workDir = fs.mkdtempSync(path.join(os.tmpdir(), 'bv-ml-tts-'));
  try {
    let mp3Buf: Buffer | null = null;
    try {
      const { MsEdgeTTS, OUTPUT_FORMAT } = await import('msedge-tts');
      const tts = new MsEdgeTTS();
      const voiceName =
        params.lang === 'en'
          ? params.gender === 'male'
            ? 'en-US-GuyNeural'
            : 'en-US-AriaNeural'
          : params.gender === 'male'
            ? 'bn-BD-PradeepNeural'
            : 'bn-BD-NabanitaNeural';
      await Promise.race([
        tts.setMetadata(voiceName, OUTPUT_FORMAT.AUDIO_24KHZ_48KBITRATE_MONO_MP3),
        new Promise<never>((_, rej) =>
          setTimeout(() => rej(new Error('edge-timeout')), 3500),
        ),
      ]);
      const { audioStream } = tts.toStream(cleanText);
      const chunks: Buffer[] = [];
      for await (const ch of audioStream) {
        chunks.push(Buffer.isBuffer(ch) ? ch : Buffer.from(ch));
      }
      const combined = Buffer.concat(chunks);
      if (combined.length > 256) mp3Buf = combined;
    } catch {
      mp3Buf = null;
    }

    const filename = `tts-${params.lang}-${Date.now()}.mp3`;
    const outPath = botStore.getAudioFilePath(filename);

    if (mp3Buf) {
      fs.writeFileSync(outPath, mp3Buf);
    } else {
      const phrases = chunkBanglaScript(cleanText, 175);
      const segPaths: string[] = [];
      for (let i = 0; i < phrases.length; i++) {
        const url = `https://translate.google.com/translate_tts?ie=UTF-8&tl=${params.lang}&client=tw-ob&q=${encodeURIComponent(phrases[i])}`;
        const resp = await fetch(url, {
          headers: {
            'User-Agent':
              'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/126.0.0.0 Safari/537.36',
            Referer: 'https://translate.google.com/',
          },
          signal: AbortSignal.timeout(10_000),
        });
        if (resp.ok) {
          const ab = await resp.arrayBuffer();
          if (ab.byteLength > 200) {
            const p = path.join(workDir, `s_${i}.mp3`);
            fs.writeFileSync(p, Buffer.from(ab));
            segPaths.push(p);
          }
        }
      }
      if (segPaths.length === 0) {
        throw new Error('অডিও সিন্থেসিস করা যায়নি।');
      }
      if (segPaths.length === 1) {
        fs.copyFileSync(segPaths[0], outPath);
      } else {
        const listPath = path.join(workDir, 'list.txt');
        fs.writeFileSync(
          listPath,
          segPaths.map((s) => `file '${s.replace(/'/g, "'\\''")}'`).join('\n'),
        );
        await execFileAsync('ffmpeg', [
          '-y',
          '-f',
          'concat',
          '-safe',
          '0',
          '-i',
          listPath,
          '-c:a',
          'libmp3lame',
          '-b:a',
          '128k',
          outPath,
        ]);
      }
    }

    const stat = fs.statSync(outPath);
    const durationSec = await probeAudioDurationSec(outPath);
    botStore.incrementFeatureUsage('voice');
    return {
      filename,
      filePath: outPath,
      url: `/api/audio/${filename}`,
      durationSec,
      fileSizeBytes: stat.size,
    };
  } finally {
    fs.rmSync(workDir, { recursive: true, force: true });
  }
}

/**
 * Audio Translation: STT -> Translate via Gemini -> Re-speak MP3 in Target Language.
 */
export async function translateAudioToTargetLanguage(params: {
  user: BotUser;
  inputPath: string;
  mimeType?: string;
  targetLang: 'bn' | 'en';
}): Promise<{
  originalText: string;
  translatedText: string;
  audio: {
    filename: string;
    filePath: string;
    url: string;
    durationSec: number;
    fileSizeBytes: number;
  };
}> {
  const stt = await transcribeAudioFile({
    user: params.user,
    filePath: params.inputPath,
    mimeType: params.mimeType,
  });

  const translatedText = await withGeminiRetry(
    'voice:translate',
    params.user.id,
    async (ai, model) => {
      const targetName =
        params.targetLang === 'en' ? 'natural English' : 'natural fluent Bengali (Bangla)';
      const res = await ai.models.generateContent({
        model,
        contents: `Translate the following spoken transcript accurately into ${targetName}. Return ONLY the translated text:\n\n${stt.transcript}`,
      });
      return (res.text ?? stt.transcript).trim();
    },
  );

  const audio = await synthesizeMultilingualSpeechMp3({
    text: translatedText,
    lang: params.targetLang,
    gender: 'female',
  });

  return {
    originalText: stt.transcript,
    translatedText,
    audio,
  };
}
