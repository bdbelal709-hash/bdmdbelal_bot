import { execFile } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { promisify } from 'node:util';
import type {
  VideoAspectRatio,
  VideoMusicMood,
  VideoResolution,
  VideoScene,
  VideoTemplateInfo,
} from './types.ts';
import {
  generateAmbientMusicTrack,
  generateTemplateTitleCardImage,
} from './videoProviders.ts';

const execFileAsync = promisify(execFile);

const BENGALI_BOLD_FONT =
  '/usr/share/fonts/truetype/noto/NotoSansBengali-Bold.ttf';

export interface MediaInfo {
  durationSec: number;
  width: number;
  height: number;
  hasAudio: boolean;
}

export async function probeMediaInfo(filePath: string): Promise<MediaInfo> {
  try {
    const { stdout } = await execFileAsync('ffprobe', [
      '-v',
      'error',
      '-show_entries',
      'format=duration:stream=codec_type,width,height',
      '-of',
      'json',
      filePath,
    ]);
    const parsed = JSON.parse(stdout) as {
      format?: { duration?: string };
      streams?: Array<{
        codec_type?: string;
        width?: number;
        height?: number;
      }>;
    };
    const durationSec = Math.max(
      0.5,
      Number.parseFloat(parsed.format?.duration ?? '5') || 5,
    );
    const vStream = (parsed.streams ?? []).find(
      (s) => s.codec_type === 'video',
    );
    const aStream = (parsed.streams ?? []).find(
      (s) => s.codec_type === 'audio',
    );
    return {
      durationSec: Math.round(durationSec * 100) / 100,
      width: vStream?.width ?? 1280,
      height: vStream?.height ?? 720,
      hasAudio: Boolean(aStream),
    };
  } catch {
    return { durationSec: 5, width: 1280, height: 720, hasAudio: false };
  }
}

export function getTargetResolutionDims(
  aspectRatio: VideoAspectRatio,
  resolution: VideoResolution,
): { width: number; height: number } {
  if (aspectRatio === '9:16') {
    if (resolution === '4k') return { width: 2160, height: 3840 };
    if (resolution === '1080p') return { width: 1080, height: 1920 };
    return { width: 720, height: 1280 };
  }
  if (aspectRatio === '1:1') {
    if (resolution === '4k') return { width: 2160, height: 2160 };
    if (resolution === '1080p') return { width: 1080, height: 1080 };
    return { width: 720, height: 720 };
  }
  // 16:9 Landscape
  if (resolution === '4k') return { width: 3840, height: 2160 };
  if (resolution === '1080p') return { width: 1920, height: 1080 };
  return { width: 1280, height: 720 };
}

function getWorkingDimensions(aspectRatio: VideoAspectRatio): {
  width: number;
  height: number;
} {
  if (aspectRatio === '9:16') return { width: 720, height: 1280 };
  if (aspectRatio === '1:1') return { width: 720, height: 720 };
  return { width: 1280, height: 720 };
}

function formatAssTime(sec: number): string {
  const safe = Math.max(0, sec);
  const h = Math.floor(safe / 3600);
  const m = Math.floor((safe % 3600) / 60);
  const s = Math.floor(safe % 60);
  const cs = Math.min(99, Math.round((safe - Math.floor(safe)) * 100));
  return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}.${String(cs).padStart(2, '0')}`;
}

function wrapBanglaCaption(text: string, maxCharsPerLine: number): string {
  const words = text.replace(/\s+/g, ' ').trim().split(' ').filter(Boolean);
  const lines: string[] = [];
  let cur = '';
  for (const w of words) {
    if (!cur) {
      cur = w;
    } else if (cur.length + 1 + w.length <= maxCharsPerLine) {
      cur = `${cur} ${w}`;
    } else {
      lines.push(cur);
      cur = w;
    }
  }
  if (cur) lines.push(cur);
  // Keep up to 3 lines cleanly using ASS line break \N
  return lines.slice(0, 3).join('\\N');
}

export function buildAssSubtitlesFile(params: {
  scenes: VideoScene[];
  template: VideoTemplateInfo;
  width: number;
  height: number;
  aspectRatio: VideoAspectRatio;
  offsetSec: number;
  outputPath: string;
}): string | null {
  const scenesWithText = params.scenes.filter(
    (s) => (s.subtitleText || s.narrationBangla || '').trim().length > 0,
  );
  if (scenesWithText.length === 0) return null;

  const isPortrait = params.aspectRatio === '9:16';
  const fontSize = Math.round(
    params.height * (isPortrait ? 0.036 : 0.045),
  );
  const marginV = Math.round(params.height * (isPortrait ? 0.14 : 0.08));
  const marginLR = Math.round(params.width * 0.07);
  const maxCharsPerLine = isPortrait ? 24 : 42;

  let primaryColour = '&H00FFFFFF';
  let backColour = '&H96000000';
  let outlineColour = '&H00000000';
  let borderStyle = 3; // Boxed background for crisp readability
  let outline = 12;

  if (params.template.id === 'viral_reels') {
    primaryColour = '&H0048E6FF'; // Vivid warm gold/amber (ASS BGR)
    borderStyle = 1;
    outline = 5;
    outlineColour = '&H00080D16';
  } else if (params.template.id === 'news_fact') {
    primaryColour = '&H00FFFFFF';
    backColour = '&HCC1E1B99'; // Broadcast crimson-dark
    borderStyle = 3;
    outline = 14;
  } else if (params.template.id === 'emotional_story') {
    primaryColour = '&H00D8F3FF'; // Warm cream
    borderStyle = 1;
    outline = 4;
  }

  const header = `[Script Info]
ScriptType: v4.00+
PlayResX: ${params.width}
PlayResY: ${params.height}
WrapStyle: 0
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Default,${params.template.subtitleFont},${fontSize},${primaryColour},&H000000FF,${outlineColour},${backColour},1,0,0,0,100,100,0,0,${borderStyle},${outline},1,2,${marginLR},${marginLR},${marginV},1

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
`;

  const dialogueLines: string[] = [];
  for (const s of scenesWithText) {
    const start = (s.startSec ?? 0) + params.offsetSec;
    const end = (s.endSec ?? start + (s.durationSec ?? 4)) + params.offsetSec;
    if (end <= start) continue;

    const rawText = (s.subtitleText || s.narrationBangla).trim();
    // Break long scene captions into ~4s readable chunks if long
    const totalDur = end - start;
    const chunksNeeded = rawText.length > maxCharsPerLine * 3 ? Math.ceil(rawText.length / (maxCharsPerLine * 2)) : 1;

    if (chunksNeeded <= 1) {
      const wrapped = wrapBanglaCaption(rawText, maxCharsPerLine);
      dialogueLines.push(
        `Dialogue: 0,${formatAssTime(start)},${formatAssTime(end)},Default,,0,0,0,,${wrapped}`,
      );
    } else {
      const words = rawText.split(/\s+/).filter(Boolean);
      const wordsPerChunk = Math.max(1, Math.ceil(words.length / chunksNeeded));
      const chunkDur = totalDur / chunksNeeded;
      for (let c = 0; c < chunksNeeded; c++) {
        const subWords = words.slice(c * wordsPerChunk, (c + 1) * wordsPerChunk);
        if (subWords.length === 0) continue;
        const cStart = start + c * chunkDur;
        const cEnd = c === chunksNeeded - 1 ? end : start + (c + 1) * chunkDur;
        const wrapped = wrapBanglaCaption(subWords.join(' '), maxCharsPerLine);
        dialogueLines.push(
          `Dialogue: 0,${formatAssTime(cStart)},${formatAssTime(cEnd)},Default,,0,0,0,,${wrapped}`,
        );
      }
    }
  }

  fs.writeFileSync(
    params.outputPath,
    header + dialogueLines.join('\n') + '\n',
    'utf-8',
  );
  return params.outputPath;
}

function buildZoompanExpression(
  motion: VideoScene['motion'],
  totalFrames: number,
  width: number,
  height: number,
): string {
  const frames = Math.max(25, totalFrames);
  let zExpr = `min(zoom+0.0014,1.18)`;
  let xExpr = `iw/2-(iw/zoom/2)`;
  let yExpr = `ih/2-(ih/zoom/2)`;

  if (motion === 'zoom_out') {
    zExpr = `max(1.18-0.18*on/${frames},1.0)`;
  } else if (motion === 'pan_left') {
    zExpr = `1.12`;
    xExpr = `(iw-iw/zoom)*(1-on/${frames})`;
  } else if (motion === 'pan_right') {
    zExpr = `1.12`;
    xExpr = `(iw-iw/zoom)*(on/${frames})`;
  } else if (motion === 'pulse') {
    zExpr = `1.06+0.05*sin(on/18)`;
  }

  return `zoompan=z='${zExpr}':x='${xExpr}':y='${yExpr}':d=${frames}:s=${width}x${height}:fps=25`;
}

async function renderSingleSceneClip(params: {
  scene: VideoScene;
  durationSec: number;
  workWidth: number;
  workHeight: number;
  template: VideoTemplateInfo;
  outputPath: string;
}): Promise<void> {
  const { scene, durationSec, workWidth, workHeight, template, outputPath } =
    params;
  const dur = Math.max(1.0, durationSec);
  const fadeDur = Math.min(0.35, dur / 4);
  const fadeOutStart = Math.max(0.1, dur - fadeDur).toFixed(2);

  if (scene.assetType === 'video' && scene.assetPath && fs.existsSync(scene.assetPath)) {
    // Stock video B-roll: loop if shorter, crop/fill cleanly to target working aspect
    const vf =
      `scale=${workWidth}:${workHeight}:force_original_aspect_ratio=increase,` +
      `crop=${workWidth}:${workHeight},fps=25,${template.ffmpegColorFilter},` +
      `fade=t=in:st=0:d=${fadeDur.toFixed(2)},fade=t=out:st=${fadeOutStart}:d=${fadeDur.toFixed(2)},format=yuv420p`;

    await execFileAsync('ffmpeg', [
      '-y',
      '-stream_loop',
      '-1',
      '-i',
      scene.assetPath,
      '-t',
      dur.toFixed(2),
      '-an',
      '-vf',
      vf,
      '-c:v',
      'libx264',
      '-preset',
      'veryfast',
      '-crf',
      '22',
      outputPath,
    ]);
    return;
  }

  // Image asset -> Cinematic Zoompan motion
  const frames = Math.max(25, Math.round(dur * 25));
  const zp = buildZoompanExpression(scene.motion, frames, workWidth, workHeight);
  const vf =
    `scale=${workWidth * 2}:${workHeight * 2}:force_original_aspect_ratio=increase,` +
    `crop=${workWidth * 2}:${workHeight * 2},${zp},${template.ffmpegColorFilter},` +
    `fade=t=in:st=0:d=${fadeDur.toFixed(2)},fade=t=out:st=${fadeOutStart}:d=${fadeDur.toFixed(2)},format=yuv420p`;

  await execFileAsync('ffmpeg', [
    '-y',
    '-loop',
    '1',
    '-i',
    scene.assetPath!,
    '-t',
    dur.toFixed(2),
    '-vf',
    vf,
    '-c:v',
    'libx264',
    '-preset',
    'veryfast',
    '-crf',
    '22',
    outputPath,
  ]);
}

async function renderTitleCardClip(params: {
  imagePath: string;
  durationSec: number;
  workWidth: number;
  workHeight: number;
  outputPath: string;
}): Promise<void> {
  const frames = Math.max(25, Math.round(params.durationSec * 25));
  const fadeOut = Math.max(0.2, params.durationSec - 0.4).toFixed(2);
  const vf =
    `scale=${params.workWidth}:${params.workHeight},` +
    `zoompan=z='min(zoom+0.001,1.08)':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=${frames}:s=${params.workWidth}x${params.workHeight}:fps=25,` +
    `fade=t=in:st=0:d=0.4,fade=t=out:st=${fadeOut}:d=0.4,format=yuv420p`;

  await execFileAsync('ffmpeg', [
    '-y',
    '-loop',
    '1',
    '-i',
    params.imagePath,
    '-t',
    params.durationSec.toFixed(2),
    '-vf',
    vf,
    '-c:v',
    'libx264',
    '-preset',
    'veryfast',
    '-crf',
    '21',
    params.outputPath,
  ]);
}

function buildAtempoFilterChain(speedFactor: number): string {
  const filters: string[] = [];
  let rem = Math.max(0.25, Math.min(4.0, speedFactor));
  while (rem > 2.0) {
    filters.push('atempo=2.0');
    rem /= 2.0;
  }
  while (rem < 0.5) {
    filters.push('atempo=0.5');
    rem /= 0.5;
  }
  filters.push(`atempo=${rem.toFixed(4)}`);
  return filters.join(',');
}

function escapeFilterPath(p: string): string {
  return p.replace(/\\/g, '/').replace(/:/g, '\\:').replace(/'/g, "\\'");
}

function escapeDrawtextText(t: string): string {
  return t
    .replace(/\\/g, '\\\\')
    .replace(/:/g, '\\:')
    .replace(/'/g, "\\'")
    .replace(/%/g, '\\%');
}

/**
 * Renders full AI generated video from scenes + voiceover audio (Modes 1, 2, 3).
 */
export async function assembleScenesVideo(params: {
  workDir: string;
  outputMp4Path: string;
  title: string;
  scenes: VideoScene[];
  narrationAudioPath: string;
  totalAudioDurationSec: number;
  template: VideoTemplateInfo;
  aspectRatio: VideoAspectRatio;
  resolution: VideoResolution;
  musicMood: VideoMusicMood;
  includeSubtitles: boolean;
  includeIntroOutro: boolean;
  watermarkText?: string;
  onProgress?: (pct: number, text: string) => Promise<void> | void;
}): Promise<{ durationSec: number; fileSizeBytes: number }> {
  const {
    workDir,
    outputMp4Path,
    title,
    scenes,
    narrationAudioPath,
    totalAudioDurationSec,
    template,
    aspectRatio,
    resolution,
    musicMood,
    includeSubtitles,
    includeIntroOutro,
    watermarkText,
    onProgress,
  } = params;

  const workDims = getWorkingDimensions(aspectRatio);
  const finalDims = getTargetResolutionDims(aspectRatio, resolution);
  const introDur = includeIntroOutro ? 1.8 : 0;
  const outroDur = includeIntroOutro ? 1.8 : 0;

  const clipPaths: string[] = [];

  if (includeIntroOutro) {
    const introImg = path.join(workDir, 'intro.png');
    const introClip = path.join(workDir, 'clip_intro.mp4');
    await generateTemplateTitleCardImage({
      title,
      subtitle: template.nameBn,
      aspectRatio,
      template,
      outputPath: introImg,
    });
    await renderTitleCardClip({
      imagePath: introImg,
      durationSec: introDur,
      workWidth: workDims.width,
      workHeight: workDims.height,
      outputPath: introClip,
    });
    clipPaths.push(introClip);
  }

  for (let i = 0; i < scenes.length; i++) {
    const sc = scenes[i];
    const dur = Math.max(1.2, sc.durationSec ?? 4);
    const clipOut = path.join(
      workDir,
      `clip_scene_${String(i).padStart(4, '0')}.mp4`,
    );
    await renderSingleSceneClip({
      scene: sc,
      durationSec: dur,
      workWidth: workDims.width,
      workHeight: workDims.height,
      template,
      outputPath: clipOut,
    });
    clipPaths.push(clipOut);

    if (onProgress) {
      const pct = Math.round(62 + ((i + 1) / Math.max(1, scenes.length)) * 22);
      await onProgress(pct, `সিন রেন্ডারিং (${i + 1}/${scenes.length})`);
    }
  }

  if (includeIntroOutro) {
    const outroImg = path.join(workDir, 'outro.png');
    const outroClip = path.join(workDir, 'clip_outro.mp4');
    await generateTemplateTitleCardImage({
      title: 'দেখার জন্য ধন্যবাদ',
      subtitle: title,
      aspectRatio,
      template,
      outputPath: outroImg,
    });
    await renderTitleCardClip({
      imagePath: outroImg,
      durationSec: outroDur,
      workWidth: workDims.width,
      workHeight: workDims.height,
      outputPath: outroClip,
    });
    clipPaths.push(outroClip);
  }

  const concatTxtPath = path.join(workDir, 'video_concat.txt');
  fs.writeFileSync(
    concatTxtPath,
    clipPaths.map((p) => `file '${p.replace(/'/g, "'\\''")}'`).join('\n'),
    'utf-8',
  );

  const stitchedSilentPath = path.join(workDir, 'stitched_silent.mp4');
  await execFileAsync('ffmpeg', [
    '-y',
    '-f',
    'concat',
    '-safe',
    '0',
    '-i',
    concatTxtPath,
    '-c',
    'copy',
    stitchedSilentPath,
  ]);

  const totalVideoDur = introDur + totalAudioDurationSec + outroDur;
  let musicPath: string | null = null;
  if (musicMood !== 'none') {
    if (onProgress) await onProgress(87, 'ব্যাকগ্রাউন্ড মিউজিক ও অডিও সিঙ্ক হচ্ছে...');
    musicPath = await generateAmbientMusicTrack({
      mood: musicMood,
      durationSec: totalVideoDur,
      outputPath: path.join(workDir, 'bg_music.m4a'),
    });
  }

  let assPath: string | null = null;
  if (includeSubtitles) {
    assPath = buildAssSubtitlesFile({
      scenes,
      template,
      width: finalDims.width,
      height: finalDims.height,
      aspectRatio,
      offsetSec: introDur,
      outputPath: path.join(workDir, 'captions.ass'),
    });
  }

  if (onProgress) {
    await onProgress(92, `${resolution.toUpperCase()} চূড়ান্ত ভিডিও রেন্ডার হচ্ছে...`);
  }

  const videoFilters: string[] = [
    `scale=${finalDims.width}:${finalDims.height}:flags=lanczos`,
  ];
  if (assPath && fs.existsSync(assPath)) {
    videoFilters.push(`ass='${escapeFilterPath(assPath)}'`);
  }
  if (watermarkText?.trim()) {
    const safeWm = escapeDrawtextText(watermarkText.trim().slice(0, 32));
    const wmSize = Math.max(18, Math.round(finalDims.height * 0.025));
    videoFilters.push(
      `drawtext=fontfile='${BENGALI_BOLD_FONT}':text='${safeWm}':fontsize=${wmSize}:fontcolor=white@0.68:x=w-tw-28:y=26:box=1:boxcolor=black@0.35:boxborderw=8`,
    );
  }
  videoFilters.push('format=yuv420p');

  const delayMs = Math.round(introDur * 1000);
  const ffmpegArgs: string[] = ['-y', '-i', stitchedSilentPath, '-i', narrationAudioPath];

  let filterComplex = `[0:v]${videoFilters.join(',')}[vout];`;
  if (musicPath && fs.existsSync(musicPath)) {
    ffmpegArgs.push('-i', musicPath);
    filterComplex +=
      `[1:a]aresample=44100,adelay=${delayMs}|${delayMs},apad=pad_dur=${(outroDur + 0.5).toFixed(2)},volume=1.0[voice];` +
      `[2:a]aresample=44100,volume=0.14[bgm];` +
      `[voice][bgm]amix=inputs=2:duration=first:dropout_transition=2,dynaudnorm[aout]`;
  } else {
    filterComplex += `[1:a]aresample=44100,adelay=${delayMs}|${delayMs},apad=pad_dur=${(outroDur + 0.5).toFixed(2)},dynaudnorm[aout]`;
  }

  await execFileAsync('ffmpeg', [
    ...ffmpegArgs,
    '-filter_complex',
    filterComplex,
    '-map',
    '[vout]',
    '-map',
    '[aout]',
    '-t',
    totalVideoDur.toFixed(2),
    '-c:v',
    'libx264',
    '-preset',
    resolution === '4k' ? 'fast' : 'medium',
    '-crf',
    '20',
    '-c:a',
    'aac',
    '-b:a',
    '192k',
    '-movflags',
    '+faststart',
    outputMp4Path,
  ]);

  const finalInfo = await probeMediaInfo(outputMp4Path);
  const stat = fs.statSync(outputMp4Path);
  return {
    durationSec: finalInfo.durationSec,
    fileSizeBytes: stat.size,
  };
}

/**
 * Mode 4: Edit User's Uploaded Video with Speed Sync, AI Voiceover,
 * Aspect Ratio Conversion, Color Grading, Bangla Subtitles, Music & Watermark.
 */
export async function renderEditedUserVideo(params: {
  workDir: string;
  inputVideoPath: string;
  outputMp4Path: string;
  title: string;
  scenes: VideoScene[];
  narrationAudioPath?: string;
  targetDurationSec: number;
  videoSpeed: number; // 0 = Auto-Fit to narration duration, else 0.5..2.0
  originalAudioMode: 'mute' | 'duck' | 'keep';
  template: VideoTemplateInfo;
  aspectRatio: VideoAspectRatio;
  resolution: VideoResolution;
  musicMood: VideoMusicMood;
  includeSubtitles: boolean;
  watermarkText?: string;
  onProgress?: (pct: number, text: string) => Promise<void> | void;
}): Promise<{ durationSec: number; fileSizeBytes: number }> {
  const {
    workDir,
    inputVideoPath,
    outputMp4Path,
    scenes,
    narrationAudioPath,
    targetDurationSec,
    videoSpeed,
    originalAudioMode,
    template,
    aspectRatio,
    resolution,
    musicMood,
    includeSubtitles,
    watermarkText,
    onProgress,
  } = params;

  const srcInfo = await probeMediaInfo(inputVideoPath);
  const finalDims = getTargetResolutionDims(aspectRatio, resolution);

  let effectiveSpeed = videoSpeed;
  if (effectiveSpeed <= 0) {
    // Auto-Fit speed seamlessly if within 0.65x..1.75x, otherwise 1.0x with seamless loop/trim
    const ratio = srcInfo.durationSec / Math.max(1, targetDurationSec);
    if (ratio >= 0.65 && ratio <= 1.75) {
      effectiveSpeed = Math.round(ratio * 100) / 100;
    } else {
      effectiveSpeed = 1.0;
    }
  }
  effectiveSpeed = Math.max(0.4, Math.min(2.5, effectiveSpeed));

  const adjustedSrcDur = srcInfo.durationSec / effectiveSpeed;
  const finalDur =
    narrationAudioPath && targetDurationSec > 0
      ? Math.max(2, targetDurationSec)
      : Math.max(2, adjustedSrcDur);

  const needLoop = adjustedSrcDur + 0.25 < finalDur;

  if (onProgress) {
    await onProgress(72, 'ভিডিও স্পিড, রেশিও ও কালার গ্রেডিং হচ্ছে...');
  }

  let assPath: string | null = null;
  if (includeSubtitles && scenes.length > 0) {
    assPath = buildAssSubtitlesFile({
      scenes,
      template,
      width: finalDims.width,
      height: finalDims.height,
      aspectRatio,
      offsetSec: 0,
      outputPath: path.join(workDir, 'edit_captions.ass'),
    });
  }

  let musicPath: string | null = null;
  if (musicMood !== 'none') {
    musicPath = await generateAmbientMusicTrack({
      mood: musicMood,
      durationSec: finalDur,
      outputPath: path.join(workDir, 'edit_bgm.m4a'),
    });
  }

  const ptsFactor = (1 / effectiveSpeed).toFixed(4);
  const postEffects: string[] = [template.ffmpegColorFilter];
  if (assPath && fs.existsSync(assPath)) {
    postEffects.push(`ass='${escapeFilterPath(assPath)}'`);
  }
  if (watermarkText?.trim()) {
    const safeWm = escapeDrawtextText(watermarkText.trim().slice(0, 32));
    const wmSize = Math.max(18, Math.round(finalDims.height * 0.025));
    postEffects.push(
      `drawtext=fontfile='${BENGALI_BOLD_FONT}':text='${safeWm}':fontsize=${wmSize}:fontcolor=white@0.72:x=w-tw-28:y=26:box=1:boxcolor=black@0.35:boxborderw=8`,
    );
  }
  postEffects.push('format=yuv420p');

  // Blurred atmospheric backdrop + sharp scaled foreground preserves subject in any aspect ratio!
  const videoChain =
    `[0:v]setpts=${ptsFactor}*PTS,fps=25,split=2[bg][fg];` +
    `[bg]scale=${finalDims.width}:${finalDims.height}:force_original_aspect_ratio=increase,crop=${finalDims.width}:${finalDims.height},boxblur=16:2[bgblur];` +
    `[fg]scale=${finalDims.width}:${finalDims.height}:force_original_aspect_ratio=decrease[fgscaled];` +
    `[bgblur][fgscaled]overlay=(W-w)/2:(H-h)/2,${postEffects.join(',')}[vout]`;

  const ffmpegArgs: string[] = ['-y'];
  if (needLoop) {
    ffmpegArgs.push('-stream_loop', '-1');
  }
  ffmpegArgs.push('-i', inputVideoPath);

  let nextIdx = 1;
  let narrationIdx = -1;
  if (narrationAudioPath && fs.existsSync(narrationAudioPath)) {
    ffmpegArgs.push('-i', narrationAudioPath);
    narrationIdx = nextIdx++;
  }

  let musicIdx = -1;
  if (musicPath && fs.existsSync(musicPath)) {
    ffmpegArgs.push('-i', musicPath);
    musicIdx = nextIdx++;
  }

  const audioInputs: string[] = [];
  const audioSteps: string[] = [];

  if (narrationIdx >= 0) {
    audioSteps.push(`[${narrationIdx}:a]aresample=44100,volume=1.0[vo]`);
    audioInputs.push('[vo]');
  }

  if (srcInfo.hasAudio && originalAudioMode !== 'mute') {
    const origVol = originalAudioMode === 'duck' ? 0.18 : 0.9;
    const atempo = buildAtempoFilterChain(effectiveSpeed);
    audioSteps.push(
      `[0:a]aresample=44100,${atempo},volume=${origVol}[origa]`,
    );
    audioInputs.push('[origa]');
  }

  if (musicIdx >= 0) {
    audioSteps.push(`[${musicIdx}:a]aresample=44100,volume=0.14[bgm]`);
    audioInputs.push('[bgm]');
  }

  if (audioInputs.length === 0) {
    // Add silent stereo audio track so output MP4 always has valid audio stream
    ffmpegArgs.push('-f', 'lavfi', '-i', `anullsrc=r=44100:cl=stereo`);
    const nullIdx = nextIdx++;
    audioSteps.push(`[${nullIdx}:a]volume=0.0[aout]`);
  } else if (audioInputs.length === 1) {
    audioSteps.push(`${audioInputs[0]}dynaudnorm[aout]`);
  } else {
    audioSteps.push(
      `${audioInputs.join('')}amix=inputs=${audioInputs.length}:duration=first:dropout_transition=2,dynaudnorm[aout]`,
    );
  }

  if (onProgress) {
    await onProgress(90, `${resolution.toUpperCase()} চূড়ান্ত এডিটেড ভিডিও তৈরি হচ্ছে...`);
  }

  const filterComplex = `${videoChain};${audioSteps.join(';')}`;

  await execFileAsync('ffmpeg', [
    ...ffmpegArgs,
    '-filter_complex',
    filterComplex,
    '-map',
    '[vout]',
    '-map',
    '[aout]',
    '-t',
    finalDur.toFixed(2),
    '-c:v',
    'libx264',
    '-preset',
    resolution === '4k' ? 'fast' : 'medium',
    '-crf',
    '20',
    '-c:a',
    'aac',
    '-b:a',
    '192k',
    '-movflags',
    '+faststart',
    outputMp4Path,
  ]);

  const outInfo = await probeMediaInfo(outputMp4Path);
  const stat = fs.statSync(outputMp4Path);
  return {
    durationSec: outInfo.durationSec,
    fileSizeBytes: stat.size,
  };
}
