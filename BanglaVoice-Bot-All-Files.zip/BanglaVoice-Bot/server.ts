import 'dotenv/config';
import express from 'express';
import fs from 'node:fs';
import path from 'node:path';
import {
  runAssistantChat,
  runCodingAssistant,
  runWebResearch,
} from './server/aiAssistant.ts';
import {
  normalizeTelegramChannelTarget,
  sendTestChannelNotification,
} from './server/adminNotify.ts';
import { buildBotSourcePackageZip } from './server/botExport.ts';
import { generateStructuredDocument } from './server/documentAssistant.ts';
import { generateCoverArtwork, prepareBanglaScript } from './server/gemini.ts';
import {
  generateAiImage,
  generateGraphicDesignPng,
} from './server/imageStudio.ts';
import { voiceJobQueue } from './server/jobs.ts';
import { botStore } from './server/store.ts';
import {
  processBotInteraction,
  telegramConnector,
} from './server/telegram.ts';
import type {
  AssistantModuleId,
  VideoAspectRatio,
  VideoMode,
  VideoMusicMood,
  VideoResolution,
  VideoTemplateId,
} from './server/types.ts';
import {
  VIDEO_TEMPLATES,
  generateBanglaVideoScriptFromPrompt,
} from './server/videoDirector.ts';
import { videoJobQueue } from './server/videoJobs.ts';
import { probeMediaInfo } from './server/videoRenderer.ts';
import { getOrGenerateVoiceDemoMp3 } from './server/voiceDemo.ts';
import { VOICE_CATALOG, chunkBanglaScript } from './server/voices.ts';

const PORT = Number(process.env.PORT) || 3000;
const isProduction = process.env.NODE_ENV === 'production';

async function createServer() {
  const app = express();
  app.use(express.json({ limit: '10mb' }));

  // Health check (also used for UptimeRobot / Render 24/7 Keep-Alive)
  app.get('/api/health', (_req, res) => {
    const cfg = botStore.getConfig();
    res.json({
      ok: true,
      bot: cfg.telegramBotUsername || null,
      mode: cfg.telegramMode,
      uptimeSec: Math.round(process.uptime()),
    });
  });

  // Voice catalog
  app.get('/api/voices', (_req, res) => {
    res.json({ voices: VOICE_CATALOG });
  });

  // Dedicated voice demo MP3 endpoint ("ডেভলপার বেলাল হোসেন" showcase per voice)
  app.get('/api/voices/:id/demo.mp3', async (req, res) => {
    try {
      const demo = await getOrGenerateVoiceDemoMp3(req.params.id);
      if (!fs.existsSync(demo.filePath)) {
        res.status(404).json({ error: 'Demo audio not found' });
        return;
      }
      res.setHeader('Content-Type', 'audio/mpeg');
      res.setHeader('Cache-Control', 'public, max-age=3600');
      fs.createReadStream(demo.filePath).pipe(res);
    } catch (err) {
      res.status(500).json({
        error:
          err instanceof Error
            ? err.message
            : 'ভয়েস ডেমো তৈরি করতে সমস্যা হয়েছে।',
      });
    }
  });

  // Serve generated MP3 audio files
  app.get('/api/audio/:filename', (req, res) => {
    const filePath = botStore.getAudioFilePath(req.params.filename);
    if (!fs.existsSync(filePath)) {
      res.status(404).json({ error: 'Audio file not found' });
      return;
    }
    const download = req.query.download === '1';
    res.setHeader('Content-Type', 'audio/mpeg');
    if (download) {
      res.setHeader(
        'Content-Disposition',
        `attachment; filename="${path.basename(filePath)}"`,
      );
    }
    fs.createReadStream(filePath).pipe(res);
  });

  // Job status polling (for live long-duration voice generation)
  app.get('/api/jobs/:id', (req, res) => {
    const job = botStore.getJobById(req.params.id);
    if (!job) {
      res.status(404).json({ error: 'Job not found' });
      return;
    }
    const generation = job.generationId
      ? botStore.getGenerationById(job.generationId)
      : undefined;
    res.json({ job, generation });
  });

  app.get('/api/jobs', (_req, res) => {
    res.json({ jobs: botStore.listJobs(30) });
  });

  // -------------------------------------------------------------------------
  // AI Automatic Professional Video Generator & Editor APIs
  // -------------------------------------------------------------------------

  app.get('/api/video/templates', (_req, res) => {
    res.json({ templates: VIDEO_TEMPLATES });
  });

  app.get('/api/videos/:filename', (req, res) => {
    const filePath = botStore.getVideoFilePath(req.params.filename);
    if (!fs.existsSync(filePath)) {
      res.status(404).json({ error: 'Video file not found' });
      return;
    }
    const download = req.query.download === '1';
    if (download) {
      res.setHeader(
        'Content-Disposition',
        `attachment; filename="${path.basename(filePath)}"`,
      );
    }
    res.sendFile(filePath);
  });

  // Serve generated/edited AI images
  app.get('/api/images/:filename', (req, res) => {
    const safeName = path.basename(req.params.filename);
    const filePath = botStore.getImageFilePath(safeName);
    if (!fs.existsSync(filePath)) {
      res.status(404).json({ error: 'Image file not found' });
      return;
    }
    const ext = path.extname(safeName).toLowerCase();
    const mime =
      ext === '.jpg' || ext === '.jpeg'
        ? 'image/jpeg'
        : ext === '.webp'
          ? 'image/webp'
          : 'image/png';
    res.setHeader('Content-Type', mime);
    if (req.query.download === '1') {
      res.setHeader(
        'Content-Disposition',
        `attachment; filename="${safeName}"`,
      );
    }
    fs.createReadStream(filePath).pipe(res);
  });

  // Serve generated AI documents and code archives
  app.get('/api/docs/:filename', (req, res) => {
    const safeName = path.basename(req.params.filename);
    const filePath = botStore.getDocFilePath(safeName);
    if (!fs.existsSync(filePath)) {
      res.status(404).json({ error: 'Document file not found' });
      return;
    }
    const ext = path.extname(safeName).toLowerCase();
    const mimeMap: Record<string, string> = {
      '.pdf': 'application/pdf',
      '.docx':
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      '.xlsx':
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      '.pptx':
        'application/vnd.openxmlformats-officedocument.presentationml.presentation',
      '.zip': 'application/zip',
      '.py': 'text/x-python; charset=utf-8',
      '.html': 'text/html; charset=utf-8',
      '.js': 'application/javascript; charset=utf-8',
      '.ts': 'text/typescript; charset=utf-8',
      '.json': 'application/json; charset=utf-8',
      '.csv': 'text/csv; charset=utf-8',
      '.md': 'text/markdown; charset=utf-8',
      '.txt': 'text/plain; charset=utf-8',
    };
    res.setHeader('Content-Type', mimeMap[ext] ?? 'application/octet-stream');
    if (req.query.download === '1') {
      res.setHeader(
        'Content-Disposition',
        `attachment; filename="${safeName}"`,
      );
    }
    fs.createReadStream(filePath).pipe(res);
  });

  app.post(
    '/api/video/upload-binary',
    express.raw({ type: '*/*', limit: '80mb' }),
    async (req, res) => {
      try {
        const buf = req.body as Buffer;
        if (!Buffer.isBuffer(buf) || buf.length === 0) {
          res.status(400).json({ error: 'ফাইল খালি বা পাওয়া যায়নি।' });
          return;
        }
        const rawHeaderName =
          typeof req.headers['x-filename'] === 'string'
            ? decodeURIComponent(req.headers['x-filename'])
            : 'upload.bin';
        const ext = path.extname(rawHeaderName) || '.bin';
        const safeBase = `up_${Date.now()}_${Math.random().toString(36).slice(2, 6)}${ext}`;
        const destPath = botStore.getUploadFilePath(safeBase);
        fs.writeFileSync(destPath, buf);
        const mediaInfo = await probeMediaInfo(destPath);
        res.json({
          filename: safeBase,
          originalName: rawHeaderName,
          filePath: destPath,
          fileSizeBytes: buf.length,
          mediaInfo,
        });
      } catch (err) {
        res.status(500).json({
          error:
            err instanceof Error ? err.message : 'ফাইল আপলোড ব্যর্থ হয়েছে।',
        });
      }
    },
  );

  app.post('/api/video/prompt-to-script', async (req, res) => {
    try {
      const { prompt, templateId, durationHintSec } = req.body as {
        prompt?: string;
        templateId?: VideoTemplateId;
        durationHintSec?: number;
      };
      if (!prompt?.trim()) {
        res.status(400).json({ error: 'অনুগ্রহ করে ভিডিও প্রম্পট লিখুন।' });
        return;
      }
      const result = await generateBanglaVideoScriptFromPrompt({
        prompt: prompt.trim(),
        templateId,
        durationHintSec,
      });
      res.json(result);
    } catch (err) {
      res.status(500).json({
        error:
          err instanceof Error
            ? err.message
            : 'প্রম্পট থেকে স্ক্রিপ্ট তৈরি করা যায়নি।',
      });
    }
  });

  app.post('/api/video/generate', async (req, res) => {
    try {
      const body = req.body as {
        userId?: string;
        mode: VideoMode;
        title?: string;
        prompt?: string;
        script?: string;
        templateId?: VideoTemplateId;
        aspectRatio?: VideoAspectRatio;
        resolution?: VideoResolution;
        videoSpeed?: number;
        voiceId?: string;
        voiceSpeed?: number;
        voicePitch?: number;
        musicMood?: VideoMusicMood;
        originalAudioMode?: 'mute' | 'duck' | 'keep';
        includeSubtitles?: boolean;
        includeIntroOutro?: boolean;
        watermarkText?: string;
        uploadedVideoFilename?: string;
        uploadedAudioFilename?: string;
      };

      const user = body.userId
        ? (botStore.getUserById(body.userId) ??
          botStore.getOrCreateUser({ telegramId: 'sim_1001' }))
        : botStore.getOrCreateUser({ telegramId: 'sim_1001' });

      const uploadedVideoPath = body.uploadedVideoFilename
        ? botStore.getUploadFilePath(body.uploadedVideoFilename)
        : undefined;
      const uploadedAudioPath = body.uploadedAudioFilename
        ? botStore.getUploadFilePath(body.uploadedAudioFilename)
        : undefined;

      const result = await videoJobQueue.enqueueVideoJob({
        user,
        mode: body.mode || 'prompt',
        title: body.title,
        prompt: body.prompt,
        script: body.script,
        templateId: body.templateId,
        aspectRatio: body.aspectRatio,
        resolution: body.resolution,
        videoSpeed: body.videoSpeed,
        voiceId: body.voiceId,
        voiceSpeed: body.voiceSpeed,
        voicePitch: body.voicePitch,
        musicMood: body.musicMood,
        originalAudioMode: body.originalAudioMode,
        includeSubtitles: body.includeSubtitles,
        includeIntroOutro: body.includeIntroOutro,
        watermarkText: body.watermarkText,
        uploadedVideoPath,
        uploadedAudioPath,
        source: 'studio',
      });

      if (!result.ok || !result.job) {
        res.status(400).json({
          error: result.error || 'ভিডিও জেনারেশন শুরু করা যায়নি।',
        });
        return;
      }

      res.json({
        job: result.job,
        user: botStore.getUserById(user.id),
      });
    } catch (err) {
      res.status(500).json({
        error:
          err instanceof Error
            ? err.message
            : 'ভিডিও জেনারেশন রিকোয়েস্ট ব্যর্থ হয়েছে।',
      });
    }
  });

  app.get('/api/video/jobs', (req, res) => {
    const userId =
      typeof req.query.userId === 'string' ? req.query.userId : undefined;
    const limit = Number(req.query.limit) || 30;
    res.json({ jobs: botStore.listVideoJobs(userId, limit) });
  });

  app.get('/api/video/jobs/:id', (req, res) => {
    const job = botStore.getVideoJobById(req.params.id);
    if (!job) {
      res.status(404).json({ error: 'Video job not found' });
      return;
    }
    res.json({ job });
  });

  // Bot Simulator endpoint (uses identical Telegram Bot state machine + background job queue)
  app.post('/api/bot/simulate', async (req, res) => {
    try {
      const { userId, text, callbackData } = (req.body ?? {}) as {
        userId?: string;
        text?: string;
        callbackData?: string;
      };

      const user = userId
        ? (botStore.getUserById(userId) ??
          botStore.getOrCreateUser({ telegramId: 'sim_1001' }))
        : botStore.getOrCreateUser({ telegramId: 'sim_1001' });

      const result = await processBotInteraction({
        user,
        text,
        callbackData,
        source: 'simulator',
      });

      res.json({
        messages: result.messages,
        user: result.user,
        queuedJob: result.queuedJob,
        queuedVideoJob: result.queuedVideoJob,
      });
    } catch (err) {
      res.status(500).json({
        error: err instanceof Error ? err.message : 'Simulator error',
      });
    }
  });

  // Smart English / Mixed -> Natural Bangla Preview Before Generate
  app.post('/api/studio/preview', async (req, res) => {
    try {
      const { userId, script, voiceId } = req.body as {
        userId?: string;
        script: string;
        voiceId?: string;
      };

      const user = userId
        ? (botStore.getUserById(userId) ??
          botStore.getOrCreateUser({ telegramId: 'sim_1001' }))
        : botStore.getOrCreateUser({ telegramId: 'sim_1001' });

      const targetVoiceId = voiceId ?? user.selectedVoiceId;
      const eligibility = botStore.canUserGenerate(user, targetVoiceId);
      if (!eligibility.ok) {
        res.status(400).json({ error: eligibility.reason });
        return;
      }

      const raw = (script ?? '').trim();
      const maxChars = botStore.getUserMaxChars(user);
      if (maxChars > 0 && raw.length > maxChars) {
        res.status(400).json({
          error: `আপনার স্ক্রিপ্টটি ${raw.length} অক্ষরের, যা আপনার প্ল্যানের সর্বোচ্চ সীমা (${maxChars} অক্ষর) অতিক্রম করেছে।`,
        });
        return;
      }

      const cfg = botStore.getConfig();
      const prep = await prepareBanglaScript(
        raw,
        cfg.strictBanglaOnly,
        cfg.autoNormalizeBangla,
        cfg.smartEnglishToBangla,
      );

      if (!prep.valid || !prep.spokenScript.trim()) {
        res.status(400).json({
          error: prep.reason || 'অনুগ্রহ করে বাংলা বা ইংরেজিতে একটি বৈধ স্ক্রিপ্ট দিন।',
        });
        return;
      }

      const banglaScript = prep.spokenScript.trim();
      const chunks = chunkBanglaScript(banglaScript, 650);
      const estimatedMinutes = Math.max(
        0.2,
        Math.round((banglaScript.length / 800) * 10) / 10,
      );

      res.json({
        detectedLanguage: prep.detectedLanguage,
        originalScript: raw,
        banglaScript,
        estimatedChunks: chunks.length,
        estimatedMinutes,
        voiceCost: botStore.getVoiceEffectiveCost(targetVoiceId),
      });
    } catch (err) {
      res.status(500).json({
        error:
          err instanceof Error
            ? err.message
            : 'বাংলা প্রিভিউ তৈরি করা যায়নি।',
      });
    }
  });

  // Direct Studio Voice Synthesis (Background Job Queue -> unlimited duration)
  app.post('/api/studio/generate', async (req, res) => {
    try {
      const {
        userId,
        script,
        originalScript,
        preConvertedBangla,
        voiceId,
        speed,
        pitch,
      } = req.body as {
        userId?: string;
        script: string;
        originalScript?: string;
        preConvertedBangla?: boolean;
        voiceId: string;
        speed?: number;
        pitch?: number;
      };

      const user = userId
        ? (botStore.getUserById(userId) ??
          botStore.getOrCreateUser({ telegramId: 'sim_1001' }))
        : botStore.getOrCreateUser({ telegramId: 'sim_1001' });

      if (voiceId) {
        botStore.updateUser(user.id, {
          selectedVoiceId: voiceId,
          speed: speed ?? user.speed,
          pitch: pitch ?? user.pitch,
        });
      }

      const result = await voiceJobQueue.enqueueVoiceJob({
        user,
        script: script ?? '',
        originalScript,
        preConvertedBangla,
        source: 'studio',
        voiceId,
        speed,
        pitch,
      });

      if (!result.ok || !result.job) {
        res.status(400).json({
          error: result.error || 'ভয়েস তৈরি করা সম্ভব হয়নি।',
        });
        return;
      }

      res.json({
        job: result.job,
        user: botStore.getUserById(user.id),
      });
    } catch (err) {
      res.status(500).json({
        error: err instanceof Error ? err.message : 'Voice generation failed',
      });
    }
  });

  // Regenerate existing clip via Background Job Queue
  app.post('/api/studio/regenerate/:id', async (req, res) => {
    try {
      const prev = botStore.getGenerationById(req.params.id);
      if (!prev) {
        res.status(404).json({ error: 'পূর্বের জেনারেশনটি পাওয়া যায়নি।' });
        return;
      }
      const user =
        botStore.getUserById(prev.userId) ??
        botStore.getOrCreateUser({ telegramId: 'sim_1001' });

      const { voiceId, speed, pitch } = (req.body ?? {}) as {
        voiceId?: string;
        speed?: number;
        pitch?: number;
      };

      const result = await voiceJobQueue.enqueueVoiceJob({
        user,
        script: prev.script,
        source: 'studio',
        voiceId: voiceId ?? prev.voiceId,
        speed: speed ?? prev.speed,
        pitch: pitch ?? prev.pitch,
      });

      if (!result.ok || !result.job) {
        res.status(400).json({
          error: result.error || 'পুনরায় জেনারেট করা যায়নি।',
        });
        return;
      }

      res.json({
        job: result.job,
        user: botStore.getUserById(user.id),
      });
    } catch (err) {
      res.status(500).json({
        error: err instanceof Error ? err.message : 'Regeneration failed',
      });
    }
  });

  // Generation History
  app.get('/api/history', (req, res) => {
    const userId =
      typeof req.query.userId === 'string' ? req.query.userId : undefined;
    const limit = Number(req.query.limit) || 50;
    res.json({ generations: botStore.listGenerations(userId, limit) });
  });

  // User Payment Request submission (Web Studio / Confirmed flow with Auto TrxID Verify)
  app.post('/api/payments/request', async (req, res) => {
    const { userId, amount, method, accountNumber, referenceNote } = req.body as {
      userId?: string;
      amount: number;
      method?: string;
      accountNumber?: string;
      referenceNote: string;
    };
    const user = userId
      ? botStore.getUserById(userId)
      : botStore.getOrCreateUser({ telegramId: 'sim_1001' });
    if (!user) {
      res.status(404).json({ error: 'User not found' });
      return;
    }
    if (!amount || amount <= 0 || !referenceNote?.trim()) {
      res.status(400).json({ error: 'সঠিক পরিমাণ এবং ট্রানজেকশন আইডি (TrxID) লিখুন।' });
      return;
    }

    try {
      const result = botStore.submitPaymentRequestAndAutoVerify({
        user,
        amount,
        method: method?.trim() || 'bKash / Nagad',
        accountNumber: accountNumber?.trim() || undefined,
        referenceNote: referenceNote.trim(),
      });

      const cfg = botStore.getConfig();
      if (cfg.telegramBotToken) {
        if (result.autoApproved) {
          if (!result.payment.telegramId.startsWith('sim_')) {
            await fetch(
              `https://api.telegram.org/bot${cfg.telegramBotToken}/sendMessage`,
              {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  chat_id: result.payment.telegramId,
                  text: `⚡ আপনার পেমেন্ট (${result.payment.id}) স্বয়ংক্রিয়ভাবে ভেরিফাই হয়েছে! ব্যালেন্সে +৳${result.payment.amount} যুক্ত হয়েছে।`,
                }),
              },
            ).catch(() => {});
          }
          for (const tgId of botStore.listAdminTelegramIds()) {
            if (tgId.startsWith('sim_')) continue;
            await fetch(
              `https://api.telegram.org/bot${cfg.telegramBotToken}/sendMessage`,
              {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  chat_id: tgId,
                  text:
                    `⚡ **অটো-ভেরিফাইড পেমেন্ট (SMS Match)**\n` +
                    `👤 ${result.payment.userName} · ৳${result.payment.amount}\n` +
                    `🧾 ${result.payment.referenceNote}`,
                }),
              },
            ).catch(() => {});
          }
        } else {
          const adminNotice =
            `🔔 **নতুন পেমেন্ট রিকোয়েস্ট (Web Wallet)**\n\n` +
            `👤 ইউজার: ${result.payment.userName} (${result.payment.telegramId})\n` +
            `💳 মাধ্যম: ${result.payment.method}${result.payment.accountNumber ? ` (${result.payment.accountNumber})` : ''}\n` +
            `💰 পরিমাণ: ৳${result.payment.amount}\n` +
            `🧾 রেফারেন্স: ${result.payment.referenceNote}\n` +
            `🆔 রিকোয়েস্ট আইডি: ${result.payment.id}`;

          for (const tgId of botStore.listAdminTelegramIds()) {
            if (tgId.startsWith('sim_')) continue;
            await fetch(
              `https://api.telegram.org/bot${cfg.telegramBotToken}/sendMessage`,
              {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                  chat_id: tgId,
                  text: adminNotice,
                  reply_markup: {
                    inline_keyboard: [
                      [
                        {
                          text: `✅ Approve ৳${result.payment.amount}`,
                          callback_data: `adm:pay_ok:${result.payment.id}`,
                        },
                        {
                          text: '❌ Reject',
                          callback_data: `adm:pay_no:${result.payment.id}`,
                        },
                      ],
                    ],
                  },
                }),
              },
            ).catch(() => {});
          }
        }
      }

      res.json({
        payment: result.payment,
        autoApproved: result.autoApproved,
        user: result.user,
      });
    } catch (err) {
      res.status(400).json({
        error: err instanceof Error ? err.message : 'পেমেন্ট রিকোয়েস্ট ব্যর্থ হয়েছে।',
      });
    }
  });

  // Incoming Mobile Banking SMS Webhook (Android SMS Forwarder / MacroDroid / Tasker)
  app.post('/api/payments/sms-webhook', async (req, res) => {
    const cfg = botStore.getConfig();
    const providedSecret =
      (typeof req.headers['x-webhook-secret'] === 'string'
        ? req.headers['x-webhook-secret']
        : '') ||
      (typeof req.body?.secret === 'string' ? req.body.secret : '') ||
      (typeof req.query.secret === 'string' ? req.query.secret : '');

    if (!cfg.smsWebhookSecret || providedSecret.trim() !== cfg.smsWebhookSecret) {
      res.status(401).json({ error: 'Invalid SMS webhook secret' });
      return;
    }

    const body = (req.body ?? {}) as Record<string, unknown>;
    const rawText = String(
      body.message ?? body.text ?? body.msg ?? body.body ?? body.sms ?? '',
    ).trim();

    if (!rawText && !body.trxId) {
      res.status(400).json({ error: 'SMS text or trxId is required' });
      return;
    }

    try {
      const result = botStore.ingestIncomingPaymentSms({
        rawText: rawText || `TrxID ${String(body.trxId)} Tk ${String(body.amount ?? '')}`,
        method: typeof body.method === 'string' ? body.method : undefined,
        amount:
          typeof body.amount === 'number'
            ? body.amount
            : typeof body.amount === 'string'
              ? Number.parseFloat(body.amount)
              : undefined,
        trxId: typeof body.trxId === 'string' ? body.trxId : undefined,
        sender: typeof body.sender === 'string' ? body.sender : undefined,
      });

      if (
        result.matchedPayment &&
        cfg.telegramBotToken &&
        !result.matchedPayment.telegramId.startsWith('sim_')
      ) {
        await fetch(
          `https://api.telegram.org/bot${cfg.telegramBotToken}/sendMessage`,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              chat_id: result.matchedPayment.telegramId,
              text: `⚡ আপনার পেমেন্ট (${result.matchedPayment.id}) স্বয়ংক্রিয়ভাবে ভেরিফাই হয়েছে! ব্যালেন্সে +৳${result.matchedPayment.amount} যুক্ত হয়েছে।`,
            }),
          },
        ).catch(() => {});
      }

      res.json({
        ok: true,
        sms: result.sms,
        duplicateSms: result.duplicateSms,
        autoMatchedPaymentId: result.matchedPayment?.id ?? null,
      });
    } catch (err) {
      res.status(400).json({
        error: err instanceof Error ? err.message : 'SMS parsing failed',
      });
    }
  });

  // Studio Cover Artwork Generator
  app.post('/api/artwork/generate', async (req, res) => {
    try {
      const { prompt, aspectRatio, imageSize, model } = req.body as {
        prompt: string;
        aspectRatio?: string;
        imageSize?: '1K' | '2K' | '4K';
        model?: 'gemini-3-pro-image-preview' | 'gemini-nano-banana-2.1';
      };

      if (!prompt?.trim()) {
        res.status(400).json({ error: 'Prompt is required.' });
        return;
      }

      const result = await generateCoverArtwork({
        prompt: prompt.trim(),
        aspectRatio: aspectRatio || '1:1',
        imageSize: imageSize || '1K',
        model: model || 'gemini-3-pro-image-preview',
      });

      res.json(result);
    } catch (err) {
      res.status(400).json({
        error:
          err instanceof Error
            ? err.message
            : 'Artwork generation failed. Paid API key may be required for studio image models.',
      });
    }
  });

  // -------------------------------------------------------------------------
  // Web Assistant Helper Endpoints (All-in-One AI Chat, Image, Research, Docs)
  // -------------------------------------------------------------------------

  app.post('/api/assistant/chat', async (req, res) => {
    try {
      const { userId, message, mode } = (req.body ?? {}) as {
        userId?: string;
        message?: string;
        mode?: 'chat' | 'coding';
      };
      if (!message?.trim()) {
        res.status(400).json({ error: 'অনুগ্রহ করে একটি প্রশ্ন বা প্রম্পট লিখুন।' });
        return;
      }
      const user = userId
        ? (botStore.getUserById(userId) ??
          botStore.getOrCreateUser({ telegramId: 'sim_1001' }))
        : botStore.getOrCreateUser({ telegramId: 'sim_1001' });

      if (mode === 'coding') {
        const out = await runCodingAssistant({
          user,
          prompt: message.trim(),
          mode: 'write',
        });
        res.json(out);
        return;
      }
      const out = await runAssistantChat({
        user,
        message: message.trim(),
      });
      res.json(out);
    } catch (err) {
      res.status(500).json({
        error: err instanceof Error ? err.message : 'Assistant chat failed',
      });
    }
  });

  app.post('/api/assistant/image', async (req, res) => {
    try {
      const { userId, prompt, aspectRatio, designKind } = (req.body ?? {}) as {
        userId?: string;
        prompt?: string;
        aspectRatio?: '1:1' | '16:9' | '9:16';
        designKind?: 'logo' | 'banner' | 'poster' | 'thumbnail';
      };
      if (!prompt?.trim()) {
        res.status(400).json({ error: 'অনুগ্রহ করে ইমেজ বা ডিজাইনের বিবরণ লিখুন।' });
        return;
      }
      const user = userId
        ? (botStore.getUserById(userId) ??
          botStore.getOrCreateUser({ telegramId: 'sim_1001' }))
        : botStore.getOrCreateUser({ telegramId: 'sim_1001' });

      if (designKind) {
        const asset = await generateGraphicDesignPng({
          user,
          designKind,
          prompt: prompt.trim(),
        });
        res.json({ asset });
        return;
      }
      const asset = await generateAiImage({
        user,
        prompt: prompt.trim(),
        aspectRatio: aspectRatio ?? '1:1',
      });
      res.json({ asset });
    } catch (err) {
      res.status(500).json({
        error: err instanceof Error ? err.message : 'Image generation failed',
      });
    }
  });

  app.post('/api/assistant/research', async (req, res) => {
    try {
      const { query, userId } = (req.body ?? {}) as {
        query?: string;
        userId?: string;
      };
      if (!query?.trim()) {
        res.status(400).json({ error: 'অনুগ্রহ করে রিসার্চ টপিক বা URL দিন।' });
        return;
      }
      const user = userId
        ? (botStore.getUserById(userId) ??
          botStore.getOrCreateUser({ telegramId: 'sim_1001' }))
        : botStore.getOrCreateUser({ telegramId: 'sim_1001' });
      const result = await runWebResearch({ queryOrUrl: query.trim(), user });
      res.json(result);
    } catch (err) {
      res.status(500).json({
        error: err instanceof Error ? err.message : 'Web research failed',
      });
    }
  });

  app.post('/api/assistant/document', async (req, res) => {
    try {
      const { format, prompt, userId } = (req.body ?? {}) as {
        format?: 'docx' | 'xlsx' | 'pptx' | 'pdf';
        prompt?: string;
        userId?: string;
      };
      if (!prompt?.trim()) {
        res.status(400).json({ error: 'ডকুমেন্ট তৈরির নির্দেশনা লিখুন।' });
        return;
      }
      const user = userId
        ? (botStore.getUserById(userId) ??
          botStore.getOrCreateUser({ telegramId: 'sim_1001' }))
        : botStore.getOrCreateUser({ telegramId: 'sim_1001' });
      const doc = await generateStructuredDocument({
        format: format ?? 'pdf',
        topicPrompt: prompt.trim(),
        user,
      });
      res.json({ document: doc });
    } catch (err) {
      res.status(500).json({
        error: err instanceof Error ? err.message : 'Document generation failed',
      });
    }
  });

  // -------------------------------------------------------------------------
  // Admin Panel APIs
  // -------------------------------------------------------------------------

  app.get('/api/admin/overview', (_req, res) => {
    res.json({
      stats: botStore.getDashboardStats(),
      users: botStore.listUsers(),
      config: botStore.getPublicConfig(),
      recentGenerations: botStore.listGenerations(undefined, 25),
      paymentRequests: botStore.listPaymentRequests(),
      incomingPaymentSms: botStore.listIncomingPaymentSms(40),
      transactions: botStore.listTransactions(undefined, 50),
      jobs: botStore.listJobs(20),
      videoJobs: botStore.listVideoJobs(undefined, 20),
      errorLogs: botStore.getErrorLogs(40),
    });
  });

  app.post('/api/admin/features', (req, res) => {
    const body = (req.body ?? {}) as {
      enabledFeatures?: Partial<Record<AssistantModuleId, boolean>>;
      defaultChatModel?: 'gemini-4-hydrogen' | 'gemini-3.1-flash-lite';
    };
    const current = botStore.getConfig();
    const validModules: AssistantModuleId[] = [
      'chat',
      'image',
      'video',
      'voice',
      'documents',
      'coding',
      'research',
      'memory',
    ];
    const nextFeatures: Record<AssistantModuleId, boolean> = {
      chat: current.enabledFeatures?.chat ?? true,
      image: current.enabledFeatures?.image ?? true,
      video: current.enabledFeatures?.video ?? true,
      voice: current.enabledFeatures?.voice ?? true,
      documents: current.enabledFeatures?.documents ?? true,
      coding: current.enabledFeatures?.coding ?? true,
      research: current.enabledFeatures?.research ?? true,
      memory: current.enabledFeatures?.memory ?? true,
    };
    if (body.enabledFeatures && typeof body.enabledFeatures === 'object') {
      for (const mod of validModules) {
        if (typeof body.enabledFeatures[mod] === 'boolean') {
          nextFeatures[mod] = body.enabledFeatures[mod]!;
        }
      }
    }
    const patch: {
      enabledFeatures: Record<AssistantModuleId, boolean>;
      defaultChatModel?: 'gemini-4-hydrogen' | 'gemini-3.1-flash-lite';
    } = {
      enabledFeatures: nextFeatures,
    };
    if (
      body.defaultChatModel === 'gemini-4-hydrogen' ||
      body.defaultChatModel === 'gemini-3.1-flash-lite'
    ) {
      patch.defaultChatModel = body.defaultChatModel;
    }
    botStore.updateConfig(patch);
    res.json({
      config: botStore.getPublicConfig(),
      stats: botStore.getDashboardStats(),
    });
  });

  app.post('/api/admin/errors/clear', (_req, res) => {
    botStore.clearErrorLogs();
    res.json({
      ok: true,
      errorLogs: [],
      stats: botStore.getDashboardStats(),
    });
  });

  // Admin manual SMS paste / sync for automatic TrxID matching
  app.post('/api/admin/payments/ingest-sms', async (req, res) => {
    const { rawText, method, amount, trxId } = req.body as {
      rawText?: string;
      method?: string;
      amount?: number;
      trxId?: string;
    };
    if (!rawText?.trim() && !trxId?.trim()) {
      res.status(400).json({ error: 'bKash / Nagad / Rocket SMS টেক্সট পেস্ট করুন।' });
      return;
    }
    try {
      const result = botStore.ingestIncomingPaymentSms({
        rawText: rawText?.trim() || `TrxID ${trxId} Tk ${amount ?? ''}`,
        method,
        amount,
        trxId,
      });

      const cfg = botStore.getConfig();
      if (
        result.matchedPayment &&
        cfg.telegramBotToken &&
        !result.matchedPayment.telegramId.startsWith('sim_')
      ) {
        await fetch(
          `https://api.telegram.org/bot${cfg.telegramBotToken}/sendMessage`,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              chat_id: result.matchedPayment.telegramId,
              text: `⚡ আপনার পেমেন্ট (${result.matchedPayment.id}) স্বয়ংক্রিয়ভাবে ভেরিফাই হয়েছে! ব্যালেন্সে +৳${result.matchedPayment.amount} যুক্ত হয়েছে।`,
            }),
          },
        ).catch(() => {});
      }

      res.json(result);
    } catch (err) {
      res.status(400).json({
        error: err instanceof Error ? err.message : 'SMS পার্স করা যায়নি।',
      });
    }
  });

  app.post('/api/admin/payments/regenerate-secret', (_req, res) => {
    const smsWebhookSecret = botStore.regenerateSmsWebhookSecret();
    res.json({ smsWebhookSecret, config: botStore.getPublicConfig() });
  });

  app.post('/api/admin/users', (req, res) => {
    const { firstName, username, tier } = req.body as {
      firstName?: string;
      username?: string;
      tier?: 'free' | 'premium';
    };
    const tgId = `sim_${Math.floor(1000 + Math.random() * 9000)}`;
    const user = botStore.getOrCreateUser({
      telegramId: tgId,
      username: username?.trim() || `user_${tgId}`,
      firstName: firstName?.trim() || 'নতুন ব্যবহারকারী',
    });
    if (tier === 'premium') {
      botStore.activatePremium(user.id);
    }
    res.json({ user: botStore.getUserById(user.id) });
  });

  app.patch('/api/admin/users/:id', (req, res) => {
    const {
      tier,
      status,
      customDailyLimit,
      customCharLimit,
      dailyCount,
      role,
    } = req.body as {
      tier?: 'free' | 'premium';
      status?: 'active' | 'banned';
      customDailyLimit?: number | null;
      customCharLimit?: number | null;
      dailyCount?: number;
      role?: 'user' | 'admin';
    };

    if (tier === 'premium') {
      botStore.activatePremium(req.params.id);
    } else if (tier === 'free') {
      botStore.deactivatePremium(req.params.id);
    }

    if (role === 'admin') {
      botStore.authorizeTelegramAdmin(req.params.id);
    } else if (role === 'user') {
      botStore.revokeTelegramAdmin(req.params.id);
    }

    const updated = botStore.updateUser(req.params.id, {
      ...(status !== undefined ? { status } : {}),
      ...(customDailyLimit !== undefined ? { customDailyLimit } : {}),
      ...(customCharLimit !== undefined ? { customCharLimit } : {}),
      ...(dailyCount !== undefined ? { dailyCount } : {}),
    });
    if (!updated) {
      res.status(404).json({ error: 'User not found' });
      return;
    }
    res.json({ user: updated });
  });

  app.post('/api/admin/users/:id/balance', (req, res) => {
    try {
      const { amountDelta, description } = req.body as {
        amountDelta: number;
        description?: string;
      };
      if (typeof amountDelta !== 'number' || Number.isNaN(amountDelta) || amountDelta === 0) {
        res.status(400).json({ error: 'Valid non-zero amount is required' });
        return;
      }
      const result = botStore.adjustBalance({
        userId: req.params.id,
        amountDelta,
        type: amountDelta > 0 ? 'admin_add' : 'admin_deduct',
        description:
          description?.trim() ||
          `অ্যাডমিন প্যানেল সমন্বয় (${amountDelta > 0 ? '+' : ''}৳${amountDelta})`,
      });
      res.json(result);
    } catch (err) {
      res.status(404).json({
        error: err instanceof Error ? err.message : 'Balance adjustment failed',
      });
    }
  });

  app.post('/api/admin/payments/:id/review', async (req, res) => {
    try {
      const { decision, reviewedBy } = req.body as {
        decision: 'approved' | 'rejected';
        reviewedBy?: string;
      };
      const result = botStore.reviewPaymentRequest({
        paymentId: req.params.id,
        decision,
        reviewedBy: reviewedBy || 'Web Admin',
      });

      // Notify Telegram user in real time if they have a real Telegram ID
      const cfg = botStore.getConfig();
      if (
        cfg.telegramBotToken &&
        !result.payment.telegramId.startsWith('sim_')
      ) {
        const msgText =
          decision === 'approved'
            ? `✅ আপনার পেমেন্ট (${result.payment.id}) অনুমোদিত হয়েছে! ব্যালেন্সে +৳${result.payment.amount} যুক্ত হয়েছে।`
            : `❌ আপনার পেমেন্ট রিকোয়েস্ট (${result.payment.id}) বাতিল করা হয়েছে।`;
        await fetch(
          `https://api.telegram.org/bot${cfg.telegramBotToken}/sendMessage`,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              chat_id: result.payment.telegramId,
              text: msgText,
            }),
          },
        ).catch(() => {});
      }

      res.json(result);
    } catch (err) {
      res.status(400).json({
        error: err instanceof Error ? err.message : 'Payment review failed',
      });
    }
  });

  app.get('/api/admin/export-bot-zip', async (_req, res) => {
    try {
      const archive = await buildBotSourcePackageZip();
      res.download(archive.zipPath, archive.filename);
    } catch (err) {
      res.status(500).json({
        error: err instanceof Error ? err.message : 'Bot source export failed',
      });
    }
  });

  app.patch('/api/admin/config', (req, res) => {
    const body = req.body as Record<string, unknown>;
    const allowedPatch: Record<string, unknown> = {};

    if (typeof body.freeDailyLimit === 'number') {
      allowedPatch.freeDailyLimit = Math.max(0, Math.min(100000, body.freeDailyLimit));
    }
    if (typeof body.premiumDailyLimit === 'number') {
      allowedPatch.premiumDailyLimit = Math.max(0, Math.min(100000, body.premiumDailyLimit));
    }
    if (typeof body.maxScriptCharsFree === 'number') {
      allowedPatch.maxScriptCharsFree = Math.max(0, Math.min(500000, body.maxScriptCharsFree));
    }
    if (typeof body.maxScriptCharsPremium === 'number') {
      allowedPatch.maxScriptCharsPremium = Math.max(0, Math.min(500000, body.maxScriptCharsPremium));
    }
    if (typeof body.voiceGenerationCost === 'number') {
      allowedPatch.voiceGenerationCost = Math.max(0, Math.min(10000, body.voiceGenerationCost));
    }
    if (body.voiceCosts && typeof body.voiceCosts === 'object' && !Array.isArray(body.voiceCosts)) {
      const sanitizedCosts: Record<string, number> = {};
      for (const [k, v] of Object.entries(body.voiceCosts as Record<string, unknown>)) {
        if (typeof v === 'number' && !Number.isNaN(v) && v >= 0) {
          sanitizedCosts[k] = Math.min(10000, v);
        }
      }
      allowedPatch.voiceCosts = sanitizedCosts;
    }
    if (Array.isArray(body.paymentAccounts)) {
      allowedPatch.paymentAccounts = body.paymentAccounts
        .filter((item): item is Record<string, unknown> => Boolean(item && typeof item === 'object'))
        .map((item, idx) => ({
          id:
            typeof item.id === 'string' && item.id.trim()
              ? item.id.trim()
              : `payacc-${Date.now()}-${idx}`,
          method:
            typeof item.method === 'string' && item.method.trim()
              ? item.method.trim()
              : 'bKash',
          accountNumber:
            typeof item.accountNumber === 'string' ? item.accountNumber.trim() : '',
          accountType:
            typeof item.accountType === 'string' && item.accountType.trim()
              ? item.accountType.trim()
              : 'Personal (Send Money)',
          note: typeof item.note === 'string' ? item.note.trim() : '',
          enabled: typeof item.enabled === 'boolean' ? item.enabled : true,
        }))
        .filter((acc) => acc.accountNumber.length > 0);
    }
    if (typeof body.paymentInstructions === 'string') {
      allowedPatch.paymentInstructions = body.paymentInstructions.trim();
    }
    if (typeof body.autoVerifyPayments === 'boolean') {
      allowedPatch.autoVerifyPayments = body.autoVerifyPayments;
    }
    if (typeof body.premiumMembershipDays === 'number') {
      allowedPatch.premiumMembershipDays = Math.max(1, Math.min(3650, body.premiumMembershipDays));
    }
    if (typeof body.adminClaimCode === 'string' && body.adminClaimCode.trim()) {
      allowedPatch.adminClaimCode = body.adminClaimCode.trim();
    }
    if (Array.isArray(body.adminTelegramIds)) {
      allowedPatch.adminTelegramIds = body.adminTelegramIds
        .map(String)
        .map((s) => s.trim())
        .filter(Boolean);
    }
    if (typeof body.strictBanglaOnly === 'boolean') {
      allowedPatch.strictBanglaOnly = body.strictBanglaOnly;
    }
    if (typeof body.autoNormalizeBangla === 'boolean') {
      allowedPatch.autoNormalizeBangla = body.autoNormalizeBangla;
    }
    if (typeof body.smartEnglishToBangla === 'boolean') {
      allowedPatch.smartEnglishToBangla = body.smartEnglishToBangla;
    }
    if (
      body.ttsModel === 'gemini-3.8-flash-lite-tts' ||
      body.ttsModel === 'gemini-3.8-flash-tts'
    ) {
      allowedPatch.ttsModel = body.ttsModel;
    }
    if (typeof body.telegramBotToken === 'string' && body.telegramBotToken.trim()) {
      allowedPatch.telegramBotToken = body.telegramBotToken.trim();
    }
    if (typeof body.videoGenerationCost === 'number') {
      allowedPatch.videoGenerationCost = Math.max(0, Math.min(10000, body.videoGenerationCost));
    }
    if (typeof body.pexelsApiKey === 'string') {
      allowedPatch.pexelsApiKey = body.pexelsApiKey.trim();
    }
    if (
      body.visualProviderMode === 'auto' ||
      body.visualProviderMode === 'ai_image' ||
      body.visualProviderMode === 'stock_video' ||
      body.visualProviderMode === 'cinematic_motion'
    ) {
      allowedPatch.visualProviderMode = body.visualProviderMode;
    }
    if (typeof body.notificationChannelId === 'string') {
      allowedPatch.notificationChannelId = normalizeTelegramChannelTarget(
        body.notificationChannelId,
      );
    }

    botStore.updateConfig(allowedPatch);
    res.json({ config: botStore.getPublicConfig() });
  });

  app.post('/api/admin/telegram/connect', async (req, res) => {
    try {
      const { token, action, webhookUrl } = req.body as {
        token?: string;
        action: 'start_polling' | 'stop' | 'verify' | 'set_webhook';
        webhookUrl?: string;
      };

      if (action === 'stop') {
        telegramConnector.stopPolling();
        res.json({ config: botStore.getPublicConfig() });
        return;
      }

      const activeToken = token?.trim() || botStore.getConfig().telegramBotToken;
      if (!activeToken) {
        res.status(400).json({ error: 'Telegram Bot Token প্রদান করুন।' });
        return;
      }

      botStore.updateConfig({ telegramBotToken: activeToken });

      if (action === 'verify') {
        const me = await telegramConnector.verifyToken(activeToken);
        botStore.updateConfig({ telegramBotUsername: me.username });
        res.json({ bot: me, config: botStore.getPublicConfig() });
        return;
      }

      if (action === 'set_webhook') {
        const targetUrl =
          webhookUrl?.trim() ||
          (process.env.APP_URL
            ? `${process.env.APP_URL.replace(/\/$/, '')}/api/telegram/webhook`
            : '');
        const me = await telegramConnector.setWebhook(targetUrl);
        res.json({ bot: me, webhookUrl: targetUrl, config: botStore.getPublicConfig() });
        return;
      }

      const me = await telegramConnector.startPolling();
      res.json({ bot: me, config: botStore.getPublicConfig() });
    } catch (err) {
      res.status(400).json({
        error:
          err instanceof Error
            ? err.message
            : 'Telegram Bot সংযোগ ব্যর্থ হয়েছে।',
      });
    }
  });

  app.post('/api/admin/telegram/test-channel', async (req, res) => {
    try {
      const { channelId } = (req.body ?? {}) as { channelId?: string };
      const normalized =
        typeof channelId === 'string'
          ? normalizeTelegramChannelTarget(channelId)
          : botStore.getConfig().notificationChannelId;

      if (typeof channelId === 'string') {
        botStore.updateConfig({ notificationChannelId: normalized });
      }

      if (!normalized) {
        res.json({
          ok: true,
          cleared: true,
          channelId: '',
          config: botStore.getPublicConfig(),
        });
        return;
      }

      const testRes = await sendTestChannelNotification(normalized);
      if (!testRes.ok) {
        res.status(400).json({
          error: testRes.error || 'চ্যানেলে মেসেজ পাঠানো যায়নি।',
          config: botStore.getPublicConfig(),
        });
        return;
      }

      res.json({
        ok: true,
        channelId: testRes.channelId,
        config: botStore.getPublicConfig(),
      });
    } catch (err) {
      res.status(500).json({
        error: err instanceof Error ? err.message : 'Channel test failed',
      });
    }
  });

  // Real Telegram Webhook endpoint (awaits processing before 200 OK so Cloud Run/serverless allocates CPU)
  app.post('/api/telegram/webhook', async (req, res) => {
    try {
      await Promise.race([
        telegramConnector.handleTelegramUpdate(req.body),
        new Promise((resolve) => setTimeout(resolve, 14000)),
      ]);
    } catch (e) {
      console.error('Webhook handling error:', e);
    }
    res.sendStatus(200);
  });

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: false, watch: null },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distDir = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distDir));
    app.get('/{*splat}', (_req, res) => {
      res.sendFile(path.join(distDir, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`BanglaVoice Bot Studio running on http://0.0.0.0:${PORT}`);
    const cfg = botStore.getConfig();
    const shouldAutoPoll =
      Boolean(cfg.telegramBotToken) &&
      (cfg.telegramMode === 'polling' ||
        (cfg.telegramMode === 'stopped' && !cfg.telegramBotUsername));
    if (shouldAutoPoll) {
      telegramConnector.startPolling().catch((err) => {
        console.error('Auto-start Telegram polling failed:', err);
      });
    } else {
      voiceJobQueue.resumePendingJobs();
    }
  });
}

createServer();
